
--Note KMIF_KMB_INF table KMIF_KMB_REF_ID auto id generation need to dropped
 
CREATE SEQUENCE "KMIF_SEQUENCE"    
         AS DECIMAL(15)                     
           START WITH 1               
           INCREMENT BY 1                   
           MINVALUE 1                       
           MAXVALUE 999999999999999         
           NO CYCLE                         
           CACHE 20                         
           NO ORDER;     
    
ALTER TABLE "PYEI_PYEVT_EVT" ADD COLUMN PYEI_CMPG_CD CHAR(8);
           
// ***********************************************************
// This is a Bean class
// "LocalKomEvents" is the name of the Bean which will be implemented
// ***********************************************************

package KomEvents;

import Domains.*;
import ErrorMessages.*;
import MCExtClasses.*;
import javax.ejb.Timer;
import javax.ejb.*;
import java.util.*;

import org.w3c.dom.*;
import java.lang.*;
import java.sql.*;
import KomEvents.wcKomEventsMABuyerList;
import KomEvents.wcKomEventsSalesEntList;
import KomEvents.wcKomEventsTransECList;
import KomEvents.wcKomReplDtls;
import KomEvents.MbsoKomEventsCEEInfo;
import KomEvents.wcKomEventsTransCgeList;
import KomEvents.wcKomReplList;
import KomEvents.wcKomCEEDtls;
import KomEvents.MbsoKomEventsAdvSchdInfo;
import KomEvents.wcKomEventsTransIntdList;
import KomEvents.wcKomEventsMASellerIntdList;
import KomEvents.wcKomEventsRetroVatEvtList;
import KomEvents.MbsoKomEventsKommbInfo;
import KomEvents.MbsoKomEventsVATRetroInfo;
import KomEvents.wcKomEventsBrokersNoteEvntList;
import KomEvents.wcKomEventsUnvestCommList;
import KomEvents.wcKomEventsCGEIntdList;
import KomEvents.wcKomEventsTransECIntdList;
import KomEvents.MbsoKomEventsISEDetails;
import KomEvents.MbsoKomEventsElmntInfo;
import KomEvents.MbsoKomEventsPreTransIntdInfo;
import KomEvents.wcKomEventsCommCGEList;
import KomEvents.wcKomEventsCommElmntHstryList;
import KomEvents.MbsoKomEventsSalsECSum;
import KomEvents.PmoKomEventsProcessor;
import KomEvents.MbsoKomEventsPreTransInfo;
import KomEvents.wcKomEventsCommIntdHstryList;
import KomEvents.wcKomEventsCteIntdList;
import KomEvents.wcKomEventsFundCommIntdList;
import KomEvents.MbsoKomEventsServEntSum;
import KomEvents.wcKomEventsUnvestCommDtls;
import KomEvents.wcKomEventsSalesEntIntdDetails;
import KomEvents.MbsoKomEventsErrWaitStore;
import KomEvents.MbsoKomEventsCGEInfo;
import KomEvents.wcKomEventsMABuyerIntdList;
import KomEvents.wcKomEventsPayKommbList;
import KomEvents.wcKomEventsSalesEntIntdList;
import KomEvents.MbsoKomEventsCommRetroInfo;
import KomEvents.wcKomEventsMACrgeIntdList;
import KomEvents.wcKomEventsRetroEvntList;
import KomEvents.MbsoKomEventsCommEnqContext;
import KomEvents.wcKomEventsCommSchdHstryList;
import KomEvents.wcKomEventsMACgeIntdList;
import KomEvents.wcKomEventsECCrgeIntdList;
import KomEvents.MbsoKomEventsSellPrctSum;
import KomEvents.MbsoKomEventsIntdCommInfo;
import KomEvents.MbsoKomEventsCXEInfo;
import KomEvents.wcKomEventsCommScoreList;
import KomEvents.MbsoKomEventsUnvestCommProjDtls;
import KomEvents.MbsoKomEventsPolicyInfo;
import KomEvents.wcKomEventsMASellerList;
import KomEvents.wcKomEventsPayElmntList;
import KomEvents.wcKomEventsErrWaitList;
import KomEvents.wcKomEventsCommEIPList;
import Domains.Direction;
import KomEvents.MbsoKomEventsErrWaitStoreListSearch;
import KomEvents.MbsoKomEventsErrWaitStoreIntd;
import KomEvents.MbsoKomEventsPymtInfo;
import KomEvents.wcKomEventsCommPolicyList;
import KomEvents.wcKomEventsCommEvntHstryList;
import KomEvents.wcKomEventsCommElmntList;
import KomEvents.MbsoKomEventsEventInfo;
import KomEvents.wcKomEventsCommIntdList;
import KomEvents.wcKomEventsServEvntIntdList;
import KomEvents.wcKomEventsTransCGEIntdList;
import KomEvents.MbsoKomEventsPasToKomAuditData;
import KomEvents.MbsoKomEventsISEIntdDetails;
import KomEvents.MbsoKomEventsEventController;

import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.*;
import com.tcs.mastercraft.mcutil.*;

import java.io.*;
import java.text.*;
import java.math.*;
import ErrLogging.*;
import javax.naming.*;
import javax.transaction.*;
import java.util.Date;

import za.co.sanlam.cms.domain.replacement.ReplacementActiveInformation;
import za.co.sanlam.cms.domain.replacement.ReplacementActiveHistory;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import za.co.sanlam.web.ElementInfo;

import java.rmi.RemoteException;
import java.rmi.Remote;
// *************** DPM 45839 Starts
import java.net.*;

// *************** DPM 45839 Ends
public class KomEventsBEAN implements SessionBean, TimedObject {
    private SessionContext sessionctx = null;
    private transient javax.sql.DataSource dataSource = null;
    private String dataDir;
    EJBContext ejbContext = null;
    /* This attribute sets the printEnabled property read from ejb environment */
    private boolean bIsPrintEnabled = false; // / default is false
    /*
     * Name of the error message file to be used for reading the message
     * description for error message id .
     */
    private String sErrMsgFileName = "ShortErrorList";

    private static final ILogger log = LoggerFactory.getLogger(KomEventsBEAN.class);

    /**
     * This method is required by the EJB Specification, but is not used by this
     * bean.
     * 
     */
    public void ejbActivate() {
        log.debug(" Inside the function 'ejbActivate() : returns void' of class KomEventsBEAN required by EJB ");
    }

    /**
     * This method is required by the EJB Specification, but is not used by this
     * bean.
     * 
     */
    public void ejbPassivate() {
        log.debug(" Inside the function 'ejbPassivate() : returns void' of class KomEventsBEAN required by EJB ");
    }

    // Sets the session context
    public void setSessionContext(SessionContext sessionctx) {
        log.debug(" Entering function 'setSessionContext(SessionContext sessionctx) : returns void' of class KomEventsBEAN ");
        if (sessionctx != null)
            this.sessionctx = sessionctx;

        InitialContext envCtx = null;
        try {
            envCtx = new InitialContext();
            String printEnabledFlag = (String) envCtx.lookup("java:comp/env/mastercraft.ejb.enablePrint");
            bIsPrintEnabled = printEnabledFlag.equals("Y");
        } catch (NamingException ne1) {
            String errMsg = "Error encountered while looking up for environment value 'mastercraft.ejb.enablePrint'";
            MasterCraftException mce = new MasterCraftException(errMsg, ne1);
            throw mce;
        }

        try {
            // DPM 45839 Starts
            // sErrMsgFileName = ( String ) envCtx.lookup(
            // "java:comp/env/mastercraft.ejb.ErrMsgFile" );
            InitialContext initCtx = new InitialContext();
            URL url = (java.net.URL) initCtx.lookup("java:comp/env/url/mcappkom/ConfigPropertiesURL");
            URLConnection conn = url.openConnection();
            InputStream is = conn.getInputStream();
            Properties properties = new Properties();
            properties.load(is);
            sErrMsgFileName = properties.getProperty("mastercraft.ejb.ErrMsgFile");
            log.debug("sErrMsgFileName - from properties file... " + sErrMsgFileName);

        } catch (NamingException ne2) {
            String errMsg = "Error encountered while looking up for environment value 'mastercraft.ejb.ErrMsgFile'";
            MasterCraftException mce = new MasterCraftException(errMsg, ne2);
            throw mce;
        } catch (IOException ioe) {
            System.out.println("IOException " + ioe);
        }
        // DPM 45839 Ends
        log.info(" SessionContext has been set successfully ");
        log.debug(" Returning from function 'setSessionContext(SessionContext sessionctx) : returns void' of class KomEventsBEAN ");
    }

    // There should be a corresponding method in the ENTERPRISE BEAN'S HOME
    // INTERFACE
    // For UTCS this method will be invoked
    public void ejbCreate() {
        log.debug(" Entering function 'ejbCreate () : returns void' of class KomEventsBEAN ");
        try {
            ServerContext.setBeanContext(sessionctx, this);
            dataSource = ServerContext.getDataSource();
            dataDir = ServerContext.getDataDir();
        } catch (Exception e) {
            String errMsg = " Error encountered while Setting the Bean Context of the ServerContext class in the funtion 'ejbCreate () : returns void' ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        log.debug(" Returning from function 'ejbCreate () : returns void' of class KomEventsBEAN ");
    }

    /**
     * This method is required by the EJB Specification, and is used to close
     * JDBC Handle.
     * 
     */
    public void ejbRemove() {
        log.debug(" Entering function 'ejbRemove () : returns void' of class KomEventsBEAN ");
        try {
            if (ServerContext.getJDBCHandle() != null) {
                ServerContext.getJDBCHandle().close();
            }
            ServerContext.clearThreadContext();
        } catch (Exception e) {
            String errMsg = " Error encountered while Removing the Bean in function 'ejbRemove () : returns void'";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }
        log.debug(" Returning from function 'ejbRemove () : returns void' of class KomEventsBEAN ");
    }

    /**
     * This method is required by the EJB Specification, but is not used by this
     * bean.
     * 
     */
    public void ejbLocate() {
        log.debug(" Inside the function 'ejbLocate() : returns void' of class KomEventsBEAN required by EJB ");
    }

    public void executeWarningCheck(ErrorType _messageTyp) {
        Vector MsgVec = new Vector();
        int size = ServerContext.getMESSAGE_ARRAY().nElem();
        int i = 0;
        for (i = 0; i < size; i++) {
            MESSAGE messg = new MESSAGE();
            messg = (MESSAGE) ServerContext.getMESSAGE_ARRAY().get(i);
            if (messg.getMessageType() == _messageTyp.XL_WARNING) {
                MsgVec.addElement(messg);
            }
        }
        /*
         * compare all the ids in the passed warning array from gui with the
         * present warning ids take a new warning, compare with all passed ids,
         * if matches, compare description, if that also matches, it is old, if
         * it doesn't, then it is a new warning, so rollback if new warning id
         * does not match with passed warning ids, then its new, so rollback
         */
        int WarVecsize = MsgVec.size();
        Vector ignoredWarnings = new Vector();
        ignoredWarnings = ServerContext.getServerContextObject().getMasterCraftClientContext().getIgnoredWarnings();
        int IgnoredWarSize = ignoredWarnings.size();
        int j = 0;
        int exists = 0;
        loop1: for (j = 0; j < WarVecsize; j++) // for new warnings
        {
            MESSAGE msg = new MESSAGE();
            msg = (MESSAGE) MsgVec.elementAt(j);
            int NewWarningCode = msg.getCode();
            Vector tmpVecNew = new Vector();
            tmpVecNew.addElement(msg);
            int k = 0;
            loop2: for (k = 0; k < IgnoredWarSize; k++) // for ignored warnings
            {
                MESSAGE IgnoredMsg = new MESSAGE();
                IgnoredMsg = (MESSAGE) ignoredWarnings.elementAt(k);
                Vector tmpVecIgnored = new Vector();
                tmpVecIgnored.addElement(IgnoredMsg);
                int IgnoredWarningCode = IgnoredMsg.getCode();
                if (NewWarningCode == IgnoredWarningCode) {
                    String IgnoredWarningDescription = utsErrMsg.showMsg(tmpVecIgnored, sErrMsgFileName);
                    String NewWarningDescription = utsErrMsg.showMsg(tmpVecNew, sErrMsgFileName);
                    if (NewWarningDescription.equals(IgnoredWarningDescription)) {
                        exists = 1;
                        break loop2;
                    } else {
                        log.debug("About to Abort");
                        sessionctx.setRollbackOnly();
                        break loop1;
                    }
                }
            }
            if (exists == 0) // warning did not match any ignored warning, so it
                             // is a new warning
            {
                log.debug("About to Abort");
                sessionctx.setRollbackOnly();
                break loop1;
            }
        }
        try {
            if (!sessionctx.getRollbackOnly()) {
                logIgnoredWarnings("Tbl_ignoredWarnings");
            }
        } catch (Exception e) {
            String errMsg = "Error in logging ignored warnings to Tbl_ignoredWarnings";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }
    }

    public void logIgnoredWarnings(String TableName) {
        int retcode = 0;
        String Warning = new String();
        StringBuffer h_SqlStmt = new StringBuffer(20000);
        int index;
        Vector ignoredWarningsVector = ServerContext.getServerContextObject().getMasterCraftClientContext().getIgnoredWarnings();
        if (ignoredWarningsVector != null && ignoredWarningsVector.size() != 0) {
            Warning = utsErrMsg.showMsg(ignoredWarningsVector, sErrMsgFileName);
        }

        String local = new String(" INSERT INTO " + TableName + " VALUES ('"
                + ServerContext.getServerContextObject().getMasterCraftClientContext().getUserId().toString() + "',"
                + ServerContext.getServerContextObject().getMasterCraftClientContext().getServiceId() + ",'"
                + ServerContext.getServerContextObject().getMasterCraftClientContext().getTransactionId().toString() + "','"
                + ServerContext.getServerContextObject().getMasterCraftClientContext().getAppTimeStamp().toString() + "','"
                + Warning + "'");
        h_SqlStmt.replace(0, local.length(), local);
        h_SqlStmt.append(" ) ");
        String sqlStmt = h_SqlStmt.toString();

        try {
            PreparedStatement pstmt = ServerContext.getJDBCHandle().prepareStatement(sqlStmt);
            int retValue = pstmt.executeUpdate();
            pstmt.close();
        }

        catch (SQLException ex) {
            retcode = ex.getErrorCode();
            if (retcode == DM_err.ORA_TABLE_DOESNOTEXISTS || retcode == DM_err.SQLSERVER_TABLE_DOESNOTEXISTS) {
                log.debug("Table not found " + TableName.toString());
            }
            String errMsg = "Error in logging ignored warnings to Tbl_ignoredWarnings";
            MasterCraftException mce = new MasterCraftException(errMsg, ex);
            throw mce;
        }
        /* clear the array being returned to GUI */
        ServerContext.clearMessages();
    }

    // This method will be called by the EJB Container after the Timer expires.
    public void ejbTimeout(javax.ejb.Timer timer_expired) {
        log.debug(" Entering function ' ejbTimeout ( Timer timer_expired ) : returns void ' of class TesterCompBEAN ");

        try {
            if (ServerContext.getContext() == null && sessionctx != null) {
                ServerContext.setContext(sessionctx);
            }

            EJBTimer.ejbTimeout(timer_expired);
        } catch (Exception ex) {
            String errMsg = "Error encountered in function ' ejbTimeout ( )  : returns void ' ";
            MasterCraftException mce = new MasterCraftException(errMsg, ex);
            throw mce;
        }
    }

    public MasterCraftretClass sh_processCommEvents(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPolicyInfo inp0, MbsoKomEventsEventInfo inp1, MbsoKomEventsElmntInfo inp2, MasterCraftVector multi_inp3) {
        log.debug(" Entering function ' sh_processCommEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPolicyInfo inp0  ,  MbsoKomEventsEventInfo inp1  ,  MbsoKomEventsElmntInfo inp2  ,  MasterCraftVector multi_inp3 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processCommEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processCommEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processCommEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPolicyInfo " + inp0
                    + " MbsoKomEventsEventInfo " + inp1 + " MbsoKomEventsElmntInfo " + inp2
                    + " Multirow of MbsoKomEventsIntdCommInfo " + multi_inp3);

            log.debug(" Calling function ' processCommEvents  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processCommEvents(inp0, inp1, inp2, multi_inp3);

            log.debug(" Returned from function ' processCommEvents  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processCommEvents  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processCommEvents  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchPolicies(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommPolicyList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchPolicies ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommPolicyList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchPolicies Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchPolicies after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchPolicies' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommPolicyList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchPolicies  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchPolicies(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchPolicies  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchPolicies  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchPolicies  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchServEntListForPolicy(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsServEntSum inp0, wcKomEventsBrokersNoteEvntList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchServEntListForPolicy ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsServEntSum inp0  ,  wcKomEventsBrokersNoteEvntList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchServEntListForPolicy Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchServEntListForPolicy after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchServEntListForPolicy' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsServEntSum " + inp0
                    + " wcKomEventsBrokersNoteEvntList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchServEntListForPolicy  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchServEntListForPolicy(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchServEntListForPolicy  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchServEntListForPolicy  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchServEntListForPolicy  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchServEntIntdBuyerList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsServEntSum inp0, wcKomEventsMABuyerIntdList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchServEntIntdBuyerList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsServEntSum inp0  ,  wcKomEventsMABuyerIntdList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchServEntIntdBuyerList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchServEntIntdBuyerList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchServEntIntdBuyerList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsServEntSum " + inp0
                    + " wcKomEventsMABuyerIntdList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchServEntIntdBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchServEntIntdBuyerList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchServEntIntdBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchServEntIntdBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchServEntIntdBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchSellPrctPolicySellerList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsSellPrctSum inp0, wcKomEventsMASellerList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchSellPrctPolicySellerList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSellPrctSum inp0  ,  wcKomEventsMASellerList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchSellPrctPolicySellerList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchSellPrctPolicySellerList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchSellPrctPolicySellerList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSellPrctSum " + inp0
                    + " wcKomEventsMASellerList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchSellPrctPolicySellerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchSellPrctPolicySellerList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchSellPrctPolicySellerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchSellPrctPolicySellerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchSellPrctPolicySellerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchKommbList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsKommbInfo inp0, wcKomEventsPayKommbList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchKommbList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsKommbInfo inp0  ,  wcKomEventsPayKommbList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchKommbList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchKommbList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchKommbList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsKommbInfo " + inp0
                    + " wcKomEventsPayKommbList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchKommbList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchKommbList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchKommbList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchKommbList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchKommbList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchPymtList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPymtInfo inp0, wcKomEventsPayElmntList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchPymtList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPymtInfo inp0  ,  wcKomEventsPayElmntList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchPymtList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchPymtList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchPymtList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPymtInfo " + inp0
                    + " wcKomEventsPayElmntList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchPymtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchPymtList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchPymtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchPymtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchPymtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchSellPrctPolicyBuyerList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsSellPrctSum inp0, wcKomEventsMABuyerList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchSellPrctPolicyBuyerList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSellPrctSum inp0  ,  wcKomEventsMABuyerList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchSellPrctPolicyBuyerList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchSellPrctPolicyBuyerList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchSellPrctPolicyBuyerList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSellPrctSum " + inp0
                    + " wcKomEventsMABuyerList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchSellPrctPolicyBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchSellPrctPolicyBuyerList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchSellPrctPolicyBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchSellPrctPolicyBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchSellPrctPolicyBuyerList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchSalesDetails(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsISEDetails inp0, wcKomEventsSalesEntList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchSalesDetails ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsISEDetails inp0  ,  wcKomEventsSalesEntList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchSalesDetails Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchSalesDetails after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchSalesDetails' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsISEDetails " + inp0
                    + " wcKomEventsSalesEntList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchSalesDetails  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchSalesDetails(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchSalesDetails  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchSalesDetails  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchSalesDetails  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchSalesIntdDetails(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsISEIntdDetails inp0, wcKomEventsSalesEntIntdList inp1,
            Direction inp2, MbsoKomEventsISEDetails inp3) {
        log.debug(" Entering function ' sh_fetchSalesIntdDetails ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsISEIntdDetails inp0  ,  wcKomEventsSalesEntIntdList inp1  ,  Direction inp2  ,  MbsoKomEventsISEDetails inp3 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchSalesIntdDetails Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchSalesIntdDetails after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchSalesIntdDetails' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsISEIntdDetails " + inp0
                    + " wcKomEventsSalesEntIntdList " + inp1 + " Direction " + inp2 + " MbsoKomEventsISEDetails " + inp3);

            log.debug(" Calling function ' fetchSalesIntdDetails  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchSalesIntdDetails(inp0, inp1, inp2, inp3);

            log.debug(" Returned from function ' fetchSalesIntdDetails  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchSalesIntdDetails  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchSalesIntdDetails  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchECList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsSalsECSum inp0, wcKomEventsTransECList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchECList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSalsECSum inp0  ,  wcKomEventsTransECList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchECList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchECList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchECList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSalsECSum " + inp0
                    + " wcKomEventsTransECList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchECList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchECList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchECList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchECList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchECList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchECIntdDtls(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCXEInfo inp0, wcKomEventsTransIntdList inp1, Direction inp2, MbsoKomEventsSalsECSum inp3) {
        log.debug(" Entering function ' sh_fetchECIntdDtls ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCXEInfo inp0  ,  wcKomEventsTransIntdList inp1  ,  Direction inp2  ,  MbsoKomEventsSalsECSum inp3 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchECIntdDtls Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchECIntdDtls after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchECIntdDtls' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCXEInfo " + inp0
                    + " wcKomEventsTransIntdList " + inp1 + " Direction " + inp2 + " MbsoKomEventsSalsECSum " + inp3);

            log.debug(" Calling function ' fetchECIntdDtls  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchECIntdDtls(inp0, inp1, inp2, inp3);

            log.debug(" Returned from function ' fetchECIntdDtls  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchECIntdDtls  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchECIntdDtls  (   inp0, inp1, inp2, inp3 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchcgeEvntList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            Direction inp0, MbsoKomEventsSalsECSum inp1, wcKomEventsTransCgeList inp2) {
        log.debug(" Entering function ' sh_fetchcgeEvntList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  Direction inp0  ,  MbsoKomEventsSalsECSum inp1  ,  wcKomEventsTransCgeList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchcgeEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchcgeEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchcgeEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0 + " MbsoKomEventsSalsECSum "
                    + inp1 + " wcKomEventsTransCgeList " + inp2);

            log.debug(" Calling function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchcgeEvntList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchErrWaitStoreList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStoreListSearch inp0,
            wcKomEventsErrWaitList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchErrWaitStoreList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStoreListSearch inp0  ,  wcKomEventsErrWaitList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchErrWaitStoreList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchErrWaitStoreList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchErrWaitStoreList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStoreListSearch " + inp0
                    + " wcKomEventsErrWaitList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchErrWaitStoreList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }
        
        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.
    
    public MasterCraftretClass sh_fetchRetroErrWaitStoreList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStoreListSearch inp0,
            wcKomEventsRetroErrWaitListBean inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchErrWaitStoreList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStoreListSearch inp0  ,  wcKomEventsErrWaitList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        List<wcKomEventsRetroErrWaitListBean> multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchErrWaitStoreList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchErrWaitStoreList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchErrWaitStoreList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStoreListSearch " + inp0
                    + " wcKomEventsErrWaitList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchRetroErrWaitStoreList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchErrWaitStoreList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchECCommRegenIntdList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, Direction inp1,
            wcKomEventsMACrgeIntdList inp2) {
        log.debug(" Entering function ' sh_fetchECCommRegenIntdList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  Direction inp1  ,  wcKomEventsMACrgeIntdList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchECCommRegenIntdList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchECCommRegenIntdList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchECCommRegenIntdList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Direction " + inp1 + " wcKomEventsMACrgeIntdList " + inp2);

            log.debug(" Calling function ' fetchECCommRegenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchECCommRegenIntdList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchECCommRegenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchECCommRegenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchECCommRegenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchCGEListIntd(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCGEInfo inp0, wcKomEventsTransCGEIntdList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchCGEListIntd ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCGEInfo inp0  ,  wcKomEventsTransCGEIntdList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchCGEListIntd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchCGEListIntd after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchCGEListIntd' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCGEInfo " + inp0
                    + " wcKomEventsTransCGEIntdList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchCGEListIntd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchCGEListIntd(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchCGEListIntd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchCGEListIntd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchCGEListIntd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchUnvestCommList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsUnvestCommProjDtls inp0, Direction inp1,
            wcKomEventsUnvestCommList inp2) {
        log.debug(" Entering function ' sh_fetchUnvestCommList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsUnvestCommProjDtls inp0  ,  Direction inp1  ,  wcKomEventsUnvestCommList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchUnvestCommList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchUnvestCommList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchUnvestCommList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsUnvestCommProjDtls " + inp0
                    + " Direction " + inp1 + " wcKomEventsUnvestCommList " + inp2);

            log.debug(" Calling function ' fetchUnvestCommList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchUnvestCommList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchUnvestCommList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchUnvestCommList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchUnvestCommList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchUnvestCommDtls(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsUnvestCommProjDtls inp0,
            wcKomEventsUnvestCommDtls inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchUnvestCommDtls ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsUnvestCommProjDtls inp0  ,  wcKomEventsUnvestCommDtls inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchUnvestCommDtls Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchUnvestCommDtls after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchUnvestCommDtls' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsUnvestCommProjDtls " + inp0
                    + " wcKomEventsUnvestCommDtls " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchUnvestCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchUnvestCommDtls(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchUnvestCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchUnvestCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchUnvestCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchRetroEvntList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsCommRetroInfo inp0, wcKomEventsRetroEvntList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchRetroEvntList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommRetroInfo inp0  ,  wcKomEventsRetroEvntList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchRetroEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchRetroEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchRetroEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommRetroInfo " + inp0
                    + " wcKomEventsRetroEvntList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchRetroEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchRetroEvntList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchRetroEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchRetroEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchRetroEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchUsrList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            Direction inp0) {
        log.debug(" Entering function ' sh_fetchUsrList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  Direction inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchUsrList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchUsrList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchUsrList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0);

            log.debug(" Calling function ' fetchUsrList  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.fetchUsrList(inp0);

            log.debug(" Returned from function ' fetchUsrList  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchUsrList  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchUsrList  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchCGEs(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommCGEList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchCGEs ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommCGEList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchCGEs Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchCGEs after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchCGEs' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommCGEList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchCGEs  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchCGEs(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchCGEs  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchCGEs  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchCGEs  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchCGEHstry(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommEvntHstryList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchCGEHstry ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommEvntHstryList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchCGEHstry Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchCGEHstry after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchCGEHstry' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommEvntHstryList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchCGEHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchCGEHstry(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchCGEHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchCGEHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchCGEHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchElementList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            Direction inp0, MbsoKomEventsCommEnqContext inp1, wcKomEventsCommElmntList inp2) {
        log.debug(" Entering function ' sh_fetchElementList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  Direction inp0  ,  MbsoKomEventsCommEnqContext inp1  ,  wcKomEventsCommElmntList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchElementList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchElementList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchElementList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0
                    + " MbsoKomEventsCommEnqContext " + inp1 + " wcKomEventsCommElmntList " + inp2);

            log.debug(" Calling function ' fetchElementList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchElementList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchElementList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchElementList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchElementList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchElmntHistory(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommElmntHstryList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchElmntHistory ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommElmntHstryList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchElmntHistory Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchElmntHistory after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchElmntHistory' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommElmntHstryList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchElmntHistory  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchElmntHistory(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchElmntHistory  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchElmntHistory  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchElmntHistory  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchIntdCommDtls(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommIntdList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchIntdCommDtls ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommIntdList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchIntdCommDtls Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchIntdCommDtls after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchIntdCommDtls' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommIntdList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchIntdCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchIntdCommDtls(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchIntdCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchIntdCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchIntdCommDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchIntdCommHstry(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsCommEnqContext inp0,
            wcKomEventsCommIntdHstryList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchIntdCommHstry ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommIntdHstryList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchIntdCommHstry Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchIntdCommHstry after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchIntdCommHstry' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommIntdHstryList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchIntdCommHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchIntdCommHstry(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchIntdCommHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchIntdCommHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchIntdCommHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchSchdHstry(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommSchdHstryList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchSchdHstry ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommSchdHstryList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchSchdHstry Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchSchdHstry after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchSchdHstry' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommSchdHstryList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchSchdHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchSchdHstry(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchSchdHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchSchdHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchSchdHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchElmntScoreDtls(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsCommEnqContext inp0, wcKomEventsCommScoreList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchElmntScoreDtls ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommScoreList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchElmntScoreDtls Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchElmntScoreDtls after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchElmntScoreDtls' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommScoreList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchElmntScoreDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchElmntScoreDtls(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchElmntScoreDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchElmntScoreDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchElmntScoreDtls  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchECCommGenIntdList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, wcKomEventsMACgeIntdList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchECCommGenIntdList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  wcKomEventsMACgeIntdList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchECCommGenIntdList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchECCommGenIntdList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchECCommGenIntdList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " wcKomEventsMACgeIntdList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchECCommGenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchECCommGenIntdList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchECCommGenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchECCommGenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchECCommGenIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchElmntHstry(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsElmntInfo inp0, wcKomEventsCommElmntHstryList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchElmntHstry ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsElmntInfo inp0  ,  wcKomEventsCommElmntHstryList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchElmntHstry Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchElmntHstry after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchElmntHstry' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsElmntInfo " + inp0
                    + " wcKomEventsCommElmntHstryList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchElmntHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchElmntHstry(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchElmntHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchElmntHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchElmntHstry  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchElmnts(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, Direction inp1) {
        log.debug(" Entering function ' sh_fetchElmnts ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  Direction inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchElmnts Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchElmnts after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchElmnts' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " Direction " + inp1);

            log.debug(" Calling function ' fetchElmnts  (   inp0, inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.fetchElmnts(inp0, inp1);

            log.debug(" Returned from function ' fetchElmnts  (   inp0, inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchElmnts  (   inp0, inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchElmnts  (   inp0, inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_handleRejectedEvents(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_handleRejectedEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsEventController return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside handleRejectedEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside handleRejectedEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'handleRejectedEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Multirow of MbsoKomEventsErrWaitStoreIntd " + multi_inp1);

            log.debug(" Calling function ' handleRejectedEvents  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.handleRejectedEvents(inp0, multi_inp1);

            log.debug(" Returned from function ' handleRejectedEvents  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' handleRejectedEvents  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                // if(jdbcCloseFlag)
                // ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' handleRejectedEvents  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_handleWaitStoreEvents(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MasterCraftVector multi_inp0) {
        log.debug(" Entering function ' sh_handleWaitStoreEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MasterCraftVector multi_inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside handleWaitStoreEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside handleWaitStoreEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'handleWaitStoreEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Multirow of wcKomEventsErrWaitList " + multi_inp0);

            log.debug(" Calling function ' handleWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.handleWaitStoreEvents(multi_inp0);

            log.debug(" Returned from function ' handleWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' handleWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' handleWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processVATRetroEvent(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MasterCraftVector multi_inp0) {
        log.debug(" Entering function ' sh_processVATRetroEvent ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MasterCraftVector multi_inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processVATRetroEvent Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processVATRetroEvent after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processVATRetroEvent' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Multirow of MbsoKomEventsVATRetroInfo "
                    + multi_inp0);

            log.debug(" Calling function ' processVATRetroEvent  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processVATRetroEvent(multi_inp0);

            log.debug(" Returned from function ' processVATRetroEvent  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processVATRetroEvent  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processVATRetroEvent  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetKommbInfo(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsKommbInfo inp0) {
        log.debug(" Entering function ' sh_pmoGetKommbInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsKommbInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsKommbInfo return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetKommbInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetKommbInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetKommbInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsKommbInfo " + inp0);

            log.debug(" Calling function ' pmoGetKommbInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetKommbInfo(inp0);

            log.debug(" Returned from function ' pmoGetKommbInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetKommbInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetKommbInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetPymtInfo(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPymtInfo inp0) {
        log.debug(" Entering function ' sh_pmoGetPymtInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPymtInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsPymtInfo return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetPymtInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetPymtInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetPymtInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPymtInfo " + inp0);

            log.debug(" Calling function ' pmoGetPymtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetPymtInfo(inp0);

            log.debug(" Returned from function ' pmoGetPymtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetPymtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetPymtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processAllECCommRegen(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, wcKomEventsECCrgeIntdList inp1,
            Direction inp2, MasterCraftVector multi_inp3, MbsoKomEventsErrWaitStore out4) {
        log.debug(" Entering function ' sh_processAllECCommRegen ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  wcKomEventsECCrgeIntdList inp1  ,  Direction inp2  ,  MasterCraftVector multi_inp3  ,  MbsoKomEventsErrWaitStore out4 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processAllECCommRegen Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processAllECCommRegen after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processAllECCommRegen' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " wcKomEventsECCrgeIntdList " + inp1 + " Direction " + inp2 + " Multirow of wcKomEventsMACgeIntdList "
                    + multi_inp3 + " MbsoKomEventsErrWaitStore " + out4);

            log.debug(" Calling function ' processAllECCommRegen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.processAllECCommRegen(inp0, inp1, inp2, multi_inp3, out4);

            log.debug(" Returned from function ' processAllECCommRegen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + out4 + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processAllECCommRegen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) out4);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processAllECCommRegen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetPolicyInfo(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0) {
        log.debug(" Entering function ' sh_pmoGetPolicyInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsPolicyInfo return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetPolicyInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetPolicyInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetPolicyInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0);

            log.debug(" Calling function ' pmoGetPolicyInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetPolicyInfo(inp0);

            log.debug(" Returned from function ' pmoGetPolicyInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetPolicyInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetPolicyInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processEvntTypeErrWaitStore(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processEvntTypeErrWaitStore ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        int return1 = 0;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processEvntTypeErrWaitStore Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processEvntTypeErrWaitStore after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processEvntTypeErrWaitStore' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Multirow of wcKomEventsMACgeIntdList " + multi_inp1);

            log.debug(" Calling function ' processEvntTypeErrWaitStore  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.processEvntTypeErrWaitStore(inp0, multi_inp1);

            log.debug(" Returned from function ' processEvntTypeErrWaitStore  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + return1 + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processEvntTypeErrWaitStore  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                d_intClass wr_ret = new d_intClass();
                wr_ret.setIntValue(return1);
                MCretObj.getOutParameters().append((Object) wr_ret);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processEvntTypeErrWaitStore  (   inp0, multi_inp1 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processAllECCommGen(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, wcKomEventsCGEIntdList inp1,
            Direction inp2, MasterCraftVector multi_inp3, MbsoKomEventsErrWaitStore out4) {
        log.debug(" Entering function ' sh_processAllECCommGen ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  wcKomEventsCGEIntdList inp1  ,  Direction inp2  ,  MasterCraftVector multi_inp3  ,  MbsoKomEventsErrWaitStore out4 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processAllECCommGen Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processAllECCommGen after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processAllECCommGen' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " wcKomEventsCGEIntdList " + inp1 + " Direction " + inp2 + " Multirow of wcKomEventsMACgeIntdList "
                    + multi_inp3 + " MbsoKomEventsErrWaitStore " + out4);

            log.debug(" Calling function ' processAllECCommGen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.processAllECCommGen(inp0, inp1, inp2, multi_inp3, out4);

            log.debug(" Returned from function ' processAllECCommGen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + out4 + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processAllECCommGen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) out4);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processAllECCommGen  (   inp0, inp1, inp2, multi_inp3, out4 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetECCommReducEvntInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_pmoGetECCommReducEvntInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStore return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetECCommReducEvntInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetECCommReducEvntInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetECCommReducEvntInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetECCommReducEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetECCommReducEvntInfo(inp0);

            log.debug(" Returned from function ' pmoGetECCommReducEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetECCommReducEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetECCommReducEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetSchdInfo(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0) {
        log.debug(" Entering function ' sh_pmoGetSchdInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsAdvSchdInfo return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetSchdInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetSchdInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetSchdInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0);

            log.debug(" Calling function ' pmoGetSchdInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetSchdInfo(inp0);

            log.debug(" Returned from function ' pmoGetSchdInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetSchdInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetSchdInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processIndexSalesEntlInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsISEDetails inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processIndexSalesEntlInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsISEDetails inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processIndexSalesEntlInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processIndexSalesEntlInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processIndexSalesEntlInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsISEDetails " + inp0
                    + " Multirow of wcKomEventsSalesEntIntdDetails " + multi_inp1);

            log.debug(" Calling function ' processIndexSalesEntlInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processIndexSalesEntlInfo(inp0, multi_inp1);

            log.debug(" Returned from function ' processIndexSalesEntlInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processIndexSalesEntlInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processIndexSalesEntlInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

   
    public MasterCraftretClass sh_processCommReducEvntType(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processCommReducEvntType ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processCommReducEvntType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processCommReducEvntType after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processCommReducEvntType' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Multirow of wcKomEventsCteIntdList " + multi_inp1);

            log.debug(" Calling function ' processCommReducEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processCommReducEvntType(inp0, multi_inp1);

            log.debug(" Returned from function ' processCommReducEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processCommReducEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processCommReducEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processMACommGenEvntType(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processMACommGenEvntType ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processMACommGenEvntType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processMACommGenEvntType after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processMACommGenEvntType' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Multirow of wcKomEventsMACgeIntdList " + multi_inp1);

            log.debug(" Calling function ' processMACommGenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processMACommGenEvntType(inp0, multi_inp1);

            log.debug(" Returned from function ' processMACommGenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processMACommGenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processMACommGenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processCommRegenEvntType(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processCommRegenEvntType ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processCommRegenEvntType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processCommRegenEvntType after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processCommRegenEvntType' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Multirow of wcKomEventsMACrgeIntdList " + multi_inp1);

            log.debug(" Calling function ' processCommRegenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processCommRegenEvntType(inp0, multi_inp1);

            log.debug(" Returned from function ' processCommRegenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processCommRegenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processCommRegenEvntType  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processRetroActiveSuspense(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsCommRetroInfo inp0) {
        log.debug(" Entering function ' sh_processRetroActiveSuspense ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommRetroInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processRetroActiveSuspense Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processRetroActiveSuspense after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processRetroActiveSuspense' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommRetroInfo " + inp0);

            log.debug(" Calling function ' processRetroActiveSuspense  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processRetroActiveSuspense(inp0);

            log.debug(" Returned from function ' processRetroActiveSuspense  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processRetroActiveSuspense  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processRetroActiveSuspense  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoValidateSellPractice(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsSellPrctSum inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_pmoValidateSellPractice ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSellPrctSum inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoValidateSellPractice Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoValidateSellPractice after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoValidateSellPractice' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSellPrctSum " + inp0
                    + " Multirow of wcKomEventsMASellerIntdList " + multi_inp1);

            log.debug(" Calling function ' pmoValidateSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.pmoValidateSellPractice(inp0, multi_inp1);

            log.debug(" Returned from function ' pmoValidateSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoValidateSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoValidateSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoValidateServiceEntlmnt(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsServEntSum inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_pmoValidateServiceEntlmnt ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsServEntSum inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoValidateServiceEntlmnt Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoValidateServiceEntlmnt after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoValidateServiceEntlmnt' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsServEntSum " + inp0
                    + " Multirow of wcKomEventsServEvntIntdList " + multi_inp1);

            log.debug(" Calling function ' pmoValidateServiceEntlmnt  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.pmoValidateServiceEntlmnt(inp0, multi_inp1);

            log.debug(" Returned from function ' pmoValidateServiceEntlmnt  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoValidateServiceEntlmnt  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoValidateServiceEntlmnt  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoValidateCancelSellPractice(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsSellPrctSum inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_pmoValidateCancelSellPractice ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSellPrctSum inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoValidateCancelSellPractice Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoValidateCancelSellPractice after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoValidateCancelSellPractice' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSellPrctSum " + inp0
                    + " Multirow of wcKomEventsMASellerList " + multi_inp1);

            log.debug(" Calling function ' pmoValidateCancelSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.pmoValidateCancelSellPractice(inp0, multi_inp1);

            log.debug(" Returned from function ' pmoValidateCancelSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoValidateCancelSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoValidateCancelSellPractice  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_auditingofEvents(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPasToKomAuditData inp0) {
        log.debug(" Entering function ' sh_auditingofEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPasToKomAuditData inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside auditingofEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside auditingofEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'auditingofEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPasToKomAuditData " + inp0);

            log.debug(" Calling function ' auditingofEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.auditingofEvents(inp0);

            log.debug(" Returned from function ' auditingofEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' auditingofEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' auditingofEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_dummyfFetchForMAComGen(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor) {
        log.debug(" Entering function ' sh_dummyfFetchForMAComGen ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside dummyfFetchForMAComGen Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside dummyfFetchForMAComGen after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'dummyfFetchForMAComGen' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor);

            log.debug(" Calling function ' dummyfFetchForMAComGen  (   )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.dummyfFetchForMAComGen();

            log.debug(" Returned from function ' dummyfFetchForMAComGen  (   )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' dummyfFetchForMAComGen  (   )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' dummyfFetchForMAComGen  (   )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_dummyFetchForMACommRegen(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor) {
        log.debug(" Entering function ' sh_dummyFetchForMACommRegen ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside dummyFetchForMACommRegen Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside dummyFetchForMACommRegen after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'dummyFetchForMACommRegen' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor);

            log.debug(" Calling function ' dummyFetchForMACommRegen  (   )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.dummyFetchForMACommRegen();

            log.debug(" Returned from function ' dummyFetchForMACommRegen  (   )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' dummyFetchForMACommRegen  (   )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' dummyFetchForMACommRegen  (   )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processTransferSalesECDtls(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsSalsECSum inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processTransferSalesECDtls ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSalsECSum inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processTransferSalesECDtls Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processTransferSalesECDtls after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processTransferSalesECDtls' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSalsECSum " + inp0
                    + " Multirow of wcKomEventsTransECIntdList " + multi_inp1);

            log.debug(" Calling function ' processTransferSalesECDtls  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processTransferSalesECDtls(inp0, multi_inp1);

            log.debug(" Returned from function ' processTransferSalesECDtls  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processTransferSalesECDtls  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processTransferSalesECDtls  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_auditingOfEvents(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsIntdCommInfo inp0) {
        log.debug(" Entering function ' sh_auditingOfEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsIntdCommInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside auditingOfEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside auditingOfEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'auditingOfEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsIntdCommInfo " + inp0);

            log.debug(" Calling function ' auditingOfEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.auditingOfEvents(inp0);

            log.debug(" Returned from function ' auditingOfEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' auditingOfEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' auditingOfEvents  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_delegateEvent(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPolicyInfo inp0, MbsoKomEventsEventInfo inp1, MbsoKomEventsElmntInfo inp2, MasterCraftVector multi_inp3) {
        log.debug(" Entering function ' sh_delegateEvent ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPolicyInfo inp0  ,  MbsoKomEventsEventInfo inp1  ,  MbsoKomEventsElmntInfo inp2  ,  MasterCraftVector multi_inp3 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside delegateEvent Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside delegateEvent after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'delegateEvent' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPolicyInfo " + inp0
                    + " MbsoKomEventsEventInfo " + inp1 + " MbsoKomEventsElmntInfo " + inp2
                    + " Multirow of MbsoKomEventsIntdCommInfo " + multi_inp3);

            log.debug(" Calling function ' delegateEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.delegateEvent(inp0, inp1, inp2, multi_inp3);

            log.debug(" Returned from function ' delegateEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' delegateEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                // if(jdbcCloseFlag)
                // ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' delegateEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_notifyAdmin(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsEventController inp0) {
        log.debug(" Entering function ' sh_notifyAdmin ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsEventController inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside notifyAdmin Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside notifyAdmin after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'notifyAdmin' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsEventController " + inp0);

            log.debug(" Calling function ' notifyAdmin  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.notifyAdmin(inp0);

            log.debug(" Returned from function ' notifyAdmin  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' notifyAdmin  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' notifyAdmin  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processWaitStoreEvents(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MasterCraftVector multi_inp0) {
        log.debug(" Entering function ' sh_processWaitStoreEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MasterCraftVector multi_inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processWaitStoreEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processWaitStoreEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processWaitStoreEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Multirow of MbsoKomEventsErrWaitStore "
                    + multi_inp0);

            log.debug(" Calling function ' processWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processWaitStoreEvents(multi_inp0);

            log.debug(" Returned from function ' processWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetECCommGenEvntInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_pmoGetECCommGenEvntInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStore return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetECCommGenEvntInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetECCommGenEvntInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetECCommGenEvntInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetECCommGenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetECCommGenEvntInfo(inp0);

            log.debug(" Returned from function ' pmoGetECCommGenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetECCommGenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetECCommGenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetECCommRegenEvntInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_pmoGetECCommRegenEvntInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStore return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetECCommRegenEvntInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetECCommRegenEvntInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetECCommRegenEvntInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetECCommRegenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetECCommRegenEvntInfo(inp0);

            log.debug(" Returned from function ' pmoGetECCommRegenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetECCommRegenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetECCommRegenEvntInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processMAFundCommission(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_processMAFundCommission ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processMAFundCommission Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processMAFundCommission after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processMAFundCommission' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Multirow of wcKomEventsFundCommIntdList " + multi_inp1);

            log.debug(" Calling function ' processMAFundCommission  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processMAFundCommission(inp0, multi_inp1);

            log.debug(" Returned from function ' processMAFundCommission  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processMAFundCommission  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processMAFundCommission  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processFundComm(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor) {
        log.debug(" Entering function ' sh_processFundComm ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processFundComm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processFundComm after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processFundComm' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor);

            log.debug(" Calling function ' processFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processFundComm();

            log.debug(" Returned from function ' processFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_dummyFundComm(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor) {
        log.debug(" Entering function ' sh_dummyFundComm ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside dummyFundComm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside dummyFundComm after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'dummyFundComm' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor);

            log.debug(" Calling function ' dummyFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.dummyFundComm();

            log.debug(" Returned from function ' dummyFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' dummyFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' dummyFundComm  (   )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_storePreTransInfo(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPreTransInfo inp0, MasterCraftVector multi_inp1) {
        log.debug(" Entering function ' sh_storePreTransInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPreTransInfo inp0  ,  MasterCraftVector multi_inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside storePreTransInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside storePreTransInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'storePreTransInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPreTransInfo " + inp0
                    + " Multirow of MbsoKomEventsPreTransIntdInfo " + multi_inp1);

            log.debug(" Calling function ' storePreTransInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.storePreTransInfo(inp0, multi_inp1);

            log.debug(" Returned from function ' storePreTransInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' storePreTransInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' storePreTransInfo  (   inp0, multi_inp1 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchFundCommIntdList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, Direction inp1,
            wcKomEventsFundCommIntdList inp2) {
        log.debug(" Entering function ' sh_fetchFundCommIntdList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  Direction inp1  ,  wcKomEventsFundCommIntdList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchFundCommIntdList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchFundCommIntdList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchFundCommIntdList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Direction " + inp1 + " wcKomEventsFundCommIntdList " + inp2);

            log.debug(" Calling function ' fetchFundCommIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchFundCommIntdList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchFundCommIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchFundCommIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchFundCommIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetECFundCommList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_pmoGetECFundCommList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStore return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetECFundCommList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetECFundCommList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetECFundCommList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetECFundCommList  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetECFundCommList(inp0);

            log.debug(" Returned from function ' pmoGetECFundCommList  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetECFundCommList  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetECFundCommList  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processWaitStoreEvent(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor) {
        log.debug(" Entering function ' sh_processWaitStoreEvent ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processWaitStoreEvent Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processWaitStoreEvent after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processWaitStoreEvent' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor);

            log.debug(" Calling function ' processWaitStoreEvent  (   )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processWaitStoreEvent();

            log.debug(" Returned from function ' processWaitStoreEvent  (   )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processWaitStoreEvent  (   )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processWaitStoreEvent  (   )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_waitStoreEventProcessor(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsPolicyInfo inp0, MbsoKomEventsEventInfo inp1,
            MbsoKomEventsElmntInfo inp2, MasterCraftVector multi_inp3) {
        log.debug(" Entering function ' sh_waitStoreEventProcessor ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPolicyInfo inp0  ,  MbsoKomEventsEventInfo inp1  ,  MbsoKomEventsElmntInfo inp2  ,  MasterCraftVector multi_inp3 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside waitStoreEventProcessor Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside waitStoreEventProcessor after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'waitStoreEventProcessor' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPolicyInfo " + inp0
                    + " MbsoKomEventsEventInfo " + inp1 + " MbsoKomEventsElmntInfo " + inp2
                    + " Multirow of MbsoKomEventsIntdCommInfo " + multi_inp3);

            log.debug(" Calling function ' waitStoreEventProcessor  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.waitStoreEventProcessor(inp0, inp1, inp2, multi_inp3);

            log.debug(" Returned from function ' waitStoreEventProcessor  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' waitStoreEventProcessor  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' waitStoreEventProcessor  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processErrorEvent(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsPolicyInfo inp0, MbsoKomEventsEventInfo inp1, MbsoKomEventsElmntInfo inp2, MasterCraftVector multi_inp3) {
        log.debug(" Entering function ' sh_processErrorEvent ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsPolicyInfo inp0  ,  MbsoKomEventsEventInfo inp1  ,  MbsoKomEventsElmntInfo inp2  ,  MasterCraftVector multi_inp3 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processErrorEvent Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processErrorEvent after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processErrorEvent' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsPolicyInfo " + inp0
                    + " MbsoKomEventsEventInfo " + inp1 + " MbsoKomEventsElmntInfo " + inp2
                    + " Multirow of MbsoKomEventsIntdCommInfo " + multi_inp3);

            log.debug(" Calling function ' processErrorEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processErrorEvent(inp0, inp1, inp2, multi_inp3);

            log.debug(" Returned from function ' processErrorEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processErrorEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processErrorEvent  (   inp0, inp1, inp2, multi_inp3 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchECCteCreIntdList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0, Direction inp1,
            wcKomEventsCteIntdList inp2) {
        log.debug(" Entering function ' sh_fetchECCteCreIntdList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  Direction inp1  ,  wcKomEventsCteIntdList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchECCteCreIntdList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchECCteCreIntdList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchECCteCreIntdList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " Direction " + inp1 + " wcKomEventsCteIntdList " + inp2);

            log.debug(" Calling function ' fetchECCteCreIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchECCteCreIntdList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchECCteCreIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchECCteCreIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchECCteCreIntdList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fillEventForSellPractice(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsSellPrctSum inout0) {
        log.debug(" Entering function ' sh_fillEventForSellPractice ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsSellPrctSum inout0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fillEventForSellPractice Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fillEventForSellPractice after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fillEventForSellPractice' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsSellPrctSum " + inout0);

            log.debug(" Calling function ' fillEventForSellPractice  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.fillEventForSellPractice(inout0);

            log.debug(" Returned from function ' fillEventForSellPractice  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + inout0);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fillEventForSellPractice  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) inout0);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fillEventForSellPractice  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fillEventForServEntlt(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsServEntSum inout0) {
        log.debug(" Entering function ' sh_fillEventForServEntlt ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsServEntSum inout0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fillEventForServEntlt Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fillEventForServEntlt after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fillEventForServEntlt' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsServEntSum " + inout0);

            log.debug(" Calling function ' fillEventForServEntlt  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.fillEventForServEntlt(inout0);

            log.debug(" Returned from function ' fillEventForServEntlt  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + inout0);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fillEventForServEntlt  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) inout0);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fillEventForServEntlt  (   inout0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_delegateRetroEvent(ThreadSpecificContext tctx, MbsoKomEventsVATRetroInfo inp0) {
        log.debug(" Entering function ' sh_delegateRetroEvent ( ThreadSpecificContext tctx  MbsoKomEventsVATRetroInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside delegateRetroEvent Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside delegateRetroEvent after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'delegateRetroEvent' are : ");
            log.info(" MbsoKomEventsVATRetroInfo " + inp0);

            log.debug(" Calling function ' delegateRetroEvent  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            PmoKomEventsProcessor.delegateRetroEvent(inp0);

            log.debug(" Returned from function ' delegateRetroEvent  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :");
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' delegateRetroEvent  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                // if(jdbcCloseFlag)
                // ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' delegateRetroEvent  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processMAPolAdjEvt(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_processMAPolAdjEvt ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processMAPolAdjEvt Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processMAPolAdjEvt after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processMAPolAdjEvt' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' processMAPolAdjEvt  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processMAPolAdjEvt(inp0);

            log.debug(" Returned from function ' processMAPolAdjEvt  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processMAPolAdjEvt  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processMAPolAdjEvt  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_updateRetroVATEvtStatus(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsVATRetroInfo inp0) {
        log.debug(" Entering function ' sh_updateRetroVATEvtStatus ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsVATRetroInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside updateRetroVATEvtStatus Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside updateRetroVATEvtStatus after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'updateRetroVATEvtStatus' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsVATRetroInfo " + inp0);

            log.debug(" Calling function ' updateRetroVATEvtStatus  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.updateRetroVATEvtStatus(inp0);

            log.debug(" Returned from function ' updateRetroVATEvtStatus  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' updateRetroVATEvtStatus  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' updateRetroVATEvtStatus  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchRetroVATEvents(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsVATRetroInfo inp0, wcKomEventsRetroVatEvtList inp1,
            Direction inp2) {
        log.debug(" Entering function ' sh_fetchRetroVATEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsVATRetroInfo inp0  ,  wcKomEventsRetroVatEvtList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchRetroVATEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchRetroVATEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchRetroVATEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsVATRetroInfo " + inp0
                    + " wcKomEventsRetroVatEvtList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchRetroVATEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchRetroVATEvents(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchRetroVATEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchRetroVATEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchRetroVATEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchEIPList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCommEnqContext inp0, wcKomEventsCommEIPList inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchEIPList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCommEnqContext inp0  ,  wcKomEventsCommEIPList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchEIPList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchEIPList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchEIPList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCommEnqContext " + inp0
                    + " wcKomEventsCommEIPList " + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchEIPList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchEIPList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchEIPList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchEIPList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchEIPList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_pmoGetECPolAdjEvtInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_pmoGetECPolAdjEvtInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStore return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetECPolAdjEvtInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetECPolAdjEvtInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetECPolAdjEvtInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetECPolAdjEvtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetECPolAdjEvtInfo(inp0);

            log.debug(" Returned from function ' pmoGetECPolAdjEvtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetECPolAdjEvtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetECPolAdjEvtInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchReplEvents(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCEEInfo inp0, wcKomReplDtls inp1, Direction inp2) {
        log.debug(" Entering function ' sh_fetchReplEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCEEInfo inp0  ,  wcKomReplDtls inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchReplEvents Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchReplEvents after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchReplEvents' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCEEInfo " + inp0 + " wcKomReplDtls "
                    + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' fetchReplEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchReplEvents(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchReplEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchReplEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchReplEvents  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processMACEE(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsCEEInfo inp0, wcKomCEEDtls inp1, Direction inp2) {
        log.debug(" Entering function ' sh_processMACEE ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsCEEInfo inp0  ,  wcKomCEEDtls inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processMACEE Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processMACEE after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processMACEE' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsCEEInfo " + inp0 + " wcKomCEEDtls "
                    + inp1 + " Direction " + inp2);

            log.debug(" Calling function ' processMACEE  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.processMACEE(inp0, inp1, inp2);

            log.debug(" Returned from function ' processMACEE  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processMACEE  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processMACEE  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_processMACommEntlEvtType(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_processMACommEntlEvtType ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processMACommEntlEvtType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processMACommEntlEvtType after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processMACommEntlEvtType' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' processMACommEntlEvtType  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processMACommEntlEvtType(inp0);

            log.debug(" Returned from function ' processMACommEntlEvtType  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processMACommEntlEvtType  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processMACommEntlEvtType  (   inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchReplEvntList(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            Direction inp0, MbsoKomEventsCommEnqContext inp1, wcKomReplList inp2) {
        log.debug(" Entering function ' sh_fetchReplEvntList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  Direction inp0  ,  MbsoKomEventsCommEnqContext inp1  ,  wcKomReplList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchReplEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchReplEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchReplEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0
                    + " MbsoKomEventsCommEnqContext " + inp1 + " wcKomReplList " + inp2);

            log.debug(" Calling function ' fetchReplEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchReplEvntList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchReplEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchReplEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchReplEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_moveToBlockStore(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            MbsoKomEventsErrWaitStore inp0, MbsoKomEventsErrWaitStoreListSearch inp1) {
        log.debug(" Entering function ' sh_moveToBlockStore ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0  ,  MbsoKomEventsErrWaitStoreListSearch inp1 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside moveToBlockStore Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside moveToBlockStore after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'moveToBlockStore' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0
                    + " MbsoKomEventsErrWaitStoreListSearch " + inp1);

            log.debug(" Calling function ' moveToBlockStore  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.moveToBlockStore(inp0, inp1);

            log.debug(" Returned from function ' moveToBlockStore  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' moveToBlockStore  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' moveToBlockStore  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    // Added for new cge Event

    public MasterCraftretClass sh_fetchCGEListForEChange(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, Direction inp0, MbsoKomEventsSalsECSum inp1,
            wcKomEventsTransCgeList inp2) {
        log.debug(" Entering function ' sh_fetchcgeEvntList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  Direction inp0  ,  MbsoKomEventsSalsECSum inp1  ,  wcKomEventsTransCgeList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchcgeEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchcgeEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchcgeEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0 + " MbsoKomEventsSalsECSum "
                    + inp1 + " wcKomEventsTransCgeList " + inp2);

            log.debug(" Calling function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchCGEListForEChange(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_fetchCGEElementList(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, Direction inp0, MbsoKomEventsSalsECSum inp1,
            wcKomEventsTransCgeList inp2) {
        log.debug(" Entering function ' sh_fetchcgeEvntList ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  Direction inp0  ,  MbsoKomEventsSalsECSum inp1  ,  wcKomEventsTransCgeList inp2 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchcgeEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchcgeEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchcgeEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0 + " MbsoKomEventsSalsECSum "
                    + inp1 + " wcKomEventsTransCgeList " + inp2);

            log.debug(" Calling function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            multi_return1 = inst_PmoKomEventsProcessor.fetchCGEElementList(inp0, inp1, inp2);

            log.debug(" Returned from function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_validateCRESpecialReinstatement(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, Direction inp0, MbsoKomEventsSalsECSum inp1,
            wcKomEventsTransCgeList inp2) {
        boolean creSpecialReinstatementStatus = true;
        log.debug(" Entering function ' sh_validateCRESpecialReinstatement ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        Boolean multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchcgeEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchcgeEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchcgeEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Direction " + inp0 + " MbsoKomEventsSalsECSum "
                    + inp1 + " wcKomEventsTransCgeList " + inp2);

            log.debug(" Calling function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");

            multi_return1 = inst_PmoKomEventsProcessor.validateCRESpecialReinstatement(inp0, inp1, inp2);

            // creSpecialReinstatementStatus =
            // inst_PmoKomEventsProcessor.validateCRESpecialReinstatement (
            // inp0, inp1, inp2 );

            log.debug(" Returned from function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public MasterCraftretClass sh_updateElement(ThreadSpecificContext tctx, PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            ElementInfo inp1) {
        boolean creSpecialReinstatementStatus = true;
        log.debug(" Entering function ' sh_validateCRESpecialReinstatement ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MasterCraftVector multi_return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchcgeEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchcgeEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'fetchcgeEvntList' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsElmntInfo  " + inp1);

            log.debug(" Calling function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");

            multi_return1 = inst_PmoKomEventsProcessor.updateElement(inp1);

            // creSpecialReinstatementStatus =
            // inst_PmoKomEventsProcessor.updateElement ( inp1 );

            log.debug(" Returned from function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + multi_return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) multi_return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' fetchcgeEvntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.

    public List<ReplacementActiveInformation> sh_retrieveReplacementPolicies(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, String policyNumber) {

        log.debug(" Entering function ' sh_retrieveReplacementPolicies");

        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;

        List<ReplacementActiveInformation> replacementPolicies = new ArrayList<ReplacementActiveInformation>();

        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) {
            ServerContext.setDataSource(dataSource);
        } else {
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside retrieveReplacementPolicies Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            replacementPolicies = inst_PmoKomEventsProcessor.retrieveReplacementPolicies(policyNumber);

            log.debug(" Returned from function ' fetchPymtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + replacementPolicies);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' retrieveReplacementPolicies : returns replacementPolicies' of class PmoKomEventsProcessor ";
            Exception mce = new Exception(errMsg, e);
            log.error(errMsg, mce);
        }

        return replacementPolicies;

    }

    public boolean sh_updateReplacementPolicyApplyIndicator(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, List<ReplacementActiveInformation> replacementPolicies) {
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;

        boolean couldUpdate = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }
        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside fetchcgeEvntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside fetchcgeEvntList after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }
        try {
            couldUpdate = inst_PmoKomEventsProcessor.updateReplacementPolicyApplyIndicator(replacementPolicies);
            _messageTyp.setValue(ServerContext.getMaxSeverity());
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' updateReplacementPolicyApplyIndicator' of class PmoKomEventsProcessor ";
            log.error(errMsg + e.getMessage());
        } finally {
            try {
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) {
                    executeWarningCheck(_messageTyp);
                }

                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' updateReplacementPolicyApplyIndicator ' of class PmoKomEventsProcessor ";
                log.debug(errMsg);

            }
        } // End of finally block
        return couldUpdate;
    }

    public boolean sh_insertReplacementPolicyHistoryInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor,
            List<ReplacementActiveHistory> replacementHistoryPolicies) {

        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        boolean insertRecord = false;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }
        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                ServerContext.setDataSource(dataSource);
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }
        try {
            insertRecord = inst_PmoKomEventsProcessor.insertReplacementPolicyHistoryInfo(replacementHistoryPolicies);
            _messageTyp.setValue(ServerContext.getMaxSeverity());
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' insertReplacementPolicyHistoryInfo' of class PmoKomEventsProcessor ";
            log.error(errMsg + e.getMessage());
        } finally {
            try {
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) {
                    executeWarningCheck(_messageTyp);
                }

                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' updateReplacementPolicyApplyIndicator ' of class PmoKomEventsProcessor ";
                log.debug(errMsg);
            }
        }
        return insertRecord;

    }
    
    public MasterCraftretClass sh_processErrorWaitStoreEventsRetro(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MasterCraftVector multi_inp0) {
        log.debug(" Entering function ' sh_processWaitStoreEvents ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MasterCraftVector multi_inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside processErrorWaitStoreEventsRetro Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside processErrorWaitStoreEventsRetro after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'processErrorWaitStoreEventsRetro' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Multirow of MbsoKomEventsErrWaitStore "
                    + multi_inp0);

            log.debug(" Calling function ' processErrorWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.processWaitStoreEventsRetro(multi_inp0);

            log.debug(" Returned from function ' processErrorWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' processErrorWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' processErrorWaitStoreEvents  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.
    
    public MasterCraftretClass sh_pmoGetErrWaitStoreInfo(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStore inp0) {
        log.debug(" Entering function ' sh_pmoGetErrWaitStoreInfo ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStore return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetErrWaitStoreInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetErrWaitStoreInfo after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetErrWaitStoreInfo' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetErrWaitStoreInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            return1 = inst_PmoKomEventsProcessor.pmoGetErrWaitStoreInfo(inp0);

            log.debug(" Returned from function ' pmoGetErrWaitStoreInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetErrWaitStoreInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetErrWaitStoreInfo  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.
    
    public MasterCraftretClass sh_pmoGetErrWaitStoreInfoRetro(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MbsoKomEventsErrWaitStoreRetro inp0) {
        log.debug(" Entering function ' sh_pmoGetErrWaitStoreInfoRetro ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MbsoKomEventsErrWaitStore inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();
        MbsoKomEventsErrWaitStoreRetro return1 = null;

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside pmoGetErrWaitStoreInfoRetro Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside pmoGetErrWaitStoreInfoRetro after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'pmoGetErrWaitStoreInfoRetro' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " MbsoKomEventsErrWaitStore " + inp0);

            log.debug(" Calling function ' pmoGetErrWaitStoreInfoRetro  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
           return1 = inst_PmoKomEventsProcessor.pmoGetErrWaitStoreInfoRetro(inp0);

            log.debug(" Returned from function ' pmoGetErrWaitStoreInfoRetro  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor + return1);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' pmoGetErrWaitStoreInfoRetro  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);
                MCretObj.getOutParameters().append((Object) return1);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' pmoGetErrWaitStoreInfoRetro  (   inp0 )  : returns return1 ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function call.
    
    
    public MasterCraftretClass sh_handleWaitStoreEventsRetro(ThreadSpecificContext tctx,
            PmoKomEventsProcessor inst_PmoKomEventsProcessor, MasterCraftVector multi_inp0) {
        log.debug(" Entering function ' sh_handleWaitStoreEventsRetro ( ThreadSpecificContext tctx , PmoKomEventsProcessor inst_PmoKomEventsProcessor  MasterCraftVector multi_inp0 ) : returns MasterCraftretClass ' of class KomEventsBEAN ");
        ErrorType _messageTyp = new ErrorType();
        boolean jdbcCloseFlag = false;
        MasterCraftretClass MCretObj = new MasterCraftretClass();

        jdbcCloseFlag = false;
        if (tctx != null && tctx.getRemoteInd() == true) {
            MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
            ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
            tctx = null;
        }

        ServerContext.setPrintEnabled(bIsPrintEnabled);
        ServerContext.setErrMsgFile(sErrMsgFileName);
        if (tctx != null) {
            ServerContext.setServerContextObject(tctx);
        } else {
            ServerContext.clearMessages();
            jdbcCloseFlag = true;
        }

        if (sessionctx != null) {
            ServerContext.setContext(sessionctx);
        }

        if (tctx == null) { // call from web tier
            ServerContext.setDataSource(dataSource);
        } else { // inter bean call
            if (tctx.getDataSource() == null) {
                log.info("WARNING Inside handleWaitStoreEventsRetro Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
                ServerContext.setDataSource(dataSource);
                log.info("Inside handleWaitStoreEventsRetro after resetting Datasource in ThreadSpecificContext");
            }
        }

        if (dataDir != null) {
            ServerContext.setDataDir(dataDir);
        }

        try {
            log.info(" The parameters passed to the operation 'handleWaitStoreEventsRetro' are : ");
            log.info(" PmoKomEventsProcessor " + inst_PmoKomEventsProcessor + " Multirow of wcKomEventsErrWaitList " + multi_inp0);

            log.debug(" Calling function ' handleWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            inst_PmoKomEventsProcessor.handleWaitStoreEventsRetro(multi_inp0);

            log.debug(" Returned from function ' handleWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ");
            _messageTyp.setValue(ServerContext.getMaxSeverity());

            log.info(" ERRORTYPE retuned is :" + _messageTyp);
            log.info(" Inout and Out parameters are :" + inst_PmoKomEventsProcessor);
        } catch (Exception e) {
            String errMsg = "Error encountered in function ' handleWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
            MasterCraftException mce = new MasterCraftException(errMsg, e);
            throw mce;
        }

        finally {
            try {
                MCretObj.getOutParameters().append((Object) inst_PmoKomEventsProcessor);

                MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
                MCretObj.setMCClientContext(cctemp);
                boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
                if (((_messageTyp.getValue() == _messageTyp.XL_WARNING) && (noWarningFlag != true))
                        || (_messageTyp.getValue() > _messageTyp.XL_WARNING)) {
                    log.info(" About to abort the current transaction ");
                    sessionctx.setRollbackOnly();
                } else if (ServerContext.checkWarning() == true) // only if
                                                                 // there are
                                                                 // warnings do
                                                                 // these
                {
                    executeWarningCheck(_messageTyp);
                }

                MCretObj.setReturnStatus(_messageTyp);
                MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
                ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
                if (jdbcCloseFlag)
                    ServerContext.clearServerContext();
            } catch (Exception e) {
                String errMsg = "Error encountered in function ' handleWaitStoreEventsRetro  (   multi_inp0 )  : returns void ' of class PmoKomEventsProcessor ";
                MasterCraftException mce = new MasterCraftException(errMsg, e);
                throw mce;
            }
        } // End of finally block
        return MCretObj;
    } // closure of opening of sh_.. shell function ca
}

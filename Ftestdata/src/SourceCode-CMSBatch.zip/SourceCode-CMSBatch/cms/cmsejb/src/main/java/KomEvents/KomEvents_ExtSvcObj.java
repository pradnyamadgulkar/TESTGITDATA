// ======================================================================
// This is the External Service Object to the Bean -- "KomEventsBEAN"
// ======================================================================
package KomEvents;

import Domains.*;
import ErrorMessages.*;
import javax.ejb.*;
import javax.naming.*;
import java.util.*;
import java.io.*;
import java.lang.*;
import java.math.*;
import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mcutil.* ;
import com.tcs.mastercraft.mctype.errlib.*;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import KomEventsRef.*;
import KomEventsRules.*;
import KomSecurity.*;

public class KomEvents_ExtSvcObj
{
	private static Context Initial_Context = null;
	private static Hashtable ejbHomeObjectTable = new Hashtable();
	private static final ILogger log = LoggerFactory.getLogger(KomEvents_ExtSvcObj.class) ; 

	public static Context getInitialContext( ) 
	{
		if ( log.isDebugEnabled())
		{
			log.debug(" Entering function 'getInitialContext( ) : returns Context' of class KomEvents_ExtSvcObj ");
		}
		try
		{
			if(Initial_Context == null)
			{
				Initial_Context =  new InitialContext();
			}
		}
		catch( Exception ex )
		{
			if(!(ex instanceof MasterCraftException))
			{
				MasterCraftException mce = new MasterCraftException ( " Error encountered while doing a lookup for the Context " , ex );
			throw mce;
			}
			else
			{
				throw (MasterCraftException)ex;
			}
		}
		if ( log.isDebugEnabled())
		{
			log.debug(" Returning from function 'getInitialContext( ) : returns Context' of class KomEvents_ExtSvcObj ");
		}
		return Initial_Context;
	}


	public static synchronized EJBLocalHome getEJBLocalHomeObject( String compName, String beanName ) 
	{
		if ( log.isDebugEnabled())
		{
			log.debug(" Entering function 'getEJBLocalHomeObject( String compName, String beanName ) : returns EJBLocalHome ' of class KomEvents_ExtSvcObj ");
		}
		Context ctx = getInitialContext();

		StringBuffer ejbHomeClass = new StringBuffer( compName );
		ejbHomeClass.append( "." );
		ejbHomeClass.append( beanName );
		ejbHomeClass.append( "BEAN_LOCAL_HOME_INTF" );

		beanName = "Local" + beanName;

		String ejbHomeClassNameObj = ejbHomeClass.toString();

		EJBLocalHome ejbHomeObj = null;

		ejbHomeObj = ( EJBLocalHome )ejbHomeObjectTable.get( ejbHomeClassNameObj );
		if ( ejbHomeObj == null )
		{
			if ( log.isDebugEnabled())
			{
				log.debug(" EJB Home Object not found in Cache.");
				log.debug("  Lookingup for EJB Home Object : " + ejbHomeClass );
			}

			try
			{
				ejbHomeObj = ( EJBLocalHome )(ctx.lookup( beanName ));
			}
			catch( Exception e )
			{
				try
				{
					StringBuffer newStr1 = new StringBuffer( "ejb/" );
					newStr1.append( beanName );
					if ( log.isDebugEnabled())
					{
						log.debug(" The String created while doing a lookup of the context is " + newStr1 );
					}
					ejbHomeObj = ( EJBLocalHome )( ctx.lookup( newStr1.toString() ) );
				}
				catch( Exception ex1 )
				{
					try
					{
						StringBuffer newStr1 = new StringBuffer( "java:comp/env/" );
						newStr1.append( beanName );
						if ( log.isDebugEnabled())
						{
							log.debug(" The String created while doing a lookup of the context is " + newStr1 );
						}
						ejbHomeObj = ( EJBLocalHome )( ctx.lookup( newStr1.toString() ) );
					}
					catch( Exception ex2 )
					{
						try
						{
							StringBuffer newStr1 = new StringBuffer( "java:comp/env/ejb/" );
							newStr1.append( beanName );
							if ( log.isDebugEnabled())
							{
								log.debug(" The String created while doing a lookup of the context is " + newStr1 );
							}
							ejbHomeObj = ( EJBLocalHome )( ctx.lookup( newStr1.toString() ) );
						}
						catch( Exception ex3 )
						{
							if(!(ex3 instanceof MasterCraftException))
								{
									MasterCraftException mce = new MasterCraftException ( " Error encountered while doing a lookup for the Context " , ex3 );
									throw mce;
								}
							else
							{
								throw (MasterCraftException)ex3;
							}
						}
					}
				}
			}
			ejbHomeObjectTable.put( ejbHomeClassNameObj, ejbHomeObj );
		}
		else
		{
			if ( log.isDebugEnabled())
			{
				log.debug(" EJB Home Object found in the Cache... ");
				log.debug(" Avoiding lookup for EJB Home Object : " +  ejbHomeClass );
			}
		}
		if ( log.isDebugEnabled())
		{
			log.debug(" Returning from function 'getEJBLocalHomeObject( String compName, String beanName ) : returns EJBLocalHome ' of class KomEvents_ExtSvcObj ");
		}

		return ( ejbHomeObj );
	}

}

// ***********************************************************
// This is a Bean class
// "LocalKomEventsRules" is the name of the Bean which will be implemented
// ***********************************************************

package KomEventsRules;
import Domains.*;
import ErrorMessages.*;
import javax.ejb.Timer;
import javax.ejb.*;
import java.util.*;
import MCExtClasses.*;
import KomEventsRules.wcKomRulesList;
import KomEventsRules.MbsoKomRulesMasterInfo;
import Domains.Direction;
import KomEventsRules.PmoKomRulesProcessor;

import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.*;
import com.tcs.mastercraft.mcutil.* ;
import java.io.*;
import java.text.*;
import java.math.*;
import java.sql.*;
import ErrLogging.*;
import javax.naming.*;
import javax.transaction.*;
import java.util.Date;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import java.rmi.RemoteException;
import java.rmi.Remote;
//*************** DPM 45839 Starts 
import java.net.*;
//*************** DPM 45839 Ends
public class KomEventsRulesBEAN implements SessionBean , TimedObject
{
	private SessionContext sessionctx = null;
	private transient javax.sql.DataSource dataSource = null;
	private String dataDir;
	EJBContext ejbContext = null;
	/* This attribute sets the printEnabled property read from ejb environment */
	private boolean bIsPrintEnabled = false ; /// default is false 
	/*Name of the error message file to be used for reading the message description for error message id .	*/
	private String sErrMsgFileName = "ShortErrorList";

	private static final ILogger log = LoggerFactory.getLogger(KomEventsRulesBEAN.class) ;

	/**
	* This method is required by the EJB Specification,
	* but is not used by this bean.
	*
	*/
	public void ejbActivate()
	{
		log.debug(" Inside the function 'ejbActivate() : returns void' of class KomEventsRulesBEAN required by EJB ");
	}

	/**
	* This method is required by the EJB Specification,
	* but is not used by this bean.
	*
	*/
	public void ejbPassivate()
	{
		log.debug(" Inside the function 'ejbPassivate() : returns void' of class KomEventsRulesBEAN required by EJB ");
	}

	// Sets the session context
	public void setSessionContext(SessionContext sessionctx)
	{
		log.debug(" Entering function 'setSessionContext(SessionContext sessionctx) : returns void' of class KomEventsRulesBEAN ");
		if ( sessionctx != null )
			this.sessionctx = sessionctx;

		InitialContext envCtx = null;
		try
		{
			envCtx = new InitialContext();
			String printEnabledFlag = ( String ) envCtx.lookup( "java:comp/env/mastercraft.ejb.enablePrint" );
			bIsPrintEnabled = printEnabledFlag.equals( "Y" );
		}
		catch ( NamingException ne1 )
		{
			String errMsg = "Error encountered while looking up for environment value 'mastercraft.ejb.enablePrint'";
			MasterCraftException mce = new MasterCraftException ( errMsg , ne1 );
			throw mce;
		}

		try
		{
			// DPM 45839 Starts
			//sErrMsgFileName = ( String ) envCtx.lookup( "java:comp/env/mastercraft.ejb.ErrMsgFile" );
			InitialContext initCtx = new InitialContext();
            URL url = (java.net.URL) initCtx.lookup("java:comp/env/url/mcappkom/ConfigPropertiesURL");
            URLConnection conn = url.openConnection();
    		InputStream is = conn.getInputStream();
    		Properties properties = new Properties();
    		properties.load( is );
    		sErrMsgFileName=properties.getProperty("mastercraft.ejb.ErrMsgFile");    		
    		log.debug("sErrMsgFileName from prop file "+sErrMsgFileName);
		}
		catch ( NamingException ne2 )
		{
			String errMsg = "Error encountered while looking up for environment value 'mastercraft.ejb.ErrMsgFile'";
			MasterCraftException mce = new MasterCraftException ( errMsg , ne2 );
			throw mce;
		}catch (IOException ioe) {
        	System.out.println("IOException "+ioe);
        }
		//DPM 45839 Ends 
		log.info(" SessionContext has been set successfully ");
		log.debug(" Returning from function 'setSessionContext(SessionContext sessionctx) : returns void' of class KomEventsRulesBEAN ");
	}

	// There should be a corresponding method in the ENTERPRISE BEAN'S HOME INTERFACE
	// For UTCS this method will be invoked
	public void ejbCreate ()
	{
		log.debug(" Entering function 'ejbCreate () : returns void' of class KomEventsRulesBEAN ");
		try
		{
			ServerContext.setBeanContext(sessionctx, this);
			dataSource = ServerContext.getDataSource();
			dataDir = ServerContext.getDataDir();
		}
		catch ( Exception e )
		{
			String errMsg = " Error encountered while Setting the Bean Context of the ServerContext class in the funtion 'ejbCreate () : returns void' ";
			MasterCraftException mce = new MasterCraftException ( errMsg , e );
			throw mce;
		}

		log.debug(" Returning from function 'ejbCreate () : returns void' of class KomEventsRulesBEAN ");
	}

	/**
	* This method is required by the EJB Specification,
	* and is used to close JDBC Handle.
	*
	*/
	public void ejbRemove()
	{
		log.debug(" Entering function 'ejbRemove () : returns void' of class KomEventsRulesBEAN ");
		try
		{
			if ( ServerContext.getJDBCHandle() != null )
			{
				ServerContext.getJDBCHandle().close();
			}
			ServerContext.clearThreadContext();
		}
		catch (Exception e)
		{
			String errMsg = " Error encountered while Removing the Bean in function 'ejbRemove () : returns void'";
			MasterCraftException mce = new MasterCraftException ( errMsg , e );
			throw mce;
		}
		log.debug(" Returning from function 'ejbRemove () : returns void' of class KomEventsRulesBEAN ");
	}

	/**
	* This method is required by the EJB Specification,
	* but is not used by this bean.
	*
	*/
	public void ejbLocate ()
	{
		log.debug(" Inside the function 'ejbLocate() : returns void' of class KomEventsRulesBEAN required by EJB ");
	}

	public void executeWarningCheck(ErrorType _messageTyp) 
	{
		Vector MsgVec = new Vector ();
		int size = ServerContext.getMESSAGE_ARRAY().nElem();
		int i = 0;
		for (i=0; i< size; i++)
		{
			MESSAGE messg = new MESSAGE ();
			messg = (MESSAGE)ServerContext.getMESSAGE_ARRAY().get(i) ;
			if (messg.getMessageType() == _messageTyp.XL_WARNING)
			{
				MsgVec.addElement(messg);
			}
		}
		/*  compare all the ids in the passed warning array from gui with the present warning ids
		take a new warning, compare with all passed ids, if matches, compare description, if that also matches, it is old,
		if it doesn't, then it is a new warning, so rollback
		if new warning id does not match with passed warning ids, then its new, so rollback */
		int WarVecsize = MsgVec.size();
		Vector ignoredWarnings = new Vector();
		ignoredWarnings = ServerContext.getServerContextObject().getMasterCraftClientContext().getIgnoredWarnings();
		int IgnoredWarSize = ignoredWarnings.size();
		int j = 0;
		int exists = 0;
		loop1 : for (j=0;j < WarVecsize; j++) //for new warnings
		{
			MESSAGE msg = new MESSAGE();
			msg = (MESSAGE)MsgVec.elementAt(j);
			int NewWarningCode = msg.getCode();
			Vector tmpVecNew = new Vector();
			tmpVecNew.addElement(msg);
			int k=0;
			loop2 : for (k=0; k<IgnoredWarSize ; k++) //for ignored warnings
			{
				MESSAGE IgnoredMsg = new MESSAGE();
				IgnoredMsg = (MESSAGE)ignoredWarnings.elementAt(k);
				Vector tmpVecIgnored = new Vector();
				tmpVecIgnored.addElement(IgnoredMsg);
				int IgnoredWarningCode = IgnoredMsg.getCode();
				if (NewWarningCode == IgnoredWarningCode )
				{
					String IgnoredWarningDescription = utsErrMsg.showMsg(tmpVecIgnored,sErrMsgFileName);
					String NewWarningDescription = utsErrMsg.showMsg(tmpVecNew,sErrMsgFileName);
					if (NewWarningDescription.equals(IgnoredWarningDescription))
					{
						exists = 1;
						break loop2;
					}
					else
					{
						log.debug("About to Abort");
						sessionctx.setRollbackOnly();
						break loop1;
					}
				}
			}
			if (exists == 0) // warning did not match any ignored warning, so it is a new warning
			{
				log.debug("About to Abort");
				sessionctx.setRollbackOnly();
				break loop1;
			}
		}
		try
		{
			if (!sessionctx.getRollbackOnly())
			{
				logIgnoredWarnings("Tbl_ignoredWarnings");
			}
		}
		catch (Exception e)
		{
			String errMsg = "Error in logging ignored warnings to Tbl_ignoredWarnings";
			MasterCraftException mce = new MasterCraftException ( errMsg , e );
			throw mce;
		}
	}
	public void logIgnoredWarnings(String TableName) 
	{
		int retcode= 0;
		String Warning = new String();
		StringBuffer h_SqlStmt = new StringBuffer (20000);
		int index;
		Vector ignoredWarningsVector = ServerContext.getServerContextObject().getMasterCraftClientContext().getIgnoredWarnings();
		if(ignoredWarningsVector != null && ignoredWarningsVector.size()!=0 )
		{
			Warning = utsErrMsg.showMsg(ignoredWarningsVector,sErrMsgFileName);
		}

		String local = new String ( " INSERT INTO " + TableName + " VALUES ('" + ServerContext.getServerContextObject().getMasterCraftClientContext().getUserId().toString() + "'," + ServerContext.getServerContextObject().getMasterCraftClientContext().getServiceId() + ",'" + ServerContext.getServerContextObject().getMasterCraftClientContext().getTransactionId().toString() + "','" + ServerContext.getServerContextObject().getMasterCraftClientContext().getAppTimeStamp().toString() + "','" + Warning + "'" );
		h_SqlStmt.replace( 0,local.length(), local );
		h_SqlStmt.append ( " ) " );
		String sqlStmt = h_SqlStmt.toString();

		try
		{
			PreparedStatement pstmt = ServerContext.getJDBCHandle().prepareStatement(sqlStmt );
			int retValue =  pstmt.executeUpdate( );
			pstmt.close();
		}

		catch ( SQLException ex )
		{
			retcode = ex.getErrorCode ();
			if( retcode == DM_err.ORA_TABLE_DOESNOTEXISTS || retcode == DM_err.SQLSERVER_TABLE_DOESNOTEXISTS )
			{
				log.debug("Table not found " + TableName.toString());
			}
			String errMsg = "Error in logging ignored warnings to Tbl_ignoredWarnings";
			MasterCraftException mce = new MasterCraftException ( errMsg , ex );
			throw mce;
		}
	/* clear the array being returned to GUI */
		ServerContext.clearMessages();
	}
	//This method will be called by the EJB Container after the Timer expires.
	public void ejbTimeout(javax.ejb.Timer timer_expired)
	{
		log.debug(" Entering function ' ejbTimeout ( Timer timer_expired ) : returns void ' of class TesterCompBEAN ");

		try
		{
			if(ServerContext.getContext( ) == null && sessionctx != null)
			{
				ServerContext.setContext( sessionctx );
			}
	
			EJBTimer.ejbTimeout(timer_expired);
		}
		catch(Exception ex)
		{
			String errMsg = "Error encountered in function ' ejbTimeout ( )  : returns void ' ";
			MasterCraftException mce = new MasterCraftException ( errMsg , ex );
			throw mce;
		}
	}

	public MasterCraftretClass sh_processAllRules ( ThreadSpecificContext tctx , PmoKomRulesProcessor inst_PmoKomRulesProcessor  ,MbsoKomRulesMasterInfo inp0 )
	{
		log.debug(" Entering function ' sh_processAllRules ( ThreadSpecificContext tctx , PmoKomRulesProcessor inst_PmoKomRulesProcessor  MbsoKomRulesMasterInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRulesBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside processAllRules Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside processAllRules after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'processAllRules' are : ");
				log.info( " PmoKomRulesProcessor " + inst_PmoKomRulesProcessor + " MbsoKomRulesMasterInfo " + inp0 );

				log.debug(" Calling function ' processAllRules  (   inp0 )  : returns void ' of class PmoKomRulesProcessor ");
				inst_PmoKomRulesProcessor.processAllRules (  inp0 );

				log.debug(" Returned from function ' processAllRules  (   inp0 )  : returns void ' of class PmoKomRulesProcessor ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomRulesProcessor );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' processAllRules  (   inp0 )  : returns void ' of class PmoKomRulesProcessor ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomRulesProcessor);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' processAllRules  (   inp0 )  : returns void ' of class PmoKomRulesProcessor ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRules ( ThreadSpecificContext tctx , PmoKomRulesProcessor inst_PmoKomRulesProcessor  ,MbsoKomRulesMasterInfo inp0  ,Direction inp1  ,wcKomRulesList inp2 )
	{
		log.debug(" Entering function ' sh_fetchRules ( ThreadSpecificContext tctx , PmoKomRulesProcessor inst_PmoKomRulesProcessor  MbsoKomRulesMasterInfo inp0  ,  Direction inp1  ,  wcKomRulesList inp2 ) : returns MasterCraftretClass ' of class KomEventsRulesBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRules Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRules after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRules' are : ");
				log.info( " PmoKomRulesProcessor " + inst_PmoKomRulesProcessor + " MbsoKomRulesMasterInfo " + inp0 + " Direction " + inp1 + " wcKomRulesList " + inp2 );

				log.debug(" Calling function ' fetchRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomRulesProcessor ");
				multi_return1 = inst_PmoKomRulesProcessor.fetchRules (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomRulesProcessor ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomRulesProcessor + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomRulesProcessor ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomRulesProcessor);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomRulesProcessor ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_pmoGetRuleMasterInfo ( ThreadSpecificContext tctx , PmoKomRulesProcessor inst_PmoKomRulesProcessor  ,MbsoKomRulesMasterInfo inp0 )
	{
		log.debug(" Entering function ' sh_pmoGetRuleMasterInfo ( ThreadSpecificContext tctx , PmoKomRulesProcessor inst_PmoKomRulesProcessor  MbsoKomRulesMasterInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRulesBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MbsoKomRulesMasterInfo return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside pmoGetRuleMasterInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside pmoGetRuleMasterInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'pmoGetRuleMasterInfo' are : ");
				log.info( " PmoKomRulesProcessor " + inst_PmoKomRulesProcessor + " MbsoKomRulesMasterInfo " + inp0 );

				log.debug(" Calling function ' pmoGetRuleMasterInfo  (   inp0 )  : returns return1 ' of class PmoKomRulesProcessor ");
				return1 = inst_PmoKomRulesProcessor.pmoGetRuleMasterInfo (  inp0 );

				log.debug(" Returned from function ' pmoGetRuleMasterInfo  (   inp0 )  : returns return1 ' of class PmoKomRulesProcessor ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomRulesProcessor + return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' pmoGetRuleMasterInfo  (   inp0 )  : returns return1 ' of class PmoKomRulesProcessor ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomRulesProcessor);
			MCretObj.getOutParameters().append((Object) return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' pmoGetRuleMasterInfo  (   inp0 )  : returns return1 ' of class PmoKomRulesProcessor ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.
}

// ## User-required Class description could start here onwards
// *******************************************************************
// * Class Name			: KomNotifier.java
// * Description			:
// * Revision History		: Date          Author         Change Made
// *					 ------------------------------------------
// *
// *******************************************************************
// ## End of User-required Class description
// ## MasterCraft generated code starts here
// ## This code should not be changed
package KomEvents;
import Domains.*;
import ErrorMessages.*;
import KomEventsRef.MbsoKomEventsRefVestingScales;
import KomEventsRef.MbsoKomEventsRefMultiplicationFactor;
import KomEventsRef.MbsoKomEventsRefVestingRules;
import KomEventsRef.MbsoKomEventsRefSplitCommSchdType;
import KomEventsRef.MbsoKomEventsRefScorePattern;
import Domains.Direction;
import MCExtClasses.*;
import javax.ejb.Timer;
import javax.ejb.*;
import java.util.*;
import org.w3c.dom.*;
import java.lang.*;
import java.sql.*;
import java.io.*;
import java.text.*;
import java.math.*;
import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.*;
import com.tcs.mastercraft.mcutil.* ;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import CommonFunctionality.*;
// ## User-required import statements could start here onwards


// ## End of User-required import statements

/**

*/
public class KomNotifier extends MasterCraftObject implements java.io.Serializable 
{
	// Following are the Class Attributes
	/**
	* Defines and initializes the commons-logging logger with the class name
	*/
	private static final ILogger log = LoggerFactory.getLogger( KomNotifier.class ) ;


	private MasterCraftBitSet specFlag;
	private MasterCraftBitSet updspecFlag;

		// ## User-required attribute declaration could start here onwards


		// ## End of User-required attribute declarations


	// This is a Default Constructor
	/**
	*
	*/
	public KomNotifier ( )
	{
		if ( log.isDebugEnabled())
		{
			log.debug(" Entering Constructor 'KomNotifier ( )' of class KomNotifier ");
		}
		specFlag = new MasterCraftBitSet(0);
		updspecFlag = new MasterCraftBitSet(0);

		// ## User-required statements for Constructor could start here onwards

		// ## End of User-required statements for Constructor

		if ( log.isDebugEnabled())
		{
			log.debug(" Returning from Constructor 'KomNotifier ( )' of class KomNotifier ");
		}
	}

	// DeepCopy Constructor
	/**
	*@param inst_KomNotifier
	*/
	public void deepcopy(Object inst_KomNotifier) 
	{
		if ( inst_KomNotifier instanceof  KomNotifier )
		{
			KomNotifier __KomNotifier_obj = ( KomNotifier ) inst_KomNotifier;

			specFlag.deepcopy( __KomNotifier_obj.specFlag);
		}
	}
/**
*@param spec
*/

	public void setspecFlag( MasterCraftBitSet spec ) 
	{
		specFlag.deepcopy(spec);
	}
/**
*@return specflag
*/

	public MasterCraftBitSet getspecFlag( )
	{
		return specFlag ;
	}
	/**
	*
	*/

	public void unmarkAll ()
	{
		specFlag.resetAll();
	}

	/**
	*@return Description string
	*/
	public String toString ( )
	{
		StringBuffer s =new StringBuffer();
		s = s.append( MasterCraftConstants.lineSeparator ).append( "Class KomNotifier : " );
		s = s.append( MasterCraftConstants.lineSeparator ).append( "specFlag = " ).append( specFlag.toString() ).append( " (MasterCraftBitSet) " ) ;
		s = s.append( MasterCraftConstants.lineSeparator ).append( "END OF KomNotifier " ).append( MasterCraftConstants.lineSeparator).append( MasterCraftConstants.lineSeparator );
		return s.toString();
	}
// ## End of MasterCraft generated code



	// ## Signature of notifyAdmin_164292 method should not be changed
	/**

	 */
	/**
	*@param  MbsoKomEventsEventController ip_mbsoKomEventsEventController
	*/
	public static void notifyAdmin ( MbsoKomEventsEventController ip_mbsoKomEventsEventController  )	{
		log.debug(" Entering function 'notifyAdmin(MbsoKomEventsEventController ip_mbsoKomEventsEventController) : returns void' of class KomNotifier ");
		ServerContext.setRetError( new ErrorType() );
		// ## Add your code for notifyAdmin_164292 method here
		

		log.debug(" Returning from function 'notifyAdmin(MbsoKomEventsEventController ip_mbsoKomEventsEventController) : returns void' of class KomNotifier ");
		
	}
	// ## End of notifyAdmin_164292 method
	// ## User-required operation declaration could start here onwards

	// Sample format to add an operation
	// public void ExampleOperation( int Param1, StringBuffer Param2 )
	// {
		//		CODE_START


		//		CODE_END
	// }

	// ## End of User-required operation declarations

}

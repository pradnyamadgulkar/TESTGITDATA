// ## User-required Class description could start here onwards
// *******************************************************************
// * Class Name			: KomAgtCaller.java
// * Description			:
// * Revision History		: Date          Author         Change Made
// *					 ------------------------------------------
// *
// *******************************************************************
// ## End of User-required Class description
// ## MasterCraft generated code starts here
// ## This code should not be changed
package KomEvents;
import Domains.*;
import ErrorMessages.*;
import KomEventsRef.MbsoKomEventsRefVestingScales;
import KomEventsRef.MbsoKomEventsRefMultiplicationFactor;
import KomEventsRef.MbsoKomEventsRefVestingRules;
import KomEventsRef.MbsoKomEventsRefSplitCommSchdType;
import KomEventsRef.MbsoKomEventsRefScorePattern;
import Domains.Direction;
import MCExtClasses.*;
import javax.ejb.Timer;
import javax.ejb.*;
import java.util.*;
import org.w3c.dom.*;
import java.lang.*;
import java.sql.*;
import java.io.*;
import java.text.*;
import java.math.*;
import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.*;
import com.tcs.mastercraft.mcutil.* ;

import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import CommonFunctionality.*;
// ## User-required import statements could start here onwards
//Sanlam Component
import za.co.sanlam.agt.intermediary.Intermediary;


// ## End of User-required import statements

/**

*/
public class KomAgtCaller extends MasterCraftObject implements java.io.Serializable 
{
	// Following are the Class Attributes
	/**
	* Defines and initializes the commons-logging logger with the class name
	*/
	private static final ILogger log = LoggerFactory.getLogger( KomAgtCaller.class ) ;


	private MasterCraftBitSet specFlag;
	private MasterCraftBitSet updspecFlag;

		// ## User-required attribute declaration could start here onwards


		// ## End of User-required attribute declarations


	// This is a Default Constructor
	/**
	*
	*/
	public KomAgtCaller ( )
	{
		if ( log.isDebugEnabled())
		{
			log.debug(" Entering Constructor 'KomAgtCaller ( )' of class KomAgtCaller ");
		}
		specFlag = new MasterCraftBitSet(0);
		updspecFlag = new MasterCraftBitSet(0);

		// ## User-required statements for Constructor could start here onwards

		// ## End of User-required statements for Constructor

		if ( log.isDebugEnabled())
		{
			log.debug(" Returning from Constructor 'KomAgtCaller ( )' of class KomAgtCaller ");
		}
	}

	// DeepCopy Constructor
	/**
	*@param inst_KomAgtCaller
	*/
	public void deepcopy(Object inst_KomAgtCaller) 
	{
		if ( inst_KomAgtCaller instanceof  KomAgtCaller )
		{
			KomAgtCaller __KomAgtCaller_obj = ( KomAgtCaller ) inst_KomAgtCaller;

			specFlag.deepcopy( __KomAgtCaller_obj.specFlag);
		}
	}
/**
*@param spec
*/

	public void setspecFlag( MasterCraftBitSet spec ) 
	{
		specFlag.deepcopy(spec);
	}
/**
*@return specflag
*/

	public MasterCraftBitSet getspecFlag( )
	{
		return specFlag ;
	}
	/**
	*
	*/

	public void unmarkAll ()
	{
		specFlag.resetAll();
	}

	/**
	*@return Description string
	*/
	public String toString ( )
	{
		StringBuffer s =new StringBuffer();
		s = s.append( MasterCraftConstants.lineSeparator ).append( "Class KomAgtCaller : " );
		s = s.append( MasterCraftConstants.lineSeparator ).append( "specFlag = " ).append( specFlag.toString() ).append( " (MasterCraftBitSet) " ) ;
		s = s.append( MasterCraftConstants.lineSeparator ).append( "END OF KomAgtCaller " ).append( MasterCraftConstants.lineSeparator).append( MasterCraftConstants.lineSeparator );
		return s.toString();
	}
// ## End of MasterCraft generated code



	// ## Signature of getIntermediaryInfo_164289 method should not be changed
	/**

	 */
	/**
	*@param  MbsoKomEventsAgtInfo ip_mbsoKomEventsAgtInfo
	*@return  MbsoKomEventsAgtInfo 
	*/
	public static MbsoKomEventsAgtInfo getIntermediaryInfo ( MbsoKomEventsAgtInfo ip_mbsoKomEventsAgtInfo  )	{
		log.debug(" Entering function 'getIntermediaryInfo(MbsoKomEventsAgtInfo ip_mbsoKomEventsAgtInfo) : returns MbsoKomEventsAgtInfo op_mbsoKomEventsAgtInfo' of class KomAgtCaller ");
		ServerContext.setRetError( new ErrorType() );
		// ## Add your code for getIntermediaryInfo_164289 method here
		MbsoKomEventsAgtInfo op_mbsoKomEventsAgtInfo = new MbsoKomEventsAgtInfo() ;
		try	{
			try	{

//				 Calling the KomAgtUtility method to get all the details of the Intermediary ...
				//mbsoAgtDataFactoryInfo = KomAgtUtility.AgtInfoDataFactory.getInstance().getIntermediaryInfo( mbsoKomEventsAgtInfo.getIntdNo() );
				// if o/p of above method is null, 'IntdValidInd'  is set to '0' , else '1' ...
				Intermediary intermediary = new Intermediary();	        
				op_mbsoKomEventsAgtInfo = intermediary.getInterInfo( ip_mbsoKomEventsAgtInfo.getIntdNo() );
			}
			catch ( Exception ex )	{
				ErrMessages.addMessage( ErrMessages.AGT_WEB_SVC_ERR );
				throw new MasterCraftException("AGT Web Service call failed. Roll back to Q.");
			}

			if ( op_mbsoKomEventsAgtInfo == null )	{
				ip_mbsoKomEventsAgtInfo.setIntdValidInd(0);
				op_mbsoKomEventsAgtInfo = new MbsoKomEventsAgtInfo();
				op_mbsoKomEventsAgtInfo.deepcopy( ip_mbsoKomEventsAgtInfo );
			}
			else	{
				//op_mbsoKomEventsAgtInfo.setIntdValidInd(1);
				op_mbsoKomEventsAgtInfo.setIntdNo(ip_mbsoKomEventsAgtInfo.getIntdNo());
			}
		}
		catch ( MasterCraftException mex )	{
			mex.printStackTrace();
			throw mex;
		}
		catch ( Exception ex )	{
			ex.printStackTrace();
			throw new MasterCraftException(ex);
		}

		log.debug(" Returning from function 'getIntermediaryInfo(MbsoKomEventsAgtInfo ip_mbsoKomEventsAgtInfo) : returns MbsoKomEventsAgtInfo op_mbsoKomEventsAgtInfo' of class KomAgtCaller ");
		return op_mbsoKomEventsAgtInfo ;
	}
	// ## End of getIntermediaryInfo_164289 method
	// ## User-required operation declaration could start here onwards

	// Sample format to add an operation
	// public void ExampleOperation( int Param1, StringBuffer Param2 )
	// {
		//		CODE_START


		//		CODE_END
	// }

	// ## End of User-required operation declarations

}

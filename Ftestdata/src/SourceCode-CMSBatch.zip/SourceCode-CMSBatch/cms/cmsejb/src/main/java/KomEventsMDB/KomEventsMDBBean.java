package KomEventsMDB;
/**
 * Bean implementation class for Enterprise Bean: KomEventsMDB
 */

import KomEvents.*;
import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.MESSAGE_ARRAY;
import java.io.*;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.ejb.*;
import javax.jms.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import javax.xml.bind.*;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import za.co.sanlam.sibnotify.notification.kom.Sibnotify;
import MCExtClasses.*;
//*************** DPM 45839 Starts 
import java.net.*;
//*************** DPM 45839 Ends

public class KomEventsMDBBean
	implements
		javax.ejb.MessageDrivenBean,
		javax.jms.MessageListener {
	
	public KomEventsMDBBean()
    {
    }

    public MessageDrivenContext getMessageDrivenContext()
    {
        return fMessageDrivenCtx;
    }

    public void setMessageDrivenContext(MessageDrivenContext ctx)
    {
        fMessageDrivenCtx = ctx;
        try
        {
            Context ctxa = new InitialContext();
            //propertyFile = (String)ctxa.lookup("java:comp/env/WebServiceProperties");
          // DPM 45839 Starts 
            InitialContext initCtx = new InitialContext();
            URL url = (java.net.URL) initCtx.lookup("java:comp/env/url/mcappkom/ConfigPropertiesURL");
            URLConnection conn = url.openConnection();
    		InputStream is = conn.getInputStream();
    		Properties properties = new Properties();
    		properties.load( is );
    		propertyFile= properties.getProperty("WebServiceProperties");
            log.info("Property File for Web Services is : " + propertyFile);
        }
        catch(NamingException ne)
        {
            log.error("NamingException encountered for Property File for Web Services ");
            log.error(ne);
            ne.printStackTrace();
        }
        // DPM 45839 Starts 
        catch(IOException ioe)
        {
            System.out.println("IOException " + ioe);
        }
        // DPM 45839 Ends
    }

    public void ejbCreate()
    {
    }

    public void onMessage(Message msg)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        GregorianCalendar calendar = new GregorianCalendar();
        SimpleDateFormat data = new SimpleDateFormat("dd/MM/yyyy");
        Sibnotify notifierCls = new Sibnotify();
        String message = "No Detail";
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss aaa");
     // Code change for the DPM 44783 Starts Here
     /*   HashMap prodType=new HashMap();
        prodType.put("D01", "D01");
        prodType.put("D02", "D02");
	// Code change for the DPM 46374 Starts Here
        prodType.put("D04", "D04");
     // Code change for the DPM 46374 Ends Here
        prodType.put("E19", "E19");
        prodType.put("E29", "E29");
        prodType.put("E79", "E79");
        prodType.put("R09C", "R09C");
        prodType.put("R09P", "R09P");
        prodType.put("R79C", "R79C");
        prodType.put("R79P", "R79P");
        prodType.put("R29C", "R29C");
        prodType.put("R29P", "R29P");
        prodType.put("R50C", "R50C");
        prodType.put("L01S", "L01S");
        prodType.put("M02W", "M02W");
        prodType.put("D50", "D50");
        prodType.put("M50W", "M50W");
        prodType.put("M51W", "M51W");
     // Code change for the DPM 44783 Ends Here
   */
     // Code change for the DPM 47649 Ends Here
        try
        {
            TextMessage textMessage = (TextMessage)msg;
            String requestMessage = null;
            requestMessage = textMessage.getText();
            log.debug(" Lamda/KOMEventMdb Start ");
            ByteArrayInputStream bais = new ByteArrayInputStream(requestMessage.getBytes("UTF-8"));
            JAXBContext jc = JAXBContext.newInstance("KomEventsMDB");
            Unmarshaller uMarshaller = jc.createUnmarshaller();
            CommissionableEvent ce = (CommissionableEvent)uMarshaller.unmarshal(bais);
            MbsoKomEventsEventInfo mbsoKomEventsEventInfo = new MbsoKomEventsEventInfo();
            mbsoKomEventsEventInfo.setEventType(ce.getEventType());
            mbsoKomEventsEventInfo.setEventEffDate(ce.getEventEffDate());
            if (!ce.getPremiumHolidayStartDate().equals(ce.getPremiumHolidayEndDate()))
            	mbsoKomEventsEventInfo.setEventEffDate(ce.getPremiumHolidayStartDate());
            mbsoKomEventsEventInfo.setPrmHolidayEndDate(ce.getPremiumHolidayEndDate());
            mbsoKomEventsEventInfo.setComType(new StringBuffer(ce.getCommissionType().toString().trim()));
            mbsoKomEventsEventInfo.setPrmReductionPct(ce.getPremiumReductionPct().doubleValue());
            mbsoKomEventsEventInfo.setIndexGrowthType(ce.getIndexGrowthType().intValue()== 0 ? 1 : ce.getIndexGrowthType().intValue());
            mbsoKomEventsEventInfo.setCampaignCode(new StringBuffer(ce.getCampaignCode().toString().trim()));
            mbsoKomEventsEventInfo.setIndexPlanOptInd(ce.isIndexPlanOptionInd() ? 1 : 0);
            mbsoKomEventsEventInfo.setTaxFundGrpCode(ce.getTaxFundGroupCode().intValue());
            mbsoKomEventsEventInfo.setNoOfElements(ce.getNoOfElements());
            mbsoKomEventsEventInfo.setRparInd(ce.isRparInd() ? 1 : 0);
            mbsoKomEventsEventInfo.setSplReinstInd(ce.isSpclReInsInd() ? 1 : 0);
			//RA Transfer Addition...
            mbsoKomEventsEventInfo.setRaXerSourceInd(ce.getTransferSourceRA());
            //SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");            
            //java.util.Date date = dateTimeFormat.parse(ce.getTransactionTs());            
            //mbsoKomEventsEventInfo.setTransactionTs(new MasterCraftDateTime(date));
            mbsoKomEventsEventInfo.setTransactionTs(new MCTimeStamp(java.sql.Timestamp.valueOf(ce.getTransactionTs())));
            mbsoKomEventsEventInfo.setNoOfPrmRecvd(ce.getNoOfPrmRecvd());
            mbsoKomEventsEventInfo.setElementNo(ce.getElementNo());
            mbsoKomEventsEventInfo.setRandValuePrmInArrears(ce.getRandValuePrmInArrears().doubleValue());
            mbsoKomEventsEventInfo.setPolicyTotalPrm(ce.getPolicyTotalPremium().doubleValue());
            mbsoKomEventsEventInfo.setWarningLevel(ce.getWarningLevel());
            mbsoKomEventsEventInfo.setApplnDate(ce.getAppInDate());
            mbsoKomEventsEventInfo.setQuotationDate(ce.getQuotationDate());
            MbsoKomEventsPolicyInfo mbsoKomEventsPolicyInfo = new MbsoKomEventsPolicyInfo();
            mbsoKomEventsPolicyInfo.setPolicyNo(new StringBuffer(ce.getPolicyNo().toString().trim()));
            mbsoKomEventsPolicyInfo.setProdType(new StringBuffer(ce.getProductType().toString().trim()));
            mbsoKomEventsPolicyInfo.setProdNameCode(new StringBuffer(ce.getProductNameCode().toString().trim()));
            mbsoKomEventsPolicyInfo.setPrmFreq(ce.getPremiumFreq().intValue());
            mbsoKomEventsPolicyInfo.setPrmPaymentMthd(ce.getPremiumPymtMethod().intValue());
            mbsoKomEventsPolicyInfo.setClientOwnerPortfolioNo(new StringBuffer(ce.getClientOwnerPortfolioNo().toString().trim()));
            mbsoKomEventsPolicyInfo.setClientInsrdPortfolioNo(new StringBuffer(ce.getClientInsuredPortfolioNo().toString().trim()));
            mbsoKomEventsPolicyInfo.setClientInsrdSurname(new StringBuffer(ce.getClientInsuredSurname().toString().trim()));
            mbsoKomEventsPolicyInfo.setClientInitialsInsrd(new StringBuffer(ce.getClientInsuredInitials().toString().trim()));
            mbsoKomEventsPolicyInfo.setCurrency(ce.getCurrency());
            //Took this out as per cr from lamda 
            //if(ce.getSourceSys() == 0)
            //    ce.setSourceSys(1);
            mbsoKomEventsPolicyInfo.setSourceSys(ce.getSourceSys());
            mbsoKomEventsPolicyInfo.setIndexPlanOptionInd(ce.isIndexPlanOptionInd() ? 1 : 0);
            mbsoKomEventsPolicyInfo.setPolicyNoBefConv(new StringBuffer(ce.getOrgPolicyNo()));
            mbsoKomEventsPolicyInfo.setApplnDate(ce.getAppInDate());
            mbsoKomEventsPolicyInfo.setQuotationDate(ce.getQuotationDate());
            mbsoKomEventsPolicyInfo.setPolicyIssueDate(ce.getPolicyIssueDate());
            mbsoKomEventsPolicyInfo.setConversionInd(ce.isCoversionInd() ? 1 : 0);
            MbsoKomEventsElmntInfo mbsoKomEventsElmntInfo = new MbsoKomEventsElmntInfo();
            mbsoKomEventsElmntInfo.setElementNo(ce.getElementNo());
            mbsoKomEventsElmntInfo.setElementStDate(ce.getElementStDate());
            mbsoKomEventsElmntInfo.setElementTerm(ce.getElementTerm());
			//Code Changes for DPM 44091 - Starts here
            if( mbsoKomEventsEventInfo.getEventType() == 004 ){
            	if(mbsoKomEventsElmntInfo.getElementTerm() == 0){
            		mbsoKomEventsElmntInfo.setElementTerm(12);
            		 log.debug(" ElementTerm is set to Default Value 12 ");
            	}            	
            }            
            //Code Changes for DPM 44091 - Ends here
            //Code Changes for DPM 45568 - Starts here
            if( mbsoKomEventsEventInfo.getEventType() == 006 ){
            	if(mbsoKomEventsElmntInfo.getElementNo() == 0){
            		mbsoKomEventsElmntInfo.setElementNo(1);
            		 log.debug(" ElementNo is set to Default Value 1 ");
            	}            	
            }            
            //Code Changes for DPM 45568 - Ends here
			//Code Changes for DPM 40836 - Starts here ...
			mbsoKomEventsElmntInfo.setScoreTerm(ce.getScoreTerm());
			//Code Changes for DPM 40836 - Starts here ...
            mbsoKomEventsElmntInfo.setElementAnnualPrm(ce.getElementPremium().doubleValue());
            mbsoKomEventsElmntInfo.setSalesComMonthlyAmt(ce.getSalesCommMonthlyAmt().doubleValue());
            mbsoKomEventsElmntInfo.setServiceComMonthlyAmt(ce.getServiceCommMonthlyAmt().doubleValue());
            mbsoKomEventsElmntInfo.setServiceComNegoPct(ce.getServiceCommNegotiatedPct().doubleValue());
            mbsoKomEventsElmntInfo.setSalesComNegoPct(ce.getSalesCommNegotiatedPct().doubleValue());
            //Code Changes for DPM 40835 - Starts here ...
            mbsoKomEventsElmntInfo.setFundComMonthlyAmt(ce.getFundCommMonthlyAmt().doubleValue());
            mbsoKomEventsElmntInfo.setElementFundValue(ce.getFundValue().doubleValue());
            mbsoKomEventsElmntInfo.setElementAnnualScorePremium(ce.getCommissionPremiumAmount().doubleValue());
            mbsoKomEventsElmntInfo.setElementConversionPremium(ce.getPremiumAtConversionAmount().doubleValue());
            //Code Changes for DPM 40835 - Ends here ...
            MasterCraftVector op_mbsoKomEventsIntdCommInfo = new MasterCraftVector();
            List intdList = ce.getIntdCommInfo();
            MbsoKomEventsIntdCommInfo mbsoKomEventsIntdCommInfo;
            for(Iterator intdListIterator = intdList.iterator(); intdListIterator.hasNext(); op_mbsoKomEventsIntdCommInfo.add(mbsoKomEventsIntdCommInfo))
            {
                IntdCommInfoType intdCommInfoType = (IntdCommInfoType)intdListIterator.next();
                mbsoKomEventsIntdCommInfo = new MbsoKomEventsIntdCommInfo();
                mbsoKomEventsIntdCommInfo.setIntdNo(intdCommInfoType.getIntermediaryNo());
                mbsoKomEventsIntdCommInfo.setApplnNo(intdCommInfoType.getAppInNo());
                mbsoKomEventsIntdCommInfo.setManCode((new Long(intdCommInfoType.getManCode())).intValue());
                // Code change for the DPM 44783 Starts Here
                log.debug(" intdCommInfoType.getSalesCommSplitPct() Before"+intdCommInfoType.getSalesCommSplitPct());
                log.debug(" intdCommInfoType.getServiceCommSplitPct() Before"+intdCommInfoType.getServiceCommSplitPct());
             // Code change for the DPM 47649 Starts 
                /*
                if(prodType.containsKey(mbsoKomEventsPolicyInfo.getProdType().toString().trim().toUpperCase())&& intdCommInfoType.getSalesCommSplitPct().doubleValue() > 0.0D && intdCommInfoType.getServiceCommSplitPct().doubleValue() == 0.0D || intdCommInfoType.getSalesCommSplitPct().doubleValue() < 0.0D){
                    intdCommInfoType.setServiceCommSplitPct(intdCommInfoType.getSalesCommSplitPct().abs());
                   
                }
                else
                if(prodType.containsKey(mbsoKomEventsPolicyInfo.getProdType().toString().trim().toUpperCase())&& intdCommInfoType.getServiceCommSplitPct().doubleValue() > 0.0D && intdCommInfoType.getSalesCommSplitPct().doubleValue() == 0.0D || intdCommInfoType.getServiceCommSplitPct().doubleValue() < 0.0D){
                    intdCommInfoType.setSalesCommSplitPct(intdCommInfoType.getServiceCommSplitPct().abs());
                
                    
            }
                */
                // Code change for the DPM 47649 Ends Here
             // Code change for the DPM 44783 Ends Here 
                log.debug(" intdCommInfoType.getSalesCommSplitPct() "+intdCommInfoType.getSalesCommSplitPct());
                log.debug(" intdCommInfoType.getServiceCommSplitPct() "+intdCommInfoType.getServiceCommSplitPct());
                mbsoKomEventsIntdCommInfo.setSalsCommSpltPct(intdCommInfoType.getSalesCommSplitPct().doubleValue());
                mbsoKomEventsIntdCommInfo.setServCommSpltPct(intdCommInfoType.getServiceCommSplitPct().doubleValue());
                //Code Changes for DPM 40835 - Starts here ...
                mbsoKomEventsIntdCommInfo.setFundComSplitPct(intdCommInfoType.getFundCommSplitPct().doubleValue());
                //Code Changes for DPM 40835 - Ends here ...
            }
            
            /*Patch for the Lamda Bug where D02 productTypes coming with non-zero element term.
             * If the Produt type is 'D02' element term is made 0.
             */
            if ( "D02".equalsIgnoreCase(mbsoKomEventsPolicyInfo.getProdType().toString().trim()) )	{
            	mbsoKomEventsElmntInfo.setElementTerm(0);
            }
         // DPM 48909 Continuations  Start 18 Mar 2010
            if ( ("EC9".equalsIgnoreCase(mbsoKomEventsPolicyInfo.getProdType().toString().trim())) || ("RC9C".equalsIgnoreCase(mbsoKomEventsPolicyInfo.getProdType().toString().trim()))
            		|| ("RC9P".equalsIgnoreCase(mbsoKomEventsPolicyInfo.getProdType().toString().trim())) || ("PP2C".equalsIgnoreCase(mbsoKomEventsPolicyInfo.getProdType().toString().trim())) || ("PF2C".equalsIgnoreCase(mbsoKomEventsPolicyInfo.getProdType().toString().trim())))	{
            	mbsoKomEventsElmntInfo.setElementTerm(999);
            }
         // DPM 48909 Continuations  Ends 18 Mar 2010

            InitialContext ctx = new InitialContext();
            KomEventsBEAN_HOME_INTF komEventsHome = (KomEventsBEAN_HOME_INTF)PortableRemoteObject.narrow(ctx.lookup("ejb/KomEvents"), KomEvents.KomEventsBEAN_HOME_INTF.class);
            KomEventsBEAN_INTF komEventsBean = komEventsHome.create();
            //KomEvents.KomEventsBEAN_HOME_INTF  komEventsHome = (KomEvents.KomEventsBEAN_HOME_INTF)PortableRemoteObject.narrow(ctx.lookup("ejb/KomEvents"), KomEvents.KomEventsBEAN_HOME_INTF .class);
            //KomEvents.KomEventsBEAN_INTF komEventsBean = komEventsHome.create();
            PmoKomEventsProcessor pmoKomEventsProcessor = new PmoKomEventsProcessor();
            ServerContext.getClientContext().setUserDefinedProperties("WebServiceProperties", propertyFile);
            MasterCraftretClass masterCraftretClass = komEventsBean.sh_processCommEvents(null, pmoKomEventsProcessor, mbsoKomEventsPolicyInfo, mbsoKomEventsEventInfo, mbsoKomEventsElmntInfo, op_mbsoKomEventsIntdCommInfo);
            ErrorType retStatus = masterCraftretClass.getReturnStatus();
            int Errortype = masterCraftretClass.getReturnStatus().getValue();
            String MessageArray = masterCraftretClass.getMessageArray().toString();
            if(retStatus.getValue() < 2)
            {
                log.debug(" :) yepee ");
            } else
            {
                log.debug("Something is wrong");
                throw new EJBException();
            }
        }        
        catch(UnsupportedEncodingException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "UnsupportedEncodingException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(UnmarshalException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "UnmarshalException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(JAXBException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "JAXBException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(NamingException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "NamingException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(CreateException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "CreateException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(JMSException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "JMSException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(RemoteException e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "RemoteException", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            message = printExceptionChain(e);
            notifierCls.sendNotification("Lamda Asynchronous ", "J2EE_APP", "KOM", "Exception", "KOM Listener Stopped - KOMEventQueuePort", message, ServerContext.getClientContext().getUserId().toString(), "KOM", "KomEventsMDB", "onMessage", dateFormat.format(calendar.getTime()), timeFormat.format(calendar.getTime()));
            throw new EJBException(e);
        }
    }

    public void ejbRemove()
    {
    }

    private static String printExceptionChain(Throwable thr)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        Throwable t = thr;
        sw.write("Exception chain (top to bottom):");
        for(; t != null; t = t.getCause())
        {
            sw.write("\n");
            sw.write("-------------------------------");
            sw.write("\n");
            StackTraceElement s[] = t.getStackTrace();
            StackTraceElement s0 = s[0];
            sw.write(t.toString());
            sw.write("\n");
            sw.write("  at " + s0.toString());
            sw.write("\n");
            sw.write("\n");
            sw.write("\n");
            if(t.getCause() == null)
            {
                sw.write("Complete traceback (bottom to top):");
                sw.write("\n");
                sw.write("-------------------------------");
                sw.write("\n");
                sw.write("\n");
                t.printStackTrace(pw);
                sw.write("\n");
            }
        }

        return sw.toString();
    }

    private MessageDrivenContext fMessageDrivenCtx;
    private String propertyFile;
    private static final ILogger log;

    static 
    {
        log = LoggerFactory.getLogger(KomEventsMDB.KomEventsMDBBean.class);
    }
	
}

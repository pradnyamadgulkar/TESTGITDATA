package KomEventsMDB;
/**
 * Bean implementation class for Enterprise Bean: AgtRetroVatMDB
 */

import KomEvents.*;

import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.MESSAGE_ARRAY;
import java.io.*;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.ejb.*;
import javax.jms.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import javax.xml.bind.*;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import za.co.sanlam.sibnotify.notification.kom.Sibnotify;

public class AgtRetroVatMDBBean
	implements
		javax.ejb.MessageDrivenBean,
		javax.jms.MessageListener {
	
	private javax.ejb.MessageDrivenContext fMessageDrivenCtx;
	/**
	 * getMessageDrivenContext
	 */
	public javax.ejb.MessageDrivenContext getMessageDrivenContext() {
		return fMessageDrivenCtx;
	}
	/**
	 * setMessageDrivenContext
	 */
	 public void setMessageDrivenContext(MessageDrivenContext ctx)
	    {
	        fMessageDrivenCtx = ctx;
	        try
	        {
	            Context ctxa = new InitialContext();	            
	        }
	        catch(NamingException ne)
	        {
	            log.error(ne);
	            ne.printStackTrace();
	        }
	    }
	/**
	 * ejbCreate
	 */
	public void ejbCreate() {
	}
	/**
	 * onMessage
	 */
	public void onMessage(javax.jms.Message msg) {
		String message = "No Detail";
		Sibnotify notifierCls = new Sibnotify();
		GregorianCalendar calendar = new GregorianCalendar();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss aaa");
		try {
			log.debug("Invoking RetroVatMDB onMessage() now.");
			//System.out.println("RetroVat message is: " +
			// ((TextMessage)msg).getText());
			SimpleDateFormat dateFormate = new SimpleDateFormat("yyyyMMdd");
			String interNo = ((TextMessage) msg).getText().trim().substring(28,
					38);
			//char stats = ((TextMessage) msg).getText().trim().charAt(38);
			Character stat = new Character((((TextMessage) msg).getText().trim().charAt(38)));
			int status = Integer.valueOf(stat.toString()).intValue();
			Date date = dateFormate.parse(((TextMessage) msg).getText().trim()
					.substring(39, 47));
			String evtTyp = ((TextMessage) msg).getText().trim().substring(47,50);
			int evtTypVal = (new Integer(evtTyp)).intValue();
			MbsoKomEventsVATRetroInfo mbsoKomEventsVATRetroInfo = new MbsoKomEventsVATRetroInfo();
			mbsoKomEventsVATRetroInfo.setIntdNo(Long.parseLong(interNo));
			//mbsoKomEventsVATRetroInfo.setVatStatus((Boolean.valueOf(String.valueOf(stats))).booleanValue() ? 1 : 0);
			mbsoKomEventsVATRetroInfo.setStatus(status);
			mbsoKomEventsVATRetroInfo.setVatStatusEffDate(new MasterCraftDate(
					date));
			mbsoKomEventsVATRetroInfo.setEventType(evtTypVal);
			log.debug("Intermediary no is "
					+ mbsoKomEventsVATRetroInfo.getIntdNo());
			log.debug("Vat Status is "
					+ mbsoKomEventsVATRetroInfo.getStatus());
			log.debug("Date Effective is "
					+ mbsoKomEventsVATRetroInfo.getVatStatusEffDate());
			log.debug("Event Type is "
					+ mbsoKomEventsVATRetroInfo.getEventType());
			InitialContext ctx = new InitialContext();
			KomEventsBEAN_HOME_INTF komEventsHome = (KomEventsBEAN_HOME_INTF)PortableRemoteObject.narrow(ctx.lookup("ejb/KomEvents"), KomEvents.KomEventsBEAN_HOME_INTF.class);
            KomEventsBEAN_INTF komEventsBean = komEventsHome.create();
			/*KomEvents.KomEventsBEAN_HOME_INTF komEventsHome = (KomEvents.KomEventsBEAN_HOME_INTF) PortableRemoteObject
					.narrow(ctx.lookup("ejb/KomEvents"),
							KomEvents.KomEventsBEAN_HOME_INTF.class);
			KomEvents.KomEventsBEAN_INTF komEventsBean = komEventsHome.create();*/
			MasterCraftVector op_mbsoKomEventsVATRetroInfo = new MasterCraftVector();
			op_mbsoKomEventsVATRetroInfo.add(mbsoKomEventsVATRetroInfo);
			PmoKomEventsProcessor pmoKomEventsProcessor = new PmoKomEventsProcessor();
			MasterCraftretClass masterCraftretClass = komEventsBean
					.sh_processVATRetroEvent(null, pmoKomEventsProcessor,
							op_mbsoKomEventsVATRetroInfo);
			//Object ref = jndiContext.lookup("MdbPojoTestSession");
			ErrorType retStatus = masterCraftretClass.getReturnStatus();
			int Errortype = masterCraftretClass.getReturnStatus().getValue();
			String MessageArray = masterCraftretClass.getMessageArray()
					.toString();
			if (retStatus.getValue() < 2) {
				log.debug(" :) yepee Retro VAT !!! ");
			} else {
				log.debug("Something is wrong Retro VAT ??? ");
				throw new EJBException();
			}
			log.debug("END of RetroVatMDB ");
		} catch (JMSException e) {
			e.printStackTrace();
			message = printExceptionChain(e);
			notifierCls.sendNotification("Retro Vat Event ", "J2EE_APP", "KOM",
					"JMSException",
					"KOM Listener Stopped - AGTRetroVatQueuePort", message,
					ServerContext.getClientContext().getUserId().toString(),
					"KOM", "AgtRetroVatMDB", "onMessage", dateFormat
							.format(calendar.getTime()), timeFormat
							.format(calendar.getTime()));
			throw new EJBException(e);
		} catch (Exception e) {
			e.printStackTrace();
			message = printExceptionChain(e);
			notifierCls.sendNotification("Retro Vat Event ", "J2EE_APP", "KOM",
					"Exception", "KOM Listener Stopped - AGTRetroVatQueuePort",
					message, ServerContext.getClientContext().getUserId()
							.toString(), "KOM", "AgtRetroVatMDB", "onMessage",
					dateFormat.format(calendar.getTime()), timeFormat
							.format(calendar.getTime()));
			throw new EJBException(e);
		}
			
		
	}
	/**
	 * ejbRemove
	 */
	public void ejbRemove() {
		
	}
	
	private static String printExceptionChain(Throwable thr)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        Throwable t = thr;
        sw.write("Exception chain (top to bottom):");
        for(; t != null; t = t.getCause())
        {
            sw.write("\n");
            sw.write("-------------------------------");
            sw.write("\n");
            StackTraceElement s[] = t.getStackTrace();
            StackTraceElement s0 = s[0];
            sw.write(t.toString());
            sw.write("\n");
            sw.write("  at " + s0.toString());
            sw.write("\n");
            sw.write("\n");
            sw.write("\n");
            if(t.getCause() == null)
            {
                sw.write("Complete traceback (bottom to top):");
                sw.write("\n");
                sw.write("-------------------------------");
                sw.write("\n");
                sw.write("\n");
                t.printStackTrace(pw);
                sw.write("\n");
            }
        }

        return sw.toString();
    }
	
    private String propertyFile;
    private static final ILogger log;

    static 
    {
        log = LoggerFactory.getLogger(KomEventsMDB.AgtRetroVatMDBBean.class);
    }
}

// ***********************************************************
// This is a Bean class
// "LocalKomEventsRef" is the name of the Bean which will be implemented
// ***********************************************************

package KomEventsRef;
import Domains.*;
import ErrorMessages.*;
import javax.ejb.Timer;
import javax.ejb.*;
import java.util.*;

import KomEventsRef.wcKomRefProdTypeIndList;
import KomEventsRef.MbsoKomEventsRefSysAgeingPmtrs;
import KomEventsRef.MbsoKomEventsRefIndexGrowthTyp;
import KomEventsRef.MbsoKomEventsRefSchTyp;
import KomEventsRef.wcKomRefCommTypVsSpltCommTyp;
import KomEventsRef.wcKomRefSysParamList;
import KomEventsRef.wcKomRefAdvanceTermList;
import KomEventsRef.wcKomRefSpltComSchdTypList;
import KomEventsRef.PmoKomEventsRefReferenceData;
import KomEventsRef.MbsoKomEventsRefSplitCommTyp;
import KomEventsRef.MbsoKomEventsRefScrTerm;
import KomEventsRef.MbsoKomEventsRefEventTyp;
import KomEventsRef.MbsoKomEventsRefCommVsSplitCommType;
import KomEventsRef.wcKomRefCntrCdElg;
import KomEventsRef.MbsoKomEventsRefVatInfo;
import KomEventsRef.MbsoKomEventsRefSourceSys;
import KomEventsRef.wcKomRefFirstPmtDtList;
import KomEventsRef.wcKomRefEvntTyp;
import KomEventsRef.MbsoKomEventsRefAdvanceTerm;
import KomEventsRef.MbsoKomEventsRefMultiplicationFactor;
import KomEventsRef.wcKomRefSpltComVsAccTrans;
import KomEventsRef.wcKomRefSpltCommTyp;
import KomEventsRef.wcKomRefVatTyp;
import KomEventsRef.MbsoKomEventsRefMultFactPtrn;
import KomEventsRef.wcKomRefKOMAGTAudit;
import KomEventsRef.wcKomEventsRefMultFactPtrnList;
import KomEventsRef.wcKomRefMulFact;
import KomEventsRef.MbsoKomEventsRefProdTypeInd;
import KomEventsRef.MbsoKomEventsRefDropDownInputClass;
import KomEventsRef.wcKomRefVestingScales;
import KomEventsRef.MbsoKomEventsRefSplitCommSchdType;
import KomEventsRef.MbsoKomEventsRefAuditAgtInfo;
import KomEventsRef.wcKomRefPremHdayVestScles;
import Domains.Direction;
import KomEventsRef.MbsoKomEventsRefCommTyp;
import KomEventsRef.MbsoKomEventsRefSystemParameter;
import KomEventsRef.wcKomRefVestingRules;
import KomEventsRef.MbsoKomEventsRefDropDownOutputClass;
import KomEventsRef.MbsoKomEventsRefSplitCommTypeAXEInfo;
import KomEventsRef.MbsoKomEventsRefContractCd;
import KomEventsRef.wcKomRefCommTyp;
import KomEventsRef.wcKomRefScrTyp;
import KomEventsRef.MbsoKomEventsRefVestingRules;
import KomEventsRef.wcKomRefIdxGthTyp;
import KomEventsRef.wcKomRefSchdTyp;
import KomEventsRef.MbsoKomEventsRefFirstPmtDt;
import KomEventsRef.wcKomRefSourceSys;
import KomEventsRef.MbsoKomEventsRefVestingScales;
import KomEventsRef.MbsoKomEventsRefVestingScalesPrmHols;

import com.tcs.mastercraft.mctype.*;
import com.tcs.mastercraft.mctype.errlib.*;
import com.tcs.mastercraft.mcutil.* ;
import java.io.*;
import java.text.*;
import java.math.*;
import java.net.URL;
import java.net.URLConnection;
import java.sql.*;
import ErrLogging.*;
import javax.naming.*;
import javax.transaction.*;
import java.util.Date;
import za.co.sanlam.cms.logging.ILogger;
import za.co.sanlam.cms.logging.LoggerFactory;
import java.rmi.RemoteException;
import java.rmi.Remote;

public class KomEventsRefBEAN implements SessionBean , TimedObject
{
	private SessionContext sessionctx = null;
	private transient javax.sql.DataSource dataSource = null;
	private String dataDir;
	EJBContext ejbContext = null;
	/* This attribute sets the printEnabled property read from ejb environment */
	private boolean bIsPrintEnabled = false ; /// default is false 
	/*Name of the error message file to be used for reading the message description for error message id .	*/
	private String sErrMsgFileName = "ShortErrorList";

	private static final ILogger log = LoggerFactory.getLogger(KomEventsRefBEAN.class) ;

	/**
	* This method is required by the EJB Specification,
	* but is not used by this bean.
	*
	*/
	public void ejbActivate()
	{
		log.debug(" Inside the function 'ejbActivate() : returns void' of class KomEventsRefBEAN required by EJB ");
	}

	/**
	* This method is required by the EJB Specification,
	* but is not used by this bean.
	*
	*/
	public void ejbPassivate()
	{
		log.debug(" Inside the function 'ejbPassivate() : returns void' of class KomEventsRefBEAN required by EJB ");
	}

	// Sets the session context
	public void setSessionContext(SessionContext sessionctx)
	{
		log.debug(" Entering function 'setSessionContext(SessionContext sessionctx) : returns void' of class KomEventsRefBEAN ");
		if ( sessionctx != null )
			this.sessionctx = sessionctx;

		InitialContext envCtx = null;
		try
		{
			envCtx = new InitialContext();
			String printEnabledFlag = ( String ) envCtx.lookup( "java:comp/env/mastercraft.ejb.enablePrint" );
			bIsPrintEnabled = printEnabledFlag.equals( "Y" );
		}
		catch ( NamingException ne1 )
		{
			String errMsg = "Error encountered while looking up for environment value 'mastercraft.ejb.enablePrint'";
			MasterCraftException mce = new MasterCraftException ( errMsg , ne1 );
			throw mce;
		}

		try
		{
			// DPM 45839 Starts
			//sErrMsgFileName = ( String ) envCtx.lookup( "java:comp/env/mastercraft.ejb.ErrMsgFile" );
			 	InitialContext initCtx = new InitialContext();
	            URL url = (java.net.URL) initCtx.lookup("java:comp/env/url/mcappkom/ConfigPropertiesURL");
	            URLConnection conn = url.openConnection();
	    		InputStream is = conn.getInputStream();
	    		Properties properties = new Properties();
	    		properties.load( is );
	    		sErrMsgFileName=properties.getProperty("mastercraft.ejb.ErrMsgFile");    		
	    		log.debug("sErrMsgFileName from prop file "+sErrMsgFileName);
		}
		catch ( NamingException ne2 )
		{
			String errMsg = "Error encountered while looking up for environment value 'mastercraft.ejb.ErrMsgFile'";
			MasterCraftException mce = new MasterCraftException ( errMsg , ne2 );
			throw mce;
		}
		catch (IOException ioe) {
        	System.out.println("IOException "+ioe);
        	//throw ioe;
        }
		//DPM 45839 Ends

		log.info(" SessionContext has been set successfully ");
		log.debug(" Returning from function 'setSessionContext(SessionContext sessionctx) : returns void' of class KomEventsRefBEAN ");
	}

	// There should be a corresponding method in the ENTERPRISE BEAN'S HOME INTERFACE
	// For UTCS this method will be invoked
	public void ejbCreate ()
	{
		log.debug(" Entering function 'ejbCreate () : returns void' of class KomEventsRefBEAN ");
		try
		{
			ServerContext.setBeanContext(sessionctx, this);
			dataSource = ServerContext.getDataSource();
			dataDir = ServerContext.getDataDir();
		}
		catch ( Exception e )
		{
			String errMsg = " Error encountered while Setting the Bean Context of the ServerContext class in the funtion 'ejbCreate () : returns void' ";
			MasterCraftException mce = new MasterCraftException ( errMsg , e );
			throw mce;
		}

		log.debug(" Returning from function 'ejbCreate () : returns void' of class KomEventsRefBEAN ");
	}

	/**
	* This method is required by the EJB Specification,
	* and is used to close JDBC Handle.
	*
	*/
	public void ejbRemove()
	{
		log.debug(" Entering function 'ejbRemove () : returns void' of class KomEventsRefBEAN ");
		try
		{
			if ( ServerContext.getJDBCHandle() != null )
			{
				ServerContext.getJDBCHandle().close();
			}
			ServerContext.clearThreadContext();
		}
		catch (Exception e)
		{
			String errMsg = " Error encountered while Removing the Bean in function 'ejbRemove () : returns void'";
			MasterCraftException mce = new MasterCraftException ( errMsg , e );
			throw mce;
		}
		log.debug(" Returning from function 'ejbRemove () : returns void' of class KomEventsRefBEAN ");
	}

	/**
	* This method is required by the EJB Specification,
	* but is not used by this bean.
	*
	*/
	public void ejbLocate ()
	{
		log.debug(" Inside the function 'ejbLocate() : returns void' of class KomEventsRefBEAN required by EJB ");
	}

	public void executeWarningCheck(ErrorType _messageTyp) 
	{
		Vector MsgVec = new Vector ();
		int size = ServerContext.getMESSAGE_ARRAY().nElem();
		int i = 0;
		for (i=0; i< size; i++)
		{
			MESSAGE messg = new MESSAGE ();
			messg = (MESSAGE)ServerContext.getMESSAGE_ARRAY().get(i) ;
			if (messg.getMessageType() == _messageTyp.XL_WARNING)
			{
				MsgVec.addElement(messg);
			}
		}
		/*  compare all the ids in the passed warning array from gui with the present warning ids
		take a new warning, compare with all passed ids, if matches, compare description, if that also matches, it is old,
		if it doesn't, then it is a new warning, so rollback
		if new warning id does not match with passed warning ids, then its new, so rollback */
		int WarVecsize = MsgVec.size();
		Vector ignoredWarnings = new Vector();
		ignoredWarnings = ServerContext.getServerContextObject().getMasterCraftClientContext().getIgnoredWarnings();
		int IgnoredWarSize = ignoredWarnings.size();
		int j = 0;
		int exists = 0;
		loop1 : for (j=0;j < WarVecsize; j++) //for new warnings
		{
			MESSAGE msg = new MESSAGE();
			msg = (MESSAGE)MsgVec.elementAt(j);
			int NewWarningCode = msg.getCode();
			Vector tmpVecNew = new Vector();
			tmpVecNew.addElement(msg);
			int k=0;
			loop2 : for (k=0; k<IgnoredWarSize ; k++) //for ignored warnings
			{
				MESSAGE IgnoredMsg = new MESSAGE();
				IgnoredMsg = (MESSAGE)ignoredWarnings.elementAt(k);
				Vector tmpVecIgnored = new Vector();
				tmpVecIgnored.addElement(IgnoredMsg);
				int IgnoredWarningCode = IgnoredMsg.getCode();
				if (NewWarningCode == IgnoredWarningCode )
				{
					String IgnoredWarningDescription = utsErrMsg.showMsg(tmpVecIgnored,sErrMsgFileName);
					String NewWarningDescription = utsErrMsg.showMsg(tmpVecNew,sErrMsgFileName);
					if (NewWarningDescription.equals(IgnoredWarningDescription))
					{
						exists = 1;
						break loop2;
					}
					else
					{
						log.debug("About to Abort");
						sessionctx.setRollbackOnly();
						break loop1;
					}
				}
			}
			if (exists == 0) // warning did not match any ignored warning, so it is a new warning
			{
				log.debug("About to Abort");
				sessionctx.setRollbackOnly();
				break loop1;
			}
		}
		try
		{
			if (!sessionctx.getRollbackOnly())
			{
				logIgnoredWarnings("Tbl_ignoredWarnings");
			}
		}
		catch (Exception e)
		{
			String errMsg = "Error in logging ignored warnings to Tbl_ignoredWarnings";
			MasterCraftException mce = new MasterCraftException ( errMsg , e );
			throw mce;
		}
	}
	public void logIgnoredWarnings(String TableName) 
	{
		int retcode= 0;
		String Warning = new String();
		StringBuffer h_SqlStmt = new StringBuffer (20000);
		int index;
		Vector ignoredWarningsVector = ServerContext.getServerContextObject().getMasterCraftClientContext().getIgnoredWarnings();
		if(ignoredWarningsVector != null && ignoredWarningsVector.size()!=0 )
		{
			Warning = utsErrMsg.showMsg(ignoredWarningsVector,sErrMsgFileName);
		}

		String local = new String ( " INSERT INTO " + TableName + " VALUES ('" + ServerContext.getServerContextObject().getMasterCraftClientContext().getUserId().toString() + "'," + ServerContext.getServerContextObject().getMasterCraftClientContext().getServiceId() + ",'" + ServerContext.getServerContextObject().getMasterCraftClientContext().getTransactionId().toString() + "','" + ServerContext.getServerContextObject().getMasterCraftClientContext().getAppTimeStamp().toString() + "','" + Warning + "'" );
		h_SqlStmt.replace( 0,local.length(), local );
		h_SqlStmt.append ( " ) " );
		String sqlStmt = h_SqlStmt.toString();

		try
		{
			PreparedStatement pstmt = ServerContext.getJDBCHandle().prepareStatement(sqlStmt );
			int retValue =  pstmt.executeUpdate( );
			pstmt.close();
		}

		catch ( SQLException ex )
		{
			retcode = ex.getErrorCode ();
			if( retcode == DM_err.ORA_TABLE_DOESNOTEXISTS || retcode == DM_err.SQLSERVER_TABLE_DOESNOTEXISTS )
			{
				log.debug("Table not found " + TableName.toString());
			}
			String errMsg = "Error in logging ignored warnings to Tbl_ignoredWarnings";
			MasterCraftException mce = new MasterCraftException ( errMsg , ex );
			throw mce;
		}
	/* clear the array being returned to GUI */
		ServerContext.clearMessages();
	}
	//This method will be called by the EJB Container after the Timer expires.
	public void ejbTimeout(javax.ejb.Timer timer_expired)
	{
		log.debug(" Entering function ' ejbTimeout ( Timer timer_expired ) : returns void ' of class TesterCompBEAN ");

		try
		{
			if(ServerContext.getContext( ) == null && sessionctx != null)
			{
				ServerContext.setContext( sessionctx );
			}
	
			EJBTimer.ejbTimeout(timer_expired);
		}
		catch(Exception ex)
		{
			String errMsg = "Error encountered in function ' ejbTimeout ( )  : returns void ' ";
			MasterCraftException mce = new MasterCraftException ( errMsg , ex );
			throw mce;
		}
	}

	public MasterCraftretClass sh_fetchRefSourceSys ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSourceSys inp0  ,wcKomRefSourceSys inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefSourceSys ( ThreadSpecificContext tctx  MbsoKomEventsRefSourceSys inp0  ,  wcKomRefSourceSys inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefSourceSys Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefSourceSys after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefSourceSys' are : ");
				log.info( " MbsoKomEventsRefSourceSys " + inp0 + " wcKomRefSourceSys " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefSourceSys  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefSourceSys (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefSourceSys  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSourceSys  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSourceSys  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefCommTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefCommTyp inp0  ,wcKomRefCommTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefCommTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefCommTyp inp0  ,  wcKomRefCommTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefCommTyp' are : ");
				log.info( " MbsoKomEventsRefCommTyp " + inp0 + " wcKomRefCommTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefCommTyp (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefSplitCommTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSplitCommTyp inp0  ,wcKomRefSpltCommTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefSplitCommTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSplitCommTyp inp0  ,  wcKomRefSpltCommTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefSplitCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefSplitCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefSplitCommTyp' are : ");
				log.info( " MbsoKomEventsRefSplitCommTyp " + inp0 + " wcKomRefSpltCommTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefSplitCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefSplitCommTyp (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefSplitCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSplitCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSplitCommTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefIndexGrowthTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefIndexGrowthTyp inp0  ,wcKomRefIdxGthTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefIndexGrowthTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefIndexGrowthTyp inp0  ,  wcKomRefIdxGthTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefIndexGrowthTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefIndexGrowthTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefIndexGrowthTyp' are : ");
				log.info( " MbsoKomEventsRefIndexGrowthTyp " + inp0 + " wcKomRefIdxGthTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefIndexGrowthTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefIndexGrowthTyp (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefIndexGrowthTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefIndexGrowthTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefIndexGrowthTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefEventTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefEventTyp inp0  ,wcKomRefEvntTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefEventTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefEventTyp inp0  ,  wcKomRefEvntTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefEventTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefEventTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefEventTyp' are : ");
				log.info( " MbsoKomEventsRefEventTyp " + inp0 + " wcKomRefEvntTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefEventTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefEventTyp (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefEventTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefEventTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefEventTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefContractCd ( ThreadSpecificContext tctx  ,MbsoKomEventsRefContractCd inp0  ,wcKomRefCntrCdElg inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefContractCd ( ThreadSpecificContext tctx  MbsoKomEventsRefContractCd inp0  ,  wcKomRefCntrCdElg inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefContractCd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefContractCd after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefContractCd' are : ");
				log.info( " MbsoKomEventsRefContractCd " + inp0 + " wcKomRefCntrCdElg " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefContractCd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefContractCd (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefContractCd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefContractCd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefContractCd  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefSchTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSchTyp inp0  ,wcKomRefSchdTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefSchTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSchTyp inp0  ,  wcKomRefSchdTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefSchTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefSchTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefSchTyp' are : ");
				log.info( " MbsoKomEventsRefSchTyp " + inp0 + " wcKomRefSchdTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefSchTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefSchTyp (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefSchTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSchTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSchTyp  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefMultiplicationFactor ( ThreadSpecificContext tctx  ,MbsoKomEventsRefMultiplicationFactor inp0  ,wcKomRefMulFact inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefMultiplicationFactor ( ThreadSpecificContext tctx  MbsoKomEventsRefMultiplicationFactor inp0  ,  wcKomRefMulFact inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefMultiplicationFactor Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefMultiplicationFactor after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefMultiplicationFactor' are : ");
				log.info( " MbsoKomEventsRefMultiplicationFactor " + inp0 + " wcKomRefMulFact " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefMultiplicationFactor  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefMultiplicationFactor (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefMultiplicationFactor  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefMultiplicationFactor  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefMultiplicationFactor  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefVatInfo ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVatInfo inp0  ,wcKomRefVatTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefVatInfo ( ThreadSpecificContext tctx  MbsoKomEventsRefVatInfo inp0  ,  wcKomRefVatTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefVatInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefVatInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefVatInfo' are : ");
				log.info( " MbsoKomEventsRefVatInfo " + inp0 + " wcKomRefVatTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefVatInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefVatInfo (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefVatInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVatInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVatInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefScrTerm ( ThreadSpecificContext tctx  ,MbsoKomEventsRefScrTerm inp0  ,wcKomRefScrTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefScrTerm ( ThreadSpecificContext tctx  MbsoKomEventsRefScrTerm inp0  ,  wcKomRefScrTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefScrTerm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefScrTerm after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefScrTerm' are : ");
				log.info( " MbsoKomEventsRefScrTerm " + inp0 + " wcKomRefScrTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefScrTerm  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefScrTerm (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefScrTerm  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefScrTerm  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefScrTerm  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefAuditAgtInfo ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAuditAgtInfo inp0  ,wcKomRefKOMAGTAudit inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefAuditAgtInfo ( ThreadSpecificContext tctx  MbsoKomEventsRefAuditAgtInfo inp0  ,  wcKomRefKOMAGTAudit inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefAuditAgtInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefAuditAgtInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefAuditAgtInfo' are : ");
				log.info( " MbsoKomEventsRefAuditAgtInfo " + inp0 + " wcKomRefKOMAGTAudit " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefAuditAgtInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefAuditAgtInfo (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefAuditAgtInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefAuditAgtInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefAuditAgtInfo  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefVestingRules ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingRules inp0  ,wcKomRefVestingRules inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefVestingRules ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingRules inp0  ,  wcKomRefVestingRules inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefVestingRules Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefVestingRules after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefVestingRules' are : ");
				log.info( " MbsoKomEventsRefVestingRules " + inp0 + " wcKomRefVestingRules " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefVestingRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefVestingRules (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefVestingRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVestingRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVestingRules  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefVestingScales ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingScales inp0  ,wcKomRefVestingScales inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefVestingScales ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingScales inp0  ,  wcKomRefVestingScales inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefVestingScales Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefVestingScales after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefVestingScales' are : ");
				log.info( " MbsoKomEventsRefVestingScales " + inp0 + " wcKomRefVestingScales " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefVestingScales  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefVestingScales (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefVestingScales  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVestingScales  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVestingScales  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefVestingScalesPrmHols ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingScalesPrmHols inp0  ,wcKomRefPremHdayVestScles inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefVestingScalesPrmHols ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingScalesPrmHols inp0  ,  wcKomRefPremHdayVestScles inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefVestingScalesPrmHols Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefVestingScalesPrmHols after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefVestingScalesPrmHols' are : ");
				log.info( " MbsoKomEventsRefVestingScalesPrmHols " + inp0 + " wcKomRefPremHdayVestScles " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefVestingScalesPrmHols  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchRefVestingScalesPrmHols (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefVestingScalesPrmHols  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVestingScalesPrmHols  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefVestingScalesPrmHols  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchPmoRefCommTypeVsSplitCommType ( ThreadSpecificContext tctx  ,MbsoKomEventsRefCommVsSplitCommType inp0  ,wcKomRefCommTypVsSpltCommTyp inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchPmoRefCommTypeVsSplitCommType ( ThreadSpecificContext tctx  MbsoKomEventsRefCommVsSplitCommType inp0  ,  wcKomRefCommTypVsSpltCommTyp inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchPmoRefCommTypeVsSplitCommType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchPmoRefCommTypeVsSplitCommType after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchPmoRefCommTypeVsSplitCommType' are : ");
				log.info( " MbsoKomEventsRefCommVsSplitCommType " + inp0 + " wcKomRefCommTypVsSpltCommTyp " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchPmoRefCommTypeVsSplitCommType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchPmoRefCommTypeVsSplitCommType (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchPmoRefCommTypeVsSplitCommType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchPmoRefCommTypeVsSplitCommType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchPmoRefCommTypeVsSplitCommType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchKomEventsRefDropDownValues ( ThreadSpecificContext tctx  ,MbsoKomEventsRefDropDownInputClass inp0 )
	{
		log.debug(" Entering function ' sh_fetchKomEventsRefDropDownValues ( ThreadSpecificContext tctx  MbsoKomEventsRefDropDownInputClass inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchKomEventsRefDropDownValues Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchKomEventsRefDropDownValues after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchKomEventsRefDropDownValues' are : ");
				log.info( " MbsoKomEventsRefDropDownInputClass " + inp0 );

				log.debug(" Calling function ' fetchKomEventsRefDropDownValues  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchKomEventsRefDropDownValues (  inp0 );

				log.debug(" Returned from function ' fetchKomEventsRefDropDownValues  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchKomEventsRefDropDownValues  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchKomEventsRefDropDownValues  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updateSystemAgeingDate ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSysAgeingPmtrs inp0 )
	{
		log.debug(" Entering function ' sh_updateSystemAgeingDate ( ThreadSpecificContext tctx  MbsoKomEventsRefSysAgeingPmtrs inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updateSystemAgeingDate Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updateSystemAgeingDate after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updateSystemAgeingDate' are : ");
				log.info( " MbsoKomEventsRefSysAgeingPmtrs " + inp0 );

				log.debug(" Calling function ' updateSystemAgeingDate  (   inp0 )  : returns void ' of class PmoKomEventsRefReferenceData ");
				PmoKomEventsRefReferenceData.updateSystemAgeingDate (  inp0 );

				log.debug(" Returned from function ' updateSystemAgeingDate  (   inp0 )  : returns void ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updateSystemAgeingDate  (   inp0 )  : returns void ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updateSystemAgeingDate  (   inp0 )  : returns void ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefSourceSys ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSourceSys inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefSourceSys ( ThreadSpecificContext tctx  MbsoKomEventsRefSourceSys inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefSourceSys Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefSourceSys after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefSourceSys' are : ");
				log.info( " MbsoKomEventsRefSourceSys " + inp0 );

				log.debug(" Calling function ' updatePmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefSourceSys (  inp0 );

				log.debug(" Returned from function ' updatePmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefCommTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefCommTyp inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefCommTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefCommTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefCommTyp' are : ");
				log.info( " MbsoKomEventsRefCommTyp " + inp0 );

				log.debug(" Calling function ' updatePmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefCommTyp (  inp0 );

				log.debug(" Returned from function ' updatePmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefSplitCommTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSplitCommTyp inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefSplitCommTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSplitCommTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefSplitCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefSplitCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefSplitCommTyp' are : ");
				log.info( " MbsoKomEventsRefSplitCommTyp " + inp0 );

				log.debug(" Calling function ' updatePmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefSplitCommTyp (  inp0 );

				log.debug(" Returned from function ' updatePmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefIndexGrowthTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefIndexGrowthTyp inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefIndexGrowthTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefIndexGrowthTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefIndexGrowthTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefIndexGrowthTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefIndexGrowthTyp' are : ");
				log.info( " MbsoKomEventsRefIndexGrowthTyp " + inp0 );

				log.debug(" Calling function ' updatePmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefIndexGrowthTyp (  inp0 );

				log.debug(" Returned from function ' updatePmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefEventTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefEventTyp inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefEventTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefEventTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefEventTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefEventTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefEventTyp' are : ");
				log.info( " MbsoKomEventsRefEventTyp " + inp0 );

				log.debug(" Calling function ' updatePmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefEventTyp (  inp0 );

				log.debug(" Returned from function ' updatePmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefContractCd ( ThreadSpecificContext tctx  ,MbsoKomEventsRefContractCd inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefContractCd ( ThreadSpecificContext tctx  MbsoKomEventsRefContractCd inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefContractCd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefContractCd after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefContractCd' are : ");
				log.info( " MbsoKomEventsRefContractCd " + inp0 );

				log.debug(" Calling function ' addPmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefContractCd (  inp0 );

				log.debug(" Returned from function ' addPmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefContractCd ( ThreadSpecificContext tctx  ,MbsoKomEventsRefContractCd inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefContractCd ( ThreadSpecificContext tctx  MbsoKomEventsRefContractCd inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefContractCd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefContractCd after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefContractCd' are : ");
				log.info( " MbsoKomEventsRefContractCd " + inp0 );

				log.debug(" Calling function ' updatePmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefContractCd (  inp0 );

				log.debug(" Returned from function ' updatePmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefContractCd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefSchTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSchTyp inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefSchTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSchTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefSchTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefSchTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefSchTyp' are : ");
				log.info( " MbsoKomEventsRefSchTyp " + inp0 );

				log.debug(" Calling function ' updatePmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefSchTyp (  inp0 );

				log.debug(" Returned from function ' updatePmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefMultiplicationFactor ( ThreadSpecificContext tctx  ,MbsoKomEventsRefMultiplicationFactor inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefMultiplicationFactor ( ThreadSpecificContext tctx  MbsoKomEventsRefMultiplicationFactor inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefMultiplicationFactor Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefMultiplicationFactor after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefMultiplicationFactor' are : ");
				log.info( " MbsoKomEventsRefMultiplicationFactor " + inp0 );

				log.debug(" Calling function ' addPmoRefMultiplicationFactor  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefMultiplicationFactor (  inp0 );

				log.debug(" Returned from function ' addPmoRefMultiplicationFactor  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefMultiplicationFactor  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefMultiplicationFactor  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefVatInfo ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVatInfo inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefVatInfo ( ThreadSpecificContext tctx  MbsoKomEventsRefVatInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefVatInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefVatInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefVatInfo' are : ");
				log.info( " MbsoKomEventsRefVatInfo " + inp0 );

				log.debug(" Calling function ' addPmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefVatInfo (  inp0 );

				log.debug(" Returned from function ' addPmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefVatInfo ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVatInfo inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefVatInfo ( ThreadSpecificContext tctx  MbsoKomEventsRefVatInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefVatInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefVatInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefVatInfo' are : ");
				log.info( " MbsoKomEventsRefVatInfo " + inp0 );

				log.debug(" Calling function ' updatePmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefVatInfo (  inp0 );

				log.debug(" Returned from function ' updatePmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVatInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefScrTerm ( ThreadSpecificContext tctx  ,MbsoKomEventsRefScrTerm inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefScrTerm ( ThreadSpecificContext tctx  MbsoKomEventsRefScrTerm inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefScrTerm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefScrTerm after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefScrTerm' are : ");
				log.info( " MbsoKomEventsRefScrTerm " + inp0 );

				log.debug(" Calling function ' updatePmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefScrTerm (  inp0 );

				log.debug(" Returned from function ' updatePmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefAuditAgtInfo ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAuditAgtInfo inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefAuditAgtInfo ( ThreadSpecificContext tctx  MbsoKomEventsRefAuditAgtInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefAuditAgtInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefAuditAgtInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefAuditAgtInfo' are : ");
				log.info( " MbsoKomEventsRefAuditAgtInfo " + inp0 );

				log.debug(" Calling function ' addPmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefAuditAgtInfo (  inp0 );

				log.debug(" Returned from function ' addPmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefAuditAgtInfo ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAuditAgtInfo inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefAuditAgtInfo ( ThreadSpecificContext tctx  MbsoKomEventsRefAuditAgtInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefAuditAgtInfo Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefAuditAgtInfo after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefAuditAgtInfo' are : ");
				log.info( " MbsoKomEventsRefAuditAgtInfo " + inp0 );

				log.debug(" Calling function ' updatePmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefAuditAgtInfo (  inp0 );

				log.debug(" Returned from function ' updatePmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefAuditAgtInfo  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefVestingRules ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingRules inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefVestingRules ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingRules inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefVestingRules Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefVestingRules after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefVestingRules' are : ");
				log.info( " MbsoKomEventsRefVestingRules " + inp0 );

				log.debug(" Calling function ' addPmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefVestingRules (  inp0 );

				log.debug(" Returned from function ' addPmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefVestingRules ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingRules inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefVestingRules ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingRules inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefVestingRules Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefVestingRules after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefVestingRules' are : ");
				log.info( " MbsoKomEventsRefVestingRules " + inp0 );

				log.debug(" Calling function ' updatePmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefVestingRules (  inp0 );

				log.debug(" Returned from function ' updatePmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVestingRules  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefVestingScales ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingScales inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefVestingScales ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingScales inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefVestingScales Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefVestingScales after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefVestingScales' are : ");
				log.info( " MbsoKomEventsRefVestingScales " + inp0 );

				log.debug(" Calling function ' addPmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefVestingScales (  inp0 );

				log.debug(" Returned from function ' addPmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefVestingScales ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingScales inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefVestingScales ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingScales inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefVestingScales Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefVestingScales after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefVestingScales' are : ");
				log.info( " MbsoKomEventsRefVestingScales " + inp0 );

				log.debug(" Calling function ' updatePmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefVestingScales (  inp0 );

				log.debug(" Returned from function ' updatePmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVestingScales  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefVestingScalesPrmHols ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingScalesPrmHols inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefVestingScalesPrmHols ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingScalesPrmHols inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefVestingScalesPrmHols Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefVestingScalesPrmHols after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefVestingScalesPrmHols' are : ");
				log.info( " MbsoKomEventsRefVestingScalesPrmHols " + inp0 );

				log.debug(" Calling function ' addPmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefVestingScalesPrmHols (  inp0 );

				log.debug(" Returned from function ' addPmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefVestingScalesPrmHols ( ThreadSpecificContext tctx  ,MbsoKomEventsRefVestingScalesPrmHols inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefVestingScalesPrmHols ( ThreadSpecificContext tctx  MbsoKomEventsRefVestingScalesPrmHols inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefVestingScalesPrmHols Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefVestingScalesPrmHols after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefVestingScalesPrmHols' are : ");
				log.info( " MbsoKomEventsRefVestingScalesPrmHols " + inp0 );

				log.debug(" Calling function ' updatePmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefVestingScalesPrmHols (  inp0 );

				log.debug(" Returned from function ' updatePmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefVestingScalesPrmHols  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefCommTypeVsSpliCommType ( ThreadSpecificContext tctx  ,MbsoKomEventsRefCommVsSplitCommType inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefCommTypeVsSpliCommType ( ThreadSpecificContext tctx  MbsoKomEventsRefCommVsSplitCommType inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefCommTypeVsSpliCommType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefCommTypeVsSpliCommType after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefCommTypeVsSpliCommType' are : ");
				log.info( " MbsoKomEventsRefCommVsSplitCommType " + inp0 );

				log.debug(" Calling function ' addPmoRefCommTypeVsSpliCommType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefCommTypeVsSpliCommType (  inp0 );

				log.debug(" Returned from function ' addPmoRefCommTypeVsSpliCommType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefCommTypeVsSpliCommType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefCommTypeVsSpliCommType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_pmoGetSystemageingDate ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSysAgeingPmtrs inp0 )
	{
		log.debug(" Entering function ' sh_pmoGetSystemageingDate ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSysAgeingPmtrs inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MbsoKomEventsRefSysAgeingPmtrs return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside pmoGetSystemageingDate Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside pmoGetSystemageingDate after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'pmoGetSystemageingDate' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSysAgeingPmtrs " + inp0 );

				log.debug(" Calling function ' pmoGetSystemageingDate  (   inp0 )  : returns return1 ' of class PmoKomEventsRefReferenceData ");
				return1 = inst_PmoKomEventsRefReferenceData.pmoGetSystemageingDate (  inp0 );

				log.debug(" Returned from function ' pmoGetSystemageingDate  (   inp0 )  : returns return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' pmoGetSystemageingDate  (   inp0 )  : returns return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' pmoGetSystemageingDate  (   inp0 )  : returns return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefSpltVsAccTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSplitCommTypeAXEInfo inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefSpltVsAccTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSplitCommTypeAXEInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefSpltVsAccTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefSpltVsAccTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefSpltVsAccTyp' are : ");
				log.info( " MbsoKomEventsRefSplitCommTypeAXEInfo " + inp0 );

				log.debug(" Calling function ' addPmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefSpltVsAccTyp (  inp0 );

				log.debug(" Returned from function ' addPmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchSpltCommVsAccTrans ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSplitCommTypeAXEInfo inp0  ,wcKomRefSpltComVsAccTrans inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchSpltCommVsAccTrans ( ThreadSpecificContext tctx  MbsoKomEventsRefSplitCommTypeAXEInfo inp0  ,  wcKomRefSpltComVsAccTrans inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchSpltCommVsAccTrans Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchSpltCommVsAccTrans after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchSpltCommVsAccTrans' are : ");
				log.info( " MbsoKomEventsRefSplitCommTypeAXEInfo " + inp0 + " wcKomRefSpltComVsAccTrans " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchSpltCommVsAccTrans  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchSpltCommVsAccTrans (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchSpltCommVsAccTrans  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchSpltCommVsAccTrans  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchSpltCommVsAccTrans  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_deletePmoRefSpltVsAccTyp ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSplitCommTypeAXEInfo inp0 )
	{
		log.debug(" Entering function ' sh_deletePmoRefSpltVsAccTyp ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSplitCommTypeAXEInfo inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside deletePmoRefSpltVsAccTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside deletePmoRefSpltVsAccTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'deletePmoRefSpltVsAccTyp' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSplitCommTypeAXEInfo " + inp0 );

				log.debug(" Calling function ' deletePmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.deletePmoRefSpltVsAccTyp (  inp0 );

				log.debug(" Returned from function ' deletePmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoRefSpltVsAccTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_deleteKomEventsRefCommTypVsSplitCommTyp ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefCommVsSplitCommType inp0 )
	{
		log.debug(" Entering function ' sh_deleteKomEventsRefCommTypVsSplitCommTyp ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefCommVsSplitCommType inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside deleteKomEventsRefCommTypVsSplitCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside deleteKomEventsRefCommTypVsSplitCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'deleteKomEventsRefCommTypVsSplitCommTyp' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefCommVsSplitCommType " + inp0 );

				log.debug(" Calling function ' deleteKomEventsRefCommTypVsSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.deleteKomEventsRefCommTypVsSplitCommTyp (  inp0 );

				log.debug(" Returned from function ' deleteKomEventsRefCommTypVsSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' deleteKomEventsRefCommTypVsSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' deleteKomEventsRefCommTypVsSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchSysParamList ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSystemParameter inp0  ,wcKomRefSysParamList inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchSysParamList ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSystemParameter inp0  ,  wcKomRefSysParamList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchSysParamList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchSysParamList after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchSysParamList' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSystemParameter " + inp0 + " wcKomRefSysParamList " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchSysParamList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.fetchSysParamList (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchSysParamList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchSysParamList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchSysParamList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addSystemParam ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSystemParameter inp0 )
	{
		log.debug(" Entering function ' sh_addSystemParam ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSystemParameter inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addSystemParam Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addSystemParam after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addSystemParam' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSystemParameter " + inp0 );

				log.debug(" Calling function ' addSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.addSystemParam (  inp0 );

				log.debug(" Returned from function ' addSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updateSystemParam ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSystemParameter inp0 )
	{
		log.debug(" Entering function ' sh_updateSystemParam ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSystemParameter inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updateSystemParam Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updateSystemParam after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updateSystemParam' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSystemParameter " + inp0 );

				log.debug(" Calling function ' updateSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.updateSystemParam (  inp0 );

				log.debug(" Returned from function ' updateSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updateSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updateSystemParam  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchAdvanceTermList ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAdvanceTerm inp0  ,wcKomRefAdvanceTermList inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchAdvanceTermList ( ThreadSpecificContext tctx  MbsoKomEventsRefAdvanceTerm inp0  ,  wcKomRefAdvanceTermList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchAdvanceTermList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchAdvanceTermList after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchAdvanceTermList' are : ");
				log.info( " MbsoKomEventsRefAdvanceTerm " + inp0 + " wcKomRefAdvanceTermList " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchAdvanceTermList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchAdvanceTermList (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchAdvanceTermList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchAdvanceTermList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchAdvanceTermList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addAdvanceTerm ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAdvanceTerm inp0 )
	{
		log.debug(" Entering function ' sh_addAdvanceTerm ( ThreadSpecificContext tctx  MbsoKomEventsRefAdvanceTerm inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addAdvanceTerm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addAdvanceTerm after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addAdvanceTerm' are : ");
				log.info( " MbsoKomEventsRefAdvanceTerm " + inp0 );

				log.debug(" Calling function ' addAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addAdvanceTerm (  inp0 );

				log.debug(" Returned from function ' addAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updateAdvanceTerm ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAdvanceTerm inp0 )
	{
		log.debug(" Entering function ' sh_updateAdvanceTerm ( ThreadSpecificContext tctx  MbsoKomEventsRefAdvanceTerm inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updateAdvanceTerm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updateAdvanceTerm after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updateAdvanceTerm' are : ");
				log.info( " MbsoKomEventsRefAdvanceTerm " + inp0 );

				log.debug(" Calling function ' updateAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updateAdvanceTerm (  inp0 );

				log.debug(" Returned from function ' updateAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updateAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updateAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_deleteAdvanceTerm ( ThreadSpecificContext tctx  ,MbsoKomEventsRefAdvanceTerm inp0 )
	{
		log.debug(" Entering function ' sh_deleteAdvanceTerm ( ThreadSpecificContext tctx  MbsoKomEventsRefAdvanceTerm inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside deleteAdvanceTerm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside deleteAdvanceTerm after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'deleteAdvanceTerm' are : ");
				log.info( " MbsoKomEventsRefAdvanceTerm " + inp0 );

				log.debug(" Calling function ' deleteAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.deleteAdvanceTerm (  inp0 );

				log.debug(" Returned from function ' deleteAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' deleteAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' deleteAdvanceTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchProdtVsElmntList ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefProdTypeInd inp0  ,wcKomRefProdTypeIndList inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchProdtVsElmntList ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefProdTypeInd inp0  ,  wcKomRefProdTypeIndList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchProdtVsElmntList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchProdtVsElmntList after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchProdtVsElmntList' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefProdTypeInd " + inp0 + " wcKomRefProdTypeIndList " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchProdtVsElmntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.fetchProdtVsElmntList (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchProdtVsElmntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchProdtVsElmntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchProdtVsElmntList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoProdTypeInd ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefProdTypeInd inp0 )
	{
		log.debug(" Entering function ' sh_addPmoProdTypeInd ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefProdTypeInd inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoProdTypeInd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoProdTypeInd after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoProdTypeInd' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefProdTypeInd " + inp0 );

				log.debug(" Calling function ' addPmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.addPmoProdTypeInd (  inp0 );

				log.debug(" Returned from function ' addPmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoProdTypeInd ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefProdTypeInd inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoProdTypeInd ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefProdTypeInd inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoProdTypeInd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoProdTypeInd after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoProdTypeInd' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefProdTypeInd " + inp0 );

				log.debug(" Calling function ' updatePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.updatePmoProdTypeInd (  inp0 );

				log.debug(" Returned from function ' updatePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_deletePmoProdTypeInd ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefProdTypeInd inp0 )
	{
		log.debug(" Entering function ' sh_deletePmoProdTypeInd ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefProdTypeInd inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside deletePmoProdTypeInd Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside deletePmoProdTypeInd after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'deletePmoProdTypeInd' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefProdTypeInd " + inp0 );

				log.debug(" Calling function ' deletePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.deletePmoProdTypeInd (  inp0 );

				log.debug(" Returned from function ' deletePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoProdTypeInd  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoFirstPmtDt ( ThreadSpecificContext tctx  ,MbsoKomEventsRefFirstPmtDt inp0 )
	{
		log.debug(" Entering function ' sh_addPmoFirstPmtDt ( ThreadSpecificContext tctx  MbsoKomEventsRefFirstPmtDt inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoFirstPmtDt Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoFirstPmtDt after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoFirstPmtDt' are : ");
				log.info( " MbsoKomEventsRefFirstPmtDt " + inp0 );

				log.debug(" Calling function ' addPmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoFirstPmtDt (  inp0 );

				log.debug(" Returned from function ' addPmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoFirstPmtDt ( ThreadSpecificContext tctx  ,MbsoKomEventsRefFirstPmtDt inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoFirstPmtDt ( ThreadSpecificContext tctx  MbsoKomEventsRefFirstPmtDt inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoFirstPmtDt Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoFirstPmtDt after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoFirstPmtDt' are : ");
				log.info( " MbsoKomEventsRefFirstPmtDt " + inp0 );

				log.debug(" Calling function ' updatePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoFirstPmtDt (  inp0 );

				log.debug(" Returned from function ' updatePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchFirstPmtDtList ( ThreadSpecificContext tctx  ,MbsoKomEventsRefFirstPmtDt inp0  ,wcKomRefFirstPmtDtList inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchFirstPmtDtList ( ThreadSpecificContext tctx  MbsoKomEventsRefFirstPmtDt inp0  ,  wcKomRefFirstPmtDtList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchFirstPmtDtList Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchFirstPmtDtList after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchFirstPmtDtList' are : ");
				log.info( " MbsoKomEventsRefFirstPmtDt " + inp0 + " wcKomRefFirstPmtDtList " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchFirstPmtDtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchFirstPmtDtList (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchFirstPmtDtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchFirstPmtDtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchFirstPmtDtList  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_deletePmoFirstPmtDt ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefFirstPmtDt inp0 )
	{
		log.debug(" Entering function ' sh_deletePmoFirstPmtDt ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefFirstPmtDt inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside deletePmoFirstPmtDt Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside deletePmoFirstPmtDt after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'deletePmoFirstPmtDt' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefFirstPmtDt " + inp0 );

				log.debug(" Calling function ' deletePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.deletePmoFirstPmtDt (  inp0 );

				log.debug(" Returned from function ' deletePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoFirstPmtDt  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_deletePmoRefSplitCommSchdType ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSplitCommSchdType inp0 )
	{
		log.debug(" Entering function ' sh_deletePmoRefSplitCommSchdType ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSplitCommSchdType inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside deletePmoRefSplitCommSchdType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside deletePmoRefSplitCommSchdType after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'deletePmoRefSplitCommSchdType' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSplitCommSchdType " + inp0 );

				log.debug(" Calling function ' deletePmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.deletePmoRefSplitCommSchdType (  inp0 );

				log.debug(" Returned from function ' deletePmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' deletePmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefSplitCommSchdType ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSplitCommSchdType inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefSplitCommSchdType ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSplitCommSchdType inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefSplitCommSchdType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefSplitCommSchdType after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefSplitCommSchdType' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSplitCommSchdType " + inp0 );

				log.debug(" Calling function ' addPmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.addPmoRefSplitCommSchdType (  inp0 );

				log.debug(" Returned from function ' addPmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSplitCommSchdType  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefSplitCommSchdTyp ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSplitCommSchdType inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefSplitCommSchdTyp ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSplitCommSchdType inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefSplitCommSchdTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefSplitCommSchdTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefSplitCommSchdTyp' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSplitCommSchdType " + inp0 );

				log.debug(" Calling function ' updatePmoRefSplitCommSchdTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.updatePmoRefSplitCommSchdTyp (  inp0 );

				log.debug(" Returned from function ' updatePmoRefSplitCommSchdTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSplitCommSchdTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefSplitCommSchdTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchRefSplitCommSchdType ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  ,MbsoKomEventsRefSplitCommSchdType inp0  ,wcKomRefSpltComSchdTypList inp1  ,Direction inp2 )
	{
		log.debug(" Entering function ' sh_fetchRefSplitCommSchdType ( ThreadSpecificContext tctx , PmoKomEventsRefReferenceData inst_PmoKomEventsRefReferenceData  MbsoKomEventsRefSplitCommSchdType inp0  ,  wcKomRefSpltComSchdTypList inp1  ,  Direction inp2 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchRefSplitCommSchdType Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchRefSplitCommSchdType after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchRefSplitCommSchdType' are : ");
				log.info( " PmoKomEventsRefReferenceData " + inst_PmoKomEventsRefReferenceData + " MbsoKomEventsRefSplitCommSchdType " + inp0 + " wcKomRefSpltComSchdTypList " + inp1 + " Direction " + inp2 );

				log.debug(" Calling function ' fetchRefSplitCommSchdType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = inst_PmoKomEventsRefReferenceData.fetchRefSplitCommSchdType (  inp0, inp1, inp2 );

				log.debug(" Returned from function ' fetchRefSplitCommSchdType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + inst_PmoKomEventsRefReferenceData + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSplitCommSchdType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) inst_PmoKomEventsRefReferenceData);
			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchRefSplitCommSchdType  (   inp0, inp1, inp2 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefMultiplicationFactorPtrn ( ThreadSpecificContext tctx  ,MbsoKomEventsRefMultFactPtrn inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefMultiplicationFactorPtrn ( ThreadSpecificContext tctx  MbsoKomEventsRefMultFactPtrn inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefMultiplicationFactorPtrn Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefMultiplicationFactorPtrn after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefMultiplicationFactorPtrn' are : ");
				log.info( " MbsoKomEventsRefMultFactPtrn " + inp0 );

				log.debug(" Calling function ' addPmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefMultiplicationFactorPtrn (  inp0 );

				log.debug(" Returned from function ' addPmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_updatePmoRefMultiplicationFactorPtrn ( ThreadSpecificContext tctx  ,MbsoKomEventsRefMultFactPtrn inp0 )
	{
		log.debug(" Entering function ' sh_updatePmoRefMultiplicationFactorPtrn ( ThreadSpecificContext tctx  MbsoKomEventsRefMultFactPtrn inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside updatePmoRefMultiplicationFactorPtrn Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside updatePmoRefMultiplicationFactorPtrn after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'updatePmoRefMultiplicationFactorPtrn' are : ");
				log.info( " MbsoKomEventsRefMultFactPtrn " + inp0 );

				log.debug(" Calling function ' updatePmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.updatePmoRefMultiplicationFactorPtrn (  inp0 );

				log.debug(" Returned from function ' updatePmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' updatePmoRefMultiplicationFactorPtrn  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_fetchPmoRefMultFactPtrn ( ThreadSpecificContext tctx  ,wcKomEventsRefMultFactPtrnList inp0  ,Direction inp1 )
	{
		log.debug(" Entering function ' sh_fetchPmoRefMultFactPtrn ( ThreadSpecificContext tctx  wcKomEventsRefMultFactPtrnList inp0  ,  Direction inp1 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside fetchPmoRefMultFactPtrn Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside fetchPmoRefMultFactPtrn after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'fetchPmoRefMultFactPtrn' are : ");
				log.info( " wcKomEventsRefMultFactPtrnList " + inp0 + " Direction " + inp1 );

				log.debug(" Calling function ' fetchPmoRefMultFactPtrn  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.fetchPmoRefMultFactPtrn (  inp0, inp1 );

				log.debug(" Returned from function ' fetchPmoRefMultFactPtrn  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchPmoRefMultFactPtrn  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' fetchPmoRefMultFactPtrn  (   inp0, inp1 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefSourceSys ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSourceSys inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefSourceSys ( ThreadSpecificContext tctx  MbsoKomEventsRefSourceSys inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefSourceSys Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefSourceSys after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefSourceSys' are : ");
				log.info( " MbsoKomEventsRefSourceSys " + inp0 );

				log.debug(" Calling function ' addPmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefSourceSys (  inp0 );

				log.debug(" Returned from function ' addPmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSourceSys  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefCommTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefCommTyp inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefCommTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefCommTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefCommTyp' are : ");
				log.info( " MbsoKomEventsRefCommTyp " + inp0 );

				log.debug(" Calling function ' addPmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefCommTyp (  inp0 );

				log.debug(" Returned from function ' addPmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefEventTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefEventTyp inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefEventTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefEventTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefEventTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefEventTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefEventTyp' are : ");
				log.info( " MbsoKomEventsRefEventTyp " + inp0 );

				log.debug(" Calling function ' addPmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefEventTyp (  inp0 );

				log.debug(" Returned from function ' addPmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefEventTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefScrTerm ( ThreadSpecificContext tctx  ,MbsoKomEventsRefScrTerm inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefScrTerm ( ThreadSpecificContext tctx  MbsoKomEventsRefScrTerm inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefScrTerm Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefScrTerm after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefScrTerm' are : ");
				log.info( " MbsoKomEventsRefScrTerm " + inp0 );

				log.debug(" Calling function ' addPmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefScrTerm (  inp0 );

				log.debug(" Returned from function ' addPmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefScrTerm  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefSplitCommTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSplitCommTyp inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefSplitCommTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSplitCommTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefSplitCommTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefSplitCommTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefSplitCommTyp' are : ");
				log.info( " MbsoKomEventsRefSplitCommTyp " + inp0 );

				log.debug(" Calling function ' addPmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefSplitCommTyp (  inp0 );

				log.debug(" Returned from function ' addPmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSplitCommTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefSchTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefSchTyp inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefSchTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefSchTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefSchTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefSchTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefSchTyp' are : ");
				log.info( " MbsoKomEventsRefSchTyp " + inp0 );

				log.debug(" Calling function ' addPmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefSchTyp (  inp0 );

				log.debug(" Returned from function ' addPmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefSchTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.

	public MasterCraftretClass sh_addPmoRefIndexGrowthTyp ( ThreadSpecificContext tctx  ,MbsoKomEventsRefIndexGrowthTyp inp0 )
	{
		log.debug(" Entering function ' sh_addPmoRefIndexGrowthTyp ( ThreadSpecificContext tctx  MbsoKomEventsRefIndexGrowthTyp inp0 ) : returns MasterCraftretClass ' of class KomEventsRefBEAN ");
		ErrorType _messageTyp = new ErrorType();
		boolean jdbcCloseFlag = false;
		MasterCraftretClass MCretObj = new MasterCraftretClass();
			MasterCraftVector  multi_return1 = null;

			jdbcCloseFlag = false ;
			if ( tctx != null && tctx.getRemoteInd() == true )
			{
				MasterCraftClientContext mcClientContext = tctx.getMasterCraftClientContext();
				ServerContext.getServerContextObject().setMasterCraftClientContext(mcClientContext);
				tctx = null ;
			}

			ServerContext.setPrintEnabled( bIsPrintEnabled );
			ServerContext.setErrMsgFile( sErrMsgFileName );
			if(tctx != null )
			{
				ServerContext.setServerContextObject( tctx );
			}
			else
			{
				ServerContext.clearMessages();
				jdbcCloseFlag=true;
			}

			if( sessionctx != null )
			{
				ServerContext.setContext( sessionctx );
			}


			if ( tctx == null )  
			{ // call from web tier 
				ServerContext.setDataSource( dataSource );
			} 
			else 
			{  // inter bean call 
				if ( tctx.getDataSource() == null )
				{
					log.info( "WARNING Inside addPmoRefIndexGrowthTyp Datasource in ThreadSpecificContext is NULL before resetting Datasource in ThreadSpecificContext");
					ServerContext.setDataSource( dataSource );
					log.info( "Inside addPmoRefIndexGrowthTyp after resetting Datasource in ThreadSpecificContext");
				}
			}

			if( dataDir != null )
			{
				ServerContext.setDataDir( dataDir );
			}



			try
			{
				log.info(" The parameters passed to the operation 'addPmoRefIndexGrowthTyp' are : ");
				log.info( " MbsoKomEventsRefIndexGrowthTyp " + inp0 );

				log.debug(" Calling function ' addPmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				multi_return1 = PmoKomEventsRefReferenceData.addPmoRefIndexGrowthTyp (  inp0 );

				log.debug(" Returned from function ' addPmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ");
				_messageTyp.setValue(ServerContext.getMaxSeverity( ));

				log.info( " ERRORTYPE retuned is :" + _messageTyp );
				log.info( " Inout and Out parameters are :"    + multi_return1 );
			}
			catch( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}

		finally
		{
			 try
			{
 			MCretObj.getOutParameters().append((Object) multi_return1);

				MasterCraftClientContext cctemp = ServerContext.getServerContextObject().getMasterCraftClientContext();
				MCretObj.setMCClientContext(cctemp);
				boolean noWarningFlag = ServerContext.getServerContextObject().getMasterCraftClientContext().getNoWarningFlag();
				if( (( _messageTyp.getValue() == _messageTyp.XL_WARNING ) && ( noWarningFlag != true) ) || ( _messageTyp.getValue() > _messageTyp.XL_WARNING ))
				{
					log.info(" About to abort the current transaction ");
					sessionctx.setRollbackOnly();
				}
				else if (ServerContext.checkWarning() == true) // only if there are warnings do these
				{
					executeWarningCheck(_messageTyp);
				}

				MCretObj.setReturnStatus(_messageTyp);
				MCretObj.setMessageArray(ServerContext.getMESSAGE_ARRAY());
				ErrLogging.ErrLog.logErrMsgs(ServerContext.getServerContextObject());
				if(jdbcCloseFlag)
				ServerContext.clearServerContext();
			}
			catch ( Exception e )
			{
				String errMsg = "Error encountered in function ' addPmoRefIndexGrowthTyp  (   inp0 )  : returns multi_return1 ' of class PmoKomEventsRefReferenceData ";
				MasterCraftException mce = new MasterCraftException ( errMsg , e );
				throw mce;
			}
		}	// End of finally block
	return MCretObj;
	} // closure of opening of sh_.. shell function call.
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for TRHS_TRCH_HST table.
 */
public class FixtureTestTrancheHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestTrancheHistory.class);

    private long trancheId;
    private String advanceCommissionAmount;
    private String clawbackCommissionAmount;
    private String vatAmount;
    private String clawbackVatAmount;
    private int trancheStatus;
    private int paymentAccount;
    private long eventInProcessId;
    private int eventInProcessType;
    private String eventInProcessDate;
    private int trancheHistoryVerifier;

    public FixtureTestTrancheHistory() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }
            setResultSetPosition();

            setTrancheId(getResultSet().getLong("TRHS_TRCH_ID"));
            setAdvanceCommissionAmount(getResultSet().getDouble("TRHS_ADV_COMM_AMT"));
            setClawbackCommissionAmount(getResultSet().getDouble("TRHS_CLBK_COMM_AMT"));
            setVatAmount(getResultSet().getDouble("TRHS_VAT_AMT"));
            setClawbackVatAmount(getResultSet().getDouble("TRHS_CLBK_VAT_AMT"));
            setTrancheStatus(getResultSet().getInt("TRHS_TRCH_STS"));
            setPaymentAccount(getResultSet().getInt("TRHS_PMT_ACC"));
            setEventInProcessId(getResultSet().getLong("TRHS_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("TRHS_EIP_TYP"));
            setEventInProcessDate(format(getResultSet().getDate("TRHS_EIP_DT")));
            setCreatedBy(getResultSet().getString("TRHS_CRTD_BY").trim());
            setVersion(getResultSet().getInt("TRHS_TRCH_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setTrancheHistoryVerifier(getResultSet().getInt("TRHS_TRCH_HST_VER"));
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestTrancheHistory", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestTrancheHistory", e);
            }
        }
    }

    public long trancheId() {
        return trancheId;
    }

    public void setTrancheId(long trancheId) {
        this.trancheId = trancheId;
    }

    public String advanceCommissionAmount() {
        return formatDouble(advanceCommissionAmount);
    }

    public void setAdvanceCommissionAmount(double advanceCommissionAmount) {
        this.advanceCommissionAmount = String.valueOf(advanceCommissionAmount);
    }

    public String clawbackCommissionAmount() {
        return formatDouble(clawbackCommissionAmount);
    }

    public void setClawbackCommissionAmount(double clawbackCommissionAmount) {
        this.clawbackCommissionAmount = String.valueOf(clawbackCommissionAmount);
    }

    public String vatAmount() {
        return formatDouble(vatAmount);
    }

    public void setVatAmount(double vatAmount) {
        this.vatAmount = String.valueOf(vatAmount);
    }

    public String clawbackVatAmount() {
        return formatDouble(clawbackVatAmount);
    }

    public void setClawbackVatAmount(double clawbackVatAmount) {
        this.clawbackVatAmount = String.valueOf(clawbackVatAmount);
    }

    public int trancheStatus() {
        return trancheStatus;
    }

    public void setTrancheStatus(int trancheStatus) {
        this.trancheStatus = trancheStatus;
    }

    public int paymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public int eventInProcessType() {
        return eventInProcessType;
    }

    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    @Deprecated
    public int trancheHistoryVerifier() {
        return trancheHistoryVerifier;
    }

    @Deprecated
    public void setTrancheHistoryVerifier(int trancheHistoryVerifier) {
        this.trancheHistoryVerifier = trancheHistoryVerifier;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer("select TRHS_TRCH_ID,TRHS_ADV_COMM_AMT,TRHS_CLBK_COMM_AMT,"
            + "TRHS_VAT_AMT,TRHS_CLBK_VAT_AMT,TRHS_TRCH_STS,TRHS_PMT_ACC,TRHS_EIP_ID,TRHS_EIP_TYP,TRHS_EIP_DT,TRHS_CRTD_BY,"
            + "TRHS_TRCH_HST_VER,DM_LSTUPDDT from {0}TRHS_TRCH_HST ORDER BY TRHS_TRCH_ID, TRHS_EIP_ID FOR FETCH ONLY WITH UR");
}

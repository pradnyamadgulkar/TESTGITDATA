/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for ERWS_ERWT_STR table.
 */
public class FixtureTestErrorWaitStore extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestErrorWaitStore.class);

    private int storeType;
    private int strType;
    private long referenceId;
    private String errorCode;
    private String errorDescription;
    private String errorType;
    private int errorStatus;
    private String policyNumber;
    private String policyInceptionDate;
    private String productType;
    private String productNameCode;
    private String clientPortfolioNumberOwn;
    private String clientPortfolioNumberIns;
    private String clientPortfolioNumberInsured;
    private String clientSurnameIns;
    private String clientSurnameInsured;
    private String clientInitialsIns;
    private String clientInitialsInsured;
    private int current;
    private int currency;
    private int sourceSystem;
    private long policyNumberConv;
    private String policyNumberConversion;
    private String prePolicyStatus;
    private String policyIssueDate;
    private int convIndicator;
    private int conversionIndicator;
    private String policyBlockIndicator;
    private int eventType;
    private String eventEffectiveDate;
    private String premiumHolidayEndDate;
    private String commissionType;
    private String premiumReductionPercentage;
    private int indexGrowthType;
    private String campaignCode;
    private int indexOpIndicator;
    private int indexOptionIndicator;
    private int taxGroupCode;
    private int numberOfElements;
    private int rparIndicator;
    private int specialReinstatementIndicator;
    private int specialReinstateIndicator;
    private String transactionTimestamp;
    private int numberOfPremiumsReceived;
    private int premiumFrequency;
    private int premiumPaymentMethod;
    private String rvalPremuimInarr;
    private String randValuePremuimInArrears;
    private String policyTotalPremium;
    private int wrongLevel;
    private int warningLevel;
    private String applicationDate;
    private String quoteDate;
    private String quotationDate;
    private int elementNumber;
    private String elementStartDate;
    private int elementTerm;
    private String premiumPerFrequency;
    private String salesCommission;
    private String serviceCommission;
    private String salesNegotiationPercentage;
    private String salesNegotiatedPercentage;
    private String serviceNegotiationPercentage;
    private String serviceNegotiatedPercentage;
    private String renServiceCommission;
    private String renegotiatedServiceCommission;
    private int auditFlag;
    private int strVerifier;
    private String fundValue;
    private String fundCommission;
    private int raXerIndicator;
    private int scoreTerm;
    private String elementScorePremium;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT ERWS_STR_TYP, ERWS_ERWS_REF_ID, ERWS_ERR_CD, ERWS_ERR_DSC, ERWS_ERR_TYP, "
                    + "ERWS_ERR_STS, ERWS_POL_NR, ERWS_POL_INCP_DT, ERWS_PRD_TYP, ERWS_PRD_NAME_CD, "
                    + "ERWS_CLT_PF_NR_OWN, ERWS_CLT_PF_NR_INS, ERWS_CLT_SUR_INS, ERWS_CLT_INI_INS, "
                    + "ERWS_CURR, ERWS_SRC_SYS, ERWS_POL_NR_CONV, ERWS_PRE_POL_STS, ERWS_POL_ISSUE_DT, "
                    + "ERWS_CONV_IND, ERWS_POL_BLOCK_IND, ERWS_EVT_TYP, ERWS_EVT_EFF_DT, ERWS_PRM_HOL_ED_DT, "
                    + "ERWS_COMM_TYP, ERWS_PRM_RDN_PCT, ERWS_IDX_GTH_TYP, ERWS_CMPG_CD, ERWS_IDX_OP_IND, "
                    + "ERWS_TAX_GRP_CD, ERWS_NR_OF_ELMTS, ERWS_RPAR_IND, ERWS_SPL_RINST_IND, ERWS_TRANSACT_TMST, "
                    + "ERWS_NR_PRM_RCVD, ERWS_PRM_FQ, ERWS_PRM_PMT_METH, ERWS_RVALPRM_INARR, ERWS_POL_TOT_PRM, "
                    + "ERWS_WRNG_LEVEL, ERWS_APP_DT, ERWS_QTE_DT, ERWS_ELMT_NR, ERWS_ELMT_START_DT, ERWS_ELMT_TRM, "
                    + "ERWS_PRM_PER_FQ, ERWS_SLS_COMM, ERWS_SRV_COMM, ERWS_SLS_NEGO_PCT, ERWS_SRV_NEGO_PCT, ERWS_REN_SERV_COMM, "
                    + "ERWS_AUD_FLAG, ERWS_CRTD_BY, ERWS_UPD_BY, ERWS_ERWT_STR_VER, DM_LSTUPDDT, "
                    + "ERWS_FUND_VALUE, ERWS_FUND_COMM, ERWS_RA_XER_IND, ERWS_SCR_TRM,ERWS_ELMT_SCR_PRM FROM {0}ERWS_ERWT_STR ORDER BY ERWS_ERWS_REF_ID FOR FETCH ONLY WITH UR");

    public FixtureTestErrorWaitStore() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        LOG.debug("Entering FixtureTestErrorWaitStore.execute()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setStoreType(getResultSet().getInt("ERWS_STR_TYP"));
            setReferenceId(getResultSet().getLong("ERWS_ERWS_REF_ID"));
            setErrorCode(getResultSet().getString("ERWS_ERR_CD"));
            setErrorDescription(getResultSet().getString("ERWS_ERR_DSC"));
            setErrorType(getResultSet().getString("ERWS_ERR_TYP"));
            setErrorStatus(getResultSet().getInt("ERWS_ERR_STS"));
            setPolicyNumber(getResultSet().getString("ERWS_POL_NR"));
            setPolicyInceptionDate(format(getResultSet().getDate("ERWS_POL_INCP_DT")));
            setProductType(getResultSet().getString("ERWS_PRD_TYP"));
            setProductNameCode(getResultSet().getString("ERWS_PRD_NAME_CD"));
            setClientPortfolioNumberOwn(getResultSet().getString("ERWS_CLT_PF_NR_OWN"));
            setClientPortfolioNumberInsured(getResultSet().getString("ERWS_CLT_PF_NR_INS"));
            setClientSurnameInsured(getResultSet().getString("ERWS_CLT_SUR_INS"));
            setClientInitialsInsured(getResultSet().getString("ERWS_CLT_INI_INS").trim());
            setCurrency(getResultSet().getInt("ERWS_CURR"));
            setSourceSystem(getResultSet().getInt("ERWS_SRC_SYS"));
            setPolicyNumberConversion(getResultSet().getString("ERWS_POL_NR_CONV"));
            setPrePolicyStatus(getResultSet().getString("ERWS_PRE_POL_STS"));
            setPolicyIssueDate(format(getResultSet().getDate("ERWS_POL_ISSUE_DT")));
            setConversionIndicator(getResultSet().getInt("ERWS_CONV_IND"));
            setPolicyBlockIndicator(getResultSet().getString("ERWS_POL_BLOCK_IND"));
            setEventType(getResultSet().getInt("ERWS_EVT_TYP"));
            setEventEffectiveDate(format(getResultSet().getDate("ERWS_EVT_EFF_DT")));
            setPremiumHolidayEndDate(format(getResultSet().getDate("ERWS_PRM_HOL_ED_DT")));
            setCommissionType(getResultSet().getString("ERWS_COMM_TYP").trim());
            setPremiumReductionPercentage(getResultSet().getDouble("ERWS_PRM_RDN_PCT"));
            setIndexGrowthType(getResultSet().getInt("ERWS_IDX_GTH_TYP"));
            setCampaignCode(getResultSet().getString("ERWS_CMPG_CD").trim());
            setIndexOptionIndicator(getResultSet().getInt("ERWS_IDX_OP_IND"));
            setTaxGroupCode(getResultSet().getInt("ERWS_TAX_GRP_CD"));
            setNumberOfElements(getResultSet().getInt("ERWS_NR_OF_ELMTS"));
            setRparIndicator(getResultSet().getInt("ERWS_RPAR_IND"));
            setSpecialReinstateIndicator(getResultSet().getInt("ERWS_SPL_RINST_IND"));
            setTransactionTimestamp(format(getResultSet().getTimestamp("ERWS_TRANSACT_TMST")));
            setNumberOfPremiumsReceived(getResultSet().getInt("ERWS_NR_PRM_RCVD"));
            setPremiumFrequency(getResultSet().getInt("ERWS_PRM_FQ"));
            setPremiumPaymentMethod(getResultSet().getInt("ERWS_PRM_PMT_METH"));
            setRandValuePremuimInArrears(getResultSet().getDouble("ERWS_RVALPRM_INARR"));
            setPolicyTotalPremium(getResultSet().getDouble("ERWS_POL_TOT_PRM"));
            setWarningLevel(getResultSet().getInt("ERWS_WRNG_LEVEL"));
            setApplicationDate(format(getResultSet().getDate("ERWS_APP_DT")));
            setQuotationDate(format(getResultSet().getDate("ERWS_QTE_DT")));
            setElementNumber(getResultSet().getInt("ERWS_ELMT_NR"));
            setElementStartDate(format(getResultSet().getDate("ERWS_ELMT_START_DT")));
            setElementTerm(getResultSet().getInt("ERWS_ELMT_TRM"));
            setPremiumPerFrequency(getResultSet().getDouble("ERWS_PRM_PER_FQ"));
            setSalesCommission(getResultSet().getDouble("ERWS_SLS_COMM"));
            setServiceCommission(getResultSet().getDouble("ERWS_SRV_COMM"));
            setSalesNegotiatedPercentage(getResultSet().getDouble("ERWS_SLS_NEGO_PCT"));
            setServiceNegotiatedPercentage(getResultSet().getDouble("ERWS_SRV_NEGO_PCT"));
            setRenegotiatedServiceCommission(getResultSet().getString("ERWS_REN_SERV_COMM"));
            setAuditFlag(getResultSet().getInt("ERWS_AUD_FLAG"));
            setCreatedBy(getResultSet().getString("ERWS_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("ERWS_UPD_BY").trim());
            setVersion(getResultSet().getInt("ERWS_ERWT_STR_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setFundValue(getResultSet().getDouble("ERWS_FUND_VALUE"));
            setFundCommission(getResultSet().getDouble("ERWS_FUND_COMM"));
            setRaXerIndicator(getResultSet().getInt("ERWS_RA_XER_IND"));
            setScoreTerm(getResultSet().getInt("ERWS_SCR_TRM"));
            setElementScorePremium(getResultSet().getString("ERWS_ELMT_SCR_PRM"));

            setStrType(storeType());
            setClientPortfolioNumberIns(clientPortfolioNumberInsured());
            setClientSurnameIns(clientSurnameInsured());
            setClientInitialsIns(clientInitialsInsured());
            setCurrent(currency());
            setPolicyNumberConv(Long.valueOf(policyNumberConversion()));
            setConvIndicator(conversionIndicator());
            setIndexOpIndicator(indexOptionIndicator());
            setSpecialReinstatementIndicator(specialReinstateIndicator());
            setRvalPremuimInarr(Double.parseDouble(randValuePremuimInArrears()));
            setWrongLevel(warningLevel());
            setQuoteDate(quotationDate());
            setSalesNegotiationPercentage(Double.parseDouble(salesNegotiatedPercentage()));
            setServiceNegotiationPercentage(Double.parseDouble(serviceNegotiatedPercentage()));
            setRenServiceCommission(Double.parseDouble(!renegotiatedServiceCommission().equals(NULL_STRING) ? renegotiatedServiceCommission() : "0"));
            setStrVerifier(version());
        } catch (SQLException ex1) {
            LOG.error("Exception encountered in operation execute of class FixtureTestErrorWaitStore", ex1);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestErrorWaitStore", se);
            }
        }
    }

    /**
     * @return the storeType
     */
    public int storeType() {
        return storeType;
    }

    /**
     * @param storeType
     *            the storeType to set
     */
    public void setStoreType(int storeType) {
        this.storeType = storeType;
    }

    /**
     * @return the clientPortfolioNumberInsured
     */
    public String clientPortfolioNumberInsured() {
        return clientPortfolioNumberInsured;
    }

    /**
     * @param clientPortfolioNumberInsured
     *            the clientPortfolioNumberInsured to set
     */
    public void setClientPortfolioNumberInsured(String clientPortfolioNumberInsured) {
        this.clientPortfolioNumberInsured = clientPortfolioNumberInsured;
    }

    /**
     * @return the clientSurnameInsured
     */
    public String clientSurnameInsured() {
        return clientSurnameInsured;
    }

    /**
     * @param clientSurnameInsured
     *            the clientSurnameInsured to set
     */
    public void setClientSurnameInsured(String clientSurnameInsured) {
        this.clientSurnameInsured = clientSurnameInsured;
    }

    /**
     * @return the clientInitialsInsured
     */
    public String clientInitialsInsured() {
        return clientInitialsInsured;
    }

    /**
     * @param clientInitialsInsured
     *            the clientInitialsInsured to set
     */
    public void setClientInitialsInsured(String clientInitialsInsured) {
        this.clientInitialsInsured = clientInitialsInsured;
    }

    /**
     * @return the currency
     */
    public int currency() {
        return currency;
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(int currency) {
        this.currency = currency;
    }

    /**
     * @return the policyNumberConversion
     */
    public String policyNumberConversion() {
        return format(policyNumberConversion);
    }

    /**
     * @param policyNumberConversion
     *            the policyNumberConversion to set
     */
    public void setPolicyNumberConversion(String policyNumberConversion) {
        this.policyNumberConversion = policyNumberConversion;
    }

    /**
     * @return the conversionIndicator
     */
    public int conversionIndicator() {
        return conversionIndicator;
    }

    /**
     * @param conversionIndicator
     *            the conversionIndicator to set
     */
    public void setConversionIndicator(int conversionIndicator) {
        this.conversionIndicator = conversionIndicator;
    }

    /**
     * @return the indexOptionIndicator
     */
    public int indexOptionIndicator() {
        return indexOptionIndicator;
    }

    /**
     * @param indexOptionIndicator
     *            the indexOptionIndicator to set
     */
    public void setIndexOptionIndicator(int indexOptionIndicator) {
        this.indexOptionIndicator = indexOptionIndicator;
    }

    /**
     * @return the specialReinstateIndicator
     */
    public int specialReinstateIndicator() {
        return specialReinstateIndicator;
    }

    /**
     * @param specialReinstateIndicator
     *            the specialReinstateIndicator to set
     */
    public void setSpecialReinstateIndicator(int specialReinstateIndicator) {
        this.specialReinstateIndicator = specialReinstateIndicator;
    }

    /**
     * @return the randValuePremuimInArrears
     */
    public String randValuePremuimInArrears() {
        return formatDouble(randValuePremuimInArrears);
    }

    /**
     * @param randValuePremuimInArrears
     *            the randValuePremuimInArrears to set
     */
    public void setRandValuePremuimInArrears(double randValuePremuimInArrears) {
        this.randValuePremuimInArrears = String.valueOf(randValuePremuimInArrears);
    }

    /**
     * @return the warningLevel
     */
    public int warningLevel() {
        return warningLevel;
    }

    /**
     * @param warningLevel
     *            the warningLevel to set
     */
    public void setWarningLevel(int warningLevel) {
        this.warningLevel = warningLevel;
    }

    /**
     * @return the quotationDate
     */
    public String quotationDate() {
        return quotationDate;
    }

    /**
     * @param quotationDate
     *            the quotationDate to set
     */
    public void setQuotationDate(String quotationDate) {
        this.quotationDate = quotationDate;
    }

    /**
     * @return the salesNegotiatedPercentage
     */
    public String salesNegotiatedPercentage() {
        return formatDouble(salesNegotiatedPercentage);
    }

    /**
     * @param salesNegotiatedPercentage
     *            the salesNegotiatedPercentage to set
     */
    public void setSalesNegotiatedPercentage(double salesNegotiatedPercentage) {
        this.salesNegotiatedPercentage = String.valueOf(salesNegotiatedPercentage);
    }

    /**
     * @return the serviceNegotiatedPercentage
     */
    public String serviceNegotiatedPercentage() {
        return formatDouble(serviceNegotiatedPercentage);
    }

    /**
     * @param serviceNegotiatedPercentage
     *            the serviceNegotiatedPercentage to set
     */
    public void setServiceNegotiatedPercentage(double serviceNegotiatedPercentage) {
        this.serviceNegotiatedPercentage = String.valueOf(serviceNegotiatedPercentage);
    }

    /**
     * @return the renegotiatedServiceCommission
     */
    public String renegotiatedServiceCommission() {
        return formatDouble(renegotiatedServiceCommission);
    }

    /**
     * @param renegotiatedServiceCommission
     *            the renegotiatedServiceCommission to set
     */
    public void setRenegotiatedServiceCommission(String renegotiatedServiceCommission) {
        this.renegotiatedServiceCommission = renegotiatedServiceCommission;
    }

    /**
     * @return the elementScorePremium
     */
    public String elementScorePremium() {
        return formatDouble(elementScorePremium);
    }

    /**
     * @param elementScorePremium
     *            the elementScorePremium to set
     */
    public void setElementScorePremium(String elementScorePremium) {
        this.elementScorePremium = elementScorePremium;
    }

    @Deprecated
    public int strType() {
        return strType;
    }

    @Deprecated
    public void setStrType(int strType) {
        this.strType = strType;
    }

    public long referenceId() {
        return referenceId;
    }

    public void setReferenceId(long referenceId) {
        this.referenceId = referenceId;
    }

    public String errorCode() {
        return format(errorCode);
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String errorDescription() {
        return format(errorDescription);
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

    public String errorType() {
        return format(errorType);
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public int errorStatus() {
        return errorStatus;
    }

    public void setErrorStatus(int errorStatus) {
        this.errorStatus = errorStatus;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String policyInceptionDate() {
        return policyInceptionDate;
    }

    public void setPolicyInceptionDate(String policyInceptionDate) {
        this.policyInceptionDate = policyInceptionDate;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String productNameCode() {
        return productNameCode;
    }

    public void setProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
    }

    public String clientPortfolioNumberOwn() {
        return clientPortfolioNumberOwn;
    }

    public void setClientPortfolioNumberOwn(String clientPortfolioNumberOwn) {
        this.clientPortfolioNumberOwn = clientPortfolioNumberOwn;
    }

    @Deprecated
    public String clientPortfolioNumberIns() {
        return clientPortfolioNumberIns;
    }

    @Deprecated
    public void setClientPortfolioNumberIns(String clientPortfolioNumberIns) {
        this.clientPortfolioNumberIns = clientPortfolioNumberIns;
    }

    @Deprecated
    public String clientSurnameIns() {
        return clientSurnameIns;
    }

    @Deprecated
    public void setClientSurnameIns(String clientSurnameIns) {
        this.clientSurnameIns = clientSurnameIns;
    }

    @Deprecated
    public String clientInitialsIns() {
        return clientInitialsIns;
    }

    @Deprecated
    public void setClientInitialsIns(String clientInitialsIns) {
        this.clientInitialsIns = clientInitialsIns;
    }

    @Deprecated
    public int current() {
        return current;
    }

    @Deprecated
    public void setCurrent(int current) {
        this.current = current;
    }

    public int sourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    @Deprecated
    public long policyNumberConv() {
        return policyNumberConv;
    }

    @Deprecated
    public void setPolicyNumberConv(long policyNumberConv) {
        this.policyNumberConv = policyNumberConv;
    }

    public String prePolicyStatus() {
        return format(prePolicyStatus);
    }

    public void setPrePolicyStatus(String prePolicyStatus) {
        this.prePolicyStatus = prePolicyStatus;
    }

    public String policyIssueDate() {
        return policyIssueDate;
    }

    public void setPolicyIssueDate(String string) {
        this.policyIssueDate = string;
    }

    @Deprecated
    public int convIndicator() {
        return convIndicator;
    }

    @Deprecated
    public void setConvIndicator(int convIndicator) {
        this.convIndicator = convIndicator;
    }

    public String policyBlockIndicator() {
        return format(policyBlockIndicator);
    }

    public void setPolicyBlockIndicator(String policyBlockIndicator) {
        this.policyBlockIndicator = policyBlockIndicator;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    public void setEventEffectiveDate(String string) {
        this.eventEffectiveDate = string;
    }

    public String premiumHolidayEndDate() {
        return premiumHolidayEndDate;
    }

    public void setPremiumHolidayEndDate(String string) {
        this.premiumHolidayEndDate = string;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String premiumReductionPercentage() {
        return formatDouble(premiumReductionPercentage);
    }

    public void setPremiumReductionPercentage(double premiumReductionPercentage) {
        this.premiumReductionPercentage = String.valueOf(premiumReductionPercentage);
    }

    public int indexGrowthType() {
        return indexGrowthType;
    }

    public void setIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
    }

    public String campaignCode() {
        return format(campaignCode);
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    @Deprecated
    public int indexOpIndicator() {
        return indexOpIndicator;
    }

    @Deprecated
    public void setIndexOpIndicator(int indexOpIndicator) {
        this.indexOpIndicator = indexOpIndicator;
    }

    public int taxGroupCode() {
        return taxGroupCode;
    }

    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    public int numberOfElements() {
        return numberOfElements;
    }

    public void setNumberOfElements(int numberOfElements) {
        this.numberOfElements = numberOfElements;
    }

    public int rparIndicator() {
        return rparIndicator;
    }

    public void setRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
    }

    @Deprecated
    public int specialReinstatementIndicator() {
        return specialReinstatementIndicator;
    }

    @Deprecated
    public void setSpecialReinstatementIndicator(int specialReinstatementIndicator) {
        this.specialReinstatementIndicator = specialReinstatementIndicator;
    }

    public String transactionTimestamp() {
        return transactionTimestamp;
    }

    public void setTransactionTimestamp(String transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
    }

    public int numberOfPremiumsReceived() {
        return numberOfPremiumsReceived;
    }

    public void setNumberOfPremiumsReceived(int numberOfPremiumsReceived) {
        this.numberOfPremiumsReceived = numberOfPremiumsReceived;
    }

    public int premiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    public int premiumPaymentMethod() {
        return premiumPaymentMethod;
    }

    public void setPremiumPaymentMethod(int premiumPaymentMethod) {
        this.premiumPaymentMethod = premiumPaymentMethod;
    }

    @Deprecated
    public String rvalPremuimInarr() {
        if (rvalPremuimInarr != null) {
            if (BigDecimal.valueOf(Double.parseDouble(rvalPremuimInarr)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(rvalPremuimInarr).intValue());
            }
        }
        return rvalPremuimInarr;
    }

    @Deprecated
    public void setRvalPremuimInarr(double rvalPremuimInarr) {
        this.rvalPremuimInarr = Double.toString(rvalPremuimInarr);
    }

    public String policyTotalPremium() {
        return formatDouble(policyTotalPremium);
    }

    public void setPolicyTotalPremium(double policyTotalPremium) {
        this.policyTotalPremium = String.valueOf(policyTotalPremium);
    }

    @Deprecated
    public int wrongLevel() {
        return wrongLevel;
    }

    @Deprecated
    public void setWrongLevel(int wrongLevel) {
        this.wrongLevel = wrongLevel;
    }

    public String applicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String string) {
        this.applicationDate = string;
    }

    @Deprecated
    public String quoteDate() {
        return quoteDate;
    }

    @Deprecated
    public void setQuoteDate(String string) {
        this.quoteDate = string;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public String elementStartDate() {
        return elementStartDate;
    }

    public void setElementStartDate(String string) {
        this.elementStartDate = string;
    }

    public int elementTerm() {
        return elementTerm;
    }

    public void setElementTerm(int elementTerm) {
        this.elementTerm = elementTerm;
    }

    public String premiumPerFrequency() {
        return formatDouble(premiumPerFrequency);
    }

    public void setPremiumPerFrequency(double premiumPerFrequency) {
        this.premiumPerFrequency = String.valueOf(premiumPerFrequency);
    }

    public String salesCommission() {

        return formatDouble(salesCommission);
    }

    public void setSalesCommission(double salesCommission) {
        this.salesCommission = String.valueOf(salesCommission);
    }

    public String serviceCommission() {
        return formatDouble(serviceCommission);
    }

    public void setServiceCommission(double serviceCommission) {
        this.serviceCommission = String.valueOf(serviceCommission);
    }

    @Deprecated
    public String salesNegotiationPercentage() {
        if (salesNegotiationPercentage != null) {
            if (BigDecimal.valueOf(Double.parseDouble(salesNegotiationPercentage)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(salesNegotiationPercentage).intValue());
            }
        }
        return salesNegotiationPercentage;
    }

    @Deprecated
    public void setSalesNegotiationPercentage(double salesNegotiationPercentage) {
        this.salesNegotiationPercentage = Double.toString(salesNegotiationPercentage);
    }

    @Deprecated
    public String serviceNegotiationPercentage() {
        if (serviceNegotiationPercentage != null) {
            if (BigDecimal.valueOf(Double.parseDouble(serviceNegotiationPercentage)).divideAndRemainder(BigDecimal.ONE)[1]
                    .signum() == 0) {
                return String.valueOf(Double.valueOf(serviceNegotiationPercentage).intValue());
            }
        }
        return serviceNegotiationPercentage;
    }

    @Deprecated
    public void setServiceNegotiationPercentage(double serviceNegotiationPercentage) {
        this.serviceNegotiationPercentage = Double.toString(serviceNegotiationPercentage);
    }

    @Deprecated
    public String renServiceCommission() {
        if (renServiceCommission != null) {
            if (BigDecimal.valueOf(Double.parseDouble(renServiceCommission)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(renServiceCommission).intValue());
            }
        }
        return renServiceCommission;
    }

    @Deprecated
    public void setRenServiceCommission(double renServiceCommission) {
        this.renServiceCommission = Double.toString(renServiceCommission);
    }

    public int auditFlag() {
        return auditFlag;
    }

    public void setAuditFlag(int auditFlag) {
        this.auditFlag = auditFlag;
    }

    @Deprecated
    public int strVerifier() {
        return strVerifier;
    }

    @Deprecated
    public void setStrVerifier(int strVerifier) {
        this.strVerifier = strVerifier;
    }

    public String fundValue() {
        return formatDouble(fundValue);
    }

    public void setFundValue(double fundValue) {
        this.fundValue = String.valueOf(fundValue);
    }

    public String fundCommission() {
        return formatDouble(fundCommission);
    }

    public void setFundCommission(double fundCommission) {
        this.fundCommission = String.valueOf(fundCommission);
    }

    public int raXerIndicator() {
        return raXerIndicator;
    }

    public void setRaXerIndicator(int raXerIndicator) {
        this.raXerIndicator = raXerIndicator;
    }

    public int scoreTerm() {
        return scoreTerm;
    }

    public void setScoreTerm(int scoreTerm) {
        this.scoreTerm = scoreTerm;
    }
}
package za.co.sanlam.cms.fixture.replacement;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

import com.tcs.mastercraft.mctype.ServerContext;

public class FixtureTestPremiumHistory extends FixtureTestKomEvents {
    private int rowNumber;
    private int replacementCategory;
    private String effectiveDate;
    private String amount;
    private String portfolioNumber;
    private String policyNumber;
    private long premiumHistoryId;
    private String commissionType;

    private PreparedStatement preparedStatement;
    private ResultSet resultSet;
    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestPremiumHistory.class);

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestActiveInfo.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute()  {

        try {
            if (inValidResultSet(resultSet)) {
                return;
            }
            resultSet.absolute(rowNumber);
            setPremiumHistoryId(resultSet.getLong("RPPH_PRM_ID"));
            setPolicyNumber(resultSet.getString("RPPH_POL_NR"));
            setPortfolioNumber(resultSet.getString("RPPH_PF_NR"));
            setAmount(resultSet.getDouble("RPPH_PRM_AMT"));
            setReplacementCategory(resultSet.getInt("RPPH_REPL_CAT"));
            setEffectiveDate(dateFormatter.format(resultSet.getDate("RPPH_EFF_DATE")));
            setCommissionType(resultSet.getString("RPPH_COMM_TYPE").trim());
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestActiveInfo", e);
        }
    }

    private void initialize() throws SQLException {
        LOGGER.debug("BUILDING : PREMIUM HISTORY RECORDS :" + ServerContext.getSchemaName());
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("RPPH_PRM_ID, RPPH_PF_NR, RPPH_POL_NR,  RPPH_REPL_CAT, RPPH_EFF_DATE, RPPH_PRM_AMT, RPPH_COMM_TYPE ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("RPPH_PRM_HISTORY ");
        sqlStatement.append("ORDER BY RPPH_PRM_ID ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");
        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class  FixtureTestPremiumHistoryPremiumHistory: ", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }

    /**
     * @return the rowNumber
     */
    public int getRowNumber() {
        return rowNumber;
    }

    /**
     * @param rowNumber
     *            the rowNumber to set
     */
    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    /**
     * @return the replacementCategory
     */
    public int replacementCategory() {
        return replacementCategory;
    }

    /**
     * @param replacementCategory
     *            the replacementCategory to set
     */
    public void setReplacementCategory(int replacementCategory) {
        this.replacementCategory = replacementCategory;
    }

    /**
     * @return the effectiveDate
     */
    public String effectiveDate() {
        return effectiveDate;
    }

    /**
     * @param effectiveDate
     *            the effectiveDate to set
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * @return the amount
     */
    public String amount() {
        if (amount != null) {
            if (BigDecimal.valueOf(Double.parseDouble(amount)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(amount).intValue());
            }
        }
        return amount;
    }

    /**
     * @param amount
     *            the amount to set
     */
    public void setAmount(double amount) {
        this.amount = Double.toString(amount);
    }

    /**
     * @return the portfolioNumber
     */
    public String portfolioNumber() {
        return portfolioNumber;
    }

    /**
     * @param portfolioNumber
     *            the portfolioNumber to set
     */
    public void setPortfolioNumber(String portfolioNumber) {
        this.portfolioNumber = portfolioNumber;
    }

    /**
     * @return the policyNumber
     */
    public String policyNumber() {
        return policyNumber;
    }

    /**
     * @param policyNumber
     *            the policyNumber to set
     */
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    /**
     * @return the premiumHistoryId
     */
    public long premiumHistoryId() {
        return premiumHistoryId;
    }

    /**
     * @param premiumHistoryId
     *            the premiumHistoryId to set
     */
    public void setPremiumHistoryId(long premiumHistoryId) {
        this.premiumHistoryId = premiumHistoryId;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }
}

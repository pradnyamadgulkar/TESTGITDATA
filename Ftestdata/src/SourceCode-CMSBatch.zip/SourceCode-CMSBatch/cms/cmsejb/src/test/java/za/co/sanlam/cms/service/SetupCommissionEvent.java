package za.co.sanlam.cms.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.util.db.DatabaseInitializer;

public class SetupCommissionEvent {

    private CommissionEvent commissionEvent;
    private EventFacade eventFacade;
    private IntermediaryInfo intermediaryInfo;

    private String policyNumber;
    private String productType;
    private int noOfPrmsRcvd;
    private String clientOwnerPFNumber;
    private String clientInsuredPFNumber;
    private String clientInsuredSurname;
    private String clientInsuredInitials;
    private String originalPolicyNumber;
    private int currency;
    private int sourceSystem;
    private String productName;
    private double randValuePremiumInArrears;
    private double policyTotalPremium;
    private int warningLevel;
    private int eventType;
    private Date eventEffectiveDate;
    private int taxFundGroupCode;
    private String commissionType;
    private int premumPaymentMethod;
    private int premiumFrequency;
    private String campaignCode;
    private int indexGrowthType;
    private Date quotationDate;
    private Date applicationDate;
    private int indexPlanOptionIndicator;
    private int noOfElements;
    private Date premiumHolidayStartDate;
    private Date premiumHolidayEndDate;
    private int rPARIndicator;
    private int specialReinstatementIndicator;
    private int conversionIndicator;
    private Timestamp transactionTimestamp;
    private int elementNumber;
    private Date elementStartDate;
    private int elementTerm;
    private double elementPremium;
    private double fundValue;
    private double premiumReductionPercentage;
    private double salesCommissionMonthlyAmount;
    private double serviceCommissionMonthlyAmount;
    private double fundCommissionMonthlyAmount;
    private int scoreTerm;
    private int combinedAlterationsIndicator;
    private String elementReplacedIndicator;
    private Date policyIssueDate;
    private double salesCommissionNegotiatedPercentage;
    private double serviceCommissionNegotiatedPercentage;
    private int rATransferIndicator;
    private double commissionPremiumAmount;
    private String intermediaryNumber;
    private String applicationNumber;
    private String manCode;
    private String salesCommissionSplitPercentage;
    private String serviceCommissionSplitPercentage;
    private String fundCommissionSplitPercentage;
    private double premiumAtConversionAmount;

    int count;

    private static final SimpleDateFormat FORMAT_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
    private static final SimpleDateFormat FORMAT_DDMMMYYYY = new SimpleDateFormat("dd-MMM-yyyy");

    private static final SimpleDateFormat FORMAT_YYYYMMDDHHMMSSssssss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
    private static final SimpleDateFormat FORMAT_DDMMMYYYYHHMMSSssssss = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss.SSSSSS");

    private DatabaseInitializer databaseInitializer;

    public void beginTable() throws Exception {
        if (databaseInitializer == null) {
            databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
        }
        databaseInitializer.initialize();
    }

    public void reset() {
        commissionEvent = new CommissionEvent();
    }

    public void execute() {
        if (eventFacade == null) {
            eventFacade = (EventFacade) BeanLocator.locateBean("eventFacade");
        }
        eventFacade.handleEvents(commissionEvent);
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
        commissionEvent.setPolicyNumber(this.policyNumber);
    }

    public void setProductType(String productType) {
        this.productType = productType;
        commissionEvent.setProductType(this.productType);
    }

    public void setNoOfPrmsRcvd(int noOfPrmsRcvd) {
        this.noOfPrmsRcvd = noOfPrmsRcvd;
        commissionEvent.setNoOfPremiumReceived(this.noOfPrmsRcvd);
    }

    public void setClientOwnerPFNumber(String clientOwnerPFNumber) {
        this.clientOwnerPFNumber = clientOwnerPFNumber;
        commissionEvent.setClientOwnerPortfolioNo(this.clientOwnerPFNumber);
    }

    public void setClientInsuredPFNumber(String clientInsuredPFNumber) {
        this.clientInsuredPFNumber = clientInsuredPFNumber;
        commissionEvent.setClientInsuredPortfolioNo(this.clientInsuredPFNumber);
    }

    public void setClientInsuredSurname(String clientInsuredSurname) {
        this.clientInsuredSurname = clientInsuredSurname;
        commissionEvent.setClientInsuredSurname(this.clientInsuredSurname);
    }

    public void setClientInsuredInitials(String clientInsuredInitials) {
        this.clientInsuredInitials = clientInsuredInitials;
        commissionEvent.setClientInsuredInitials(this.clientInsuredInitials);
    }

    public void setOriginalPolicyNumber(String originalPolicyNumber) {
        this.originalPolicyNumber = originalPolicyNumber;
        commissionEvent.setOrginalPolicyNumber(this.originalPolicyNumber);
    }

    public void setCurrency(int currency) {
        this.currency = currency;
        commissionEvent.setCurrency(this.currency);
    }

    public void setSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
        commissionEvent.setSourceSystem(this.sourceSystem);
    }

    public void setProductName(String productName) {
        this.productName = productName;
        commissionEvent.setProductNameCode(this.productName);
    }

    public void setRandValuePremiumInArrears(double randValuePremiumInArrears) {
        this.randValuePremiumInArrears = randValuePremiumInArrears;
        commissionEvent.setRandValuePremiumInArrears(this.randValuePremiumInArrears);
    }

    public void setPolicyTotalPremium(double policyTotalPremium) {
        this.policyTotalPremium = policyTotalPremium;
        commissionEvent.setPolicyTotalPremium(this.policyTotalPremium);
    }

    public void setWarningLevel(int warningLevel) {
        this.warningLevel = warningLevel;
        commissionEvent.setWarningLevel(this.warningLevel);
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
        commissionEvent.setEventType(this.eventType);
    }

    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = convertToDate(eventEffectiveDate);
        commissionEvent.setEventEffectiveDate(this.eventEffectiveDate);
    }

    public void setTaxFundGroupCode(int taxFundGroupCode) {
        this.taxFundGroupCode = taxFundGroupCode;
        commissionEvent.setTaxFundGroupCode(this.taxFundGroupCode);
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
        commissionEvent.setCommissionType(this.commissionType);
    }

    public void setPremumPaymentMethod(int premumPaymentMethod) {
        this.premumPaymentMethod = premumPaymentMethod;
        commissionEvent.setPremiumPaymentMethod(this.premumPaymentMethod);
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
        commissionEvent.setPremiumFrequency(this.premiumFrequency);
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
        commissionEvent.setCampaignCode(this.campaignCode);
    }

    public void setIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
        commissionEvent.setIndexGrowthType(this.indexGrowthType);
    }

    public void setQuotationDate(String quotationDate) {
        this.quotationDate = convertToDate(quotationDate);
        commissionEvent.setQuotationDate(this.quotationDate);
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = convertToDate(applicationDate);
        commissionEvent.setApplicationInceptionDate(this.applicationDate);
    }

    public void setIndexPlanOptionIndicator(String indexPlanOptionIndicator) {
        this.indexPlanOptionIndicator = convertToBoolean(indexPlanOptionIndicator);
        commissionEvent.setIndexPlanOptionIndicator(this.indexPlanOptionIndicator);
    }

    public void setNoOfElements(int noOfElements) {
        this.noOfElements = noOfElements;
        commissionEvent.setNoOfElements(this.noOfElements);
    }

    public void setPremiumHolidayStartDate(String premiumHolidayStartDate) {
        this.premiumHolidayStartDate = convertToDate(premiumHolidayStartDate);
        commissionEvent.setPremiumHolidayStartDate(this.premiumHolidayStartDate);
    }

    public void setPremiumHolidayEndDate(String premiumHolidayEndDate) {
        this.premiumHolidayEndDate = convertToDate(premiumHolidayEndDate);
        commissionEvent.setPremiumHolidayEndDate(this.premiumHolidayEndDate);
    }

    public void setRPARIndicator(int rPARIndicator) {
        this.rPARIndicator = rPARIndicator;
        commissionEvent.setRparIndicator(this.rPARIndicator);
    }

    public void setSpecialReinstatementIndicator(String specialReinstatementIndicator) {
        this.specialReinstatementIndicator = convertToBoolean(specialReinstatementIndicator);
        commissionEvent.setSpecialReInstatementIndicator(this.specialReinstatementIndicator);
    }

    public void setConversionIndicator(String conversionIndicator) {
        this.conversionIndicator = convertToBoolean(conversionIndicator);
        commissionEvent.setCoversionIndicator(this.conversionIndicator);
    }

    public void setTransactionTimestamp(String transactionTimestamp) {
        this.transactionTimestamp = convertToTimestamp(transactionTimestamp);
        commissionEvent.setTransactionTimestamp(this.transactionTimestamp);
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
        commissionEvent.setElementNumber(this.elementNumber);
    }

    public void setElementStartDate(String elementStartDate) {
        this.elementStartDate = convertToDate(elementStartDate);
        commissionEvent.setElementStartDate(this.elementStartDate);
    }

    public void setElementTerm(int elementTerm) {
        this.elementTerm = elementTerm;
        commissionEvent.setElementTerm(this.elementTerm);
    }

    public void setElementPremium(double elementPremium) {
        this.elementPremium = elementPremium;
        commissionEvent.setElementPremium(this.elementPremium);
    }

    public void setFundValue(double fundValue) {
        this.fundValue = fundValue;
        commissionEvent.setFundValue(this.fundValue);
    }

    public void setPremiumReductionPercentage(double premiumReductionPercentage) {
        this.premiumReductionPercentage = premiumReductionPercentage;
        commissionEvent.setPremiumReductionPercentage(this.premiumReductionPercentage);
    }

    public void setSalesCommissionMonthlyAmount(double salesCommissionMonthlyAmount) {
        this.salesCommissionMonthlyAmount = salesCommissionMonthlyAmount;
        commissionEvent.setSalesCommissionMonthlyAmount(this.salesCommissionMonthlyAmount);
    }

    public void setServiceCommissionMonthlyAmount(double serviceCommissionMonthlyAmount) {
        this.serviceCommissionMonthlyAmount = serviceCommissionMonthlyAmount;
        commissionEvent.setServiceCommissionMonthlyAmount(this.serviceCommissionMonthlyAmount);
    }

    public void setFundCommissionMonthlyAmount(double fundCommissionMonthlyAmount) {
        this.fundCommissionMonthlyAmount = fundCommissionMonthlyAmount;
        commissionEvent.setFundCommissionMonthlyAmount(this.fundCommissionMonthlyAmount);
    }

    public void setPolicyIssueDate(String policyIssueDate) {
        this.policyIssueDate = convertToDate(policyIssueDate);
        commissionEvent.setPolicyIssueDate(this.policyIssueDate);
    }

    public void setSalesCommissionNegotiatedPercentage(double salesCommissionNegotiatedPercentage) {
        this.salesCommissionNegotiatedPercentage = salesCommissionNegotiatedPercentage;
        commissionEvent.setSalesCommissionNegotiatedPercentage(this.salesCommissionNegotiatedPercentage);
    }

    public void setServiceCommissionNegotiatedPercentage(double serviceCommissionNegotiatedPercentage) {
        this.serviceCommissionNegotiatedPercentage = serviceCommissionNegotiatedPercentage;
        commissionEvent.setServiceCommissionNegotiatedPercentage(this.serviceCommissionNegotiatedPercentage);
    }

    public void setScoreTerm(int scoreTerm) {
        this.scoreTerm = scoreTerm;
        commissionEvent.setScoreTerm(this.scoreTerm);
    }

    public void setCombinedAlterationsIndicator(int combinedAlterationsIndicator) {
        this.combinedAlterationsIndicator = combinedAlterationsIndicator;
        commissionEvent.setCombinedAlterationIndicator(this.combinedAlterationsIndicator);
    }

    public void setElementReplacedIndicator(String elementReplacedIndicator) {
        this.elementReplacedIndicator = elementReplacedIndicator;
        commissionEvent.setReplacementIndicator(this.elementReplacedIndicator);
    }

    public void setRATransferIndicator(int rATransferIndicator) {
        this.rATransferIndicator = rATransferIndicator;
        commissionEvent.setTransferSourceRA(this.rATransferIndicator);
    }

    public void setCommissionPremiumAmount(double commissionPremiumAmount) {
        this.commissionPremiumAmount = commissionPremiumAmount;
        commissionEvent.setElementScorePremium(this.commissionPremiumAmount);
    }

    public void setPremiumAtConversionAmount(double premiumAtConversionAmount) {
        this.premiumAtConversionAmount = premiumAtConversionAmount;
        commissionEvent.setConversionPremium(this.premiumAtConversionAmount);
    }

    public void setIntermediaryNumber(String intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
        String intermediaryNumberList[] = this.intermediaryNumber.split(",");
        for (String intermediaryNo : intermediaryNumberList) {
            intermediaryInfo = new IntermediaryInfo();
            intermediaryInfo.setIntermediaryNumber(Long.parseLong(intermediaryNo));
            commissionEvent.getIntermediarys().add(intermediaryInfo);
        }
    }

    public void setApplicationNumber(String applicationNumber) {
        this.applicationNumber = applicationNumber;
        String applicationNumberList[] = this.applicationNumber.split(",");
        if (commissionEvent.getIntermediarys().size() != applicationNumberList.length) {
            throw new RuntimeException("check application number");
        }
        count = 0;
        for (String applicationNo : applicationNumberList) {
            IntermediaryInfo intermediaryInfo = commissionEvent.getIntermediarys().get(count);
            intermediaryInfo.setApplicationNumber(Long.parseLong(applicationNo));
            count++;
        }
    }

    public void setManCode(String manCode) {
        this.manCode = manCode;
        String manCodeList[] = this.manCode.split(",");
        if (commissionEvent.getIntermediarys().size() != manCodeList.length) {
            throw new RuntimeException("check ManCode");
        }
        count = 0;
        for (String manCd : manCodeList) {
            IntermediaryInfo intermediaryInfo = commissionEvent.getIntermediarys().get(count);
            intermediaryInfo.setApplicationNumber(Long.parseLong(manCd));
            count++;
        }
    }

    public void setSalesCommissionSplitPercentage(String salesCommissionSplitPercentage) {
        this.salesCommissionSplitPercentage = salesCommissionSplitPercentage;
        String salesCommissionSplitPercentageList[] = this.salesCommissionSplitPercentage.split(",");
        if (commissionEvent.getIntermediarys().size() != salesCommissionSplitPercentageList.length) {
            throw new RuntimeException("check SalesCommissionSplitPercentage");
        }
        count = 0;
        for (String salesCommissionSplitPct : salesCommissionSplitPercentageList) {
            IntermediaryInfo intermediaryInfo = commissionEvent.getIntermediarys().get(count);
            intermediaryInfo.setSalesCommissionSplitPercentage(Double.parseDouble(salesCommissionSplitPct));
            count++;
        }
    }

    public void setServiceCommissionSplitPercentage(String serviceCommissionSplitPercentage) {
        this.serviceCommissionSplitPercentage = serviceCommissionSplitPercentage;
        String serviceCommissionSplitPercentageList[] = this.serviceCommissionSplitPercentage.split(",");
        if (commissionEvent.getIntermediarys().size() != serviceCommissionSplitPercentageList.length) {
            throw new RuntimeException("check ServiceCommissionSplitPercentage");
        }
        count = 0;
        for (String serviceCommissionSplitPct : serviceCommissionSplitPercentageList) {
            IntermediaryInfo intermediaryInfo = commissionEvent.getIntermediarys().get(count);
            intermediaryInfo.setServiceCommissionSplitPercentage(Float.parseFloat(serviceCommissionSplitPct));
            count++;
        }
    }

    public void setFundCommissionSplitPercentage(String fundCommissionSplitPercentage) {
        this.fundCommissionSplitPercentage = fundCommissionSplitPercentage;
        String fundCommissionSplitPercentageList[] = this.fundCommissionSplitPercentage.split(",");
        if (commissionEvent.getIntermediarys().size() != fundCommissionSplitPercentageList.length) {
            throw new RuntimeException("check FundCommissionSplitPercentage");
        }
        count = 0;
        for (String fundCommissionSplitPct : fundCommissionSplitPercentageList) {
            IntermediaryInfo intermediaryInfo = commissionEvent.getIntermediarys().get(count);
            intermediaryInfo.setFundCommissionSplitPercentage(Float.parseFloat(fundCommissionSplitPct));
            count++;
        }
    }

    private int convertToBoolean(String booleanString) {
        return booleanString.trim().equals("FALSE") || booleanString.trim().equals("0") ? 0 : 1;
    }

    private Date convertToDate(String dateString) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(FORMAT_YYYYMMDD.parse(dateString));
            String date = FORMAT_DDMMMYYYY.format(calendar.getTime());
            return FORMAT_DDMMMYYYY.parse(date);
        } catch (ParseException pe) {
            pe.printStackTrace();
        }
        return null;
    }

    private Timestamp convertToTimestamp(String dateString) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(FORMAT_YYYYMMDDHHMMSSssssss.parse(dateString));
            String date = FORMAT_DDMMMYYYYHHMMSSssssss.format(calendar.getTime());
            return new Timestamp(FORMAT_DDMMMYYYYHHMMSSssssss.parse(date).getTime());
        } catch (ParseException pe) {
            pe.printStackTrace();
        }
        return null;
    }
}

package za.co.sanlam.cms.fixture.replacement;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.StringTokenizer;

import com.ibm.db2.jcc.t2zos.e;

import za.co.sanlam.cms.batch.BatchBeanFactory;
import za.co.sanlam.cms.domain.IntermediaryCommission;
import za.co.sanlam.cms.domain.replacement.ReplacementPolicy;
import za.co.sanlam.cms.domain.repository.replacement.ReplacementRuleRepository;
import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestReplacementType extends FixtureTestKomEvents {

    private ReplacementRuleRepository replacementRuleRepository;

    private String storedReplacementType;
    private int replacementType;

    private String activeInceptionDate;
    private String inActiveLapseDate;

    private String activeApplicationDate;
    private String inActiveApplicationDate;

    private int activeEventType;
    private int inActiveEventType;

    private int result;

    public void beginTable() throws SQLException {
        super.beginTable();
        replacementRuleRepository = new ReplacementRuleRepository();
        replacementRuleRepository.setReferenceDataRepository(BatchBeanFactory.getInstance().getReferenceDataRepository());
    }

    public void execute()  {
        try {
            ReplacementPolicy activeReplacementPolicy = new ReplacementPolicy();
            activeReplacementPolicy.setActiveReplacementPolicyInd(storedReplacementType().equals("YES"));
            activeReplacementPolicy.setActivePolicyReplacementType(replacementType());
            activeReplacementPolicy.setPolicyInceptionDate(dateFormatter.parse(activeInceptionDate()));
            activeReplacementPolicy.setApplicationDate(dateFormatter.parse(activeApplicationDate()));
            activeReplacementPolicy.setEventType(activeEventType());
    
            ReplacementPolicy inActiveReplacementPolicy = new ReplacementPolicy();
            inActiveReplacementPolicy.setLapseDate(dateFormatter.parse(inActiveLapseDate()));
            inActiveReplacementPolicy.setApplicationDate(dateFormatter.parse(inActiveApplicationDate()));
            inActiveReplacementPolicy.setEventType(inActiveEventType);
            setResult(replacementRuleRepository.determineReplacementType(activeReplacementPolicy, inActiveReplacementPolicy));
        } catch (ParseException pe) {
            pe.printStackTrace();
        }
    }

    public int result() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public String storedReplacementType() {
        return storedReplacementType;
    }

    public void setStoredReplacementType(String storedReplacementType) {
        this.storedReplacementType = storedReplacementType;
    }

    public int replacementType() {
        return replacementType;
    }

    public void setReplacementType(int replacementType) {
        this.replacementType = replacementType;
    }

    public String activeInceptionDate() {
        return activeInceptionDate;
    }

    public void setActiveInceptionDate(String activeInceptionDate) {
        this.activeInceptionDate = activeInceptionDate;
    }

    public String inActiveLapseDate() {
        return inActiveLapseDate;
    }

    public void setInActiveLapseDate(String inActiveLapseDate) {
        this.inActiveLapseDate = inActiveLapseDate;
    }

    public String activeApplicationDate() {
        return activeApplicationDate;
    }

    public void setActiveApplicationDate(String activeApplicationDate) {
        this.activeApplicationDate = activeApplicationDate;
    }

    public String inActiveApplicationDate() {
        return inActiveApplicationDate;
    }

    public void setInActiveApplicationDate(String inActiveApplicationDate) {
        this.inActiveApplicationDate = inActiveApplicationDate;
    }

    public int activeEventType() {
        return activeEventType;
    }

    public void setActiveEventType(int activeEventType) {
        this.activeEventType = activeEventType;
    }

    public int inActiveEventType() {
        return inActiveEventType;
    }

    public void setInActiveEventType(int inActiveEventType) {
        this.inActiveEventType = inActiveEventType;
    }
}

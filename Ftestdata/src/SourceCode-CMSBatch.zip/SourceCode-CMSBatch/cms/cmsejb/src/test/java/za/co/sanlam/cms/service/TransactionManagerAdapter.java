package za.co.sanlam.cms.service;

import org.mockejb.MockContainer;
import org.mockejb.TransactionManager;
import org.mockejb.TransactionPolicy;
import org.mockejb.interceptor.InvocationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.transaction.*;
import java.sql.SQLException;

/**
 * An adapter that binds the transaction interceptor capability of MockEJB to the TransactionManager provided by Atomikos.
 */
public class TransactionManagerAdapter extends TransactionManager {

    // log for this class
    private static Logger log = LoggerFactory.getLogger(TransactionManagerAdapter.class);

    private javax.transaction.TransactionManager manager;

    public void setTransactionManager(javax.transaction.TransactionManager manager) {
        this.manager = manager;
    }

    protected boolean suspendTransaction(TransactionPolicy policy, boolean hasCurrentTransaction) {
        if (hasCurrentTransaction) {
            if (policy == TransactionPolicy.NOT_SUPPORTED || policy == TransactionPolicy.REQUIRED_NEW) {
                return true;
            }
        }
        return false;
    }

    protected boolean newTransaction(TransactionPolicy policy, boolean hasExistingTransaction) {
        if (policy == TransactionPolicy.REQUIRED && !hasExistingTransaction) {
            return true;
        }
        if (policy == TransactionPolicy.REQUIRED_NEW) {
            return true;
        }
        return false;
    }


    @Override
    public void intercept(InvocationContext invocationContext) throws Exception {
        TransactionPolicy thisCallPolicy = (TransactionPolicy) invocationContext.getOptionalPropertyValue(POLICY_CONTEXT_KEY);
        if (thisCallPolicy == null) {
            thisCallPolicy = getPolicy();
        }

        if (log.isDebugEnabled()) {
            String methodName = invocationContext.getTargetMethod() != null ? invocationContext.getTargetMethod().getName() : "*";
            log.debug("Intercepting {} with Policy.{}", methodName, thisCallPolicy);
        }

        Transaction existingTransaction = manager.getTransaction();
        boolean hasExistingTransaction = existingTransaction != null ? existingTransaction.getStatus() == Status.STATUS_ACTIVE : false;
        boolean suspend = suspendTransaction(thisCallPolicy, hasExistingTransaction);

        try {

            if (suspend) {
                manager.suspend();
                log.debug("Suspending transaction {}",existingTransaction);
            }
            boolean startNewTransaction = newTransaction(thisCallPolicy, hasExistingTransaction);
            if (startNewTransaction) {
                manager.begin();


                Transaction current = manager.getTransaction();

                if (log.isDebugEnabled()) {
                    log.debug("Beginning transaction {}",manager.getTransaction());
                }
            }


            invocationContext.proceed();

            commitOrRollback(manager.getTransaction());

            if (suspend) {
                manager.resume(existingTransaction);
                log.debug("Resuming transaction {}",existingTransaction);
            }

        }

        /* Here we try to follow the guidelines of chapter 18 of EJB spec
         * with the exception of javax.transaction.TransactionRolledback
         * Note that ExceptionHandler already provides logging and wrapping services
         * so we don't need to do it here
         */ catch (Exception exception) {

            if (MockContainer.isSystemException(exception)) {
                // If this transaction was started immediately before this invocation
                Transaction transaction = manager.getTransaction();
                if (transaction != null && (transaction.getStatus() == Status.STATUS_ACTIVE ||
                        transaction.getStatus() == Status.STATUS_MARKED_ROLLBACK)) {
                    transaction.rollback();
                    log.warn("Rollback because of system exception");
                }
            }
            // if it is application exception
            // we should rollback/commit only if it was new transaction context
            else {
                try {
                    commitOrRollback(manager.getTransaction());

                } catch (RollbackException rollbackEx) {
                    log.error(
                            "There has been rollback exception trying to rollback the transaction set for rollback. Ignoring. ", rollbackEx);
                }
            }

            throw exception;
        }


    }

    private void commitOrRollback(Transaction tran) throws
            SystemException, RollbackException, HeuristicMixedException,
            HeuristicRollbackException,SQLException {

        if (tran != null) {
            boolean error = tran.getStatus() == Status.STATUS_ACTIVE;

            if (error) {

                tran.commit();
                log.debug("Committing transaction {}",tran);
            } else {

                tran.rollback();
                log.debug("Rolling back transaction {}", tran);
            }
        }
    }

}

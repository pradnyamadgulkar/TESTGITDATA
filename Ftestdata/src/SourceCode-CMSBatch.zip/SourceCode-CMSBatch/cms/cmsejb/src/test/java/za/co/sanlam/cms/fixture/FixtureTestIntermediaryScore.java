/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for INSI_INTM_SCR table.
 */
public class FixtureTestIntermediaryScore extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestIntermediaryScore.class);

    private long intermediaryScoreId;
    private String policyNumber;
    private long eventId;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private String splitCommType;
    private long splitCommissionId;
    private long splitCommId;
    private String scorePremium;
    private String policyCount;
    private String policyCounter;
    private String totalScorePremium;
    private String scoreSplitPercentage;
    private long eventInProcessId;
    private long skekReferenceId;
    private long skekRefId;
    private long kmbReferenceId;
    private long kmbRefId;
    private int creditDebitIndicator;
    private int intermediaryScoreVerifier;
    private int replacementIndicator;
    private long replacementRetroId;

    public FixtureTestIntermediaryScore() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestIntermediaryScoreDetails.execute()");
        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setIntermediaryScoreId(getResultSet().getLong("INSI_INTM_SCR_ID"));
            setPolicyNumber(getResultSet().getString("INSI_POL_NR"));
            setEventId(getResultSet().getLong("INSI_EVT_ID"));
            setElementNumber(getResultSet().getInt("INSI_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("INSI_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("INSI_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getLong("INSI_SPLT_COMM_ID"));
            setScorePremium(getResultSet().getDouble("INSI_SCR_PRM"));
            setPolicyCount(getResultSet().getDouble("INSI_POL_CNT"));
            setTotalScorePremium(getResultSet().getDouble("INSI_TOT_SCR_PRM"));
            setScoreSplitPercentage(getResultSet().getDouble("INSI_SCR_SPLT_PCT"));
            setEventInProcessId(getResultSet().getLong("INSI_EIP_ID"));
            setSkekReferenceId(getResultSet().getLong("INSI_SKEK_REF_ID"));
            setKmbReferenceId(getResultSet().getLong("INSI_KMB_REF_ID"));
            setCreditDebitIndicator(getResultSet().getInt("INSI_CR_DR_IND"));
            setCreatedBy(getResultSet().getString("INSI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("INSI_UPD_BY").trim());
            setVersion(getResultSet().getInt("INSI_INTM_SCR_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setReplacementIndicator(getResultSet().getInt("INSI_REPL_IND"));
            setReplacementRetroId(getResultSet().getLong("INSI_REPL_RETRO_ID"));

            setSplitCommType(splitCommissionType());
            setSplitCommId(splitCommissionId());
            setPolicyCounter(Double.parseDouble(policyCount()));
            setSkekRefId(skekReferenceId());
            setKmbRefId(kmbReferenceId());
            setIntermediaryScoreVerifier(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestIntermediaryScoreDetails", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestIntermediaryScoreDetails", e);
            }
        }
    }

    /**
     * @return the splitCommissionType
     */
    public String splitCommissionType() {
        return splitCommissionType;
    }

    /**
     * @param splitCommissionType
     *            the splitCommissionType to set
     */
    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    /**
     * @return the splitCommissionId
     */
    public long splitCommissionId() {
        return splitCommissionId;
    }

    /**
     * @param splitCommissionId
     *            the splitCommissionId to set
     */
    public void setSplitCommissionId(long splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    /**
     * @return the policyCount
     */
    public String policyCount() {
        return formatDouble(policyCount);
    }

    /**
     * @param policyCount
     *            the policyCount to set
     */
    public void setPolicyCount(double policyCount) {
        this.policyCount = String.valueOf(policyCount);
    }

    /**
     * @return the skekReferenceId
     */
    public long skekReferenceId() {
        return skekReferenceId;
    }

    /**
     * @param skekReferenceId
     *            the skekReferenceId to set
     */
    public void setSkekReferenceId(long skekReferenceId) {
        this.skekReferenceId = skekReferenceId;
    }

    /**
     * @return the kmbReferenceId
     */
    public long kmbReferenceId() {
        return kmbReferenceId;
    }

    /**
     * @param kmbReferenceId
     *            the kmbReferenceId to set
     */
    public void setKmbReferenceId(long kmbReferenceId) {
        this.kmbReferenceId = kmbReferenceId;
    }

    public long intermediaryScoreId() {
        return intermediaryScoreId;
    }

    public void setIntermediaryScoreId(long intermediaryScoreId) {
        this.intermediaryScoreId = intermediaryScoreId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long eventId() {
        return eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    @Deprecated
    public String splitCommType() {
        return splitCommType;
    }

    @Deprecated
    public void setSplitCommType(String splitCommType) {
        this.splitCommType = splitCommType;
    }

    @Deprecated
    public long splitCommId() {
        return splitCommId;
    }

    @Deprecated
    public void setSplitCommId(long splitCommId) {
        this.splitCommId = splitCommId;
    }

    public String scorePremium() {
        return formatDouble(scorePremium);
    }

    public void setScorePremium(double scorePremium) {
        this.scorePremium = String.valueOf(scorePremium);
    }

    @Deprecated
    public String policyCounter() {
        return formatDouble(policyCounter);
    }

    @Deprecated
    public void setPolicyCounter(double policyCounter) {
        this.policyCounter = Double.toString(policyCounter);
    }

    public String totalScorePremium() {
        return formatDouble(totalScorePremium);
    }

    public void setTotalScorePremium(double totalScorePremium) {
        this.totalScorePremium = String.valueOf(totalScorePremium);
    }

    public String scoreSplitPercentage() {
        return formatDouble(scoreSplitPercentage);
    }

    public void setScoreSplitPercentage(double scoreSplitPercentage) {
        this.scoreSplitPercentage = String.valueOf(scoreSplitPercentage);
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    @Deprecated
    public long skekRefId() {
        return skekRefId;
    }

    @Deprecated
    public void setSkekRefId(long skekRefId) {
        this.skekRefId = skekRefId;
    }

    @Deprecated
    public long kmbRefId() {
        return kmbRefId;
    }

    @Deprecated
    public void setKmbRefId(long kmbRefId) {
        this.kmbRefId = kmbRefId;
    }

    public int creditDebitIndicator() {
        return creditDebitIndicator;
    }

    public void setCreditDebitIndicator(int creditDebitIndicator) {
        this.creditDebitIndicator = creditDebitIndicator;
    }

    @Deprecated
    public int intermediaryScoreVerifier() {
        return intermediaryScoreVerifier;
    }

    @Deprecated
    public void setIntermediaryScoreVerifier(int intermediaryScoreVerifier) {
        this.intermediaryScoreVerifier = intermediaryScoreVerifier;
    }

    public int replacementIndicator() {
        return replacementIndicator;
    }

    public void setReplacementIndicator(int replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }

    public long replacementRetroId() {
        return replacementRetroId;
    }

    public void setReplacementRetroId(long replacementRetroId) {
        this.replacementRetroId = replacementRetroId;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT INSI_INTM_SCR_ID,INSI_POL_NR,INSI_EVT_ID,"
                    + "INSI_ELMT_NR,INSI_INTM_NR,INSI_SPLT_COMM_TYP,INSI_SPLT_COMM_ID,"
                    + "INSI_SCR_PRM,INSI_POL_CNT,INSI_TOT_SCR_PRM,INSI_SCR_SPLT_PCT, INSI_EIP_ID,INSI_SKEK_REF_ID,INSI_KMB_REF_ID,INSI_CR_DR_IND,"
                    + "INSI_CRTD_BY,INSI_UPD_BY,INSI_INTM_SCR_VER, DM_LSTUPDDT,INSI_REPL_IND,INSI_REPL_RETRO_ID FROM {0}INSI_INTM_SCR "
                    + "ORDER BY INSI_EVT_ID, INSI_ELMT_NR, INSI_EIP_ID, INSI_SPLT_COMM_TYP, INSI_INTM_NR, INSI_INTM_SCR_ID FOR FETCH ONLY WITH UR");
}

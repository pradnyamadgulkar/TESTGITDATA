package za.co.sanlam.cms.util.db;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.BeanLocator;

import com.atomikos.jdbc.nonxa.AtomikosNonXADataSourceBean;

public class DatabaseInitializer {

	private static final Logger LOG = LoggerFactory
			.getLogger(DatabaseInitializer.class);

	// Dependencies
	private DataSource dataSource;
	private String schemaName;
	private int clearType;

	public void initialize() throws IOException, SQLException {
		if (dataSource instanceof AtomikosNonXADataSourceBean) {
			initialiseH2();
		} else {
			initialiseDB2();
		}
	}
	
	public void initialize(List<String> affectedTables) throws Exception {
	    String sql = "DELETE FROM {0}{1}"; 
	    Connection connection = null;
        Statement statement = null;
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            for (String table : affectedTables) {
                statement.execute(MessageFormat.format(sql, new Object[] {schemaName, table}));
            }
        } catch (SQLException se) {
            connection.rollback();
            LOG.error("Error initialising DB2 datasource", se);
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
	}
	
	public void initializeReplacement() throws Exception {
	    execute("ClearReplacementData.sql", null, true);
	    LOG.info("DB2(Schema : {}) replacement tables initialised!!!", schemaName);
	}
	
	public void initializeAssissa() throws Exception {
        execute("ClearAssissaData.sql", null, true);
        LOG.info("DB2 Assissa tables initialised!!!");
	}

	private void initialiseH2() throws SQLException {
		Connection connection = null;
		Statement statement = null;
		try {
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			statement
					.execute("RUNSCRIPT FROM 'classpath:/h2/CreateSchema.sql'");
			statement
					.execute("RUNSCRIPT FROM 'classpath:/h2/CreateReferenceData.sql'");
			statement
					.execute("RUNSCRIPT FROM 'classpath:/h2/LoadIntermediaries.sql'");
			LOG.info("H2 database initialised!!!");
		} catch (SQLException e) {
			LOG.error("Error initialising H2 datasource", e);
			connection.rollback();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
		}
	}

	private void initialiseDB2() throws IOException, SQLException {
	    if (clearType <= 0) {
	        LOG.info("CLEAR TYPE {} :: DB2 database(Schema : {}) NOT initialised!!!", clearType, schemaName);
	        return;
	    }
	    
		if (clearType != 1) {
			execute("ClearReferenceData.sql", null, true);
			execute("CreateReferenceData.sql", "INSERT", false);
			// execute("LoadIntermediaries.sql", null, false);
			LOG.info("DB2 reference data re-initialised!!!");
		}
		execute("ClearBusinessData.sql", null, true);
		execute("ResetIdentities.sql", null, true);
		LOG.info("CLEAR TYPE {} :: DB2 database(Schema : {}) initialised!!!", clearType, schemaName);
	}
	
	public void setUpData(String sqlSetupName) throws IOException, SQLException {
        execute(sqlSetupName, null, false);
    }

	private void execute(String sqlFileName, String validateValue,
			boolean swallowException) throws IOException, SQLException {
		Connection connection = null;
		Statement statement = null;
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					DatabaseInitializer.class.getResourceAsStream("/db2/"
							+ sqlFileName)));
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			int lineNo = 1;
			String line;
			while ((line = reader.readLine()) != null) {
				// line must contain value ie.. INSERT or DELETE
				if (validateValue != null
						&& line.toUpperCase().indexOf(validateValue) < 0
						&& lineNo != 1) {
					continue;
				}

				int endIndex = line.lastIndexOf(";"); // 4 create script
				line = endIndex > 0 ? line.trim().substring(0, endIndex) : line;
				try {
					if (lineNo == 1) {
						// set current schema
						line = MessageFormat.format(line,
								new Object[] { schemaName });
					}
					statement.execute(line);
				} catch (SQLException e) {
					LOG.error(e.getMessage() + " :: " + lineNo + " :: " + line);
					if (!swallowException) {
						throw e;
					}
				}
				lineNo++;
			}
			connection.commit();
		} catch (SQLException se) {
			connection.rollback();
			LOG.error("Error initialising DB2 datasource", se);
		} finally {
			if (reader != null) {
				reader.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
		}
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
     * @return the dataSource
     */
    public DataSource getDataSource() {
        return dataSource;
    }

    public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public void setClearType(int clearType) {
		this.clearType = clearType;
	}

    public static void main(String[] args) {
		try {
			((DatabaseInitializer) BeanLocator
					.locateBean("databaseInitializer")).initialiseDB2();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for BEM_LAMDA_XML_INFO table.
 */
public class FixtureTestLamdaXmlInfo extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestLamdaXmlInfo.class);

    private long lamdaTransRefId;
    private long lamdaTransactionReferenceId;
    private String policyNumber;
    private String productType;
    private int currency;
    private int sourceSystem;
    private int eventType;
    private String eventEffectiveDate;
    private String commissionType;
    private String extractDate;
    private int numberOfPremiumsReceived;
    private String clientOwnerPortfolioNumber;
    private String clientInsuredPortfolioNumber;
    private String clientInsuredSurname;
    private String clientInsuredInitials;
    private String orgPolicyNumber;
    private String originalPolicyNumber;
    private String productNameCode;
    private String randValuePremiumInArrears;
    private String policyTotalPremium;
    private int warningLevel;
    private int taxFundGroupCode;
    private int premiumPaymentMethod;
    private int premiumFrequency;
    private String campaignCode;
    private int indexGrowthType;
    private String quotationDate;
    private String applicationInDate;
    private int indexPlanOptionInd;
    private int indexPlanOptionIndicator;
    private int numberOfElements;
    private String premiumHolidayStartDate;
    private String premiumHolidayEndDate;
    private int rparIndicator;
    private int specialReinstateInd;
    private int specialReinstateIndicator;
    private int conversionInd;
    private int conversionIndicator;
    private int elementNumber;
    private String elementStartDate;
    private int elementTerm;
    private String elementPremium;
    private String fundValue;
    private String premiumReductionPercentage;
    private String salesCommMonthlyAmt;
    private String salesCommissionMonthlyAmount;
    private String serviceCommMonthlyAmt;
    private String serviceCommissionMonthlyAmount;
    private String fundCommMonthlyAmt;
    private String fundCommissionMonthlyAmount;
    private String policyIssueDate;
    private String salesCommNegotiatedPercentage;
    private String salesCommissionNegotiatedPercentage;
    private String serviceCommNegotiatedPercentage;
    private String serviceCommissionNegotiatedPercentage;
    private String scoreTerm;
    private int combinedAlterationInd;
    private int combinedAlterationIndicator;
    private int elementReplacedInd;
    private int elementReplacedIndicator;
    private int transferSourceRa;
    private int transactionVersion;
    private String elementScorePremium;

    public FixtureTestLamdaXmlInfo() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setLamdaTransactionReferenceId(getResultSet().getLong("LAMDA_TRANS_REF_ID"));
            setPolicyNumber(getResultSet().getString("POLICY_NO"));
            setProductType(getResultSet().getString("PRODUCT_TYPE"));
            setCurrency(getResultSet().getInt("CURRENCY"));
            setSourceSystem(getResultSet().getInt("SOURCE_SYSTEM"));
            setEventType(getResultSet().getInt("EVENT_TYPE"));
            setEventEffectiveDate(format(getResultSet().getDate("EVENT_EFF_DATE")));
            setCommissionType(getResultSet().getString("COMMISSION_TYPE").trim());
            setExtractDate(format(getResultSet().getDate("EXTRACT_DATE")));
            setNumberOfPremiumsReceived(getResultSet().getInt("NO_OF_PRM_RECVD"));
            setClientOwnerPortfolioNumber(getResultSet().getString("CLIENT_OWNER_PORTFOLIO_NO"));
            setClientInsuredPortfolioNumber(getResultSet().getString("CLIENT_INSURED_PORTFOLIO_NO"));
            setClientInsuredSurname(getResultSet().getString("CLIENT_INSURED_SURNAME"));
            setClientInsuredInitials(getResultSet().getString("CLIENT_INSURED_INITIALS"));
            setOriginalPolicyNumber(getResultSet().getString("ORG_POLICY_NO"));
            setProductNameCode(getResultSet().getString("PRODUCT_NAME_CODE"));
            setRandValuePremiumInArrears(getResultSet().getDouble("RAND_VALUE_PRM_IN_ARREARS"));
            setPolicyTotalPremium(getResultSet().getDouble("POLICY_TOTAL_PREMIUM"));
            setWarningLevel(getResultSet().getInt("WARNING_LEVEL"));
            setTaxFundGroupCode(getResultSet().getInt("TAXFUND_GROUP_CODE"));
            setPremiumPaymentMethod(getResultSet().getInt("PREMIUM_PYMT_METHOD"));
            setPremiumFrequency(getResultSet().getInt("PREMIUM_FREQ"));
            setCampaignCode(getResultSet().getString("CAMPAIGN_CODE"));
            setIndexGrowthType(getResultSet().getInt("INDEX_GROWTH_TYPE"));
            setQuotationDate(format(getResultSet().getDate("QUOTATION_DATE")));
            setApplicationInDate(format(getResultSet().getDate("APP_IN_DATE")));
            setIndexPlanOptionIndicator(getResultSet().getInt("INDEX_PLAN_OPTION_IND"));
            setNumberOfElements(getResultSet().getInt("NO_OF_ELEMENTS"));
            setPremiumHolidayStartDate(format(getResultSet().getDate("PREMIUM_HOLIDAY_START_DATE")));
            setPremiumHolidayEndDate(format(getResultSet().getDate("PREMIUM_HOLIDAY_END_DATE")));
            setRparIndicator(getResultSet().getInt("RPAR_IND"));
            setSpecialReinstateIndicator(getResultSet().getInt("SPCL_REINS_IND"));
            setConversionIndicator(getResultSet().getInt("COVERSION_IND"));
            setElementNumber(getResultSet().getInt("ELEMENT_NO"));
            setElementStartDate(format(getResultSet().getDate("ELEMENT_ST_DATE")));
            setElementTerm(getResultSet().getInt("ELEMENT_TERM"));
            setElementPremium(getResultSet().getDouble("ELEMENT_PREMIUM"));
            setFundValue(getResultSet().getInt("FUND_VALUE"));
            setPremiumReductionPercentage(getResultSet().getInt("PREMIUM_REDUCTION_PCT"));
            setSalesCommissionMonthlyAmount(getResultSet().getDouble("SALES_COMM_MONTHLY_AMT"));
            setServiceCommissionMonthlyAmount(getResultSet().getDouble("SERVICE_COMM_MONTHLY_AMT"));
            setFundCommissionMonthlyAmount(getResultSet().getDouble("FUND_COMM_MONTHLY_AMT"));
            setPolicyIssueDate(format(getResultSet().getDate("POLICY_ISSUE_DATE")));
            setSalesCommissionNegotiatedPercentage(getResultSet().getDouble("SALES_COMM_NEGOTIATED_PCT"));
            setServiceCommissionNegotiatedPercentage(getResultSet().getDouble("SERVICE_COMM_NEGOTIATED_PCT"));
            setScoreTerm(getResultSet().getString("SCORE_TERM"));
            setCombinedAlterationIndicator(getResultSet().getInt("COMB_ALT_IND"));
            setElementReplacedIndicator(getResultSet().getInt("ELEM_REPLACED_IND"));
            setTransferSourceRa(getResultSet().getInt("TRANSFER_SOURCE_RA"));
            setCreatedBy(getResultSet().getString("CREATED_BY"));
            setUpdatedBy(getResultSet().getString("UPDATE_BY"));
            setVersion(getResultSet().getInt("TRAN_VER"));

            setLamdaTransRefId(getResultSet().getLong("LAMDA_TRANS_REF_ID"));
            setOrgPolicyNumber(getResultSet().getString("ORG_POLICY_NO"));
            setIndexPlanOptionInd(getResultSet().getInt("INDEX_PLAN_OPTION_IND"));
            setSpecialReinstateInd(getResultSet().getInt("SPCL_REINS_IND"));
            setConversionInd(getResultSet().getInt("COVERSION_IND"));
            setSalesCommMonthlyAmt(getResultSet().getDouble("SALES_COMM_MONTHLY_AMT"));
            setServiceCommMonthlyAmt(getResultSet().getDouble("SERVICE_COMM_MONTHLY_AMT"));
            setFundCommMonthlyAmt(getResultSet().getDouble("FUND_COMM_MONTHLY_AMT"));
            setSalesCommNegotiatedPercentage(getResultSet().getDouble("SALES_COMM_NEGOTIATED_PCT"));
            setServiceCommNegotiatedPercentage(getResultSet().getDouble("SERVICE_COMM_NEGOTIATED_PCT"));
            setCombinedAlterationInd(getResultSet().getInt("COMB_ALT_IND"));
            setElementReplacedInd(getResultSet().getInt("ELEM_REPLACED_IND"));
            setTransactionVersion(getResultSet().getInt("TRAN_VER"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestLamdaXmlInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestLamdaXmlInfo", se);
            }
        }
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT LAMDA_TRANS_REF_ID, POLICY_NO, PRODUCT_TYPE, NO_OF_PRM_RECVD, CLIENT_OWNER_PORTFOLIO_NO, CLIENT_INSURED_PORTFOLIO_NO, "
                    + "CLIENT_INSURED_SURNAME, CLIENT_INSURED_INITIALS, ORG_POLICY_NO, CURRENCY, SOURCE_SYSTEM, PRODUCT_NAME_CODE, RAND_VALUE_PRM_IN_ARREARS, "
                    + "POLICY_TOTAL_PREMIUM, WARNING_LEVEL, EVENT_TYPE, EVENT_EFF_DATE, TAXFUND_GROUP_CODE, COMMISSION_TYPE, PREMIUM_PYMT_METHOD, PREMIUM_FREQ,"
                    + "CAMPAIGN_CODE, INDEX_GROWTH_TYPE, QUOTATION_DATE, APP_IN_DATE, INDEX_PLAN_OPTION_IND, NO_OF_ELEMENTS, PREMIUM_HOLIDAY_START_DATE, "
                    + "PREMIUM_HOLIDAY_END_DATE, RPAR_IND, SPCL_REINS_IND, COVERSION_IND, TRANSACTION_TS, ELEMENT_NO, ELEMENT_ST_DATE, ELEMENT_TERM, ELEMENT_PREMIUM, "
                    + "FUND_VALUE, PREMIUM_REDUCTION_PCT, SALES_COMM_MONTHLY_AMT, SERVICE_COMM_MONTHLY_AMT, FUND_COMM_MONTHLY_AMT, POLICY_ISSUE_DATE, "
                    + "SALES_COMM_NEGOTIATED_PCT, SERVICE_COMM_NEGOTIATED_PCT, SCORE_TERM, COMB_ALT_IND, ELEM_REPLACED_IND, TRANSFER_SOURCE_RA, "
                    + "CREATED_BY, UPDATE_BY, TRAN_VER, EXTRACT_DATE, ELEMENT_SCORE_PREMIUM FROM {0}BEM_LAMDA_XML_INFO ORDER BY LAMDA_TRANS_REF_ID FOR FETCH ONLY WITH UR");

    @Deprecated
    public long lamdaTransRefId() {
        return lamdaTransRefId;
    }

    @Deprecated
    public void setLamdaTransRefId(long lamdaTransRefId) {
        this.lamdaTransRefId = lamdaTransRefId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int currency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int sourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String extractDate() {
        return extractDate;
    }

    public void setExtractDate(String extractDate) {
        this.extractDate = extractDate;
    }

    public int numberOfPremiumsReceived() {
        return numberOfPremiumsReceived;
    }

    public void setNumberOfPremiumsReceived(int numberOfPremiumsReceived) {
        this.numberOfPremiumsReceived = numberOfPremiumsReceived;
    }

    public String clientOwnerPortfolioNumber() {
        return clientOwnerPortfolioNumber;
    }

    public void setClientOwnerPortfolioNumber(String clientOwnerPortfolioNumber) {
        this.clientOwnerPortfolioNumber = clientOwnerPortfolioNumber;
    }

    public String clientInsuredPortfolioNumber() {
        return clientInsuredPortfolioNumber;
    }

    public void setClientInsuredPortfolioNumber(String clientInsuredPortfolioNumber) {
        this.clientInsuredPortfolioNumber = clientInsuredPortfolioNumber;
    }

    public String clientInsuredSurname() {
        return clientInsuredSurname;
    }

    public void setClientInsuredSurname(String clientInsuredSurname) {
        this.clientInsuredSurname = clientInsuredSurname;
    }

    public String clientInsuredInitials() {
        return clientInsuredInitials;
    }

    public void setClientInsuredInitials(String clientInsuredInitials) {
        this.clientInsuredInitials = clientInsuredInitials;
    }

    @Deprecated
    public String orgPolicyNumber() {
        return orgPolicyNumber;
    }

    @Deprecated
    public void setOrgPolicyNumber(String orgPolicyNumber) {
        this.orgPolicyNumber = orgPolicyNumber;
    }

    public String productNameCode() {
        return productNameCode;
    }

    public void setProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
    }

    public String randValuePremiumInArrears() {
        return formatDouble(randValuePremiumInArrears);
    }

    public void setRandValuePremiumInArrears(double randValuePremiumInArrears) {
        this.randValuePremiumInArrears = Double.toString(randValuePremiumInArrears);
    }

    public String policyTotalPremium() {
        return formatDouble(policyTotalPremium);
    }

    public void setPolicyTotalPremium(double policyTotalPremium) {
        this.policyTotalPremium = Double.toString(policyTotalPremium);
    }

    public int warningLevel() {
        return warningLevel;
    }

    public void setWarningLevel(int warningLevel) {
        this.warningLevel = warningLevel;
    }

    public int taxFundGroupCode() {
        return taxFundGroupCode;
    }

    public void setTaxFundGroupCode(int taxFundGroupCode) {
        this.taxFundGroupCode = taxFundGroupCode;
    }

    public int premiumPaymentMethod() {
        return premiumPaymentMethod;
    }

    public void setPremiumPaymentMethod(int premiumPaymentMethod) {
        this.premiumPaymentMethod = premiumPaymentMethod;
    }

    public int premiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    public String campaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    public int indexGrowthType() {
        return indexGrowthType;
    }

    public void setIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
    }

    public String quotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(String quotationDate) {
        this.quotationDate = quotationDate;
    }

    public String applicationInDate() {
        return applicationInDate;
    }

    public void setApplicationInDate(String applicationInDate) {
        this.applicationInDate = applicationInDate;
    }

    @Deprecated
    public int indexPlanOptionInd() {
        return indexPlanOptionInd;
    }

    @Deprecated
    public void setIndexPlanOptionInd(int indexPlanOptionInd) {
        this.indexPlanOptionInd = indexPlanOptionInd;
    }

    public int numberOfElements() {
        return numberOfElements;
    }

    public void setNumberOfElements(int numberOfElements) {
        this.numberOfElements = numberOfElements;
    }

    public String premiumHolidayStartDate() {
        return premiumHolidayStartDate;
    }

    public void setPremiumHolidayStartDate(String premiumHolidayStartDate) {
        this.premiumHolidayStartDate = premiumHolidayStartDate;
    }

    public String premiumHolidayEndDate() {
        return premiumHolidayEndDate;
    }

    public void setPremiumHolidayEndDate(String premiumHolidayEndDate) {
        this.premiumHolidayEndDate = premiumHolidayEndDate;
    }

    public int rparIndicator() {
        return rparIndicator;
    }

    public void setRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
    }

    @Deprecated
    public int specialReinstateInd() {
        return specialReinstateInd;
    }

    @Deprecated
    public void setSpecialReinstateInd(int specialReinstateInd) {
        this.specialReinstateInd = specialReinstateInd;
    }

    @Deprecated
    public int conversionInd() {
        return conversionInd;
    }

    @Deprecated
    public void setConversionInd(int conversionInd) {
        this.conversionInd = conversionInd;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public String elementStartDate() {
        return elementStartDate;
    }

    public void setElementStartDate(String elementStartDate) {
        this.elementStartDate = elementStartDate;
    }

    public int elementTerm() {
        return elementTerm;
    }

    public void setElementTerm(int elementTerm) {
        this.elementTerm = elementTerm;
    }

    public String elementPremium() {
        return formatDouble(elementPremium);
    }

    public void setElementPremium(double elementPremium) {
        this.elementPremium = Double.toString(elementPremium);
    }

    public String fundValue() {
        return formatDouble(fundValue);
    }

    public void setFundValue(double fundValue) {
        this.fundValue = Double.toString(fundValue);
    }

    public String premiumReductionPercentage() {
        return formatDouble(premiumReductionPercentage);
    }

    public void setPremiumReductionPercentage(double premiumReductionPercentage) {
        this.premiumReductionPercentage = Double.toString(premiumReductionPercentage);
    }

    @Deprecated
    public String salesCommMonthlyAmt() {
        return formatDouble(salesCommMonthlyAmt);
    }

    @Deprecated
    public void setSalesCommMonthlyAmt(double salesCommMonthlyAmt) {
        this.salesCommMonthlyAmt = Double.toString(salesCommMonthlyAmt);
    }

    @Deprecated
    public String serviceCommMonthlyAmt() {
        return formatDouble(serviceCommMonthlyAmt);
    }

    @Deprecated
    public void setServiceCommMonthlyAmt(double serviceCommMonthlyAmt) {
        this.serviceCommMonthlyAmt = Double.toString(serviceCommMonthlyAmt);
    }

    @Deprecated
    public String fundCommMonthlyAmt() {
        return formatDouble(fundCommMonthlyAmt);
    }

    @Deprecated
    public void setFundCommMonthlyAmt(double fundCommMonthlyAmt) {
        this.fundCommMonthlyAmt = Double.toString(fundCommMonthlyAmt);
    }

    public String policyIssueDate() {
        return policyIssueDate;
    }

    public void setPolicyIssueDate(String policyIssueDate) {
        this.policyIssueDate = policyIssueDate;
    }

    @Deprecated
    public String salesCommNegotiatedPercentage() {
        return formatDouble(salesCommNegotiatedPercentage);
    }

    @Deprecated
    public void setSalesCommNegotiatedPercentage(double salesCommNegotiatedPercentage) {
        this.salesCommNegotiatedPercentage = Double.toString(salesCommNegotiatedPercentage);
    }

    @Deprecated
    public String serviceCommNegotiatedPercentage() {
        return formatDouble(serviceCommNegotiatedPercentage);
    }

    @Deprecated
    public void setServiceCommNegotiatedPercentage(double serviceCommNegotiatedPercentage) {
        this.serviceCommNegotiatedPercentage = Double.toString(serviceCommNegotiatedPercentage);
    }

    public String scoreTerm() {
        return scoreTerm;
    }

    public void setScoreTerm(String scoreTerm) {
        this.scoreTerm = scoreTerm;
    }

    @Deprecated
    public int combinedAlterationInd() {
        return combinedAlterationInd;
    }

    @Deprecated
    public void setCombinedAlterationInd(int combinedAlterationInd) {
        this.combinedAlterationInd = combinedAlterationInd;
    }

    @Deprecated
    public int elementReplacedInd() {
        return elementReplacedInd;
    }

    @Deprecated
    public void setElementReplacedInd(int elementReplacedInd) {
        this.elementReplacedInd = elementReplacedInd;
    }

    public int transferSourceRa() {
        return transferSourceRa;
    }

    public void setTransferSourceRa(int transferSourceRa) {
        this.transferSourceRa = transferSourceRa;
    }

    @Deprecated
    public int transactionVersion() {
        return transactionVersion;
    }

    @Deprecated
    public void setTransactionVersion(int transactionVersion) {
        this.transactionVersion = transactionVersion;
    }

    /**
     * @return the lamdaTransactionReferenceId
     */
    public long lamdaTransactionReferenceId() {
        return lamdaTransactionReferenceId;
    }

    /**
     * @param lamdaTransactionReferenceId
     *            the lamdaTransactionReferenceId to set
     */
    public void setLamdaTransactionReferenceId(long lamdaTransactionReferenceId) {
        this.lamdaTransactionReferenceId = lamdaTransactionReferenceId;
    }

    /**
     * @return the originalPolicyNumber
     */
    public String originalPolicyNumber() {
        return originalPolicyNumber;
    }

    /**
     * @param originalPolicyNumber
     *            the originalPolicyNumber to set
     */
    public void setOriginalPolicyNumber(String originalPolicyNumber) {
        this.originalPolicyNumber = originalPolicyNumber;
    }

    /**
     * @return the indexPlanOptionIndicator
     */
    public int indexPlanOptionIndicator() {
        return indexPlanOptionIndicator;
    }

    /**
     * @param indexPlanOptionIndicator
     *            the indexPlanOptionIndicator to set
     */
    public void setIndexPlanOptionIndicator(int indexPlanOptionIndicator) {
        this.indexPlanOptionIndicator = indexPlanOptionIndicator;
    }

    /**
     * @return the specialReinstateIndicator
     */
    public int specialReinstateIndicator() {
        return specialReinstateIndicator;
    }

    /**
     * @param specialReinstateIndicator
     *            the specialReinstateIndicator to set
     */
    public void setSpecialReinstateIndicator(int specialReinstateIndicator) {
        this.specialReinstateIndicator = specialReinstateIndicator;
    }

    /**
     * @return the conversionIndicator
     */
    public int conversionIndicator() {
        return conversionIndicator;
    }

    /**
     * @param conversionIndicator
     *            the conversionIndicator to set
     */
    public void setConversionIndicator(int conversionIndicator) {
        this.conversionIndicator = conversionIndicator;
    }

    /**
     * @return the salesCommissionMonthlyAmount
     */
    public String salesCommissionMonthlyAmount() {
        return formatDouble(salesCommissionMonthlyAmount);
    }

    /**
     * @param salesCommissionMonthlyAmount
     *            the salesCommissionMonthlyAmount to set
     */
    public void setSalesCommissionMonthlyAmount(double salesCommissionMonthlyAmount) {
        this.salesCommissionMonthlyAmount = String.valueOf(salesCommissionMonthlyAmount);
    }

    /**
     * @return the serviceCommissionMonthlyAmount
     */
    public String serviceCommissionMonthlyAmount() {
        return formatDouble(serviceCommissionMonthlyAmount);
    }

    /**
     * @param serviceCommissionMonthlyAmount
     *            the serviceCommissionMonthlyAmount to set
     */
    public void setServiceCommissionMonthlyAmount(double serviceCommissionMonthlyAmount) {
        this.serviceCommissionMonthlyAmount = String.valueOf(serviceCommissionMonthlyAmount);
    }

    /**
     * @return the fundCommissionMonthlyAmount
     */
    public String fundCommissionMonthlyAmount() {
        return formatDouble(fundCommissionMonthlyAmount);
    }

    /**
     * @param fundCommissionMonthlyAmount
     *            the fundCommissionMonthlyAmount to set
     */
    public void setFundCommissionMonthlyAmount(double fundCommissionMonthlyAmount) {
        this.fundCommissionMonthlyAmount = String.valueOf(fundCommissionMonthlyAmount);
    }

    /**
     * @return the salesCommissionNegotiatedPercentage
     */
    public String salesCommissionNegotiatedPercentage() {
        return formatDouble(salesCommissionNegotiatedPercentage);
    }

    /**
     * @param salesCommissionNegotiatedPercentage
     *            the salesCommissionNegotiatedPercentage to set
     */
    public void setSalesCommissionNegotiatedPercentage(double salesCommissionNegotiatedPercentage) {
        this.salesCommissionNegotiatedPercentage = String.valueOf(salesCommissionNegotiatedPercentage);
    }

    /**
     * @return the serviceCommissionNegotiatedPercentage
     */
    public String serviceCommissionNegotiatedPercentage() {
        return formatDouble(serviceCommissionNegotiatedPercentage);
    }

    /**
     * @param serviceCommissionNegotiatedPercentage
     *            the serviceCommissionNegotiatedPercentage to set
     */
    public void setServiceCommissionNegotiatedPercentage(double serviceCommissionNegotiatedPercentage) {
        this.serviceCommissionNegotiatedPercentage = String.valueOf(serviceCommissionNegotiatedPercentage);
    }

    /**
     * @return the combinedAlterationIndicator
     */
    public int combinedAlterationIndicator() {
        return combinedAlterationIndicator;
    }

    /**
     * @param combinedAlterationIndicator
     *            the combinedAlterationIndicator to set
     */
    public void setCombinedAlterationIndicator(int combinedAlterationIndicator) {
        this.combinedAlterationIndicator = combinedAlterationIndicator;
    }

    /**
     * @return the elementReplacedIndicator
     */
    public int elementReplacedIndicator() {
        return elementReplacedIndicator;
    }

    /**
     * @param elementReplacedIndicator
     *            the elementReplacedIndicator to set
     */
    public void setElementReplacedIndicator(int elementReplacedIndicator) {
        this.elementReplacedIndicator = elementReplacedIndicator;
    }

    /**
     * @return the elementScorePremium
     */
    public String elementScorePremium() {
        return formatDouble(elementScorePremium);
    }

    /**
     * @param elementScorePremium
     *            the elementScorePremium to set
     */
    public void setElementScorePremium(double elementScorePremium) {
        this.elementScorePremium = String.valueOf(elementScorePremium);
    }
}

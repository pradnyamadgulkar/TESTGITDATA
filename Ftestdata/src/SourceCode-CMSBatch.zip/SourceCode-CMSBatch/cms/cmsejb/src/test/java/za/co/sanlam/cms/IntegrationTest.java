package za.co.sanlam.cms;


public interface IntegrationTest {

}

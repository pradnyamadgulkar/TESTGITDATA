package za.co.sanlam.cms.service;

import java.sql.Timestamp;
import java.util.Date;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.util.db.DatabaseInitializer;

public class SetUpRetroVATEvent {
	
	private RetroVATEvent retroVATEvent;
	private EventFacade eventFacade;
	private DatabaseInitializer databaseInitializer;
	private int eventType;
	private int intermediaryNumber;
	private Date eventEffectiveDate;
	private Timestamp transactionTimestamp;
	private int vatStatus;	
	
	public void beginTable() throws Exception {
		if (databaseInitializer == null) {
			databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
		}
		databaseInitializer.initialize();
	}

	public void reset() {
		retroVATEvent= new RetroVATEvent();
	}

	public void execute() {
		eventFacade.handleEvents(retroVATEvent);
	}
		
	public void setEventType(int eventType) {
		this.eventType = eventType;
		retroVATEvent.setEventType(this.eventType);
	}
	
	public void setIntermediaryNumber(int intermediaryNumber) {
		this.intermediaryNumber = intermediaryNumber;	
		retroVATEvent.setIntermediaryNumber(this.intermediaryNumber);
	}
	
	public void setEventEffectiveDate(Date eventEffectiveDate) {
		this.eventEffectiveDate = eventEffectiveDate;
		retroVATEvent.setEventEffectiveDate(this.eventEffectiveDate);
	}
	
	public void setTransactionTimestamp(Timestamp transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
		retroVATEvent.setTransactionTimestamp(this.transactionTimestamp);
	}
	
	public void setVatStatus(int vatStatus) {
		this.vatStatus = vatStatus;
		retroVATEvent.setVatStatus(this.vatStatus);
	}
}

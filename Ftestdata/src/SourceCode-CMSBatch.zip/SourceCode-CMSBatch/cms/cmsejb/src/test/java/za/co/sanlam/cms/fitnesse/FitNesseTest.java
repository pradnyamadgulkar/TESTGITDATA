package za.co.sanlam.cms.fitnesse;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import za.co.sanlam.cms.IntegrationTest;

import fitnesse.junit.JUnitHelper;
import fitnesse.responders.run.JavaFormatter;
import junit.framework.Assert;
import junit.framework.TestCase;
@Ignore
@Category(IntegrationTest.class)
public class FitNesseTest extends TestCase {

	private JUnitHelper helper;
	private String fitNesseRootPath;
	private String htmlOutputDirectory;
	private int port;

	private final String SUITE_SINGLE_EVT = "OnlineRegressionTests.SingleEvent";
	private final String SUITE_SMALL_BASELINE = "OnlineRegressionTests.SmallBaseline2010";

	@Before
	public void setUp() {
		fitNesseRootPath = "/var/local/fitnesse";
		htmlOutputDirectory = "/tmp/fitnesse/output/html";
		helper = new JUnitHelper(fitNesseRootPath, htmlOutputDirectory);
		helper.setDebugMode(true);
		// helper.setPort(port);
		JavaFormatter.dropInstance(SUITE_SINGLE_EVT);
		//JavaFormatter.dropInstance(SUITE_SMALL_BASELINE);
	}

	@Test
	public void testSingleEvent() throws Exception {
		helper.assertSuitePasses(SUITE_SINGLE_EVT);

		// validate
		JavaFormatter formatter = JavaFormatter.getInstance(SUITE_SINGLE_EVT);
		Assert.assertEquals(30, formatter.getTestsExecuted().size());
	}
	
	/*@Test
	public void testSmallBaseLine() throws Exception {
		helper.assertSuitePasses(SUITE_SMALL_BASELINE);

		// validate
		JavaFormatter formatter = JavaFormatter.getInstance(SUITE_SMALL_BASELINE);
		Assert.assertEquals(31, formatter.getTestsExecuted().size());
	}*/
}
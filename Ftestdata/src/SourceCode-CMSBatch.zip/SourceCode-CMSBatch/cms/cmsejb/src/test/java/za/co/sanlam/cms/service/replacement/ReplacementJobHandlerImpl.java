package za.co.sanlam.cms.service.replacement;

import KomEvents.KomEventsBatchPrgInvoker;

public class ReplacementJobHandlerImpl implements ReplacementJobHandler {

    private String webServiceProperties;

    public void processJob(int batchKey) {
        try {
            System.setProperty("WebServiceProperties", webServiceProperties);
            switch (batchKey) {
                case 410:
                    KomEventsBatchPrgInvoker.processReplacements();
                    break;
                case 420:
                    KomEventsBatchPrgInvoker.processPremiumHistory();
                    break;
                case 430:
                    KomEventsBatchPrgInvoker.processReplacementTriggers();
                    break;
                case 440:
                    KomEventsBatchPrgInvoker.processReplacementPolicy();
                    break;
                case 450:
                    KomEventsBatchPrgInvoker.processReplacementReinstates();
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setWebServiceProperties(String webServiceProperties) {
        this.webServiceProperties = webServiceProperties;
    }
}

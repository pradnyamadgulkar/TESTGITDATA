/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PLIF_POL_INF table.
 */
public class FixtureTestPolicyInfo extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPolicyInfo.class);

    private String policyNumber;
    private long policyId;
    private String policyInceptionDate;
    private String productType;
    private String productNameCode;
    private int premiumFrequency;
    private int premiumPaymentMethod;
    private String clientPortfolioNumberOwn;
    private String clientPortfolioNumberInsured;
    private String clientSurnameInsured;
    private String clientInitialsInsured;
    private int currency;
    private int sourceSystem;
    private int indexPlanOptionIndicator;
    private String policyNumberBeforeConversion;
    private String policyNumberConversion;
    private String applicationDate;
    private String quotationDate;
    private String policyIssueDate;
    private int conversionIndicator;
    private int policyStatus;
    private int unvestedCommissionProcessedStatus;
    private int unvcProcessStatus; // unvested commission
    private int futureCommissionProcessedStatus;
    private int ftcpProcessStatus; // future commission
    private int extractKomPasReconlnProcessedStatus;
    private int kprpProcessStatus; // kom pas reconciliation
    private int accountAdjustmentProcessedStatus;
    private int aadpProcessStatus;// account adjustment
    private int policyInformationVerifier;
    private int serviceModelIndicator;

    public FixtureTestPolicyInfo() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setPolicyNumber(getResultSet().getString("PLIF_POL_NR"));
            setPolicyId(getResultSet().getLong("PLIF_POL_ID"));
            setPolicyInceptionDate(format(getResultSet().getDate("PLIF_POL_INCP_DT")));
            setProductType(getResultSet().getString("PLIF_PRD_TYP"));
            setProductNameCode(getResultSet().getString("PLIF_PRD_NAME_CD"));
            setPremiumFrequency(getResultSet().getInt("PLIF_PRM_FQ"));
            setPremiumPaymentMethod(getResultSet().getInt("PLIF_PRM_PMT_METH"));
            setClientPortfolioNumberOwn(getResultSet().getString("PLIF_CLT_PF_NR_OWN"));
            setClientPortfolioNumberInsured(getResultSet().getString("PLIF_CLT_PF_NR_INS"));
            setClientSurnameInsured(getResultSet().getString("PLIF_CLT_SUR_INS"));
            setClientInitialsInsured(getResultSet().getString("PLIF_CLT_INI_INS").trim());
            setCurrency(getResultSet().getInt("PLIF_CURR"));
            setSourceSystem(getResultSet().getInt("PLIF_SRC_SYS"));
            setIndexPlanOptionIndicator(getResultSet().getInt("PLIF_IDX_OP_IND"));
            setPolicyNumberConversion(getResultSet().getString("PLIF_POL_NR_CONV"));
            setApplicationDate(format(getResultSet().getDate("PLIF_APP_DT")));
            setQuotationDate(format(getResultSet().getDate("PLIF_QTE_DT")));
            setPolicyIssueDate(format(getResultSet().getDate("PLIF_POL_ISSUE_DT")));
            setConversionIndicator(getResultSet().getInt("PLIF_CONV_IND"));
            setPolicyStatus(getResultSet().getInt("PLIF_POL_STS"));
            setUnvcProcessStatus(getResultSet().getInt("PLIF_UNVC_PRC_STS"));
            setFtcpProcessStatus(getResultSet().getInt("PLIF_FTCP_PRC_STS"));
            setKprpProcessStatus(getResultSet().getInt("PLIF_KPRP_PRC_STS"));
            setAccountAdjustmentProcessedStatus(getResultSet().getInt("PLIF_AADP_PRC_STS"));
            setCreatedBy(getResultSet().getString("PLIF_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PLIF_UPD_BY").trim());
            setVersion(getResultSet().getInt("PLIF_POL_INF_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setServiceModelIndicator(getResultSet().getInt("PLIF_SERVICE_MODEL_IND"));

            setUnvestedCommissionProcessedStatus(unvcProcessStatus());
            setFutureCommissionProcessedStatus(ftcpProcessStatus());
            setExtractKompasReconlnProcessedStatus(kprpProcessStatus());
            setAccountAdjustmentProcessedStatus(aadpProcessStatus());

            setPolicyNumberBeforeConversion(policyNumberConversion());
            setPolicyInformationVerifier(version());

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestPolicyInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestPolicyInfo", e);
            }
        }
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long policyId() {
        return policyId;
    }

    public void setPolicyId(long policyId) {
        this.policyId = policyId;
    }

    public String policyInceptionDate() {
        return policyInceptionDate;
    }

    public void setPolicyInceptionDate(String policyInceptionDate) {
        this.policyInceptionDate = policyInceptionDate;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String productNameCode() {
        return productNameCode;
    }

    public void setProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
    }

    public int premiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    public int premiumPaymentMethod() {
        return premiumPaymentMethod;
    }

    public void setPremiumPaymentMethod(int premiumPaymentMethod) {
        this.premiumPaymentMethod = premiumPaymentMethod;
    }

    public String clientPortfolioNumberOwn() {
        return clientPortfolioNumberOwn;
    }

    public void setClientPortfolioNumberOwn(String clientPortfolioNumberOwn) {
        this.clientPortfolioNumberOwn = clientPortfolioNumberOwn;
    }

    public String clientPortfolioNumberInsured() {
        return clientPortfolioNumberInsured;
    }

    public void setClientPortfolioNumberInsured(String clientPortfolioNumberInsured) {
        this.clientPortfolioNumberInsured = clientPortfolioNumberInsured;
    }

    public String clientSurnameInsured() {
        return clientSurnameInsured;
    }

    public void setClientSurnameInsured(String clientSurnameInsured) {
        this.clientSurnameInsured = clientSurnameInsured;
    }

    public String clientInitialsInsured() {
        return clientInitialsInsured;
    }

    public void setClientInitialsInsured(String clientinitialsInsured) {
        this.clientInitialsInsured = clientinitialsInsured;
    }

    public int currency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int sourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public int indexPlanOptionIndicator() {
        return indexPlanOptionIndicator;
    }

    public void setIndexPlanOptionIndicator(int indexPlanOptionIndicator) {
        this.indexPlanOptionIndicator = indexPlanOptionIndicator;
    }

    @Deprecated
    public String policyNumberBeforeConversion() {
        return policyNumberBeforeConversion;
    }

    @Deprecated
    public void setPolicyNumberBeforeConversion(String policyNumberBeforeConversion) {
        this.policyNumberBeforeConversion = policyNumberBeforeConversion;
    }

    public String applicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String quotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(String quotationDate) {
        this.quotationDate = quotationDate;
    }

    public String policyIssueDate() {
        return policyIssueDate;
    }

    public void setPolicyIssueDate(String policyIssueDate) {
        this.policyIssueDate = policyIssueDate;
    }

    public int conversionIndicator() {
        return conversionIndicator;
    }

    public void setConversionIndicator(int conversionIndicator) {
        this.conversionIndicator = conversionIndicator;
    }

    public int policyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(int policyStatus) {
        this.policyStatus = policyStatus;
    }

    public int unvestedCommissionProcessedStatus() {
        return unvestedCommissionProcessedStatus;
    }

    public void setUnvestedCommissionProcessedStatus(int unvestedCommissionProcessedStatus) {
        this.unvestedCommissionProcessedStatus = unvestedCommissionProcessedStatus;
    }

    public int futureCommissionProcessedStatus() {
        return futureCommissionProcessedStatus;
    }

    public void setFutureCommissionProcessedStatus(int futureCommissionProcessedStatus) {
        this.futureCommissionProcessedStatus = futureCommissionProcessedStatus;
    }

    public int extractKomPasReconlnProcessedStatus() {
        return extractKomPasReconlnProcessedStatus;
    }

    public void setExtractKompasReconlnProcessedStatus(int extractKomPasReconlnProcessedStatus) {
        this.extractKomPasReconlnProcessedStatus = extractKomPasReconlnProcessedStatus;
    }

    public int accountAdjustmentProcessedStatus() {
        return accountAdjustmentProcessedStatus;
    }

    public void setAccountAdjustmentProcessedStatus(int accountAdjustmentProcessedStatus) {
        this.accountAdjustmentProcessedStatus = accountAdjustmentProcessedStatus;
    }

    @Deprecated
    public int policyInformationVerifier() {
        return policyInformationVerifier;
    }

    @Deprecated
    public void setPolicyInformationVerifier(int policyInformationVerifier) {
        this.policyInformationVerifier = policyInformationVerifier;
    }

    /**
     * @return the policyNumberConversion
     */
    public String policyNumberConversion() {
        return policyNumberConversion;
    }

    /**
     * @param policyNumberConversion
     *            the policyNumberConversion to set
     */
    public void setPolicyNumberConversion(String policyNumberConversion) {
        this.policyNumberConversion = policyNumberConversion;
    }

    /**
     * @return the ucpProcessStatus
     */
    public int unvcProcessStatus() {
        return unvcProcessStatus;
    }

    /**
     * @param ucpProcessStatus
     *            the ucpProcessStatus to set
     */
    public void setUnvcProcessStatus(int unvcProcessStatus) {
        this.unvcProcessStatus = unvcProcessStatus;
    }

    /**
     * @return the ftcpProcessStatus
     */
    public int ftcpProcessStatus() {
        return ftcpProcessStatus;
    }

    /**
     * @param ftcpProcessStatus
     *            the ftcpProcessStatus to set
     */
    public void setFtcpProcessStatus(int ftcpProcessStatus) {
        this.ftcpProcessStatus = ftcpProcessStatus;
    }

    /**
     * @return the kprpProcessStatus
     */
    public int kprpProcessStatus() {
        return kprpProcessStatus;
    }

    /**
     * @param kprpProcessStatus
     *            the kprpProcessStatus to set
     */
    public void setKprpProcessStatus(int kprpProcessStatus) {
        this.kprpProcessStatus = kprpProcessStatus;
    }

    /**
     * @return the acasProcessStatus
     */
    public int aadpProcessStatus() {
        return aadpProcessStatus;
    }

    /**
     * @param acasProcessStatus
     *            the acasProcessStatus to set
     */
    public void setAcasProcessStatus(int aadpProcessStatus) {
        this.aadpProcessStatus = aadpProcessStatus;
    }

    /**
     * @return the serviceModelIndicator
     */
    public int serviceModelIndicator() {
        return serviceModelIndicator;
    }

    /**
     * @param serviceModelIndicator
     *            the serviceModelIndicator to set
     */
    public void setServiceModelIndicator(int serviceModelIndicator) {
        this.serviceModelIndicator = serviceModelIndicator;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PLIF_POL_NR,PLIF_POL_ID,PLIF_POL_INCP_DT, PLIF_PRD_TYP,PLIF_PRD_NAME_CD,PLIF_PRM_FQ,PLIF_PRM_PMT_METH,"
                    + "PLIF_CLT_PF_NR_OWN,PLIF_CLT_PF_NR_INS,PLIF_CLT_SUR_INS,PLIF_CLT_INI_INS, PLIF_CURR,PLIF_SRC_SYS,PLIF_IDX_OP_IND,PLIF_POL_NR_CONV,"
                    + "PLIF_APP_DT,PLIF_QTE_DT,PLIF_POL_ISSUE_DT,PLIF_CONV_IND,PLIF_POL_STS, PLIF_UNVC_PRC_STS,PLIF_FTCP_PRC_STS,PLIF_KPRP_PRC_STS,PLIF_AADP_PRC_STS,"
                    + "PLIF_CRTD_BY,PLIF_UPD_BY, PLIF_POL_INF_VER, DM_LSTUPDDT, PLIF_SERVICE_MODEL_IND FROM {0}PLIF_POL_INF ORDER BY PLIF_POL_ID FOR FETCH ONLY WITH UR");

}

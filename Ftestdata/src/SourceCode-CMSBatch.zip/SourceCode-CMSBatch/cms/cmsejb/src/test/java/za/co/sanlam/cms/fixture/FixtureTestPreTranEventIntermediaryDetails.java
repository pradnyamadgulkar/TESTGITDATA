package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PTIN_PRT_INTM table.
 */
public class FixtureTestPreTranEventIntermediaryDetails extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPreTranEventIntermediaryDetails.class);

    private long preTranIntermediaryRefId;
    private long preTranIntermediaryReferenceId;
    private long intermediaryNumber;
    private String salesSplitPercentage;
    private String serviceSplitPercentage;
    private long applicationNumber;
    private int manualCode;
    private int manCode;
    private long preTranRefId;
    private long preTranReferenceId;
    private int preTranIntermediaryVerifier;
    private String fundSplitPercentage;

    public void beginTable() throws SQLException {
        LOG.debug("Entering FixtureTestPretranEventIntermediaryDetails.beginTable()");

        setSqlQuery(SQL_QUERY);

        super.beginTable();

    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setPreTranIntermediaryReferenceId(getResultSet().getLong("PTIN_PRII_REF_ID"));
            setIntermediaryNumber(getResultSet().getLong("PTIN_INTM_NR"));
            setSalesSplitPercentage(getResultSet().getDouble("PTIN_SLS_SPLT_PCT"));
            setServiceSplitPercentage(getResultSet().getDouble("PTIN_SRV_SPLT_PCT"));
            setApplicationNumber(getResultSet().getLong("PTIN_APP_NR"));
            setManCode(getResultSet().getInt("PTIN_MAN_CD"));
            setPreTranReferenceId(getResultSet().getLong("PTIN_PRI_REF_ID"));
            setCreatedBy(getResultSet().getString("PTIN_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PTIN_UPD_BY").trim());
            setVersion(getResultSet().getInt("PTIN_PRT_INTM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setFundSplitPercentage(getResultSet().getDouble("PTIN_FUND_SPLT_PCT"));

            setPreTranIntermediaryRefId(preTranIntermediaryReferenceId());
            setPreTranRefId(preTranReferenceId());
            setPreTranIntermediaryVerifier(version());
            setManualCode(manCode());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestPretranEventIntermediaryDetails", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestPretranEventIntermediaryDetails", e);
            }
        }
    }

    /**
     * @return the preTranIntermediaryReferenceId
     */
    public long preTranIntermediaryReferenceId() {
        return preTranIntermediaryReferenceId;
    }

    /**
     * @param preTranIntermediaryReferenceId
     *            the preTranIntermediaryReferenceId to set
     */
    public void setPreTranIntermediaryReferenceId(long preTranIntermediaryReferenceId) {
        this.preTranIntermediaryReferenceId = preTranIntermediaryReferenceId;
    }

    /**
     * @return the manCode
     */
    public int manCode() {
        return manCode;
    }

    /**
     * @param manCode
     *            the manCode to set
     */
    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    /**
     * @return the preTranReferenceId
     */
    public long preTranReferenceId() {
        return preTranReferenceId;
    }

    /**
     * @param preTranReferenceId
     *            the preTranReferenceId to set
     */
    public void setPreTranReferenceId(long preTranReferenceId) {
        this.preTranReferenceId = preTranReferenceId;
    }

    @Deprecated
    public long preTranIntermediaryRefId() {
        return preTranIntermediaryRefId;
    }

    @Deprecated
    public void setPreTranIntermediaryRefId(long preTranIntermediaryRefId) {
        this.preTranIntermediaryRefId = preTranIntermediaryRefId;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String salesSplitPercentage() {
        return formatDouble(salesSplitPercentage);
    }

    public void setSalesSplitPercentage(double salesSplitPercentage) {
        this.salesSplitPercentage = String.valueOf(salesSplitPercentage);
    }

    public String serviceSplitPercentage() {
        return formatDouble(serviceSplitPercentage);
    }

    public void setServiceSplitPercentage(double serviceSplitPercentage) {
        this.serviceSplitPercentage = String.valueOf(serviceSplitPercentage);
    }

    public long applicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(long applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    @Deprecated
    public int manualCode() {
        return manualCode;
    }

    @Deprecated
    public void setManualCode(int manualCode) {
        this.manualCode = manualCode;
    }

    @Deprecated
    public long preTranRefId() {
        return preTranRefId;
    }

    @Deprecated
    public void setPreTranRefId(long preTranRefId) {
        this.preTranRefId = preTranRefId;
    }

    @Deprecated
    public int preTranIntermediaryVerifier() {
        return preTranIntermediaryVerifier;
    }

    @Deprecated
    public void setPreTranIntermediaryVerifier(int preTranIntermediaryVerifier) {
        this.preTranIntermediaryVerifier = preTranIntermediaryVerifier;
    }

    public String fundSplitPercentage() {
        return fundSplitPercentage;
    }

    public void setFundSplitPercentage(double fundSplitPercentage) {
        this.fundSplitPercentage = String.valueOf(fundSplitPercentage);
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer("SELECT PTIN_PRII_REF_ID,PTIN_INTM_NR,PTIN_SLS_SPLT_PCT,"
            + "PTIN_SRV_SPLT_PCT,PTIN_APP_NR,PTIN_MAN_CD,PTIN_PRI_REF_ID,PTIN_CRTD_BY,PTIN_UPD_BY, PTIN_PRT_INTM_VER,"
            + "DM_LSTUPDDT,PTIN_FUND_SPLT_PCT from {0}PTIN_PRT_INTM ORDER BY  PTIN_PRII_REF_ID FOR FETCH ONLY WITH UR");
}

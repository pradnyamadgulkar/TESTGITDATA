/*
 * 
 */
package za.co.sanlam.cms.fixture.batch;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 */
public class FixtureTestAccountAdjustmentDetail extends FixtureTestAccountAdjustmentSummary {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestAccountAdjustmentDetail.class);

    private long accountAdjustmentDetailId;
    private int elementNumber;
    private int trancheNumber;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "ACAD_ACC_ADJ_ID,ACAD_ACC_DET_ID,ACAD_ELMT_NR,ACAD_TRCH_NR,ACAD_COMM_AMT,ACAD_VAT_AMT,"
                    + "ACAD_CRTD_BY,ACAD_UPD_BY,ACAD_CRTD_TMST,ACAD_UPD_TMST,ACAD_ADJ_DET_VER,DM_LSTUPDDT,ACAD_REPL_IND"
                    + " ORDER BY ACAD_ACC_DET_ID FOR FETCH ONLY WITH UR");

    public FixtureTestAccountAdjustmentDetail() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setAccountAdjustmentId(getResultSet().getLong("ACAD_ACC_ADJ_ID"));
            setAccountAdjustmentDetailId(getResultSet().getLong("ACAD_ACC_DET_ID"));
            setElementNumber(getResultSet().getInt("ACAD_ELMT_NR"));
            setTrancheNumber(getResultSet().getInt("ACAD_TRCH_NR"));
            setCommissionAmount(formatDouble(getResultSet().getDouble("ACAD_COMM_AMT")));
            setVatAmount(formatDouble(getResultSet().getDouble("ACAD_VAT_AMT")));
            setReplacementIndicator(getResultSet().getInt("ACAD_REPL_IND"));
            setCreatedBy(getResultSet().getString("ACAD_CRTD_BY"));
            setUpdatedBy(getResultSet().getString("ACAD_UPD_BY"));
            setVersion(getResultSet().getInt("ACAD_ADJ_DET_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestAccountAdjustmentDetail", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestAccountAdjustmentDetail", se);
            }
        }

    }

    /**
     * @return the accountAdjustmentDetailId
     */
    public long accountAdjustmentDetailId() {
        return accountAdjustmentDetailId;
    }

    /**
     * @param accountAdjustmentDetailId
     *            the accountAdjustmentDetailId to set
     */
    public void setAccountAdjustmentDetailId(long accountAdjustmentDetailId) {
        this.accountAdjustmentDetailId = accountAdjustmentDetailId;
    }

    /**
     * @return the elementNumber
     */
    public int elementNumber() {
        return elementNumber;
    }

    /**
     * @param elementNumber
     *            the elementNumber to set
     */
    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    /**
     * @return the trancheNumber
     */
    public int trancheNumber() {
        return trancheNumber;
    }

    /**
     * @param trancheNumber
     *            the trancheNumber to set
     */
    public void setTrancheNumber(int trancheNumber) {
        this.trancheNumber = trancheNumber;
    }
}
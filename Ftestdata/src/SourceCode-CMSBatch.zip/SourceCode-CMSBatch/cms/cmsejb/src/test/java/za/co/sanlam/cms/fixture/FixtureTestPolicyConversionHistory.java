/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PLCH_CONV_HST table.
 */
public class FixtureTestPolicyConversionHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPolicyConversionHistory.class);

    private long conversionId;
    private String convertedPolicyNumber;
    private String conversionPolicyNumber;
    private int conversionType;
    private int conversionStatus;
    private int numberOfPremiumsReceived;
    private int eventInProcessType;
    private long eventInProcessId;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PLCH_CONV_ID, PLCH_CONVRT_POL_NR, PLCH_CONVRS_POL_NR, PLCH_CONVRS_TYP, "
                    + "PLCH_CONVRS_STS, PLCH_NR_PRM_RCVD, PLCH_EIP_TYP, PLCH_EIP_ID, PLCH_CRTD_BY, PLCH_UPD_BY, PLCH_CRTD_TMST, PLCH_UPD_TMST, "
                    + "PLCH_CONV_HST_VER, DM_LSTUPDDT FROM {0}PLCH_CONV_HST ORDER BY PLCH_CONV_ID FOR FETCH ONLY WITH UR ");

    public FixtureTestPolicyConversionHistory() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestPolicyConversionHistory.execute()");
        try {
            // do not continue if results set is closed
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            // populate
            setConversionId(getResultSet().getLong("PLCH_CONV_ID"));
            setConvertedPolicyNumber(getResultSet().getString("PLCH_CONVRT_POL_NR").trim());
            setConversionPolicyNumber(getResultSet().getString("PLCH_CONVRS_POL_NR").trim());
            setConversionType(getResultSet().getInt("PLCH_CONVRS_TYP"));
            setConversionStatus(getResultSet().getInt("PLCH_CONVRS_STS"));
            setNumberOfPremiumsReceived(getResultSet().getInt("PLCH_NR_PRM_RCVD"));
            setEventInProcessType(getResultSet().getInt("PLCH_EIP_TYP"));
            setEventInProcessId(getResultSet().getLong("PLCH_EIP_ID"));
            setCreatedBy(getResultSet().getString("PLCH_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PLCH_UPD_BY").trim());
            setVersion(getResultSet().getInt("PLCH_CONV_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestPolicyConversionHistory", ignore);
        } finally {
            try {
                // close result set and prepared statement if last item
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestPolicyConversionHistory", se);
            }
        }
    }

    /**
     * @return the conversionId
     */
    public long conversionId() {
        return conversionId;
    }

    /**
     * @param conversionId
     *            the conversionId to set
     */
    public void setConversionId(long conversionId) {
        this.conversionId = conversionId;
    }

    /**
     * @return the convertedPolicyNumber
     */
    public String convertedPolicyNumber() {
        return convertedPolicyNumber;
    }

    /**
     * @param convertedPolicyNumber
     *            the convertedPolicyNumber to set
     */
    public void setConvertedPolicyNumber(String convertedPolicyNumber) {
        this.convertedPolicyNumber = convertedPolicyNumber;
    }

    /**
     * @return the conversionPolicyNumber
     */
    public String conversionPolicyNumber() {
        return conversionPolicyNumber;
    }

    /**
     * @param conversionPolicyNumber
     *            the conversionPolicyNumber to set
     */
    public void setConversionPolicyNumber(String conversionPolicyNumber) {
        this.conversionPolicyNumber = conversionPolicyNumber;
    }

    /**
     * @return the conversionType
     */
    public int conversionType() {
        return conversionType;
    }

    /**
     * @param conversionType
     *            the conversionType to set
     */
    public void setConversionType(int conversionType) {
        this.conversionType = conversionType;
    }

    /**
     * @return the conversionStatus
     */
    public int conversionStatus() {
        return conversionStatus;
    }

    /**
     * @param conversionStatus
     *            the conversionStatus to set
     */
    public void setConversionStatus(int conversionStatus) {
        this.conversionStatus = conversionStatus;
    }

    /**
     * @return the numberOfPremiumsReceived
     */
    public int numberOfPremiumsReceived() {
        return numberOfPremiumsReceived;
    }

    /**
     * @param numberOfPremiumsReceived
     *            the numberOfPremiumsReceived to set
     */
    public void setNumberOfPremiumsReceived(int numberOfPremiumsReceived) {
        this.numberOfPremiumsReceived = numberOfPremiumsReceived;
    }

    /**
     * @return the eventInProcessType
     */
    public int eventInProcessType() {
        return eventInProcessType;
    }

    /**
     * @param eventInProcessType
     *            the eventInProcessType to set
     */
    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    /**
     * @return the eventInProcessId
     */
    public long eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }
}

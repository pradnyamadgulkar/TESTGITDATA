/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for AASH_ACC_SCHD table.
 */
public class FixtureTestAccountAdjustmentScheduleHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestAccountAdjustmentScheduleHistory.class);

    private long scheduleId;
    private String policyNumber;
    private long masterEventId;
    private String startDate;
    private String nextPaymentDate;
    private String endDate;
    private int scheduleStatus;
    private long eventInProcessId;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT AASH_SCHD_ID,AASH_POL_NR,AASH_MSTR_EVT_ID,AASH_START_DT,AASH_NXT_PMT_DT,AASH_END_DT,AASH_SCHD_STS,AASH_EIP_ID,"
                    + "AASH_CRTD_BY,AASH_UPD_BY,AASH_CRTD_TMST,AASH_UPD_TMST,AASH_ACC_SCHD_VER,DM_LSTUPDDT FROM {0}AASH_ACC_SCHD "
                    + "ORDER BY AASH_MSTR_EVT_ID, AASH_POL_NR, AASH_SCHD_ID FOR FETCH ONLY WITH UR");

    public FixtureTestAccountAdjustmentScheduleHistory() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setScheduleId(getResultSet().getLong("AASH_SCHD_ID"));
            setPolicyNumber(getResultSet().getString("AASH_POL_NR").trim());
            setMasterEventId(getResultSet().getLong("AASH_MSTR_EVT_ID"));
            setStartDate(format(getResultSet().getDate("AASH_START_DT")));
            setNextPaymentDate(format(getResultSet().getDate("AASH_NXT_PMT_DT")));
            setEndDate(format(getResultSet().getDate("AASH_END_DT")));
            setScheduleStatus(getResultSet().getInt("AASH_SCHD_STS"));
            setEventInProcessId(getResultSet().getLong("AASH_EIP_ID"));
            setCreatedBy(getResultSet().getString("AASH_CRTD_BY"));
            setUpdatedBy(getResultSet().getString("AASH_UPD_BY"));
            setVersion(getResultSet().getInt("AASH_ACC_SCHD_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestAccountAdjustmentScheduleHistory: "
                    + ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestAccountAdjustmentScheduleHistory", se);
            }
        }
    }

    /**
     * @return the scheduleId
     */
    public long scheduleId() {
        return scheduleId;
    }

    /**
     * @param scheduleId
     *            the scheduleId to set
     */
    public void setScheduleId(long scheduleId) {
        this.scheduleId = scheduleId;
    }

    /**
     * @return the policyNumber
     */
    public String policyNumber() {
        return policyNumber;
    }

    /**
     * @param policyNumber
     *            the policyNumber to set
     */
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    /**
     * @return the masterEventId
     */
    public long masterEventId() {
        return masterEventId;
    }

    /**
     * @param masterEventId
     *            the masterEventId to set
     */
    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    /**
     * @return the startDate
     */
    public String startDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the nextPaymentDate
     */
    public String nextPaymentDate() {
        return nextPaymentDate;
    }

    /**
     * @param nextPaymentDate
     *            the nextPaymentDate to set
     */
    public void setNextPaymentDate(String nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    /**
     * @return the endDate
     */
    public String endDate() {
        return endDate;
    }

    /**
     * @param endDate
     *            the endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * @return the scheduleStatus
     */
    public int scheduleStatus() {
        return scheduleStatus;
    }

    /**
     * @param scheduleStatus
     *            the scheduleStatus to set
     */
    public void setScheduleStatus(int scheduleStatus) {
        this.scheduleStatus = scheduleStatus;
    }

    /**
     * @return the eventInProcessId
     */
    public long eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }
}

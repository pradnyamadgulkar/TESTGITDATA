package za.co.sanlam.cms.service;

import java.util.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class CommissionEvent {

    private String policyNumber;
    private String productType;
    private int noOfPremiumReceived;
    private String clientOwnerPortfolioNo;
    private String clientInsuredPortfolioNo;
    private String clientInsuredSurname;
    private String clientInsuredInitials;
    private String orginalPolicyNumber;
    private int currency;
    private int sourceSystem;
    private String productNameCode;
    private double randValuePremiumInArrears;
    private double policyTotalPremium;
    private int warningLevel;
    private int eventType;
    private Date eventEffectiveDate;
    private int taxFundGroupCode;
    private String commissionType;
    private int premiumPaymentMethod;
    private int premiumFrequency;
    private String campaignCode;
    private int indexGrowthType;
    private Date quotationDate;
    private Date applicationInceptionDate;
    private int indexPlanOptionIndicator;
    private int noOfElements;
    private Date premiumHolidayStartDate;
    private Date premiumHolidayEndDate;
    private int rparIndicator;
    private int specialReInstatementIndicator;
    private int coversionIndicator;
    private Timestamp transactionTimestamp;
    private int elementNumber;
    private Date elementStartDate;
    private int elementTerm;
    private double elementPremium;
    private double fundValue;
    private double premiumReductionPercentage;
    private double salesCommissionMonthlyAmount;
    private double serviceCommissionMonthlyAmount;
    private double fundCommissionMonthlyAmount;
    private Date policyIssueDate;
    private double salesCommissionNegotiatedPercentage;
    private double serviceCommissionNegotiatedPercentage;
    private int scoreTerm;
    private int combinedAlterationIndicator;
    private String replacementIndicator;
    private int transferSourceRA;
    private double elementScorePremium;
    private double conversionPremium;
    private String createdby;
    private String updateby;
    private Timestamp createdTimeStamp;
    private Timestamp updatedTimeStamp;
    private List<IntermediaryInfo> intermediarys = new ArrayList<IntermediaryInfo>();

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int getNoOfPremiumReceived() {
        return noOfPremiumReceived;
    }

    public void setNoOfPremiumReceived(int noOfPremiumReceived) {
        this.noOfPremiumReceived = noOfPremiumReceived;
    }

    public String getClientOwnerPortfolioNo() {
        return clientOwnerPortfolioNo;
    }

    public void setClientOwnerPortfolioNo(String clientOwnerPortfolioNo) {
        this.clientOwnerPortfolioNo = clientOwnerPortfolioNo;
    }

    public String getClientInsuredPortfolioNo() {
        return clientInsuredPortfolioNo;
    }

    public void setClientInsuredPortfolioNo(String clientInsuredPortfolioNo) {
        this.clientInsuredPortfolioNo = clientInsuredPortfolioNo;
    }

    public String getClientInsuredSurname() {
        return clientInsuredSurname;
    }

    public void setClientInsuredSurname(String clientInsuredSurname) {
        this.clientInsuredSurname = clientInsuredSurname;
    }

    public String getClientInsuredInitials() {
        return clientInsuredInitials;
    }

    public void setClientInsuredInitials(String clientInsuredInitials) {
        this.clientInsuredInitials = clientInsuredInitials;
    }

    public String getOrginalPolicyNumber() {
        return orginalPolicyNumber;
    }

    public void setOrginalPolicyNumber(String orginalPolicyNumber) {
        this.orginalPolicyNumber = orginalPolicyNumber;
    }

    public int getCurrency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    public String getProductNameCode() {
        return productNameCode;
    }

    public void setProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
    }

    public double getRandValuePremiumInArrears() {
        return randValuePremiumInArrears;
    }

    public void setRandValuePremiumInArrears(double randValuePremiumInArrears) {
        this.randValuePremiumInArrears = randValuePremiumInArrears;
    }

    public double getPolicyTotalPremium() {
        return policyTotalPremium;
    }

    public void setPolicyTotalPremium(double policyTotalPremium) {
        this.policyTotalPremium = policyTotalPremium;
    }

    public int getWarningLevel() {
        return warningLevel;
    }

    public void setWarningLevel(int warningLevel) {
        this.warningLevel = warningLevel;
    }

    public int getEventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public Date getEventEffectiveDate() {
        return eventEffectiveDate;
    }

    public void setEventEffectiveDate(Date eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    public int getTaxFundGroupCode() {
        return taxFundGroupCode;
    }

    public void setTaxFundGroupCode(int taxFundGroupCode) {
        this.taxFundGroupCode = taxFundGroupCode;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public int getPremiumPaymentMethod() {
        return premiumPaymentMethod;
    }

    public void setPremiumPaymentMethod(int premiumPaymentMethod) {
        this.premiumPaymentMethod = premiumPaymentMethod;
    }

    public int getPremiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    public String getCampaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    public int getIndexGrowthType() {
        return indexGrowthType;
    }

    public void setIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
    }

    public Date getQuotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(Date quotationDate) {
        this.quotationDate = quotationDate;
    }

    public Date getApplicationInceptionDate() {
        return applicationInceptionDate;
    }

    public void setApplicationInceptionDate(Date applicationInceptionDate) {
        this.applicationInceptionDate = applicationInceptionDate;
    }

    public int getIndexPlanOptionIndicator() {
        return indexPlanOptionIndicator;
    }

    public void setIndexPlanOptionIndicator(int indexPlanOptionIndicator) {
        this.indexPlanOptionIndicator = indexPlanOptionIndicator;
    }

    public int getNoOfElements() {
        return noOfElements;
    }

    public void setNoOfElements(int noOfElements) {
        this.noOfElements = noOfElements;
    }

    public Date getPremiumHolidayStartDate() {
        return premiumHolidayStartDate;
    }

    public void setPremiumHolidayStartDate(Date premiumHolidayStartDate) {
        this.premiumHolidayStartDate = premiumHolidayStartDate;
    }

    public Date getPremiumHolidayEndDate() {
        return premiumHolidayEndDate;
    }

    public void setPremiumHolidayEndDate(Date premiumHolidayEndDate) {
        this.premiumHolidayEndDate = premiumHolidayEndDate;
    }

    public int getRparIndicator() {
        return rparIndicator;
    }

    public void setRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
    }

    public int getSpecialReInstatementIndicator() {
        return specialReInstatementIndicator;
    }

    public void setSpecialReInstatementIndicator(int specialReInstatementIndicator) {
        this.specialReInstatementIndicator = specialReInstatementIndicator;
    }

    public int getCoversionIndicator() {
        return coversionIndicator;
    }

    public void setCoversionIndicator(int coversionIndicator) {
        this.coversionIndicator = coversionIndicator;
    }

    public Timestamp getTransactionTimestamp() {
        return transactionTimestamp;
    }

    public void setTransactionTimestamp(Timestamp transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
    }

    public int getElementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public Date getElementStartDate() {
        return elementStartDate;
    }

    public void setElementStartDate(Date elementStartDate) {
        this.elementStartDate = elementStartDate;
    }

    public int getElementTerm() {
        return elementTerm;
    }

    public void setElementTerm(int elementTerm) {
        this.elementTerm = elementTerm;
    }

    public double getElementPremium() {
        return elementPremium;
    }

    public void setElementPremium(double elementPremium) {
        this.elementPremium = elementPremium;
    }

    public double getFundValue() {
        return fundValue;
    }

    public void setFundValue(double fundValue) {
        this.fundValue = fundValue;
    }

    public double getPremiumReductionPercentage() {
        return premiumReductionPercentage;
    }

    public void setPremiumReductionPercentage(double premiumReductionPercentage) {
        this.premiumReductionPercentage = premiumReductionPercentage;
    }

    public double getSalesCommissionMonthlyAmount() {
        return salesCommissionMonthlyAmount;
    }

    public void setSalesCommissionMonthlyAmount(double salesCommissionMonthlyAmount) {
        this.salesCommissionMonthlyAmount = salesCommissionMonthlyAmount;
    }

    public double getServiceCommissionMonthlyAmount() {
        return serviceCommissionMonthlyAmount;
    }

    public void setServiceCommissionMonthlyAmount(double serviceCommissionMonthlyAmount) {
        this.serviceCommissionMonthlyAmount = serviceCommissionMonthlyAmount;
    }

    public double getFundCommissionMonthlyAmount() {
        return fundCommissionMonthlyAmount;
    }

    public void setFundCommissionMonthlyAmount(double fundCommissionMonthlyAmount) {
        this.fundCommissionMonthlyAmount = fundCommissionMonthlyAmount;
    }

    public Date getPolicyIssueDate() {
        return policyIssueDate;
    }

    public void setPolicyIssueDate(Date policyIssueDate) {
        this.policyIssueDate = policyIssueDate;
    }

    public double getSalesCommissionNegotiatedPercentage() {
        return salesCommissionNegotiatedPercentage;
    }

    public void setSalesCommissionNegotiatedPercentage(double salesCommissionNegotiatedPercentage) {
        this.salesCommissionNegotiatedPercentage = salesCommissionNegotiatedPercentage;
    }

    public double getServiceCommissionNegotiatedPercentage() {
        return serviceCommissionNegotiatedPercentage;
    }

    public void setServiceCommissionNegotiatedPercentage(double serviceCommissionNegotiatedPercentage) {
        this.serviceCommissionNegotiatedPercentage = serviceCommissionNegotiatedPercentage;
    }

    public int getScoreTerm() {
        return scoreTerm;
    }

    public void setScoreTerm(int scoreTerm) {
        this.scoreTerm = scoreTerm;
    }

    public int getCombinedAlterationIndicator() {
        return combinedAlterationIndicator;
    }

    public void setCombinedAlterationIndicator(int combinedAlterationIndicator) {
        this.combinedAlterationIndicator = combinedAlterationIndicator;
    }

    public String getReplacementIndicator() {
        return replacementIndicator;
    }

    public void setReplacementIndicator(String replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }

    public int getTransferSourceRA() {
        return transferSourceRA;
    }

    public void setTransferSourceRA(int transferSourceRA) {
        this.transferSourceRA = transferSourceRA;
    }

    public double getElementScorePremium() {
        return elementScorePremium;
    }

    public void setElementScorePremium(double elementScorePremium) {
        this.elementScorePremium = elementScorePremium;
    }

    /**
     * @return the conversionPremium
     */
    public double getConversionPremium() {
        return conversionPremium;
    }

    /**
     * @param conversionPremium
     *            the conversionPremium to set
     */
    public void setConversionPremium(double conversionPremium) {
        this.conversionPremium = conversionPremium;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public Timestamp getCreatedTimeStamp() {
        return createdTimeStamp;
    }

    public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
        this.createdTimeStamp = createdTimeStamp;
    }

    public Timestamp getUpdatedTimeStamp() {
        return updatedTimeStamp;
    }

    public void setUpdatedTimeStamp(Timestamp updatedTimeStamp) {
        this.updatedTimeStamp = updatedTimeStamp;
    }

    public List<IntermediaryInfo> getIntermediarys() {
        return intermediarys;
    }

    public void setIntermediarys(List<IntermediaryInfo> intermediarys) {
        this.intermediarys = intermediarys;
    }

}

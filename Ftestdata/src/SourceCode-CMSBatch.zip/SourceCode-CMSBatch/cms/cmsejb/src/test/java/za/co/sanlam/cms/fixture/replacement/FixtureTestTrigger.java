package za.co.sanlam.cms.fixture.replacement;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tcs.mastercraft.mctype.ServerContext;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestTrigger extends FixtureTestKomEvents {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestTrigger.class);

    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    private long replacementTriggerId;
    private String portfolioNumber;
    private String commissionType;
    private String effectiveDate;
    private String policyNumber;
    private String premiumDecreaseAmount;
    private int replacementCategory;
    private String replacementDate;
    private int triggerType;
    private String createdBy;
    private int rowNumber;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestTrigger.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute() {
        LOGGER.debug("FixtureTestTrigger.execute()");
        try {
            if (inValidResultSet(resultSet)) {
                return;
            }
            resultSet.absolute(rowNumber);
            setReplacementTriggerId(resultSet.getLong("RPRT_TRIGGER_ID"));
            setPortfolioNumber(resultSet.getString("RPRT_PF_NR").trim());
            setCommissionType(resultSet.getString("RPRT_COMM_TYPE").trim());
            setEffectiveDate(dateFormatter.format(resultSet.getDate("RPRT_EFF_DATE")));
            setPolicyNumber(resultSet.getString("RPRT_POL_NR").trim());
            setPremiumDecreaseAmount(resultSet.getDouble("RPRT_PRM_DCR_AMT"));
            setReplacementCategory(resultSet.getInt("RPRT_REPL_CAT"));
            setReplacementDate(dateFormatter.format(resultSet.getDate("RPRT_REPL_DATE")));
            setTriggerType(resultSet.getInt("RPRT_TRIGGER_TYPE"));
            setCreatedBy(resultSet.getString("RPRT_CRTD_BY").trim());
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestTrigger", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestTrigger", se);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }


    public long replacementTriggerId() {
        return replacementTriggerId;
    }

    public void setReplacementTriggerId(long replacementTriggerId) {
        this.replacementTriggerId = replacementTriggerId;
    }

    public String portfolioNumber() {
        return portfolioNumber;
    }

    public void setPortfolioNumber(String portfolioNumber) {
        this.portfolioNumber = portfolioNumber;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String effectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String premiumDecreaseAmount() {
        if (premiumDecreaseAmount != null) {
            if (BigDecimal.valueOf(Double.parseDouble(premiumDecreaseAmount)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(premiumDecreaseAmount).intValue());
            }
        }
        return premiumDecreaseAmount;
    }

    public void setPremiumDecreaseAmount(double premiumDecreaseAmount) {
        this.premiumDecreaseAmount = Double.toString(premiumDecreaseAmount);
    }

    public int replacementCategory() {
        return replacementCategory;
    }

    public void setReplacementCategory(int replacementCategory) {
        this.replacementCategory = replacementCategory;
    }

    public String replacementDate() {
        return replacementDate;
    }

    public void setReplacementDate(String replacementDate) {
        this.replacementDate = replacementDate;
    }

    public int triggerType() {
        return triggerType;
    }

    public void setTriggerType(int triggerType) {
        this.triggerType = triggerType;
    }

    public String createdBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    private void initialize() throws SQLException {
        LOGGER.debug("Retrieving info for Marketers");
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("RPRT_TRIGGER_ID, RPRT_POL_NR, RPRT_PF_NR, RPRT_EFF_DATE, RPRT_PRM_DCR_AMT, ");
        sqlStatement.append("RPRT_REPL_CAT, RPRT_REPL_DATE, RPRT_TRIGGER_TYPE, RPRT_COMM_TYPE, RPRT_CRTD_BY ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("RPRT_REPL_TRIGGER ");
        //sqlStatement.append("ORDER BY RPRT_TRIGGER_ID ");
        sqlStatement.append("ORDER BY RPRT_POL_NR, RPRT_TRIGGER_ID ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");

        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestTrigger", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }
}

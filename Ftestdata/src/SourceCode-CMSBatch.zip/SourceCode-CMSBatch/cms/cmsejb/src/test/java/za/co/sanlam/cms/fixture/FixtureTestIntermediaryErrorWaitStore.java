/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for EWSI_ERWT_INTM table.
 */
public class FixtureTestIntermediaryErrorWaitStore extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestIntermediaryErrorWaitStore.class);

    private long errorWaitStoreReferenceId;
    private long errWaitStoreRefId;
    private long intermediaryNumber;
    private String salesSplitPercentage;
    private String salesComSplitPct;
    private String serviceSplitPercentage;
    private String serviceComSplitPct;
    private int applicationNumber;
    private int manCode;
    private int errInfoVer;
    private String fundSplitPerctg;
    private String fundSplitPercentage;

    public FixtureTestIntermediaryErrorWaitStore() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setErrorWaitStoreReferenceId(getResultSet().getLong("EWSI_ERWS_REF_ID"));
            setIntermediaryNumber(getResultSet().getLong("EWSI_INTM_NR"));
            setSalesSplitPercentage(getResultSet().getDouble("EWSI_SLS_SPLT_PCT"));
            setServiceSplitPercentage(getResultSet().getDouble("EWSI_SRV_SPLT_PCT"));
            setApplicationNumber(getResultSet().getInt("EWSI_APP_NR"));
            setManCode(getResultSet().getInt("EWSI_MAN_CD"));
            setCreatedBy(getResultSet().getString("EWSI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("EWSI_UPD_BY").trim());
            setVersion(getResultSet().getInt("EWSI_ERWT_INTM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setFundSplitPercentage(getResultSet().getDouble("EWSI_FUND_SPLT_PCT"));

            setErrWaitStoreRefId(getResultSet().getLong("EWSI_ERWS_REF_ID"));
            setSalesComSplitPct(getResultSet().getDouble("EWSI_SLS_SPLT_PCT"));
            setServiceComSplitPct(getResultSet().getDouble("EWSI_SRV_SPLT_PCT"));
            setFundSplitPerctg(getResultSet().getDouble("EWSI_FUND_SPLT_PCT"));
            setErrInfoVer(getResultSet().getInt("EWSI_ERWT_INTM_VER"));
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestIntdErrorWaitStore", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestIntdErrorWaitStore", se);
            }
        }
    }

    /**
     * @return the errorWaitStoreReferenceId
     */
    public long errorWaitStoreReferenceId() {
        return errorWaitStoreReferenceId;
    }

    /**
     * @param errorWaitStoreReferenceId
     *            the errorWaitStoreReferenceId to set
     */
    public void setErrorWaitStoreReferenceId(long errorWaitStoreReferenceId) {
        this.errorWaitStoreReferenceId = errorWaitStoreReferenceId;
    }

    /**
     * @return the salesSplitPercentage
     */
    public String salesSplitPercentage() {
        return formatDouble(salesSplitPercentage);
    }

    /**
     * @param salesSplitPercentage
     *            the salesSplitPercentage to set
     */
    public void setSalesSplitPercentage(double salesSplitPercentage) {
        this.salesSplitPercentage = String.valueOf(salesSplitPercentage);
    }

    /**
     * @return the serviceSplitPercentage
     */
    public String serviceSplitPercentage() {
        return formatDouble(serviceSplitPercentage);
    }

    /**
     * @param serviceSplitPercentage
     *            the serviceSplitPercentage to set
     */
    public void setServiceSplitPercentage(double serviceSplitPercentage) {
        this.serviceSplitPercentage = String.valueOf(serviceSplitPercentage);
    }

    /**
     * @return the fundSplitPercentage
     */
    public String fundSplitPercentage() {
        return formatDouble(fundSplitPercentage);
    }

    /**
     * @param fundSplitPercentage
     *            the fundSplitPercentage to set
     */
    public void setFundSplitPercentage(double fundSplitPercentage) {
        this.fundSplitPercentage = String.valueOf(fundSplitPercentage);
    }

    @Deprecated
    public long errWaitStoreRefId() {
        return errWaitStoreRefId;
    }

    @Deprecated
    public void setErrWaitStoreRefId(long errWaitStoreRefId) {
        this.errWaitStoreRefId = errWaitStoreRefId;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    @Deprecated
    public String salesComSplitPct() {
        if (salesComSplitPct != null) {
            if (BigDecimal.valueOf(Double.parseDouble(salesComSplitPct)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(salesComSplitPct).intValue());
            }
        }
        return salesComSplitPct;
    }

    @Deprecated
    public void setSalesComSplitPct(double salesComSplitPct) {
        this.salesComSplitPct = Double.toString(salesComSplitPct);
    }

    @Deprecated
    public String serviceComSplitPct() {
        if (serviceComSplitPct != null) {
            if (BigDecimal.valueOf(Double.parseDouble(serviceComSplitPct)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(serviceComSplitPct).intValue());
            }
        }
        return serviceComSplitPct;
    }

    @Deprecated
    public void setServiceComSplitPct(double serviceComSplitPct) {
        this.serviceComSplitPct = Double.toString(serviceComSplitPct);
    }

    public int applicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(int applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    public int manCode() {
        return manCode;
    }

    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    @Deprecated
    public int errInfoVer() {
        return errInfoVer;
    }

    @Deprecated
    public void setErrInfoVer(int errInfoVer) {
        this.errInfoVer = errInfoVer;
    }

    @Deprecated
    public String fundSplitPerctg() {
        if (fundSplitPerctg != null) {
            if (BigDecimal.valueOf(Double.parseDouble(fundSplitPerctg)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(fundSplitPerctg).intValue());
            }
        }
        return fundSplitPerctg;
    }

    @Deprecated
    public void setFundSplitPerctg(double fundSplitPerctg) {
        this.fundSplitPerctg = Double.toString(fundSplitPerctg);
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT EWSI_ERWS_REF_ID, EWSI_INTM_NR, EWSI_SLS_SPLT_PCT, EWSI_SRV_SPLT_PCT, "
                    + "EWSI_APP_NR, EWSI_MAN_CD, EWSI_CRTD_BY, EWSI_UPD_BY, EWSI_ERWT_INTM_VER, DM_LSTUPDDT, EWSI_FUND_SPLT_PCT from {0}EWSI_ERWT_INTM "
                    + "ORDER BY EWSI_ERWS_REF_ID, EWSI_INTM_NR  FOR FETCH ONLY WITH UR");
}

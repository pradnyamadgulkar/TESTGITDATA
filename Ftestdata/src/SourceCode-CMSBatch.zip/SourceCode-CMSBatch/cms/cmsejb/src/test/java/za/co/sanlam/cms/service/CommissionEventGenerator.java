package za.co.sanlam.cms.service;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import KomEvents.DaoIntermediaryInfo;
import KomEvents.MbsoKomEventsIntdCommInfo;

import com.tcs.mastercraft.mctype.MasterCraftVector;
import com.tcs.mastercraft.mctype.ServerContext;

/**
 * Generate Commission Event using PTRI_PRE_TRAN or BEM_LAMDA_XML_INFo tables.
 */
public class CommissionEventGenerator {

    private static final Logger LOG = LoggerFactory.getLogger(CommissionEventGenerator.class);

    private void setupDataSource() {
        try {
            Properties properties = new Properties();
            properties.load(CommissionEventGenerator.class.getResourceAsStream("/config.properties"));

            BasicDataSource dataSource = new BasicDataSource();
            dataSource.setDriverClassName(properties.getProperty("gen.ce.db.driver"));
            dataSource.setUsername(properties.getProperty("gen.ce.db.user"));
            dataSource.setPassword(properties.getProperty("gen.ce.db.password"));
            dataSource.setUrl(properties.getProperty("gen.ce.db.url"));

            ServerContext.setDataSource(dataSource);
            ServerContext.getServerContextObject().setSchemaName(properties.getProperty("gen.ce.db.schema"));
            ServerContext.getClientContext().setUserId(new StringBuffer("IntTest"));
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public List<CommissionEvent> generateCommissionEventFromPreTran(String preTranPolNr) throws SQLException {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            setupDataSource();

            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(getSQLForPreTranUsingPolNr());
            preparedStatement.setString(1, preTranPolNr);

            resultSet = preparedStatement.executeQuery();
            return generateCommissionEventFromPreTran(resultSet);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw sqle;
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                ServerContext.clearServerContext();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }

    public CommissionEvent generateCommissionEventFromPreTran(long preTranRefId) throws SQLException {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            setupDataSource();

            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(getSQLForPreTranUsingId());
            preparedStatement.setLong(1, preTranRefId);

            resultSet = preparedStatement.executeQuery();
            List<CommissionEvent> commissionEvents = generateCommissionEventFromPreTran(resultSet);
            return commissionEvents.isEmpty() ? null : commissionEvents.get(0);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw sqle;
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                ServerContext.clearServerContext();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
        }
    }

    public CommissionEvent generateCommissionEventFromLamdaXmlInfo(long lamdaTranRefId) throws Exception {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        CommissionEvent commissionEvent = null;
        try {
            setupDataSource();

            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(getSQLForLamdaXml());
            preparedStatement.setLong(1, lamdaTranRefId);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                commissionEvent = new CommissionEvent();
                commissionEvent.setPolicyNumber(resultSet.getString("POLICY_NO").trim());
                commissionEvent.setProductType(resultSet.getString("PRODUCT_TYPE").trim());
                commissionEvent.setNoOfPremiumReceived(resultSet.getInt("NO_OF_PRM_RECVD"));
                commissionEvent.setClientOwnerPortfolioNo(resultSet.getString("CLIENT_OWNER_PORTFOLIO_NO").trim());
                commissionEvent.setClientInsuredPortfolioNo(resultSet.getString("CLIENT_INSURED_PORTFOLIO_NO").trim());
                commissionEvent.setClientInsuredSurname(resultSet.getString("CLIENT_INSURED_SURNAME").trim());
                commissionEvent.setClientInsuredInitials(resultSet.getString("CLIENT_INSURED_INITIALS").trim());
                commissionEvent.setOrginalPolicyNumber(resultSet.getString("ORG_POLICY_NO").trim());
                commissionEvent.setCurrency(resultSet.getInt("CURRENCY"));
                commissionEvent.setSourceSystem(resultSet.getInt("SOURCE_SYSTEM"));
                commissionEvent.setProductNameCode(resultSet.getString("PRODUCT_NAME_CODE").trim());
                commissionEvent.setRandValuePremiumInArrears(resultSet.getDouble("RAND_VALUE_PRM_IN_ARREARS"));
                commissionEvent.setPolicyTotalPremium(resultSet.getDouble("POLICY_TOTAL_PREMIUM"));
                commissionEvent.setWarningLevel(resultSet.getInt("WARNING_LEVEL"));
                commissionEvent.setEventType(resultSet.getInt("EVENT_TYPE"));
                commissionEvent.setEventEffectiveDate(resultSet.getDate("EVENT_EFF_DATE"));
                commissionEvent.setTaxFundGroupCode(resultSet.getInt("TAXFUND_GROUP_CODE"));
                commissionEvent.setCommissionType(resultSet.getString("COMMISSION_TYPE").trim());
                commissionEvent.setPremiumPaymentMethod(resultSet.getInt("PREMIUM_PYMT_METHOD"));
                commissionEvent.setPremiumFrequency(resultSet.getInt("PREMIUM_FREQ"));
                commissionEvent.setCampaignCode(resultSet.getString("CAMPAIGN_CODE").trim());
                commissionEvent.setIndexGrowthType(resultSet.getInt("INDEX_GROWTH_TYPE"));
                commissionEvent.setQuotationDate(resultSet.getDate("QUOTATION_DATE"));

                commissionEvent.setApplicationInceptionDate(resultSet.getDate("APP_IN_DATE"));
                commissionEvent.setIndexPlanOptionIndicator(resultSet.getInt("INDEX_PLAN_OPTION_IND"));
                commissionEvent.setNoOfElements(resultSet.getInt("NO_OF_ELEMENTS"));

                commissionEvent.setPremiumHolidayStartDate(resultSet.getDate("PREMIUM_HOLIDAY_START_DATE"));

                commissionEvent.setPremiumHolidayEndDate(resultSet.getDate("PREMIUM_HOLIDAY_END_DATE"));
                commissionEvent.setRparIndicator(resultSet.getInt("RPAR_IND"));
                commissionEvent.setSpecialReInstatementIndicator(resultSet.getInt("SPCL_REINS_IND"));
                commissionEvent.setCoversionIndicator(resultSet.getInt("COVERSION_IND"));
                commissionEvent.setTransactionTimestamp(resultSet.getTimestamp("TRANSACTION_TS"));
                commissionEvent.setElementNumber(resultSet.getInt("ELEMENT_NO"));

                commissionEvent.setElementStartDate(resultSet.getDate("ELEMENT_ST_DATE"));
                commissionEvent.setElementTerm(resultSet.getInt("ELEMENT_TERM"));
                commissionEvent.setElementPremium(resultSet.getDouble("ELEMENT_PREMIUM"));
                commissionEvent.setFundValue(resultSet.getDouble("FUND_VALUE"));
                commissionEvent.setPremiumReductionPercentage(resultSet.getDouble("PREMIUM_REDUCTION_PCT"));
                commissionEvent.setSalesCommissionMonthlyAmount(resultSet.getDouble("SALES_COMM_MONTHLY_AMT"));
                commissionEvent.setServiceCommissionMonthlyAmount(resultSet.getDouble("SERVICE_COMM_MONTHLY_AMT"));
                commissionEvent.setFundCommissionMonthlyAmount(resultSet.getDouble("FUND_COMM_MONTHLY_AMT"));
                commissionEvent.setPolicyIssueDate(resultSet.getDate("POLICY_ISSUE_DATE"));
                commissionEvent.setSalesCommissionNegotiatedPercentage(resultSet.getDouble("SALES_COMM_NEGOTIATED_PCT"));
                commissionEvent.setServiceCommissionNegotiatedPercentage(resultSet.getDouble("SERVICE_COMM_NEGOTIATED_PCT"));
                commissionEvent.setScoreTerm(resultSet.getInt("SCORE_TERM"));
                commissionEvent.setCombinedAlterationIndicator(resultSet.getInt("COMB_ALT_IND"));
                commissionEvent.setReplacementIndicator(resultSet.getString("ELEM_REPLACED_IND"));
                commissionEvent.setTransferSourceRA(resultSet.getInt("TRANSFER_SOURCE_RA"));
                commissionEvent.setElementScorePremium(resultSet.getDouble("ELEMENT_SCORE_PREMIUM"));
                commissionEvent.setConversionPremium(resultSet.getDouble("CONVERSION_PREMIUM"));

                DaoIntermediaryInfo daoIntermediaryInfo = new DaoIntermediaryInfo();
                MasterCraftVector vector = daoIntermediaryInfo.fetchIntermediaryInfo(lamdaTranRefId);
                for (int i = 0; i < vector.size(); i++) {
                    MbsoKomEventsIntdCommInfo intermediaryCommInfo = (MbsoKomEventsIntdCommInfo) vector.get(i);
                    IntermediaryInfo intermediaryInfo = new IntermediaryInfo();
                    intermediaryInfo.setIntermediaryNumber(intermediaryCommInfo.getIntdNo());
                    intermediaryInfo.setApplicationNumber(intermediaryCommInfo.getApplnNo());
                    intermediaryInfo.setManCode(intermediaryCommInfo.getManCode());
                    intermediaryInfo.setSalesCommissionSplitPercentage(intermediaryCommInfo.getSalsCommSpltPct());
                    intermediaryInfo.setServiceCommissionSplitPercentage(intermediaryCommInfo.getServCommSpltPct());
                    intermediaryInfo.setFundCommissionSplitPercentage(intermediaryCommInfo.getFundComSplitPct());
                    if (commissionEvent.getIntermediarys() == null) {
                        commissionEvent.setIntermediarys(new ArrayList<IntermediaryInfo>());
                    }
                    commissionEvent.getIntermediarys().add(intermediaryInfo);
                }
            }
            LOG.info("Commission Event generated from BEM_LAMDA_XML_INFO");
            return commissionEvent;
        } catch (SQLException e) {
            e.getNextException().printStackTrace();
            ServerContext.getJDBCHandle().rollback();
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
            ServerContext.clearServerContext();
        }
        return null;
    }

    // ----- PRIVATE METHODS ---
    private String getSQLForPreTranUsingId() {
        return getSQLForPreTran("PTRI_PTIN_REF_ID");
    }

    private String getSQLForPreTranUsingPolNr() {
        return getSQLForPreTran("PTRI_POL_NR");
    }

    private String getSQLForPreTran(String whereClause) {
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement
                .append("PTRI_PTIN_REF_ID, PTRI_POL_NR, PTRI_PRD_TYP, PTRI_PRD_NAME_CD, PTRI_CLT_PF_NR_OWN, PTRI_CLT_PF_NR_INS, PTRI_CLT_SUR_INS, PTRI_CLT_INI_INS, ");
        sqlStatement
                .append("PTRI_CURR, PTRI_SRC_SYS, PTRI_POL_ISSUE_DT, PTRI_CONV_IND, PTRI_EVT_TYP, PTRI_EVT_EFF_DT, PTRI_PRM_HOL_ED_DT, PTRI_COMM_TYP, ");
        sqlStatement
                .append("PTRI_PRM_RDN_PCT, PTRI_IDX_GTH_TYP, PTRI_CMPG_CD, PTRI_IDX_OP_IND, PTRI_TAX_GRP_CD, PTRI_NR_OF_ELMTS, PTRI_RPAR_IND, PTRI_SPL_RINST_IND, ");
        sqlStatement
                .append("PTRI_NR_PRM_RCVD, PTRI_PRM_FQ, PTRI_PRM_PMT_METH, PTRI_RVALPRM_INARR, PTRI_POL_TOT_PRM, PTRI_WRNG_LEVEL, ");
        sqlStatement
                .append("PTRI_APP_DT, PTRI_QTE_DT, PTRI_ELMT_NR, PTRI_ELMT_START_DT, PTRI_ELMT_TRM, PTRI_PRM_PER_FQ, PTRI_SLS_COMM, PTRI_SRV_COMM, PTRI_REN_SERV_COMM, ");
        sqlStatement
                .append("PTRI_SLS_NEGO_PCT, PTRI_SRV_NEGO_PCT, PTRI_FUND_VALUE, PTRI_FUND_COMM, PTRI_RA_XER_IND, PTRI_SCR_TRM, PTRI_TRANSACT_TMST, PTRI_POL_NR_CONV, PTRI_ELMT_SCR_PRM, PTRI_CONV_PRM ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("PTRI_PRE_TRAN ");
        sqlStatement.append("WHERE ");
        sqlStatement.append(whereClause);
        sqlStatement.append(" = ? ORDER BY PTRI_PTIN_REF_ID with ur;");
        return sqlStatement.toString();
    }

    private String getSQLForPreTranInt() {
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("PTIN_INTM_NR, PTIN_SLS_SPLT_PCT, PTIN_SRV_SPLT_PCT, PTIN_APP_NR, PTIN_MAN_CD, PTIN_FUND_SPLT_PCT ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("PTIN_PRT_INTM ");
        sqlStatement.append("WHERE PTIN_PRI_REF_ID = ? with ur;");
        return sqlStatement.toString();
    }

    private String getSQLForLamdaXml() {
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement
                .append("LAMDA_TRANS_REF_ID,  POLICY_NO,PRODUCT_TYPE, NO_OF_PRM_RECVD, CLIENT_OWNER_PORTFOLIO_NO, CLIENT_INSURED_PORTFOLIO_NO, ");
        sqlStatement
                .append("CLIENT_INSURED_SURNAME, CLIENT_INSURED_INITIALS, ORG_POLICY_NO,CURRENCY, SOURCE_SYSTEM, PRODUCT_NAME_CODE,  RAND_VALUE_PRM_IN_ARREARS, ");
        sqlStatement
                .append("POLICY_TOTAL_PREMIUM, WARNING_LEVEL,EVENT_TYPE, EVENT_EFF_DATE, TAXFUND_GROUP_CODE, COMMISSION_TYPE, PREMIUM_PYMT_METHOD, ");
        sqlStatement
                .append("PREMIUM_FREQ, CAMPAIGN_CODE, INDEX_GROWTH_TYPE, QUOTATION_DATE, APP_IN_DATE, INDEX_PLAN_OPTION_IND, NO_OF_ELEMENTS, ");
        sqlStatement
                .append("PREMIUM_HOLIDAY_START_DATE, PREMIUM_HOLIDAY_END_DATE, RPAR_IND, SPCL_REINS_IND, COVERSION_IND, TRANSACTION_TS, ELEMENT_NO, ");
        sqlStatement
                .append("ELEMENT_ST_DATE, ELEMENT_TERM, ELEMENT_PREMIUM, FUND_VALUE, PREMIUM_REDUCTION_PCT, SALES_COMM_MONTHLY_AMT, SERVICE_COMM_MONTHLY_AMT, ");
        sqlStatement
                .append("FUND_COMM_MONTHLY_AMT, POLICY_ISSUE_DATE, SALES_COMM_NEGOTIATED_PCT, SERVICE_COMM_NEGOTIATED_PCT, SCORE_TERM, COMB_ALT_IND, ");
        sqlStatement
                .append("ELEM_REPLACED_IND, TRANSFER_SOURCE_RA, CREATED_BY, UPDATE_BY, CREATE_TIME_ST, UPDATE_TIME_ST, TRAN_VER, EXTRACT_DATE, ELEMENT_SCORE_PREMIUM, CONVERSION_PREMIUM ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("BEM_LAMDA_XML_INFO ");
        sqlStatement.append("WHERE LAMDA_TRANS_REF_ID = ? with ur");
        return sqlStatement.toString();
    }

    private List<CommissionEvent> generateCommissionEventFromPreTran(ResultSet resultSet) throws SQLException {
        List<CommissionEvent> commissionEvents = new ArrayList<CommissionEvent>();
        try {
            while (resultSet.next()) {
                long preTranRefId = resultSet.getLong("PTRI_PTIN_REF_ID");
                Date policyIssueDate = resultSet.getDate("PTRI_POL_ISSUE_DT");
                Date premiumHoldidayEndDate = resultSet.getDate("PTRI_PRM_HOL_ED_DT");
                Date applicationInceptionDate = resultSet.getDate("PTRI_APP_DT");
                Date quotationDate = resultSet.getDate("PTRI_QTE_DT");
                Date elementStart = resultSet.getDate("PTRI_ELMT_START_DT");

                CommissionEventBuilder commissionEventBuilder = new CommissionEventBuilder()
                        .withPolicyNumber(resultSet.getString("PTRI_POL_NR"))
                        .withProductType(resultSet.getString("PTRI_PRD_TYP"))
                        .withProductNameCode(resultSet.getString("PTRI_PRD_NAME_CD"))
                        .withClientOwnerPortfolioNo(resultSet.getString("PTRI_CLT_PF_NR_OWN"))
                        .withClientInsuredPortfolioNo(resultSet.getString("PTRI_CLT_PF_NR_INS"))
                        .withClientInsuredSurname(resultSet.getString("PTRI_CLT_SUR_INS"))
                        .withClientInsuredInitials(resultSet.getString("PTRI_CLT_INI_INS"))
                        .withCurrency(resultSet.getInt("PTRI_CURR"))
                        .withSourceSystem(resultSet.getInt("PTRI_SRC_SYS"))
                        .withPolicyIssueDate(policyIssueDate != null ? new Date(policyIssueDate.getTime()) : null)
                        .withCoversionIndicator(resultSet.getInt("PTRI_CONV_IND"))
                        .withEventType(resultSet.getInt("PTRI_EVT_TYP"))
                        .withEventEffectiveDate(new Date(resultSet.getDate("PTRI_EVT_EFF_DT").getTime()))
                        .withPremiumHolidayEndDate(
                                premiumHoldidayEndDate != null ? new Date(premiumHoldidayEndDate.getTime()) : null)
                        .withPremiumHolidayStartDate(
                                premiumHoldidayEndDate != null ? new Date(premiumHoldidayEndDate.getTime()) : null)
                        .withCommissionType(resultSet.getString("PTRI_COMM_TYP"))
                        .withPremiumReductionPercentage(resultSet.getDouble("PTRI_PRM_RDN_PCT"))
                        .withIndexGrowthType(resultSet.getInt("PTRI_IDX_GTH_TYP"))
                        .withCampaignCode(resultSet.getString("PTRI_CMPG_CD"))
                        .withIndexPlanOptionIndicator(resultSet.getInt("PTRI_IDX_OP_IND"))
                        .withTaxFundGroupCode(resultSet.getInt("PTRI_TAX_GRP_CD"))
                        .withNoOfElements(resultSet.getInt("PTRI_NR_OF_ELMTS"))
                        .withRparIndicator(resultSet.getInt("PTRI_RPAR_IND"))
                        .withSpecialReInstatementIndicator(resultSet.getInt("PTRI_SPL_RINST_IND"))
                        .withNoOfPremiumReceived(resultSet.getInt("PTRI_NR_PRM_RCVD"))
                        .withPremiumFrequency(resultSet.getInt("PTRI_PRM_FQ"))
                        .withPremiumPaymentMethod(resultSet.getInt("PTRI_PRM_PMT_METH"))
                        .withRandValuePremiumInArrears(resultSet.getDouble("PTRI_RVALPRM_INARR"))
                        .withPolicyTotalPremium(resultSet.getDouble("PTRI_POL_TOT_PRM"))
                        .withWarningLevel(resultSet.getInt("PTRI_WRNG_LEVEL"))
                        .withApplicationInceptionDate(
                                applicationInceptionDate != null ? new Date(applicationInceptionDate.getTime()) : null)
                        .withQuotationDate(quotationDate != null ? new Date(quotationDate.getTime()) : null)
                        .withElementNumber(resultSet.getInt("PTRI_ELMT_NR"))
                        .withElementStartDate(elementStart != null ? new Date(elementStart.getTime()) : null)
                        .withElementTerm(resultSet.getInt("PTRI_ELMT_TRM"))
                        .withElementPremium(resultSet.getDouble("PTRI_PRM_PER_FQ"))
                        .withSalesCommissionMonthlyAmount(resultSet.getDouble("PTRI_SLS_COMM"))
                        .withServiceCommissionMonthlyAmount(resultSet.getDouble("PTRI_SRV_COMM"))
                        .withSalesCommissionNegotiatedPercentage(resultSet.getDouble("PTRI_SLS_NEGO_PCT"))
                        .withServiceCommissionNegotiatedPercentage(resultSet.getDouble("PTRI_SRV_NEGO_PCT"))
                        .withFundValue(resultSet.getDouble("PTRI_FUND_VALUE"))
                        .withFundCommissionMonthlyAmount(resultSet.getDouble("PTRI_FUND_COMM"))
                        .withTransferSourceRA(resultSet.getInt("PTRI_RA_XER_IND"))
                        .withScoreTerm(resultSet.getInt("PTRI_SCR_TRM"))
                        .withElementScorePremium(resultSet.getDouble("PTRI_ELMT_SCR_PRM"))
                        .withOrginalPolicyNumber(resultSet.getString("PTRI_POL_NR_CONV"))
                        .withTransactionTimestamp(resultSet.getTimestamp("PTRI_TRANSACT_TMST"))
                        .withConversionPremium(resultSet.getDouble("PTRI_CONV_PRM"));
                
                // Add intermediary data
                ResultSet rs = null;
                PreparedStatement ps = null;
                List<IntermediaryInfo> intermediaries = new ArrayList<IntermediaryInfo>();
                try {
                    ps = ServerContext.getJDBCHandle().prepareStatement(getSQLForPreTranInt());
                    ps.setLong(1, preTranRefId);

                    rs = ps.executeQuery();
                    while (rs.next()) {

                        intermediaries.add(new IntermediaryInfoBuilder().withIntermediaryNumber(rs.getLong("PTIN_INTM_NR"))
                                .withSalesCommissionSplitPercentage(rs.getDouble("PTIN_SLS_SPLT_PCT"))
                                .withServiceCommissionSplitPercentage(rs.getDouble("PTIN_SRV_SPLT_PCT"))
                                .withApplicationNumber(rs.getLong("PTIN_APP_NR")).withManCode(rs.getInt("PTIN_MAN_CD"))
                                .withFundCommissionSplitPercentage(rs.getDouble("PTIN_FUND_SPLT_PCT")).build());
                    }
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                    throw sqle;
                } finally {
                    if (rs != null) {
                        rs.close();
                    }
                    if (ps != null) {
                        ps.close();
                    }
                }
                LOG.info("Commission Event generated from PTRI_PRE_TRAN");
                commissionEvents.add(commissionEventBuilder.setIntermediarys(intermediaries).build());
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw sqle;
        }
        return commissionEvents;
    }
}

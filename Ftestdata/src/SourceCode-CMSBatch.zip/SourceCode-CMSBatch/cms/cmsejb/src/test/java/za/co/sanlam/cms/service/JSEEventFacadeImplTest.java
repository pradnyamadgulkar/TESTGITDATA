package za.co.sanlam.cms.service;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.naming.NamingException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.IntegrationTest;
import za.co.sanlam.cms.util.db.DatabaseInitializer;
@Ignore
@Category(IntegrationTest.class)
public class JSEEventFacadeImplTest {
    CommissionEvent commissionEvent;
    IntermediaryInfo intermediaryInfo;
    RetroVATEvent retroVATEvent;

    private static EventFacade facade;
    private static DatabaseInitializer databaseInitializer;

    @BeforeClass
    public static void setUp() throws IOException, NamingException, Exception {
        databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
       databaseInitializer.initialize();
        facade = (EventFacade) BeanLocator.locateBean("eventFacade");
    }

    @Test
    public void testHandleEventsCommissionEvent() throws IllegalArgumentException, IllegalAccessException,
            InvocationTargetException, Exception {
        populateCommissionEventFromPreTran(11662257L);
        facade.handleEvents(commissionEvent);

       populateCommissionEventFromPreTran(14284792L);
       commissionEvent.setEventType(122);
       facade.handleEvents(commissionEvent);
    }

    ///@Test
    public void _testHandleEventsRetroVATEvent() throws IllegalArgumentException, IllegalAccessException,
            InvocationTargetException {
        populateRetroVATEvent();
        facade.handleEvents(retroVATEvent);
    }

    ///@Test
    public void _testHandleEventsCommissionEvent209() {
        // NUB
        String policyNumber = "0001";
        facade.handleEvents(new CommissionEventBuilder().withPolicyNumber(policyNumber).withProductType("R19C")
                .withProductNameCode("R19C").build());

        // Preferred Underwriting Discount
        facade.handleEvents(new CommissionEventBuilder().withPolicyNumber(policyNumber).withProductType("R19C")
                .withProductNameCode("R19C").withEventType(209).build());
    }
    
    //@Test
    public void _testInValidLamdaEvent() {
        facade.handleEvents(new CommissionEventBuilder().withProductType("").withPremiumReductionPercentage(10.00).withEventType(5).withPolicyNumber("invalid002").build());
    }
    
    private void populateCommissionEvent() throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
        commissionEvent = new CommissionEventBuilder().build();
    }
    
    @SuppressWarnings("unused")
    private void populateCommissionEventFromLamdaXmlInfo(long lamdaTranRefId) throws Exception {
        commissionEvent = new CommissionEventGenerator().generateCommissionEventFromLamdaXmlInfo(lamdaTranRefId);
    }
    
    @SuppressWarnings("unused")
    private void populateCommissionEventFromPreTran(long preTranRefId) throws Exception {
        commissionEvent = new CommissionEventGenerator().generateCommissionEventFromPreTran(preTranRefId);
    }

    @SuppressWarnings("unused")
    private List<CommissionEvent> populateCommissionEventFromPreTran(String policyNumber) throws Exception {
        return new CommissionEventGenerator().generateCommissionEventFromPreTran(policyNumber);
    }
    
    private void populateRetroVATEvent() {
        retroVATEvent = new RetroVATEvent();
        Calendar defaultCalendar = Calendar.getInstance();
        defaultCalendar.set(2012, 01, 01);
        retroVATEvent.setTransactionTimestamp(new Timestamp(System.currentTimeMillis()));
        retroVATEvent.setIntermediaryNumber(177);
        retroVATEvent.setVatStatus(1);
        retroVATEvent.setEventEffectiveDate(defaultCalendar.getTime());
        retroVATEvent.setEventType(602);
    }
}

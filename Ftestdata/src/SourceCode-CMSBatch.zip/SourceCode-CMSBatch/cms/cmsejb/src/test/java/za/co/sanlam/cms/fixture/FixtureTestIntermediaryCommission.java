/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for INCI_INTM_COMM table.
 */
public class FixtureTestIntermediaryCommission extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestIntermediaryCommission.class);

    private long intermediaryCommissionId;
    private long intermediaryCommId;
    private String policyNumber;
    private long masterEventId;
    private int eventType;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private long splitCommissionId;
    private String commissionSplitPercentage;
    private String commissionAmountMonthly;
    private String commissionAmountMon;
    private int scheduleType;
    private long applicationNumber;
    private int manCode;
    private int manCd;
    private int contractCode;
    private int cntrCd;
    private long eventInProcessId;
    private long eipId;
    private int intermediaryCommissionStatus;
    private String statusEndDate;
    private String originalCommissionSplit;
    private String orgCommissionSplit;
    private int intermediaryCommissionVer;

    public FixtureTestIntermediaryCommission() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestIntermediaryCommInfo.execute()");
        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setIntermediaryCommissionId(getResultSet().getLong("INCI_INTM_COMM_ID"));
            setPolicyNumber(getResultSet().getString("INCI_POL_NR"));
            setMasterEventId(getResultSet().getLong("INCI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("INCI_EVT_TYP"));
            setElementNumber(getResultSet().getInt("INCI_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("INCI_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("INCI_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getLong("INCI_SPLT_COMM_ID"));
            setCommissionSplitPercentage(getResultSet().getDouble("INCI_COMM_SPLT_PCT"));
            setCommissionAmountMonthly(getResultSet().getDouble("INCI_COMM_AMT_MON"));
            setScheduleType(getResultSet().getInt("INCI_SCHD_TYP"));
            setApplicationNumber(getResultSet().getLong("INCI_APP_NR"));
            setManCode(getResultSet().getInt("INCI_MAN_CD"));
            setContractCode(getResultSet().getInt("INCI_CNTR_CD"));
            setEventInProcessId(getResultSet().getLong("INCI_EIP_ID"));
            setIntermediaryCommissionStatus(getResultSet().getInt("INCI_INTM_COMM_STS"));
            setStatusEndDate(format(getResultSet().getDate("INCI_STS_END_DT")));
            setOriginalCommissionSplit(getResultSet().getDouble("INCI_ORG_COMM_SPLT"));
            setCreatedBy(getResultSet().getString("INCI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("INCI_UPD_BY").trim());
            setVersion(getResultSet().getInt("INCI_INTM_COMM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setIntermediaryCommId(intermediaryCommissionId());
            setCommissionAmountMon(Double.valueOf(commissionAmountMonthly()));
            setManCd(manCode());
            setCntrCd(contractCode());
            setEipId(eventInProcessId());
            setOrgCommissionSplit(getResultSet().getDouble("INCI_ORG_COMM_SPLT"));
            setIntermediaryCommissionVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestIntermediaryCommInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestIntermediaryCommInfo", se);
            }
        }
    }

    /**
     * @return the intermediaryCommissionId
     */
    public long intermediaryCommissionId() {
        return intermediaryCommissionId;
    }

    /**
     * @param intermediaryCommissionId
     *            the intermediaryCommissionId to set
     */
    public void setIntermediaryCommissionId(long intermediaryCommissionId) {
        this.intermediaryCommissionId = intermediaryCommissionId;
    }

    /**
     * @return the commissionAmountMonthly
     */
    public String commissionAmountMonthly() {
        return formatDouble(commissionAmountMonthly);
    }

    /**
     * @param commissionAmountMonthly
     *            the commissionAmountMonthly to set
     */
    public void setCommissionAmountMonthly(double commissionAmountMonthly) {
        this.commissionAmountMonthly = String.valueOf(commissionAmountMonthly);
    }

    /**
     * @return the manCode
     */
    public int manCode() {
        return manCode;
    }

    /**
     * @param manCode
     *            the manCode to set
     */
    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    /**
     * @return the contractCode
     */
    public int contractCode() {
        return contractCode;
    }

    /**
     * @param contractCode
     *            the contractCode to set
     */
    public void setContractCode(int contractCode) {
        this.contractCode = contractCode;
    }

    /**
     * @return the originalCommissionSplit
     */
    public String originalCommissionSplit() {
        return formatDouble(originalCommissionSplit);
    }

    /**
     * @param originalCommissionSplit
     *            the originalCommissionSplit to set
     */
    public void setOriginalCommissionSplit(double originalCommissionSplit) {
        this.originalCommissionSplit = String.valueOf(originalCommissionSplit);
    }

    /**
     * @return the eventInProcessId
     */
    public long eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    /**
     * @return the eventType
     */
    public int getEventType() {
        return eventType;
    }

    @Deprecated
    public long intermediaryCommId() {
        return intermediaryCommId;
    }

    @Deprecated
    public void setIntermediaryCommId(long intermediaryCommId) {
        this.intermediaryCommId = intermediaryCommId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public long splitCommissionId() {
        return splitCommissionId;
    }

    public void setSplitCommissionId(long splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    public String commissionSplitPercentage() {
        return formatDouble(commissionSplitPercentage);
    }

    public void setCommissionSplitPercentage(double commissionSplitPercentage) {
        this.commissionSplitPercentage = Double.toString(commissionSplitPercentage);
    }

    @Deprecated
    public String commissionAmountMon() {
        if (commissionAmountMon != null) {
            if (BigDecimal.valueOf(Double.parseDouble(commissionAmountMon)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(commissionAmountMon).intValue());
            }
        }
        return commissionAmountMon;
    }

    @Deprecated
    public void setCommissionAmountMon(double commissionAmountMon) {
        this.commissionAmountMon = Double.toString(commissionAmountMon);
    }

    public int scheduleType() {
        return scheduleType;
    }

    public void setScheduleType(int scheduleType) {
        this.scheduleType = scheduleType;
    }

    public long applicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(long applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    @Deprecated
    public int manCd() {
        return manCd;
    }

    @Deprecated
    public void setManCd(int manCd) {
        this.manCd = manCd;
    }

    @Deprecated
    public int cntrCd() {
        return cntrCd;
    }

    @Deprecated
    public void setCntrCd(int cntrCd) {
        this.cntrCd = cntrCd;
    }

    @Deprecated
    public long eipId() {
        return eipId;
    }

    @Deprecated
    public void setEipId(long eipId) {
        this.eipId = eipId;
    }

    public int intermediaryCommissionStatus() {
        return intermediaryCommissionStatus;
    }

    public void setIntermediaryCommissionStatus(int intermediaryCommissionStatus) {
        this.intermediaryCommissionStatus = intermediaryCommissionStatus;
    }

    public String statusEndDate() {
        return statusEndDate;
    }

    public void setStatusEndDate(String string) {
        this.statusEndDate = string;
    }

    @Deprecated
    public String orgCommissionSplit() {
        if (orgCommissionSplit != null) {
            if (BigDecimal.valueOf(Double.parseDouble(orgCommissionSplit)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(orgCommissionSplit).intValue());
            }
        }
        return orgCommissionSplit;
    }

    @Deprecated
    public void setOrgCommissionSplit(double orgCommissionSplit) {
        this.orgCommissionSplit = Double.toString(orgCommissionSplit);
    }

    @Deprecated
    public int intermediaryCommissionVer() {
        return intermediaryCommissionVer;
    }

    @Deprecated
    public void setIntermediaryCommissionVer(int intermediaryCommissionVer) {
        this.intermediaryCommissionVer = intermediaryCommissionVer;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT INCI_INTM_COMM_ID,INCI_POL_NR,INCI_MSTR_EVT_ID,"
                    + "INCI_EVT_TYP, INCI_ELMT_NR,INCI_INTM_NR, INCI_SPLT_COMM_TYP, INCI_SPLT_COMM_ID, "
                    + "INCI_COMM_SPLT_PCT, INCI_COMM_AMT_MON,INCI_SCHD_TYP, INCI_APP_NR, INCI_MAN_CD, "
                    + "INCI_CNTR_CD, INCI_EIP_ID,INCI_INTM_COMM_STS, INCI_STS_END_DT, INCI_ORG_COMM_SPLT, "
                    + "INCI_CRTD_BY, INCI_UPD_BY,INCI_INTM_COMM_VER, DM_LSTUPDDT FROM {0}INCI_INTM_COMM "
                    + "ORDER BY  INCI_MSTR_EVT_ID, INCI_ELMT_NR, INCI_INTM_NR, INCI_SPLT_COMM_TYP,  INCI_SPLT_COMM_ID FOR FETCH ONLY WITH UR");

    // order by INCI_MSTR_EVT_ID, INCI_ELMT_NR, INCI_EIP_ID, INCI_SPLT_COMM_TYP,
    // INCI_INTM_NR, INCI_CNTR_CD FOR FETCH ONLY WITH UR"
}

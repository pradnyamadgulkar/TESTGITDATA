/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PMHS_PMT_HST table.
 */
public class FixtureTestPaymentHistory extends FixtureTestKomEvents {

    private static Logger LOG = LoggerFactory.getLogger(FixtureTestPaymentHistory.class);

    private long paymentId;
    private int vatIndicator;
    private long vatRefId;
    private long vatReferenceId;
    private int paymentHstryInfoVer;

    public FixtureTestPaymentHistory() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setPaymentId(getResultSet().getLong("PMHS_PMT_ID"));
            setVatIndicator(getResultSet().getInt("PMHS_VAT_IND"));
            setVatReferenceId(getResultSet().getLong("PMHS_VAT_REF_ID"));
            setCreatedBy(getResultSet().getString("PMHS_CRTD_BY").trim());
            setVersion(getResultSet().getInt("PMHS_PMT_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setVatRefId(getResultSet().getLong("PMHS_VAT_REF_ID"));
            setPaymentHstryInfoVer(getResultSet().getInt("PMHS_PMT_HST_VER"));
        } catch (SQLException ex1) {
            LOG.error("Exception encountered in operation execute of class FixtureTestPaymentHistory", ex1);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestPaymentHistory", se);
            }
        }
    }

    public long paymentId() {
        return paymentId;
    }

    public void setPaymentId(long paymentId) {
        this.paymentId = paymentId;
    }

    @Deprecated
    public long vatRefId() {
        return vatRefId;
    }

    @Deprecated
    public void setVatRefId(long vatRefId) {
        this.vatRefId = vatRefId;
    }

    @Deprecated
    public int paymentHstryInfoVer() {
        return paymentHstryInfoVer;
    }

    @Deprecated
    public void setPaymentHstryInfoVer(int paymentHstryInfoVer) {
        this.paymentHstryInfoVer = paymentHstryInfoVer;
    }

    public int vatIndicator() {
        return vatIndicator;
    }

    public void setVatIndicator(int vatIndicator) {
        this.vatIndicator = vatIndicator;
    }

    /**
     * @return the vatReferenceId
     */
    public long vatReferenceId() {
        return vatReferenceId;
    }

    /**
     * @param vatReferenceId
     *            the vatReferenceId to set
     */
    public void setVatReferenceId(long vatReferenceId) {
        this.vatReferenceId = vatReferenceId;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer("SELECT PMHS_PMT_ID,PMHS_VAT_IND,PMHS_VAT_REF_ID,"
            + "PMHS_CRTD_BY,PMHS_PMT_HST_VER,DM_LSTUPDDT from {0}PMHS_PMT_HST ORDER BY PMHS_PMT_ID FOR FETCH ONLY WITH UR");

}

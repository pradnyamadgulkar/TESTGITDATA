package za.co.sanlam.cms.service;

import java.sql.Timestamp;
import java.util.Date;

public class RetroVATEvent {

	private int eventType;
	private int intermediaryNumber;
	private Date eventEffectiveDate;
	private Timestamp transactionTimestamp;
	private int vatStatus;
	
	public int getEventType() {
		return eventType;
	}
	public void setEventType(int eventType) {
		this.eventType = eventType;
	}
	public int getIntermediaryNumber() {
		return intermediaryNumber;
	}
	public void setIntermediaryNumber(int intermediaryNumber) {
		this.intermediaryNumber = intermediaryNumber;
	}
	public Date getEventEffectiveDate() {
		return eventEffectiveDate;
	}
	public void setEventEffectiveDate(Date eventEffectiveDate) {
		this.eventEffectiveDate = eventEffectiveDate;
	}
	public Timestamp getTransactionTimestamp() {
		return transactionTimestamp;
	}
	public void setTransactionTimestamp(Timestamp transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
	}
	public int getVatStatus() {
		return vatStatus;
	}
	public void setVatStatus(int vatStatus) {
		this.vatStatus = vatStatus;
	}
	
	
}

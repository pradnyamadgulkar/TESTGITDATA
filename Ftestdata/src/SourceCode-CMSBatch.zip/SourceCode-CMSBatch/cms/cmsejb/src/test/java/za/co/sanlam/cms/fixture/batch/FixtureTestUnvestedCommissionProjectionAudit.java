package za.co.sanlam.cms.fixture.batch;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

import com.tcs.mastercraft.mctype.ServerContext;

public class FixtureTestUnvestedCommissionProjectionAudit extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestUnvestedCommissionProjectionAudit.class);

    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    private int rowNumber;

    private long auditId;
    private String cgePolicyNumber;
    private String unvestedCommissionPolicyNumber;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestProjectionUnvestedCommAudit.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet(resultSet)) {
                return;
            }
            LOGGER.debug("execute" + rowNumber);
            resultSet.absolute(rowNumber);
            setAuditId(resultSet.getLong("PUCA_AUDIT_ID"));
            setCgePolicyNumber(resultSet.getString("PUCA_CGEI_POL_NR"));
            setUnvestedCommissionPolicyNumber(resultSet.getString("PUCA_PUCD_POL_NR"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestProjectionUnvestedCommAudit", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestProjectionUnvestedCommAudit", se);
            }
        }
    }

    private void initialize() throws SQLException {
        LOGGER.debug("Setting info for Active Policies" + ServerContext.getSchemaName());
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("PUCA_AUDIT_ID, PUCA_CGEI_POL_NR, PUCA_PUCD_POL_NR ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("PUCA_UVST_AUD ");
        sqlStatement.append("ORDER BY PUCA_AUDIT_ID ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");
        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestProjectionUnvestedCommAudit", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public long auditId() {
        return auditId;
    }

    public void setAuditId(long auditId) {
        this.auditId = auditId;
    }

    public String cgePolicyNumber() {
        return cgePolicyNumber;
    }

    public void setCgePolicyNumber(String cgePolicyNumber) {
        this.cgePolicyNumber = cgePolicyNumber;
    }

    public String unvestedCommissionPolicyNumber() {
        return unvestedCommissionPolicyNumber;
    }

    public void setUnvestedCommissionPolicyNumber(String unvestedCommissionPolicyNumber) {
        this.unvestedCommissionPolicyNumber = unvestedCommissionPolicyNumber;
    }
}

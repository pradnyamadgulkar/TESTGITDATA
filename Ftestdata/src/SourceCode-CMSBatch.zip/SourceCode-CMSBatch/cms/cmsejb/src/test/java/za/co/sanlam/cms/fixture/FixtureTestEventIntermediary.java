/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for EVII_EVT_INTM table.
 */
public class FixtureTestEventIntermediary extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestEventIntermediary.class);

    private long masterEventId;
    private long intermediaryNumber;
    private int eventType;
    private String commissionSplitPercentage;
    private String splitCommissionType;
    private int applicationNumber;
    private int manCode;
    private int contractCode;

    private int eventIntdInfoVer;
    private String commissionSplitPerctg;
    private String splitCommType;
    private int contrctCode;

    public FixtureTestEventIntermediary() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("EVII_MSTR_EVT_ID"));
            setIntermediaryNumber(getResultSet().getLong("EVII_INTM_NR"));
            setEventType(getResultSet().getInt("EVII_EVT_TYP"));
            setCommissionSplitPercentage(getResultSet().getDouble("EVII_COMM_SPLT_PCT"));
            setSplitCommissionType(getResultSet().getString("EVII_SPLT_COMM_TYP").trim());
            setApplicationNumber(getResultSet().getInt("EVII_APP_NR"));
            setManCode(getResultSet().getInt("EVII_MAN_CD"));
            setContractCode(getResultSet().getInt("EVII_CNTR_CD"));
            setCreatedBy(getResultSet().getString("EVII_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("EVII_UPD_BY").trim());
            setVersion(getResultSet().getInt("EVII_EVT_INTM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setCommissionSplitPerctg(Double.parseDouble(commissionSplitPercentage()));
            setSplitCommType(splitCommissionType());
            setContrctCode(contractCode());
            setEventIntdInfoVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestEventIntermediaryInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestEventIntermediaryInfo", se);
            }
        }
    }

    /**
     * @return the commissionSplitPercetage
     */
    public String commissionSplitPercentage() {
        return formatDouble(commissionSplitPercentage);
    }

    /**
     * @param commissionSplitPercetage
     *            the commissionSplitPercetage to set
     */
    public void setCommissionSplitPercentage(double commissionSplitPercentage) {
        this.commissionSplitPercentage = String.valueOf(commissionSplitPercentage);
    }

    /**
     * @return the splitCommissionType
     */
    public String splitCommissionType() {
        return splitCommissionType;
    }

    /**
     * @param splitCommissionType
     *            the splitCommissionType to set
     */
    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    /**
     * @return the contractCode
     */
    public int contractCode() {
        return contractCode;
    }

    /**
     * @param contractCode
     *            the contractCode to set
     */
    public void setContractCode(int contractCode) {
        this.contractCode = contractCode;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    @Deprecated
    public String commissionSplitPerctg() {
        if (commissionSplitPerctg != null) {
            if (BigDecimal.valueOf(Double.parseDouble(commissionSplitPerctg)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(commissionSplitPerctg).intValue());
            }
        }
        return commissionSplitPerctg;
    }

    @Deprecated
    public void setCommissionSplitPerctg(double commissionSplitPerctg) {
        this.commissionSplitPerctg = Double.toString(commissionSplitPerctg);
    }

    @Deprecated
    public String splitCommType() {
        return splitCommType;
    }

    @Deprecated
    public void setSplitCommType(String splitCommType) {
        this.splitCommType = splitCommType;
    }

    public int applicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(int applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    public int manCode() {
        return manCode;
    }

    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    @Deprecated
    public int contrctCode() {
        return contrctCode;
    }

    @Deprecated
    public void setContrctCode(int contrctCode) {
        this.contrctCode = contrctCode;
    }

    @Deprecated
    public int eventIntdInfoVer() {
        return eventIntdInfoVer;
    }

    @Deprecated
    public void setEventIntdInfoVer(int eventIntdInfoVer) {
        this.eventIntdInfoVer = eventIntdInfoVer;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT EVII_MSTR_EVT_ID, EVII_INTM_NR, EVII_EVT_TYP, EVII_COMM_SPLT_PCT, "
                    + "EVII_SPLT_COMM_TYP, EVII_APP_NR, EVII_MAN_CD, EVII_CNTR_CD, EVII_CRTD_BY, EVII_UPD_BY, "
                    + "EVII_EVT_INTM_VER, DM_LSTUPDDT from {0}EVII_EVT_INTM ORDER BY EVII_MSTR_EVT_ID, EVII_INTM_NR, EVII_CNTR_CD, EVII_SPLT_COMM_TYP FOR FETCH ONLY WITH UR");

}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for BEM_LAMDA_XML_INT_INFO table.
 */
public class FixtureTestLamdaXmlIntermediaryInfo extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestLamdaXmlIntermediaryInfo.class);

    private long lamdaIntermediaryReferenceId;
    private long lamdaTransactionReferenceId;
    private long intermediaryNumber;
    private String applicationNumber;
    private int manCode;
    private String salesCommissionSplitPercentage;
    private String serviceCommissionSplitPercentage;
    private String fundCommissionSplitPercentage;
    private String extractDate;

    public FixtureTestLamdaXmlIntermediaryInfo() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setLamdaIntermediaryReferenceId(getResultSet().getLong("LAMDA_INT_REF_ID"));
            setLamdaTransactionReferenceId(getResultSet().getLong("LAMDA_TRANS_REF_ID"));
            setIntermediaryNumber(getResultSet().getLong("INTERMEDIARY_NO"));
            setApplicationNumber(getResultSet().getDouble("APP_IN_NO"));
            setManCode(getResultSet().getInt("MAN_CODE"));
            setSalesCommissionSplitPercenatge(getResultSet().getDouble("SALES_COMM_SPLIT_PCT"));
            setServiceCommissionSplitPercentage(getResultSet().getDouble("SERVICE_COMM_SPLIT_PCT"));
            setFundCommissionSplitPercentage(getResultSet().getDouble("FUND_COMM_SPLIT_PCT"));
            setCreatedBy(getResultSet().getString("CREATED_BY"));
            setUpdatedBy(getResultSet().getString("UPDATE_BY"));
            setVersion(getResultSet().getInt("TRAN_VER"));
            setExtractDate(format(getResultSet().getDate("EXTRACT_DATE")));

        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestLamdaXmlIntermediaryInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestLamdaXmlIntermediaryInfo", se);
            }
        }
    }

    /**
     * @return the lamdaIntermediaryReferenceId
     */
    public long lamdaIntermediaryReferenceId() {
        return lamdaIntermediaryReferenceId;
    }

    /**
     * @param lamdaIntermediaryReferenceId
     *            the lamdaIntermediaryReferenceId to set
     */
    public void setLamdaIntermediaryReferenceId(long lamdaIntermediaryReferenceId) {
        this.lamdaIntermediaryReferenceId = lamdaIntermediaryReferenceId;
    }

    /**
     * @return the lamdaTransactionReferenceId
     */
    public long lamdaTransactionReferenceId() {
        return lamdaTransactionReferenceId;
    }

    /**
     * @param lamdaTransactionReferenceId
     *            the lamdaTransactionReferenceId to set
     */
    public void setLamdaTransactionReferenceId(long lamdaTransactionReferenceId) {
        this.lamdaTransactionReferenceId = lamdaTransactionReferenceId;
    }

    /**
     * @return the intermediaryNumber
     */
    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    /**
     * @param intermediaryNumber
     *            the intermediaryNumber to set
     */
    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    /**
     * @return the applicationNumber
     */
    public String applicationNumber() {
        return applicationNumber;
    }

    /**
     * @param applicationNumber
     *            the applicationNumber to set
     */
    public void setApplicationNumber(double applicationNumber) {
        this.applicationNumber = String.valueOf(applicationNumber);
    }

    /**
     * @return the manCode
     */
    public int manCode() {
        return manCode;
    }

    /**
     * @param manCode
     *            the manCode to set
     */
    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    /**
     * @return the salesCommissionSplitPercenatge
     */
    public String salesCommissionSplitPercenatge() {
        return formatDouble(salesCommissionSplitPercentage);
    }

    /**
     * @param salesCommissionSplitPercenatge
     *            the salesCommissionSplitPercenatge to set
     */
    public void setSalesCommissionSplitPercenatge(double salesCommissionSplitPercenatge) {
        this.salesCommissionSplitPercentage = String.valueOf(salesCommissionSplitPercenatge);
    }

    /**
     * @return the serviceCommissionSplitPercenatge
     */
    public String serviceCommissionSplitPercentage() {
        return formatDouble(serviceCommissionSplitPercentage);
    }

    /**
     * @param serviceCommissionSplitPercenatge
     *            the serviceCommissionSplitPercenatge to set
     */
    public void setServiceCommissionSplitPercentage(double serviceCommissionSplitPercentage) {
        this.serviceCommissionSplitPercentage = String.valueOf(serviceCommissionSplitPercentage);
    }

    /**
     * @return the fundCommissionSplitPercentage
     */
    public String fundCommissionSplitPercentage() {
        return formatDouble(fundCommissionSplitPercentage);
    }

    /**
     * @param fundCommissionSplitPercentage
     *            the fundCommissionSplitPercentage to set
     */
    public void setFundCommissionSplitPercentage(double fundCommissionSplitPercentage) {
        this.fundCommissionSplitPercentage = String.valueOf(fundCommissionSplitPercentage);
    }

    /**
     * @return the extractDate
     */
    public String extractDate() {
        return extractDate;
    }

    /**
     * @param extractDate
     *            the extractDate to set
     */
    public void setExtractDate(String extractDate) {
        this.extractDate = extractDate;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT LAMDA_INT_REF_ID, LAMDA_TRANS_REF_ID, INTERMEDIARY_NO, APP_IN_NO, MAN_CODE, SALES_COMM_SPLIT_PCT, "
                    + "SERVICE_COMM_SPLIT_PCT, FUND_COMM_SPLIT_PCT, CREATED_BY, UPDATE_BY,CREATE_TIME_ST, UPDATE_TIME_ST,"
                    + "TRAN_VER, EXTRACT_DATE FROM {0}BEM_LAMDA_XML_INT_INFO ORDER BY LAMDA_INT_REF_ID FOR FETCH ONLY WITH UR");
}

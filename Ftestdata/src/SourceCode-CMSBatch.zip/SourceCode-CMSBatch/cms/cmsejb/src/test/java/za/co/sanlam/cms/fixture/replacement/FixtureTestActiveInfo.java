package za.co.sanlam.cms.fixture.replacement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

import com.tcs.mastercraft.mctype.ServerContext;

public class FixtureTestActiveInfo extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestActiveInfo.class);

    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    private int rowNumber;
    private long activeId;
    private String policyNumber;
    private String cgeDate;
    private String commissionType;
    private int recordType;
    private int directIndicator;
    private int replacementType;
    private int rparIndicator;
    private String replacementDate;
    private String productType;
    private int applyIndicator;
    private String clientName;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestActiveInfo.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet(resultSet)) {
                return;
            }
            LOGGER.debug("execute" + rowNumber);
            resultSet.absolute(rowNumber);
            setActiveId(resultSet.getLong("RPAI_ACTV_ID"));
            setPolicyNumber(resultSet.getString("RPAI_POL_NR").trim());
            setCgeDate(dateFormatter.format(resultSet.getDate("RPAI_CGE_DATE")));
            setCommissionType(resultSet.getString("RPAI_COMM_TYPE").trim());
            setRecordType(resultSet.getInt("RPAI_REC_TYPE"));
            setDirectIndicator(resultSet.getInt("RPAI_DIR_IND"));
            setReplacementType(resultSet.getInt("RPAI_REPL_TYPE"));
            setRparIndicator(resultSet.getInt("RPAI_RPAR_IND"));
            setReplacementDate(dateFormatter.format(resultSet.getDate("RPAI_REPL_DATE")));
            setProductType(resultSet.getString("RPAI_PRD_TYPE"));
            setApplyIndicator(resultSet.getInt("RPAI_APPLY_IND"));
            setClientName(resultSet.getString("RPAI_CLT_NAME"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestActiveInfo", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestActiveInfo", se);
            }
        }
    }

    private void initialize() throws SQLException {
        LOGGER.debug("Setting info for Active Policies" + ServerContext.getSchemaName());
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("RPAI_ACTV_ID, RPAI_POL_NR, RPAI_CGE_DATE,  RPAI_COMM_TYPE, RPAI_REC_TYPE, RPAI_DIR_IND, ");
        sqlStatement.append("RPAI_REPL_TYPE, RPAI_RPAR_IND, RPAI_REPL_DATE, RPAI_PRD_TYPE, RPAI_APPLY_IND, RPAI_CLT_NAME ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("RPAI_ACTV_INFO ");
        sqlStatement.append("ORDER BY RPAI_ACTV_ID, RPAI_POL_NR, RPAI_CGE_DATE, RPAI_COMM_TYPE ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");
        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestActiveInfo", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public long activeId() {
        return activeId;
    }

    public void setActiveId(long activeId) {
        this.activeId = activeId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String cgeDate() {
        return cgeDate;
    }

    public void setCgeDate(String cgeDate) {
        this.cgeDate = cgeDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public int recordType() {
        return recordType;
    }

    public void setRecordType(int recordType) {
        this.recordType = recordType;
    }

    public int directIndicator() {
        return directIndicator;
    }

    public void setDirectIndicator(int directIndicator) {
        this.directIndicator = directIndicator;
    }

    public int replacementType() {
        return replacementType;
    }

    public void setReplacementType(int replacementType) {
        this.replacementType = replacementType;
    }

    public int rparIndicator() {
        return rparIndicator;
    }

    public void setRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
    }

    public String replacementDate() {
        return replacementDate;
    }

    public void setReplacementDate(String replacementDate) {
        this.replacementDate = replacementDate;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int applyIndicator() {
        return applyIndicator;
    }

    public void setApplyIndicator(int applyIndicator) {
        this.applyIndicator = applyIndicator;
    }

    public String clientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }
}

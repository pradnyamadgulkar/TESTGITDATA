/**
 * Public service interfaces of the CMS application
 * 
 * @author brendan
 *
 */
package za.co.sanlam.cms.service;
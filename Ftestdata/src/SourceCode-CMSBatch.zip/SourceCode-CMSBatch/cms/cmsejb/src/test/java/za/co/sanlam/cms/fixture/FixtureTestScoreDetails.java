/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for SCDT_SCR_DTLS table.
 */
public class FixtureTestScoreDetails extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestScoreDetails.class);

    private long intermediaryScoreId;
    private String policyNumber;
    private long masterEventId;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private long splitCommissionId;
    private String scorePremium;
    private String policyCount;
    private String totalScorePremium;
    private String clawbackSp;
    private String clawbackPc;
    private String clawbackTsp;
    private String scoreSplitPercentage;
    private long eventInProcessId;
    private int scoreStatus;
    private int tspTerm;

    private long scoreIntmId;
    private long intmNumber;
    private String policyCounter;
    private String splitPercentage;
    private long eipId;
    private int scoreDetailsVer;

    public FixtureTestScoreDetails() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestScore.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setIntermediaryScoreId(getResultSet().getLong("SCDT_INTM_SCR_ID"));
            setPolicyNumber(getResultSet().getString("SCDT_POL_NR"));
            setMasterEventId(getResultSet().getLong("SCDT_MSTR_EVT_ID"));
            setElementNumber(getResultSet().getInt("SCDT_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("SCDT_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("SCDT_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getLong("SCDT_SPLT_COMM_ID"));
            setScorePremium(getResultSet().getDouble("SCDT_SCR_PRM"));
            setPolicyCount(getResultSet().getDouble("SCDT_POL_CNT"));
            setTotalScorePremium(getResultSet().getDouble("SCDT_TOT_SCR_PRM"));
            setClawbackSp(getResultSet().getDouble("SCDT_CLBK_SP"));
            setClawbackPc(getResultSet().getDouble("SCDT_CLBK_PC"));
            setClawbackTsp(getResultSet().getDouble("SCDT_CLBK_TSP"));
            setScoreSplitPercentage(getResultSet().getDouble("SCDT_SCR_SPLT_PCT"));
            setEventInProcessId(getResultSet().getLong("SCDT_EIP_ID"));
            setScoreStatus(getResultSet().getInt("SCDT_SCR_STS"));
            setTspTerm(getResultSet().getInt("SCDT_TSP_TRM"));
            setCreatedBy(getResultSet().getString("SCDT_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("SCDT_UPD_BY").trim());
            setVersion(getResultSet().getInt("SCDT_SCR_DTLS_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setScoreIntmId(intermediaryScoreId());
            setIntmNumber(intermediaryNumber());
            setPolicyCounter(Double.parseDouble(policyCount()));
            setSplitPercentage(Double.parseDouble(scoreSplitPercentage()));
            setEipId(eventInProcessId());
            setScoreDetailsVer(version());
        } catch (SQLException sqle) {
            LOG.error("Exception encountered in operation execute of class FixtureTestScore", sqle);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestScore", se);
            }
        }
    }

    /**
     * @return the intermediaryScoreId
     */
    public long intermediaryScoreId() {
        return intermediaryScoreId;
    }

    /**
     * @param intermediaryScoreId
     *            the intermediaryScoreId to set
     */
    public void setIntermediaryScoreId(long intermediaryScoreId) {
        this.intermediaryScoreId = intermediaryScoreId;
    }

    /**
     * @return the intermediaryNumber
     */
    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    /**
     * @param intermediaryNumber
     *            the intermediaryNumber to set
     */
    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    /**
     * @return the policyCount
     */
    public String policyCount() {
        return formatDouble(policyCount);
    }

    /**
     * @param policyCount
     *            the policyCount to set
     */
    public void setPolicyCount(double policyCount) {
        this.policyCount = String.valueOf(policyCount);
    }

    /**
     * @return the scoreSplitPercentage
     */
    public String scoreSplitPercentage() {
        return formatDouble(scoreSplitPercentage);
    }

    /**
     * @param scoreSplitPercentage
     *            the scoreSplitPercentage to set
     */
    public void setScoreSplitPercentage(double scoreSplitPercentage) {
        this.scoreSplitPercentage = String.valueOf(scoreSplitPercentage);
    }

    /**
     * @return the eventInProcessId
     */
    public long eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    @Deprecated
    public int scoreDetailsVer() {
        return scoreDetailsVer;
    }

    @Deprecated
    public void setScoreDetailsVer(int scoreDetailsVer) {
        this.scoreDetailsVer = scoreDetailsVer;
    }

    public int tspTerm() {
        return tspTerm;
    }

    public void setTspTerm(int tspTerm) {
        this.tspTerm = tspTerm;
    }

    @Deprecated
    public long eipId() {
        return eipId;
    }

    @Deprecated
    public void setEipId(long eipId) {
        this.eipId = eipId;
    }

    @Deprecated
    public String splitPercentage() {
        return formatDouble(splitPercentage);
    }

    @Deprecated
    public void setSplitPercentage(double splitPercentage) {
        this.splitPercentage = Double.toString(splitPercentage);
    }

    public String scorePremium() {
        return formatDouble(scorePremium);
    }

    @Deprecated
    public void setScoreIntmId(long scoreIntmId) {
        this.scoreIntmId = scoreIntmId;
    }

    public int scoreStatus() {
        return scoreStatus;
    }

    public void setScoreStatus(int scoreStatus) {
        this.scoreStatus = scoreStatus;
    }

    public void setScorePremium(double scorePremium) {
        this.scorePremium = Double.toString(scorePremium);
    }

    @Deprecated
    public String policyCounter() {
        return formatDouble(policyCounter);
    }

    @Deprecated
    public void setPolicyCounter(double policyCounter) {
        this.policyCounter = Double.toString(policyCounter);
    }

    public String totalScorePremium() {
        return formatDouble(totalScorePremium);
    }

    public void setTotalScorePremium(double totalScorePremium) {
        this.totalScorePremium = Double.toString(totalScorePremium);
    }

    public String clawbackSp() {
        return formatDouble(clawbackSp);
    }

    public void setClawbackSp(double clawbackSp) {
        this.clawbackSp = Double.toString(clawbackSp);
    }

    public String clawbackTsp() {
        return formatDouble(clawbackTsp);
    }

    public void setClawbackTsp(double clawbackTsp) {
        this.clawbackTsp = Double.toString(clawbackTsp);
    }

    public String clawbackPc() {
        return formatDouble(clawbackPc);
    }

    public void setClawbackPc(double clawbackPc) {
        this.clawbackPc = Double.toString(clawbackPc);
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public long splitCommissionId() {
        return splitCommissionId;
    }

    public void setSplitCommissionId(long splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    @Deprecated
    public long scoreIntmId() {
        return scoreIntmId;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    @Deprecated
    public long intmNumber() {
        return intmNumber;
    }

    @Deprecated
    public void setIntmNumber(long intmNumber) {
        this.intmNumber = intmNumber;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT SCDT_INTM_SCR_ID, SCDT_POL_NR, SCDT_MSTR_EVT_ID,"
                    + "SCDT_ELMT_NR, SCDT_INTM_NR, SCDT_SPLT_COMM_TYP, SCDT_SPLT_COMM_ID, SCDT_SCR_PRM,"
                    + "SCDT_POL_CNT, SCDT_TOT_SCR_PRM, SCDT_CLBK_SP, SCDT_CLBK_PC, SCDT_CLBK_TSP,"
                    + "SCDT_SCR_SPLT_PCT, SCDT_EIP_ID, SCDT_SCR_STS, SCDT_TSP_TRM, SCDT_CRTD_BY,"
                    + "SCDT_UPD_BY, SCDT_SCR_DTLS_VER, DM_LSTUPDDT FROM "
                    // +
                    // "{0}SCDT_SCR_DTLS ORDER BY  SCDT_MSTR_EVT_ID,  SCDT_ELMT_NR, SCDT_EIP_ID, SCDT_INTM_NR, SCDT_SPLT_COMM_TYP, SCDT_INTM_SCR_ID FOR FETCH ONLY WITH UR");
                    + "{0}SCDT_SCR_DTLS ORDER BY  SCDT_MSTR_EVT_ID, SCDT_ELMT_NR, SCDT_INTM_NR, SCDT_SPLT_COMM_TYP, SCDT_SPLT_COMM_ID FOR FETCH ONLY WITH UR");
}

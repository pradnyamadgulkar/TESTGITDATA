/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.service.EventFacade;

import com.tcs.mastercraft.mctype.ServerContext;
/**
 * 
 * @author e928809
 *
 */
public abstract class FixtureTestKomEvents {

    protected static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
    protected static final SimpleDateFormat timestampFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    protected static final DecimalFormat decimalFormatter = new DecimalFormat("#0.0000");

    // ----
    private PreparedStatement pstmt = null;
    private ResultSet resultSet = null;

    private String createdBy;
    private String updatedBy;
    private String createdTimestamp;
    private String updatedTimestamp;
    private int version;
    private String lastUpdatedDate;

    private int rowNumber;

    private StringBuffer sqlQuery;
    
    public static final String NULL_STRING = "<null>";

    public void beginTable() throws SQLException {
        ((EventFacade) BeanLocator.locateBean("eventFacade")).initialize();

        if (getSqlQuery() != null) {
            initialize(getSqlQuery());
        }
    }

    public void reset() throws SQLException {
    }
    
    public abstract void execute();

    // -- Utility Methods --
    
    protected void cleanUp(ResultSet resultSet, PreparedStatement preparedStatement) throws SQLException {
        if (resultSet != null && !resultSet.isClosed() && resultSet.isLast()) {
            close(resultSet, preparedStatement);
        }
    }

    protected void cleanUp() throws SQLException {
        cleanUp(getResultSet(), getPstmt());
    }

    protected void close(ResultSet resultSet, PreparedStatement preparedStatement) throws SQLException {
        if (resultSet != null) {
            resultSet.close();
        }
        if (preparedStatement != null) {
            preparedStatement.close();
        }
    }

    protected void close() throws SQLException {
        close(getResultSet(), getPstmt());
    }

    protected boolean inValidResultSet(ResultSet resultSet) throws SQLException {
        return resultSet == null || resultSet.isClosed();
    }

    protected boolean inValidResultSet() throws SQLException {
        return inValidResultSet(getResultSet());
    }

    protected void setResultSetPosition() throws SQLException {
        getResultSet().absolute(rowNumber());
    }

    protected String format(Timestamp timestamp) {
        if (timestamp == null) {
            return NULL_STRING;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timestamp.getTime());
        return timestampFormatter.format(calendar.getTime());
    }

    protected String format(Date date) {
        if (date == null) {
            return NULL_STRING;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return dateFormatter.format(calendar.getTime());
    }

    protected String format(String value) {
        if (value == null) {
            return NULL_STRING;
        }
        return value.trim();
    }

    protected String formatDouble(String value) {
        if (value != null) {
            return decimalFormatter.format(Double.valueOf(value));
        } else {
            return format(value);
        }
    }

    
    protected String formatDouble(double value) {
        return format(String.valueOf(value));
    }
    // ----------------------
    protected void initialize(StringBuffer sqlQuery) throws SQLException {
        boolean foundData = false;
        try {
            pstmt = ServerContext.getJDBCHandle().prepareStatement(
                    MessageFormat.format(sqlQuery.toString(), new Object[] { ServerContext.getSchemaName() }),
                    ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = pstmt.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, pstmt);
            }
        }
    }

    // --------------

    public String createdBy() {
        return format(createdBy);
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String updatedBy() {
        return format(updatedBy);
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * @return the createdTimestamp
     */
    public String createdTimestamp() {
        return createdTimestamp;
    }

    /**
     * @param createdTimestamp
     *            the createdTimestamp to set
     */
    public void setCreatedTimestamp(String createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    /**
     * @return the updatedTimestamp
     */
    public String updatedTimestamp() {
        return updatedTimestamp;
    }

    /**
     * @param updatedTimestamp
     *            the updatedTimestamp to set
     */
    public void setUpdatedTimestamp(String updatedTimestamp) {
        this.updatedTimestamp = updatedTimestamp;
    }

    public int version() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String lastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    /**
     * @return the pstmt
     */
    public PreparedStatement getPstmt() {
        return pstmt;
    }

    /**
     * @param pstmt
     *            the pstmt to set
     */
    public void setPstmt(PreparedStatement pstmt) {
        this.pstmt = pstmt;
    }

    /**
     * @return the resultSet
     */
    public ResultSet getResultSet() {
        return resultSet;
    }

    /**
     * @param resultSet
     *            the resultSet to set
     */
    public void setResultSet(ResultSet resultSet) {
        this.resultSet = resultSet;
    }

    public int rowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    /**
     * @return the sqlQuery
     */
    public StringBuffer getSqlQuery() {
        return sqlQuery;
    }

    /**
     * @param sqlQuery
     *            the sqlQuery to set
     */
    public void setSqlQuery(StringBuffer sqlQuery) {
        this.sqlQuery = sqlQuery;
    }
}

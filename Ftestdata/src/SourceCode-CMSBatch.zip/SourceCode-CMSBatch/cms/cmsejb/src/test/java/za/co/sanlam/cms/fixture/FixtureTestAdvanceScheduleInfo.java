/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for ADSI_SCHD_INF table.
 */
public class FixtureTestAdvanceScheduleInfo extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestAdvanceScheduleInfo.class);

    private long scheduleId;
    private String policyNumber;
    private long masterEventId;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private String splitCommissionId;
    private int scheduleType;
    private String startDate;
    private String nextPaymentDate;
    private String endDate;
    private String commissionAmountMonthly;
    private String totalCommissionAmount;
    private String totalVatAmount;
    private int scheduleStatus;
    private String statusEndDate;
    private long eventInProcessId;
    private int indexEntitlementIndicator;
    private int taxGroupCode;
    private String firstPaymentDate;
    private int infoVer;
    private String ftcpProcessStatus;

    private String commissionAmntMonthly;
    private String totalCommissionAmnt;
    private int taxGrpCode;
    private int indexEntitlementInd;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT ADSI_SCHD_ID,ADSI_POL_NR,ADSI_MSTR_EVT_ID,"
                    + "ADSI_ELMT_NR,ADSI_INTM_NR,ADSI_SPLT_COMM_TYP,ADSI_SPLT_COMM_ID,ADSI_SCHD_TYP,ADSI_START_DT,"
                    + "ADSI_NXT_PMT_DT,ADSI_END_DT,ADSI_COMM_AMT_MON,ADSI_TOT_COMM_AMT,ADSI_TOT_VAT_AMT,ADSI_SCHD_STS,ADSI_STS_END_DT,"
                    + "ADSI_EIP_ID,ADSI_IDX_ENT_IND,ADSI_TAX_GRP_CD,ADSI_FIRST_PMT_DT,ADSI_CRTD_BY,ADSI_UPD_BY,"
                    + "ADSI_SCHD_INF_VER,DM_LSTUPDDT,ADSI_FTCP_PRC_STS FROM {0}ADSI_SCHD_INF "
                    + "ORDER BY ADSI_MSTR_EVT_ID, ADSI_ELMT_NR, ADSI_INTM_NR, ADSI_SPLT_COMM_TYP, ADSI_SPLT_COMM_ID, ADSI_SCHD_TYP FOR FETCH ONLY WITH UR");

    public FixtureTestAdvanceScheduleInfo() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestAdvanceSchedule.execute()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setScheduleId(getResultSet().getLong("ADSI_SCHD_ID"));
            setPolicyNumber(getResultSet().getString("ADSI_POL_NR"));
            setMasterEventId(getResultSet().getLong("ADSI_MSTR_EVT_ID"));
            setElementNumber(getResultSet().getInt("ADSI_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getInt("ADSI_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("ADSI_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getString("ADSI_SPLT_COMM_ID"));
            setScheduleType(getResultSet().getInt("ADSI_SCHD_TYP"));
            setStartDate(format(getResultSet().getDate("ADSI_START_DT")));
            setNextPaymentDate(format(getResultSet().getDate("ADSI_NXT_PMT_DT")));
            setEndDate(format(getResultSet().getDate("ADSI_END_DT")));
            setCommissionAmountMonthly(getResultSet().getDouble("ADSI_COMM_AMT_MON"));
            setTotalCommissionAmount(getResultSet().getDouble("ADSI_TOT_COMM_AMT"));
            setTotalVatAmount(getResultSet().getDouble("ADSI_TOT_VAT_AMT"));
            setScheduleStatus(getResultSet().getInt("ADSI_SCHD_STS"));
            setStatusEndDate(format(getResultSet().getDate("ADSI_STS_END_DT")));
            setEventInProcessId(getResultSet().getLong("ADSI_EIP_ID"));
            setIndexEntitlementIndicator(getResultSet().getInt("ADSI_IDX_ENT_IND"));
            setTaxGroupCode(getResultSet().getInt("ADSI_TAX_GRP_CD"));
            setFirstPaymentDate(format(getResultSet().getDate("ADSI_FIRST_PMT_DT")));
            setCreatedBy(getResultSet().getString("ADSI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("ADSI_UPD_BY").trim());
            setVersion(getResultSet().getInt("ADSI_SCHD_INF_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setFtcpProcessStatus(getResultSet().getString("ADSI_FTCP_PRC_STS"));

            setCommissionAmntMonthly(Double.parseDouble(commissionAmountMonthly()));
            setTotalCommissionAmnt(Double.parseDouble(totalCommissionAmount()));
            setIndexEntitlementInd(indexEntitlementIndicator());
            setTaxGrpCode(taxGroupCode());
            setInfoVer(version());

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestAdvanceSchedule", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestAdvanceSchedule", e);
            }
        }
        LOG.debug("Exit FixtureTestAdvanceSchedule.execute()");
    }

    public long scheduleId() {
        return scheduleId;
    }

    public void setScheduleId(long scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public String splitCommissionId() {
        return splitCommissionId;
    }

    public void setSplitCommissionId(String splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    public int scheduleType() {
        return scheduleType;
    }

    public void setScheduleType(int scheduleType) {
        this.scheduleType = scheduleType;
    }

    public String startDate() {
        return startDate;
    }

    public void setStartDate(String string) {
        this.startDate = string;
    }

    public String nextPaymentDate() {
        return nextPaymentDate;
    }

    public void setNextPaymentDate(String string) {
        this.nextPaymentDate = string;
    }

    public String endDate() {
        return endDate;
    }

    public void setEndDate(String string) {
        this.endDate = string;
    }

    @Deprecated
    public String commissionAmntMonthly() {
        if (commissionAmntMonthly != null) {
            if (BigDecimal.valueOf(Double.parseDouble(commissionAmntMonthly)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(commissionAmntMonthly).intValue());
            }
        }
        return commissionAmntMonthly;

    }

    @Deprecated
    public void setCommissionAmntMonthly(double commissionAmntMonthly) {
        this.commissionAmntMonthly = Double.toString(commissionAmntMonthly);
    }

    @Deprecated
    public String totalCommissionAmnt() {
        if (totalCommissionAmnt != null) {
            if (BigDecimal.valueOf(Double.parseDouble(totalCommissionAmnt)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(totalCommissionAmnt).intValue());
            }
        }
        return totalCommissionAmnt;
    }

    @Deprecated
    public void setTotalCommissionAmnt(double totalCommissionAmnt) {
        this.totalCommissionAmnt = Double.toString(totalCommissionAmnt);
    }

    public String totalVatAmount() {
        return formatDouble(totalVatAmount);
    }

    public void setTotalVatAmount(double totalvatAmount) {
        this.totalVatAmount = String.valueOf(totalvatAmount);
    }

    /**
     * @return the commissionAmountMonthly
     */
    public String commissionAmountMonthly() {
        return formatDouble(commissionAmountMonthly);
    }

    /**
     * @param commissionAmountMonthly
     *            the commissionAmountMonthly to set
     */
    public void setCommissionAmountMonthly(double commissionAmountMonthly) {
        this.commissionAmountMonthly = String.valueOf(commissionAmountMonthly);
        ;
    }

    /**
     * @return the totalCommissionAmount
     */
    public String totalCommissionAmount() {
        return formatDouble(totalCommissionAmount);
    }

    /**
     * @param totalCommissionAmount
     *            the totalCommissionAmount to set
     */
    public void setTotalCommissionAmount(double totalCommissionAmount) {
        this.totalCommissionAmount = String.valueOf(totalCommissionAmount);
    }

    /**
     * @return the indexEntitlementIndicator
     */
    public int indexEntitlementIndicator() {
        return indexEntitlementIndicator;
    }

    /**
     * @param indexEntitlementIndicator
     *            the indexEntitlementIndicator to set
     */
    public void setIndexEntitlementIndicator(int indexEntitlementIndicator) {
        this.indexEntitlementIndicator = indexEntitlementIndicator;
    }

    /**
     * @return the taxGroupCode
     */
    public int taxGroupCode() {
        return taxGroupCode;
    }

    /**
     * @param taxGroupCode
     *            the taxGroupCode to set
     */
    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    public int scheduleStatus() {
        return scheduleStatus;
    }

    public void setScheduleStatus(int scheduleStatus) {
        this.scheduleStatus = scheduleStatus;
    }

    public String statusEndDate() {
        return statusEndDate;
    }

    public void setStatusEndDate(String string) {
        this.statusEndDate = string;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    @Deprecated
    public int indexEntitlementInd() {
        return indexEntitlementInd;
    }

    @Deprecated
    public void setIndexEntitlementInd(int indexEntitlementInd) {
        this.indexEntitlementInd = indexEntitlementInd;
    }

    @Deprecated
    public int taxGrpCode() {
        return taxGrpCode;
    }

    @Deprecated
    public void setTaxGrpCode(int taxGrpCode) {
        this.taxGrpCode = taxGrpCode;
    }

    public String firstPaymentDate() {
        return firstPaymentDate;
    }

    public void setFirstPaymentDate(String string) {
        this.firstPaymentDate = string;
    }

    @Deprecated
    public int infoVer() {
        return infoVer;
    }

    @Deprecated
    public void setInfoVer(int infoVer) {
        this.infoVer = infoVer;
    }

    public String ftcpProcessStatus() {
        return format(ftcpProcessStatus);
    }

    public void setFtcpProcessStatus(String ftcpProcessStatus) {
        this.ftcpProcessStatus = ftcpProcessStatus;
    }
}

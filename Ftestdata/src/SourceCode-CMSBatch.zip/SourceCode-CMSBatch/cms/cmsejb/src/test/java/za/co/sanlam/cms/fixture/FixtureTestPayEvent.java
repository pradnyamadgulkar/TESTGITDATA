/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PYEI_PYEVT_EVT table.
 */
public class FixtureTestPayEvent extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPayEvent.class);

    private long masterEventId;
    private int eventType;
    private String eventEffectiveDate;
    private String commissionType;
    private int taxGroupCode;
    private String policyNumber;
    private int elementNumber;
    private String commissionMonthlyAmount;
    private String fundValue;
    private String negotiatedCommissionPercentage;
    private String campaignCode;

    public FixtureTestPayEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("PYEI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("PYEI_PAY_EVT_TYP"));
            setEventEffectiveDate(format(getResultSet().getDate("PYEI_PAY_EVT_EF_DT")));
            setCommissionType(getResultSet().getString("PYEI_COMM_TYP").trim());
            setTaxGroupCode(getResultSet().getInt("PYEI_TAX_GRP_CD"));
            setPolicyNumber(getResultSet().getString("PYEI_POL_NR"));
            setElementNumber(getResultSet().getInt("PYEI_ELMT_NR"));
            setCommissionMonthlyAmount(getResultSet().getDouble("PYEI_COMM_MON"));
            setFundValue(getResultSet().getDouble("PYEI_FUND_VAL"));
            setNegotiatedCommissionPercentage(getResultSet().getDouble("PYEI_NEGO_COMM_PCT"));
            setCreatedBy(getResultSet().getString("PYEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PYEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("PYEI_PYEVT_EVT_VER"));
            setCampaignCode(getResultSet().getString("PYEI_CMPG_CD").trim());
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestOneOffPayment: " + ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestOneOffPayment", se);
            }
        }
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public int taxGroupCode() {
        return taxGroupCode;
    }

    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public String commissionMonthlyAmount() {
        return formatDouble(commissionMonthlyAmount);
    }

    public void setCommissionMonthlyAmount(double commissionMonthlyAmount) {
        this.commissionMonthlyAmount = String.valueOf(commissionMonthlyAmount);
    }

    public String fundValue() {
        return formatDouble(fundValue);
    }

    public void setFundValue(double fundValue) {
        this.fundValue = String.valueOf(fundValue);
    }

    public String negotiatedCommissionPercentage() {
        return formatDouble(negotiatedCommissionPercentage);
    }

    public void setNegotiatedCommissionPercentage(double negotiatedCommissionPercentage) {
        this.negotiatedCommissionPercentage = String.valueOf(negotiatedCommissionPercentage);
    }

    public String campaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PYEI_MSTR_EVT_ID, PYEI_PAY_EVT_TYP, PYEI_PAY_EVT_EF_DT, PYEI_COMM_TYP, PYEI_TAX_GRP_CD, PYEI_POL_NR, PYEI_ELMT_NR, "
                    + "PYEI_COMM_MON, PYEI_FUND_VAL, PYEI_NEGO_COMM_PCT, PYEI_CRTD_BY, PYEI_UPD_BY,  PYEI_PYEVT_EVT_VER, DM_LSTUPDDT, PYEI_CMPG_CD  "
                    + " FROM {0}PYEI_PYEVT_EVT ORDER BY PYEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");
}

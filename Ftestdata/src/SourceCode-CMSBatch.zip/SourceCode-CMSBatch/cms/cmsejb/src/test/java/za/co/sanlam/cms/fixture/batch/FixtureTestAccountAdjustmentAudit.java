package za.co.sanlam.cms.fixture.batch;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tcs.mastercraft.mctype.ServerContext;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestAccountAdjustmentAudit extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestAccountAdjustmentAudit.class);

    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    private int rowNumber;

    private long auditId;
    private String policyNumber;
    private String kmifTotalCommissionAmount;
    private String acasTotalCommissionAmount;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestAccountAdjustmentAudit.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet(resultSet)) {
                return;
            }
            LOGGER.debug("execute" + rowNumber);
            resultSet.absolute(rowNumber);
            setAuditId(resultSet.getLong("ACAA_AUDIT_ID"));
            setPolicyNumber(resultSet.getString("ACAA_POL_NR"));
            setKmifTotalCommissionAmount(resultSet.getDouble("ACAA_KMIF_TOT_COMM_AMT"));
            setAcasTotalCommissionAmount(resultSet.getDouble("ACAA_ACAS_TOT_COMM_AMT"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestAccountAdjustmentAudit", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestAccountAdjustmentAudit", se);
            }
        }
    }

    private void initialize() throws SQLException {
        LOGGER.debug("Setting info for Active Policies" + ServerContext.getSchemaName());
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("ACAA_AUDIT_ID, ACAA_POL_NR, ACAA_KMIF_TOT_COMM_AMT,  ACAA_ACAS_TOT_COMM_AMT ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("ACAA_ACJ_AUD ");
        sqlStatement.append("ORDER BY ACAA_AUDIT_ID ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");
        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestAccountAdjustmentAudit", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public long auditId() {
        return auditId;
    }

    public void setAuditId(long auditId) {
        this.auditId = auditId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String kmifTotalCommissionAmount() {
        if (kmifTotalCommissionAmount != null) {
            if (BigDecimal.valueOf(Double.parseDouble(kmifTotalCommissionAmount)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(kmifTotalCommissionAmount).intValue());
            }
        }
        return kmifTotalCommissionAmount;
    }

    public void setKmifTotalCommissionAmount(double kmifTotalCommissionAmount) {
        this.kmifTotalCommissionAmount = Double.toString(kmifTotalCommissionAmount);
    }

    public String acasTotalCommissionAmount() {
        if (acasTotalCommissionAmount != null) {
            if (BigDecimal.valueOf(Double.parseDouble(acasTotalCommissionAmount)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(acasTotalCommissionAmount).intValue());
            }
        }
        return acasTotalCommissionAmount;
    }

    public void setAcasTotalCommissionAmount(double acasTotalCommissionAmount) {
        this.acasTotalCommissionAmount = Double.toString(acasTotalCommissionAmount);
    }
}

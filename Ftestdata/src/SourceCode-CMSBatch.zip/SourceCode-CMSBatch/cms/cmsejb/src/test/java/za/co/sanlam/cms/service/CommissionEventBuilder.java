package za.co.sanlam.cms.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

public class CommissionEventBuilder {

    private String policyNumber = "0000000001";
    private String productType = "D03";
    private int noOfPremiumReceived = 0;
    private String clientOwnerPortfolioNo = "JOE123";
    private String clientInsuredPortfolioNo = "JOE123";
    private String clientInsuredSurname = "Bloggs";
    private String clientInsuredInitials = "J";
    private String orginalPolicyNumber = "0";
    private int currency = 1;
    private int sourceSystem = 1;
    private String productNameCode = "D03";
    private double randValuePremiumInArrears = 0.0;
    private double policyTotalPremium = 0.0;
    private int warningLevel = 0;
    private int eventType = 1;
    private Date eventEffectiveDate = new GregorianCalendar(2015, 6, 30).getTime();;
    private int taxFundGroupCode = 5;
    private String commissionType = "2";
    private int premiumPaymentMethod = 1;
    private int premiumFrequency = 1;
    private String campaignCode = "0";
    private int indexGrowthType = 1;
    private Date quotationDate = new GregorianCalendar(2012, 01, 01).getTime();
    private Date applicationInceptionDate = new GregorianCalendar(2009, 9, 01).getTime();
    private int indexPlanOptionIndicator = 0;
    private int noOfElements = 1;
    private Date premiumHolidayStartDate = new GregorianCalendar(9999, 12, 31).getTime();
    private Date premiumHolidayEndDate = new GregorianCalendar(9999, 12, 31).getTime();
    private int rparIndicator = 0;
    private int specialReInstatementIndicator = 0;
    private int coversionIndicator = 0;
    private Timestamp transactionTimestamp = new Timestamp(System.currentTimeMillis());
    private int elementNumber = 1;
    private Date elementStartDate = new GregorianCalendar(2015, 6, 30).getTime();
    private int elementTerm = 60;
    private double elementPremium = 3600.00;
    private double fundValue = 0.0;
    private double premiumReductionPercentage = 0.0;
    private double salesCommissionMonthlyAmount = 15.0;
    private double serviceCommissionMonthlyAmount = 0.0;
    private double fundCommissionMonthlyAmount = 0.0;
    private Date policyIssueDate = new GregorianCalendar(2009, 9, 11).getTime();;
    private double salesCommissionNegotiatedPercentage = 100.0;
    private double serviceCommissionNegotiatedPercentage = 0.0;
    private int scoreTerm = 0;
    private int combinedAlterationIndicator;
    private String replacementIndicator = "0";
    private int transferSourceRA = 0;
    private double elementScorePremium = 10.00;
    private double conversionPremium = 200.00;

    private List<IntermediaryInfo> intermediarys = new ArrayList<IntermediaryInfo>(Arrays.asList(new IntermediaryInfoBuilder()
            .build()));

    public CommissionEventBuilder withPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
        return this;
    }

    public CommissionEventBuilder withProductType(String productType) {
        this.productType = productType;
        return this;
    }

    public CommissionEventBuilder withNoOfPremiumReceived(int noOfPremiumReceived) {
        this.noOfPremiumReceived = noOfPremiumReceived;
        return this;
    }

    public CommissionEventBuilder withClientOwnerPortfolioNo(String clientOwnerPortfolioNo) {
        this.clientOwnerPortfolioNo = clientOwnerPortfolioNo;
        return this;
    }

    public CommissionEventBuilder withClientInsuredPortfolioNo(String clientInsuredPortfolioNo) {
        this.clientInsuredPortfolioNo = clientInsuredPortfolioNo;
        return this;
    }

    public CommissionEventBuilder withClientInsuredSurname(String clientInsuredSurname) {
        this.clientInsuredSurname = clientInsuredSurname;
        return this;
    }

    public CommissionEventBuilder withClientInsuredInitials(String clientInsuredInitials) {
        this.clientInsuredInitials = clientInsuredInitials;
        return this;
    }

    public CommissionEventBuilder withOrginalPolicyNumber(String orginalPolicyNumber) {
        this.orginalPolicyNumber = orginalPolicyNumber;
        return this;
    }

    public CommissionEventBuilder withCurrency(int currency) {
        this.currency = currency;
        return this;
    }

    public CommissionEventBuilder withSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
        return this;
    }

    public CommissionEventBuilder withProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
        return this;
    }

    public CommissionEventBuilder withRandValuePremiumInArrears(double randValuePremiumInArrears) {
        this.randValuePremiumInArrears = randValuePremiumInArrears;
        return this;
    }

    public CommissionEventBuilder withPolicyTotalPremium(double policyTotalPremium) {
        this.policyTotalPremium = policyTotalPremium;
        return this;
    }

    public CommissionEventBuilder withWarningLevel(int warningLevel) {
        this.warningLevel = warningLevel;
        return this;
    }

    public CommissionEventBuilder withEventType(int eventType) {
        this.eventType = eventType;
        return this;
    }

    public CommissionEventBuilder withEventEffectiveDate(Date eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
        return this;
    }

    public CommissionEventBuilder withTaxFundGroupCode(int taxFundGroupCode) {
        this.taxFundGroupCode = taxFundGroupCode;
        return this;
    }

    public CommissionEventBuilder withCommissionType(String commissionType) {
        this.commissionType = commissionType;
        return this;
    }

    public CommissionEventBuilder withPremiumPaymentMethod(int premiumPaymentMethod) {
        this.premiumPaymentMethod = premiumPaymentMethod;
        return this;
    }

    public CommissionEventBuilder withPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
        return this;
    }

    public CommissionEventBuilder withCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
        return this;
    }

    public CommissionEventBuilder withIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
        return this;
    }

    public CommissionEventBuilder withQuotationDate(Date quotationDate) {
        this.quotationDate = quotationDate;
        return this;
    }

    public CommissionEventBuilder withApplicationInceptionDate(Date applicationInceptionDate) {
        this.applicationInceptionDate = applicationInceptionDate;
        return this;
    }

    public CommissionEventBuilder withIndexPlanOptionIndicator(int indexPlanOptionIndicator) {
        this.indexPlanOptionIndicator = indexPlanOptionIndicator;
        return this;
    }

    public CommissionEventBuilder withNoOfElements(int noOfElements) {
        this.noOfElements = noOfElements;
        return this;
    }

    public CommissionEventBuilder withPremiumHolidayStartDate(Date premiumHolidayStartDate) {
        this.premiumHolidayStartDate = premiumHolidayStartDate;
        return this;
    }

    public CommissionEventBuilder withPremiumHolidayEndDate(Date premiumHolidayEndDate) {
        this.premiumHolidayEndDate = premiumHolidayEndDate;
        return this;
    }

    public CommissionEventBuilder withRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
        return this;
    }

    public CommissionEventBuilder withSpecialReInstatementIndicator(int specialReInstatementIndicator) {
        this.specialReInstatementIndicator = specialReInstatementIndicator;
        return this;
    }

    public CommissionEventBuilder withCoversionIndicator(int coversionIndicator) {
        this.coversionIndicator = coversionIndicator;
        return this;
    }

    public CommissionEventBuilder withTransactionTimestamp(Timestamp transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
        return this;
    }

    public CommissionEventBuilder withElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
        return this;
    }

    public CommissionEventBuilder withElementStartDate(Date elementStartDate) {
        this.elementStartDate = elementStartDate;
        return this;
    }

    public CommissionEventBuilder withElementTerm(int elementTerm) {
        this.elementTerm = elementTerm;
        return this;
    }

    public CommissionEventBuilder withElementPremium(double elementPremium) {
        this.elementPremium = elementPremium;
        return this;
    }

    public CommissionEventBuilder withFundValue(double fundValue) {
        this.fundValue = fundValue;
        return this;
    }

    public CommissionEventBuilder withPremiumReductionPercentage(double premiumReductionPercentage) {
        this.premiumReductionPercentage = premiumReductionPercentage;
        return this;
    }

    public CommissionEventBuilder withSalesCommissionMonthlyAmount(double salesCommissionMonthlyAmount) {
        this.salesCommissionMonthlyAmount = salesCommissionMonthlyAmount;
        return this;
    }

    public CommissionEventBuilder withServiceCommissionMonthlyAmount(double serviceCommissionMonthlyAmount) {
        this.serviceCommissionMonthlyAmount = serviceCommissionMonthlyAmount;
        return this;
    }

    public CommissionEventBuilder withFundCommissionMonthlyAmount(double fundCommissionMonthlyAmount) {
        this.fundCommissionMonthlyAmount = fundCommissionMonthlyAmount;
        return this;
    }

    public CommissionEventBuilder withPolicyIssueDate(Date policyIssueDate) {
        this.policyIssueDate = policyIssueDate;
        return this;
    }

    public CommissionEventBuilder withSalesCommissionNegotiatedPercentage(double salesCommissionNegotiatedPercentage) {
        this.salesCommissionNegotiatedPercentage = salesCommissionNegotiatedPercentage;
        return this;
    }

    public CommissionEventBuilder withServiceCommissionNegotiatedPercentage(double serviceCommissionNegotiatedPercentage) {
        this.serviceCommissionNegotiatedPercentage = serviceCommissionNegotiatedPercentage;
        return this;
    }

    public CommissionEventBuilder withScoreTerm(int scoreTerm) {
        this.scoreTerm = scoreTerm;
        return this;
    }

    public CommissionEventBuilder withCombinedAlterationIndicator(int combinedAlterationIndicator) {
        this.combinedAlterationIndicator = combinedAlterationIndicator;
        return this;
    }

    public CommissionEventBuilder withReplacementIndicator(String replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
        return this;
    }

    public CommissionEventBuilder withTransferSourceRA(int transferSourceRA) {
        this.transferSourceRA = transferSourceRA;
        return this;
    }

    public CommissionEventBuilder withElementScorePremium(double elementScorePremium) {
        this.elementScorePremium = elementScorePremium;
        return this;
    }

    public CommissionEventBuilder setIntermediarys(List<IntermediaryInfo> intermediarys) {
        this.intermediarys = intermediarys;
        return this;
    }

    public CommissionEventBuilder addIntermediaries(IntermediaryInfo intermediaryInfo) {
        this.intermediarys.add(intermediaryInfo);
        return this;
    }

    public CommissionEventBuilder withConversionPremium(double conversionPremium) {
        this.conversionPremium = conversionPremium;
        return this;
    }

    // ArrayList<IntermediaryInfo>();
    public CommissionEvent build() {
        CommissionEvent commissionEvent = new CommissionEvent();
        commissionEvent.setPolicyNumber(policyNumber);
        commissionEvent.setProductType(productType);
        commissionEvent.setNoOfPremiumReceived(noOfPremiumReceived);
        commissionEvent.setClientOwnerPortfolioNo(clientOwnerPortfolioNo);
        commissionEvent.setClientInsuredPortfolioNo(clientInsuredPortfolioNo);
        commissionEvent.setClientInsuredSurname(clientInsuredSurname);
        commissionEvent.setClientInsuredInitials(clientInsuredInitials);
        commissionEvent.setOrginalPolicyNumber(orginalPolicyNumber);
        commissionEvent.setCurrency(currency);
        commissionEvent.setSourceSystem(sourceSystem);
        commissionEvent.setProductNameCode(productNameCode);
        commissionEvent.setRandValuePremiumInArrears(randValuePremiumInArrears);
        commissionEvent.setPolicyTotalPremium(policyTotalPremium);
        commissionEvent.setWarningLevel(warningLevel);
        commissionEvent.setEventType(eventType);
        commissionEvent.setEventEffectiveDate(eventEffectiveDate);
        commissionEvent.setTaxFundGroupCode(taxFundGroupCode);
        commissionEvent.setCommissionType(commissionType);
        commissionEvent.setPremiumPaymentMethod(premiumPaymentMethod);
        commissionEvent.setPremiumFrequency(premiumFrequency);
        commissionEvent.setCampaignCode(campaignCode);
        commissionEvent.setIndexGrowthType(indexGrowthType);
        commissionEvent.setQuotationDate(quotationDate);
        commissionEvent.setApplicationInceptionDate(applicationInceptionDate);
        commissionEvent.setIndexPlanOptionIndicator(indexPlanOptionIndicator);
        commissionEvent.setNoOfElements(noOfElements);
        commissionEvent.setPremiumHolidayStartDate(premiumHolidayStartDate);
        commissionEvent.setPremiumHolidayEndDate(premiumHolidayEndDate);
        commissionEvent.setRparIndicator(rparIndicator);
        commissionEvent.setSpecialReInstatementIndicator(specialReInstatementIndicator);
        commissionEvent.setCoversionIndicator(coversionIndicator);
        commissionEvent.setTransactionTimestamp(transactionTimestamp);
        commissionEvent.setElementNumber(elementNumber);
        commissionEvent.setElementStartDate(elementStartDate);
        commissionEvent.setElementTerm(elementTerm);
        commissionEvent.setElementPremium(elementPremium);
        commissionEvent.setFundValue(fundValue);
        commissionEvent.setPremiumReductionPercentage(premiumReductionPercentage);
        commissionEvent.setSalesCommissionMonthlyAmount(salesCommissionMonthlyAmount);
        commissionEvent.setServiceCommissionMonthlyAmount(serviceCommissionMonthlyAmount);
        commissionEvent.setFundCommissionMonthlyAmount(fundCommissionMonthlyAmount);
        commissionEvent.setPolicyIssueDate(policyIssueDate);
        commissionEvent.setSalesCommissionNegotiatedPercentage(salesCommissionNegotiatedPercentage);
        commissionEvent.setServiceCommissionNegotiatedPercentage(serviceCommissionNegotiatedPercentage);
        commissionEvent.setScoreTerm(scoreTerm);
        commissionEvent.setCombinedAlterationIndicator(combinedAlterationIndicator);
        commissionEvent.setReplacementIndicator(replacementIndicator);
        commissionEvent.setTransferSourceRA(transferSourceRA);
        commissionEvent.setElementScorePremium(elementScorePremium);
        commissionEvent.setCreatedby("ITTest");
        commissionEvent.setUpdateby("ITTest");
        commissionEvent.setConversionPremium(conversionPremium);

        for (Iterator<IntermediaryInfo> iterator = intermediarys.iterator(); iterator.hasNext();) {
            IntermediaryInfo intermediaryInfo = iterator.next();
            commissionEvent.getIntermediarys().add(intermediaryInfo);
        }
        return commissionEvent;
    }
}

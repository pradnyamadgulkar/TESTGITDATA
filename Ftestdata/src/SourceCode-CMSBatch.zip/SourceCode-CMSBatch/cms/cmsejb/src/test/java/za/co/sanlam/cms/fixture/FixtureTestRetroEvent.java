/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FixtureTestRetroEvent extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestRetroEvent.class);

    private long masterEventId;
    private int retroEventType;
    private String retroEventEffectiveDate;
    private int fromAccountIndicator;
    private int toAccountIndicator;
    private long intermediaryNumber;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT ATEI_MSTR_EVT_ID, ATEI_AXE_TYP, ATEI_EFF_DT, ATEI_FROM_ACC_IND, ATEI_TO_ACC_IND, ATEI_INTM_NR, ATEI_CRTD_BY, ATEI_UPD_BY, ATEI_CRTD_TMST,"
                    + "ATEI_UPD_TMST, ATEI_ATR_EVT_VER, DM_LSTUPDDT FROM {0}ATEI_ATR_EVT ORDER BY ATEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");

    public FixtureTestRetroEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestRetroEvent.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("ATEI_MSTR_EVT_ID"));
            setRetroEventType(getResultSet().getInt("ATEI_AXE_TYP"));
            setFromAccountIndicator(getResultSet().getInt("ATEI_FROM_ACC_IND"));
            setToAccountIndicator(getResultSet().getInt("ATEI_TO_ACC_IND"));
            setIntermediaryNumber(getResultSet().getLong("ATEI_INTM_NR"));
            setRetroEventEffectiveDate(format(getResultSet().getDate("ATEI_EFF_DT")));
            setCreatedBy(getResultSet().getString("ATEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("ATEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("ATEI_ATR_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestRetroEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestRetroEvent", se);
            }
        }
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int retroEventType() {
        return retroEventType;
    }

    public void setRetroEventType(int retroEventType) {
        this.retroEventType = retroEventType;
    }

    public String retroEventEffectiveDate() {
        return retroEventEffectiveDate;
    }

    public void setRetroEventEffectiveDate(String retroEventEffectiveDate) {
        this.retroEventEffectiveDate = retroEventEffectiveDate;
    }

    public int fromAccountIndicator() {
        return fromAccountIndicator;
    }

    public void setFromAccountIndicator(int fromAccountIndicator) {
        this.fromAccountIndicator = fromAccountIndicator;
    }

    public int toAccountIndicator() {
        return toAccountIndicator;
    }

    public void setToAccountIndicator(int toAccountIndicator) {
        this.toAccountIndicator = toAccountIndicator;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }
}
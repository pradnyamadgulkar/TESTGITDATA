/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for CTEI_CTE_EVT table.
 */
public class FixtureTestCommissionTerminatingEvent extends FixtureTestMasterEvent {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestCommissionTerminatingEvent.class);

    private String effectiveDate;
    private String eventEffectiveDate;
    private int numberOfPremiumsRcvd;
    private int numberOfPremiumsReceived;
    private int cteInfoVer;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT CTEI_MSTR_EVT_ID, CTEI_CTE_TYP, CTEI_CTE_EFF_DT, CTEI_NR_PRM_RCVD, "
                    + "CTEI_POL_NR, CTEI_CRTD_BY, CTEI_UPD_BY, CTEI_CTE_EVT_VER, DM_LSTUPDDT from "
                    + "{0}CTEI_CTE_EVT ORDER BY CTEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");

    public FixtureTestCommissionTerminatingEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestCommissionTerminatingEvent.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("CTEI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("CTEI_CTE_TYP"));
            setEffectiveDate(format(getResultSet().getDate("CTEI_CTE_EFF_DT")));
            setNumberOfPremiumsReceived(getResultSet().getInt("CTEI_NR_PRM_RCVD"));
            setPolicyNumber(getResultSet().getString("CTEI_POL_NR"));
            setCreatedBy(getResultSet().getString("CTEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("CTEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("CTEI_CTE_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setEventEffectiveDate(effectiveDate());
            setNumberOfPremiumsRcvd(numberOfPremiumsReceived());
            setCteInfoVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestCommTerminatingEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestCommTerminatingEvent", se);
            }
        }
    }

    @Deprecated
    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    @Deprecated
    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    /**
     * @return the effectiveDate
     */
    public String effectiveDate() {
        return effectiveDate;
    }

    /**
     * @param effectiveDate
     *            the effectiveDate to set
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    @Deprecated
    public int numberOfPremiumsRcvd() {
        return numberOfPremiumsRcvd;
    }

    @Deprecated
    public void setNumberOfPremiumsRcvd(int numberOfPremiumsRcvd) {
        this.numberOfPremiumsRcvd = numberOfPremiumsRcvd;
    }

    @Deprecated
    public int cteInfoVer() {
        return cteInfoVer;
    }

    @Deprecated
    public void setCteInfoVer(int cteInfoVer) {
        this.cteInfoVer = cteInfoVer;
    }

    /**
     * @return the numberOfPremiumsReceived
     */
    public int numberOfPremiumsReceived() {
        return numberOfPremiumsReceived;
    }

    /**
     * @param numberOfPremiumsReceived
     *            the numberOfPremiumsReceived to set
     */
    public void setNumberOfPremiumsReceived(int numberOfPremiumsReceived) {
        this.numberOfPremiumsReceived = numberOfPremiumsReceived;
    }
}

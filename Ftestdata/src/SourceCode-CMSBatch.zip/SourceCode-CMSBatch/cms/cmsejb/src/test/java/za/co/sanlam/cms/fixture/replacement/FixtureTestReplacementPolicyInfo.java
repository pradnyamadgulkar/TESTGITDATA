/*
 * 
 */
package za.co.sanlam.cms.fixture.replacement;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestReplacementPolicyInfo extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestReplacementPolicyInfo.class);

    private long policyId;
    private String policyNumber;
    private String policyInceptionDate;
    private String productType;
    private int policyStatus;
    private int eventType;
    private String applicationDate;
    private String lapseDate;
    private int intermediaryNumber;
    private String intermediaryPct;
    private String commissionType;
    private String elementStartDate;
    private int rparIndicator;
    private int raIndicator;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestReplacementPolicyInfo.beginTable()");

        super.beginTable();

        initialize(SQL_QUERY);
    }

    public void execute() {
        try {

            if (inValidResultSet()) {
                return;
            }

            getResultSet().absolute(rowNumber());

            setPolicyId(getResultSet().getLong("RPPI_POL_ID"));
            setPolicyNumber(getResultSet().getString("RPPI_POL_NR"));
            setPolicyInceptionDate(dateFormatter.format(getResultSet().getDate("RPPI_INCP_DATE")));
            setProductType(getResultSet().getString("RPPI_PRD_TYPE"));
            setPolicyStatus(getResultSet().getShort("RPPI_STATUS"));
            setEventType(getResultSet().getInt("RPPI_EVT_TYPE"));
            setApplicationDate(dateFormatter.format(getResultSet().getDate("RPPI_APP_DATE")));
            setLapseDate(dateFormatter.format(getResultSet().getDate("RPPI_LAPSE_DATE")));
            setIntermediaryNumber(getResultSet().getInt("RPPI_INTM_NR"));
            setIntermediaryPct(getResultSet().getDouble("RPPI_INTM_PCT"));
            setCommissionType(getResultSet().getString("RPPI_COMM_TYPE"));
            setElementStartDate(dateFormatter.format(getResultSet().getDate("RPPI_ELMT_START_DATE")));
            setRparIndicator(getResultSet().getInt("RPPI_RPAR_IND"));
            setRaIndicator(getResultSet().getInt("RPPI_RA_IND"));
            setCreatedBy(getResultSet().getString("RPPI_CRTD_BY"));

        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestReplacementPolicyInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOGGER.error("Error cleaning up connections in FixtureTestReplacementPolicyInfo", e);
            }
        }
    }

    public long policyId() {
        return policyId;
    }

    public void setPolicyId(long policyId) {
        this.policyId = policyId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String policyInceptionDate() {
        return policyInceptionDate;
    }

    public void setPolicyInceptionDate(String policyInceptionDate) {
        this.policyInceptionDate = policyInceptionDate;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int policyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(int policyStatus) {
        this.policyStatus = policyStatus;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String applicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String lapseDate() {
        return lapseDate;
    }

    public void setLapseDate(String lapseDate) {
        this.lapseDate = lapseDate;
    }

    public int intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(int intemerdiaryNumber) {
        this.intermediaryNumber = intemerdiaryNumber;
    }

    public String intermediaryPct() {
        return formatDouble(intermediaryPct);
        // if (intermediaryPct != null) {
        // if
        // (BigDecimal.valueOf(Double.parseDouble(intermediaryPct)).divideAndRemainder(BigDecimal.ONE)[1].signum()
        // == 0) {
        // return String.valueOf(Double.valueOf(intermediaryPct).intValue());
        // }
        // }
        // return intermediaryPct;
    }

    public void setIntermediaryPct(double intermediaryPct) {
        this.intermediaryPct = Double.toString(intermediaryPct);
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String elementStartDate() {
        return elementStartDate;
    }

    public void setElementStartDate(String elementStartDate) {
        this.elementStartDate = elementStartDate;
    }

    public int rparIndicator() {
        return rparIndicator;
    }

    public void setRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
    }

    public int raIndicator() {
        return raIndicator;
    }

    public void setRaIndicator(int raIndicator) {
        this.raIndicator = raIndicator;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT RPPI_POL_ID, RPPI_POL_NR,RPPI_INCP_DATE, RPPI_STATUS, RPPI_PRD_TYPE, RPPI_EVT_TYPE, RPPI_APP_DATE,"
                    + "RPPI_LAPSE_DATE, RPPI_RPAR_IND, RPPI_ELMT_START_DATE, RPPI_INTM_NR, RPPI_INTM_PCT, "
                    + "RPPI_COMM_TYPE, RPPI_RA_IND, RPPI_CRTD_BY FROM {0}RPPI_POL_INFO "
                    + "ORDER BY RPPI_POL_ID FOR FETCH ONLY WITH UR");

}

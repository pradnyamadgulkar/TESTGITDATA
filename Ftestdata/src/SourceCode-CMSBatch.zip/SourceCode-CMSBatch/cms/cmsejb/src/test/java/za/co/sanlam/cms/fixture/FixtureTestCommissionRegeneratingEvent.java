/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for RGEI_CRGE_EVT table.
 */
public class FixtureTestCommissionRegeneratingEvent extends FixtureTestMasterEvent {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestCommissionRegeneratingEvent.class);

    private int spltReInstIndicator;
    private int specialReinstateIndicator;
    private int rgeInfoVer;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT RGEI_MSTR_EVT_ID, RGEI_CRGE_TYP, RGEI_SPL_RINST_IND, RGEI_POL_NR, "
                    + "RGEI_CRTD_BY, RGEI_UPD_BY, RGEI_CRGE_EVT_VER, DM_LSTUPDDT from "
                    + "{0}RGEI_CRGE_EVT ORDER BY  RGEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");

    public FixtureTestCommissionRegeneratingEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestCommissionRegeneratingEvent.execute()");
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("RGEI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("RGEI_CRGE_TYP"));
            setSpecialReinstateIndicator(getResultSet().getInt("RGEI_SPL_RINST_IND"));
            setPolicyNumber(getResultSet().getString("RGEI_POL_NR"));
            setCreatedBy(getResultSet().getString("RGEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("RGEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("RGEI_CRGE_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setSpltReInstIndicator(specialReinstateIndicator());
            setRgeInfoVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestCommRegeneratingEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestCommRegeneratingEvent", se);
            }
        }
        LOG.debug("Exit FixtureTestCommissionRegeneratingEvent.execute()");
    }

    @Deprecated
    public int rgeInfoVer() {
        return rgeInfoVer;
    }

    @Deprecated
    public void setRgeInfoVer(int rgeInfoVer) {
        this.rgeInfoVer = rgeInfoVer;
    }

    @Deprecated
    public int spltReInstIndicator() {
        return spltReInstIndicator;
    }

    @Deprecated
    public void setSpltReInstIndicator(int spltReInstIndicator) {
        this.spltReInstIndicator = spltReInstIndicator;
    }

    /**
     * @return the specialReinstateIndicator
     */
    public int specialReinstateIndicator() {
        return specialReinstateIndicator;
    }

    /**
     * @param specialReinstateIndicator
     *            the specialReinstateIndicator to set
     */
    public void setSpecialReinstateIndicator(int specialReinstateIndicator) {
        this.specialReinstateIndicator = specialReinstateIndicator;
    }
}

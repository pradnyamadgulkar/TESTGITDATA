/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for KMIF_KMB_INF table.
 */
public class FixtureTestKmif extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestKmif.class);

    private long kmifRefId;
    private long kmbReferenceId;
    private long intermediaryNumber;
    private long policyNumber;
    private long masterEventId;
    private Date policyInceptionDate;
    private int eventType;
    private Date eventEffectiveDate;
    private String splitCommissionType;
    private int trancheNumber;
    private String commissionAmount;
    private String vatAmount;
    private String scorePremium;
    private String policyCount;
    private String totalScorePremium;
    private String scoreSplitPercentage;
    private int vatIndicator;
    private int paymentAccount;
    private Timestamp kommbExitTimeStamp;
    private Timestamp kmbExtractionTimestamp;
    private long eventInProcessId;
    private long eventInProcessTyp;
    private long eventInProcessType;
    private Date eventInProcessDate;
    private int eventTerm;
    private int origSalesEntitlementIndicator;
    private int originalSalesEntitlementIndicator;
    private int creditDebtIndicator;
    private int creditDebitIndicator;
    private int indexGrwthType;
    private int indexGrowthType;
    private String cmpgCode;
    private String campaigCode;
    private long applicationNumber;
    private int manCode;
    private long commissionSplitPercntage;
    private long commissionSplitPercentage;
    private int taxGrpCode;
    private int taxGroupCode;
    private String clientInsuredPortfolioNumber;
    private String clientPortfolioNumberInsured;
    private String clientInsuredSurname;
    private String clientSurnameInsured;
    private String clientInsuredInitial;
    private String clientInitialInsured;
    private String clientOwnerPortfolioNumber;
    private String clientPortfolioNumberOwn;
    private int srcSystem;
    private int sourceSystem;
    private String productType;
    private String productNameCode;
    private int premiumType;
    private int premiumPaymntMethod;
    private int premiumPaymentMethod;
    private int premiumFrequency;
    private int currency;
    private String eventAnnualPremium;
    private long retroEventId;
    private int retroEventType;
    private String negSalesPercentage;
    private String salesNegotiatedPercentage;
    private String negServicePercentage;
    private String serviceNegotiatedPercentage;
    private int NumberOfPremiumsRcvd;
    private int numberOfPremiumsReceived;
    private int kommbInfoVer;
    private String commissionMonthlyAmount;
    private int replIndicator;
    private int replacementIndicator;
    private int raXerIndicator;
    private int oneOffSubtype;
    private int commissionProductType;
    private int origin;
    private int serviceModelIndicator;
    private String conversionPolicyNumber;

    public FixtureTestKmif() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setKmbReferenceId(getResultSet().getLong("KMIF_KMB_REF_ID"));
            setIntermediaryNumber(getResultSet().getLong("KMIF_INTM_NR"));
            setPolicyNumber(getResultSet().getLong("KMIF_POL_NR"));
            setPolicyInceptionDate(getResultSet().getDate("KMIF_POL_INCP_DT"));
            setMasterEventId(getResultSet().getInt("KMIF_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("KMIF_EVT_TYP"));
            setEventEffectiveDate(getResultSet().getDate("KMIF_EVT_EFF_DT"));
            setSplitCommissionType(getResultSet().getString("KMIF_SPLT_COMM_TYP").trim());
            setTrancheNumber(getResultSet().getInt("KMIF_TRCH_NR"));
            setCommissionAmount(getResultSet().getDouble("KMIF_COMM_AMT"));
            setVatAmount(getResultSet().getDouble("KMIF_VAT_AMT"));
            setScorePremium(getResultSet().getDouble("KMIF_SCR_PRM"));
            setPolicyCount(getResultSet().getDouble("KMIF_POL_CNT"));
            setTotalScorePremium(getResultSet().getDouble("KMIF_TOT_SCR_PRM"));
            setScoreSplitPercentage(getResultSet().getDouble("KMIF_SCR_SPLT_PCT"));
            setVatIndicator(getResultSet().getInt("KMIF_VAT_IND"));
            setPaymentAccount(getResultSet().getInt("KMIF_PMT_ACC"));
            setKmbExtractionTimestamp(getResultSet().getTimestamp("KMIF_KMB_EXT_TMST"));
            setEventInProcessId(getResultSet().getLong("KMIF_EIP_ID"));
            setEventInProcessTyp(getResultSet().getLong("KMIF_EIP_TYP"));
            setEventInProcessDate(getResultSet().getDate("KMIF_EIP_DT"));
            setEventTerm(getResultSet().getInt("KMIF_EVT_TRM"));
            setOriginalSalesEntitlementIndicator(getResultSet().getInt("KMIF_ORI_ISE_IND"));
            setCreditDebitIndicator(getResultSet().getInt("KMIF_CR_DT_IND"));
            setIndexGrowthType(getResultSet().getInt("KMIF_IDX_GTH_TYP"));
            setCampaigCode(getResultSet().getString("KMIF_CMPG_CD"));
            setApplicationNumber(getResultSet().getLong("KMIF_APP_NR"));
            setManCode(getResultSet().getInt("KMIF_MAN_CD"));
            setCommissionSplitPercentage(getResultSet().getLong("KMIF_COMM_SPLT_PCT"));
            setTaxGroupCode(getResultSet().getInt("KMIF_TAX_GRP_CD"));
            setClientPortfolioNumberInsured(getResultSet().getString("KMIF_CLT_PF_NR_INS"));
            setClientSurnameInsured(getResultSet().getString("KMIF_CLT_SUR_INS"));
            setClientInitialInsured(getResultSet().getString("KMIF_CLT_INI_INS"));
            setClientPortfolioNumberOwn(getResultSet().getString("KMIF_CLT_PF_NR_OWN"));
            setSourceSystem(getResultSet().getInt("KMIF_SRC_SYS"));
            setProductType(getResultSet().getString("KMIF_PRD_TYP"));
            setProductNameCode(getResultSet().getString("KMIF_PRD_NAME_CD"));
            setPremiumType(getResultSet().getInt("KMIF_PRM_TYP"));
            setPremiumPaymentMethod(getResultSet().getInt("KMIF_PRM_PMT_METH"));
            setPremiumFrequency(getResultSet().getInt("KMIF_PRM_FQ"));
            setCurrency(getResultSet().getInt("KMIF_CURR"));
            setEventAnnualPremium(getResultSet().getDouble("KMIF_EVT_ANN_PRM"));
            setRetroEventId(getResultSet().getLong("KMIF_RTR_EVT_ID"));
            setRetroEventType(getResultSet().getInt("KMIF_RTR_EVT_TYP"));
            setSalesNegotiatedPercentage(getResultSet().getDouble("KMIF_SLS_NEGO_PCT"));
            setServiceNegotiatedPercentage(getResultSet().getDouble("KMIF_SRV_NEGO_PCT"));
            setNumberOfPremiumsReceived(getResultSet().getInt("KMIF_NO_PRM_RCVD"));
            setCreatedBy(getResultSet().getString("KMIF_CRTD_BY"));
            setUpdatedBy(getResultSet().getString("KMIF_UPD_BY"));
            setVersion(getResultSet().getInt("KMIF_KMB_INF_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setCommissionMonthlyAmount(getResultSet().getDouble("KMIF_COMM_AMT_MON"));
            setReplacementIndicator(getResultSet().getInt("KMIF_REPL_IND"));
            setRaXerIndicator(getResultSet().getInt("KMIF_RA_XER_IND"));
            setOneOffSubtype(getResultSet().getInt("KMIF_OOFF_STYPE"));
            setCommissionProductType(getResultSet().getInt("KMIF_COM_PRO_TYPE"));
            setOrigin(getResultSet().getInt("KMIF_ORIGIN"));
            setServiceModelIndicator(getResultSet().getInt("KMIF_SERVICE_MODEL_IND"));
            setConversionPolicyNumber(getResultSet().getString("KMIF_CONV_POL_NR"));

            setKmifRefId(kmbReferenceId());
            setKommbExitTimeStamp(kmbExtractionTimestamp());
            setOrigSalesEntitlementIndicator(originalSalesEntitlementIndicator());
            setCreditDebtIndicator(creditDebitIndicator());
            setIndexGrwthType(indexGrowthType());
            setCmpgCode(campaigCode());
            setSrcSystem(sourceSystem());
            setPremiumPaymntMethod(premiumPaymentMethod());
            setNegSalesPercentage(Double.parseDouble(salesNegotiatedPercentage()));
            setNegServicePercentage(Double.parseDouble(serviceNegotiatedPercentage()));
            setNumberOfPremiumsRcvd(numberOfPremiumsReceived());
            setReplIndicator(replacementIndicator());
            setKommbInfoVer(version());
        } catch (SQLException ex1) {
            LOG.error("Exception Encountered in operation execute of class FixtureTestKmif", ex1);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestKmif", se);
            }
        }
    }

    @Deprecated
    public long kmifRefId() {
        return kmifRefId;
    }

    @Deprecated
    public void setKmifRefId(long kmifRefId) {
        this.kmifRefId = kmifRefId;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public long policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(long policyNumber) {
        this.policyNumber = policyNumber;
    }

    public Date policyInceptionDate() {
        return policyInceptionDate;
    }

    public void setPolicyInceptionDate(Date policyInceptionDate) {
        this.policyInceptionDate = policyInceptionDate;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public int trancheNumber() {
        return trancheNumber;
    }

    public void setTrancheNumber(int trancheNumber) {
        this.trancheNumber = trancheNumber;
    }

    public String commissionAmount() {
        return formatDouble(commissionAmount);
    }

    public void setCommissionAmount(double commissionAmount) {
        this.commissionAmount = String.valueOf(commissionAmount);
    }

    public String vatAmount() {
        return formatDouble(vatAmount);
    }

    public void setVatAmount(double vatAmount) {
        this.vatAmount = String.valueOf(vatAmount);
    }

    public String scorePremium() {
        return formatDouble(scorePremium);
    }

    public void setScorePremium(double scorePremium) {
        this.scorePremium = String.valueOf(scorePremium);
    }

    public String policyCount() {
        return formatDouble(policyCount);
    }

    public void setPolicyCount(double policyCount) {
        this.policyCount = String.valueOf(policyCount);
    }

    public String totalScorePremium() {
        return formatDouble(totalScorePremium);
    }

    public void setTotalScorePremium(double totalScorePremium) {
        this.totalScorePremium = String.valueOf(totalScorePremium);
    }

    public String scoreSplitPercentage() {
        return formatDouble(scoreSplitPercentage);
    }

    public void setScoreSplitPercentage(double scoreSplitPercentage) {
        this.scoreSplitPercentage = String.valueOf(scoreSplitPercentage);
    }

    public int vatIndicator() {
        return vatIndicator;
    }

    public void setVatIndicator(int vatIndicator) {
        this.vatIndicator = vatIndicator;
    }

    public int paymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public long eventInProcessTyp() {
        return eventInProcessTyp;
    }

    public void setEventInProcessTyp(long eventInProcessTyp) {
        this.eventInProcessTyp = eventInProcessTyp;
    }

    public Date eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(Date eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    public int eventTerm() {
        return eventTerm;
    }

    public void setEventTerm(int eventTerm) {
        this.eventTerm = eventTerm;
    }

    @Deprecated
    public int origSalesEntitlementIndicator() {
        return origSalesEntitlementIndicator;
    }

    @Deprecated
    public void setOrigSalesEntitlementIndicator(int origSalesEntitlementIndicator) {
        this.origSalesEntitlementIndicator = origSalesEntitlementIndicator;
    }

    @Deprecated
    public int creditDebtIndicator() {
        return creditDebtIndicator;
    }

    @Deprecated
    public void setCreditDebtIndicator(int creditDebtIndicator) {
        this.creditDebtIndicator = creditDebtIndicator;
    }

    @Deprecated
    public long commissionSplitPercntage() {
        return commissionSplitPercntage;
    }

    @Deprecated
    public void setCommissionSplitPercntage(long commissionSplitPercntage) {
        this.commissionSplitPercntage = commissionSplitPercntage;
    }

    @Deprecated
    public int taxGrpCode() {
        return taxGrpCode;
    }

    @Deprecated
    public void setTaxGrpCode(int taxGrpCode) {
        this.taxGrpCode = taxGrpCode;
    }

    @Deprecated
    public String clientInsuredPortfolioNumber() {
        return clientInsuredPortfolioNumber;
    }

    @Deprecated
    public void setClientInsuredPortfolioNumber(String clientInsuredPortfolioNumber) {
        this.clientInsuredPortfolioNumber = clientInsuredPortfolioNumber;
    }

    @Deprecated
    public String clientInsuredSurname() {
        return clientInsuredSurname;
    }

    @Deprecated
    public void setClientInsuredSurname(String clientInsuredSurname) {
        this.clientInsuredSurname = clientInsuredSurname;
    }

    @Deprecated
    public String clientInsuredInitial() {
        return clientInsuredInitial;
    }

    @Deprecated
    public void setClientInsuredInitial(String clientInsuredInitial) {
        this.clientInsuredInitial = clientInsuredInitial;
    }

    @Deprecated
    public String clientOwnerPortfolioNumber() {
        return clientOwnerPortfolioNumber;
    }

    @Deprecated
    public void setClientOwnerPortfolioNumber(String clientOwnerPortfolioNumber) {
        this.clientOwnerPortfolioNumber = clientOwnerPortfolioNumber;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String productNameCode() {
        return productNameCode;
    }

    public void setProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
    }

    public int premiumType() {
        return premiumType;
    }

    public void setPremiumType(int premiumType) {
        this.premiumType = premiumType;
    }

    @Deprecated
    public int premiumPaymntMethod() {
        return premiumPaymntMethod;
    }

    @Deprecated
    public void setPremiumPaymntMethod(int premiumPaymntMethod) {
        this.premiumPaymntMethod = premiumPaymntMethod;
    }

    public int premiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    public String eventAnnualPremium() {
        return formatDouble(eventAnnualPremium);
    }

    public void setEventAnnualPremium(double eventAnnualPremium) {
        this.eventAnnualPremium = String.valueOf(eventAnnualPremium);
    }

    @Deprecated
    public String negSalesPercentage() {
        if (negSalesPercentage != null) {
            if (BigDecimal.valueOf(Double.parseDouble(negSalesPercentage)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(negSalesPercentage).intValue());
            }
        }
        return negSalesPercentage;
    }

    @Deprecated
    public void setNegSalesPercentage(double negSalesPercentage) {
        this.negSalesPercentage = String.valueOf(negSalesPercentage);
    }

    @Deprecated
    public String negServicePercentage() {
        if (negServicePercentage != null) {
            if (BigDecimal.valueOf(Double.parseDouble(negServicePercentage)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(negServicePercentage).intValue());
            }
        }
        return negServicePercentage;
    }

    @Deprecated
    public void setNegServicePercentage(double negServicePercentage) {
        this.negServicePercentage = String.valueOf(negServicePercentage);
    }

    @Deprecated
    public int numberOfPremiumsRcvd() {
        return NumberOfPremiumsRcvd;
    }

    @Deprecated
    public void setNumberOfPremiumsRcvd(int numberOfPremiumsRcvd) {
        NumberOfPremiumsRcvd = numberOfPremiumsRcvd;
    }

    public String commissionMonthlyAmount() {
        return formatDouble(commissionMonthlyAmount);
    }

    public void setCommissionMonthlyAmount(double commissionMonthlyAmount) {
        this.commissionMonthlyAmount = String.valueOf(commissionMonthlyAmount);
    }

    @Deprecated
    public int replIndicator() {
        return replIndicator;
    }

    @Deprecated
    public void setReplIndicator(int replIndicator) {
        this.replIndicator = replIndicator;
    }

    public int oneOffSubtype() {
        return oneOffSubtype;
    }

    public void setOneOffSubtype(int oneOffSubtype) {
        this.oneOffSubtype = oneOffSubtype;
    }

    public int commissionProductType() {
        return commissionProductType;
    }

    public void setCommissionProductType(int commissionProductType) {
        this.commissionProductType = commissionProductType;
    }

    public int origin() {
        return origin;
    }

    public void setOrigin(int origin) {
        this.origin = origin;
    }

    public Date eventEffectiveDate() {
        return eventEffectiveDate;
    }

    public void setEventEffectiveDate(Date eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    @Deprecated
    public Timestamp kommbExitTimeStamp() {
        return kommbExitTimeStamp;
    }

    @Deprecated
    public void setKommbExitTimeStamp(Timestamp kommbExitTimeStamp) {
        this.kommbExitTimeStamp = kommbExitTimeStamp;
    }

    @Deprecated
    public int indexGrwthType() {
        return indexGrwthType;
    }

    @Deprecated
    public void setIndexGrwthType(int indexGrwthType) {
        this.indexGrwthType = indexGrwthType;
    }

    @Deprecated
    public String cmpgCode() {
        return cmpgCode;
    }

    @Deprecated
    public void setCmpgCode(String cmpgCode) {
        this.cmpgCode = cmpgCode;
    }

    public long applicationNumber() {
        return applicationNumber;
    }

    public void setApplicationNumber(long applicationNumber) {
        this.applicationNumber = applicationNumber;
    }

    public int manCode() {
        return manCode;
    }

    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    @Deprecated
    public int srcSystem() {
        return srcSystem;
    }

    @Deprecated
    public void setSrcSystem(int srcSystem) {
        this.srcSystem = srcSystem;
    }

    public int currency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public long retroEventId() {
        return retroEventId;
    }

    public void setRetroEventId(long retroEventId) {
        this.retroEventId = retroEventId;
    }

    public int retroEventType() {
        return retroEventType;
    }

    public void setRetroEventType(int retroEventType) {
        this.retroEventType = retroEventType;
    }

    @Deprecated
    public int kommbInfoVer() {
        return kommbInfoVer;
    }

    @Deprecated
    public void setKommbInfoVer(int kommbInfoVer) {
        this.kommbInfoVer = kommbInfoVer;
    }

    public int raXerIndicator() {
        return raXerIndicator;
    }

    public void setRaXerIndicator(int raXerIndicator) {
        this.raXerIndicator = raXerIndicator;
    }

    /**
     * @return the kmbReferenceId
     */
    public long kmbReferenceId() {
        return kmbReferenceId;
    }

    /**
     * @param kmbReferenceId
     *            the kmbReferenceId to set
     */
    public void setKmbReferenceId(long kmbReferenceId) {
        this.kmbReferenceId = kmbReferenceId;
    }

    /**
     * @return the kmbExtractionTimestamp
     */
    public Timestamp kmbExtractionTimestamp() {
        return kmbExtractionTimestamp;
    }

    /**
     * @param kmbExtractionTimestamp
     *            the kmbExtractionTimestamp to set
     */
    public void setKmbExtractionTimestamp(Timestamp kmbExtractionTimestamp) {
        this.kmbExtractionTimestamp = kmbExtractionTimestamp;
    }

    /**
     * @return the eventInProcessType
     */
    public long eventInProcessType() {
        return eventInProcessType;
    }

    /**
     * @param eventInProcessType
     *            the eventInProcessType to set
     */
    public void setEventInProcessType(long eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    /**
     * @return the originalSalesEntitlementIndicator
     */
    public int originalSalesEntitlementIndicator() {
        return originalSalesEntitlementIndicator;
    }

    /**
     * @param originalSalesEntitlementIndicator
     *            the originalSalesEntitlementIndicator to set
     */
    public void setOriginalSalesEntitlementIndicator(int originalSalesEntitlementIndicator) {
        this.originalSalesEntitlementIndicator = originalSalesEntitlementIndicator;
    }

    /**
     * @return the creditDebitIndicator
     */
    public int creditDebitIndicator() {
        return creditDebitIndicator;
    }

    /**
     * @param creditDebitIndicator
     *            the creditDebitIndicator to set
     */
    public void setCreditDebitIndicator(int creditDebitIndicator) {
        this.creditDebitIndicator = creditDebitIndicator;
    }

    /**
     * @return the indexGrowthType
     */
    public int indexGrowthType() {
        return indexGrowthType;
    }

    /**
     * @param indexGrowthType
     *            the indexGrowthType to set
     */
    public void setIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
    }

    /**
     * @return the campaigCode
     */
    public String campaigCode() {
        return campaigCode;
    }

    /**
     * @param campaigCode
     *            the campaigCode to set
     */
    public void setCampaigCode(String campaigCode) {
        this.campaigCode = campaigCode;
    }

    /**
     * @return the commissionSplitPercentage
     */
    public long commissionSplitPercentage() {
        return commissionSplitPercentage;
    }

    /**
     * @param commissionSplitPercentage
     *            the commissionSplitPercentage to set
     */
    public void setCommissionSplitPercentage(long commissionSplitPercentage) {
        this.commissionSplitPercentage = commissionSplitPercentage;
    }

    /**
     * @return the taxGroupCode
     */
    public int taxGroupCode() {
        return taxGroupCode;
    }

    /**
     * @param taxGroupCode
     *            the taxGroupCode to set
     */
    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    /**
     * @return the clientPortfolioNumberInsured
     */
    public String clientPortfolioNumberInsured() {
        return clientPortfolioNumberInsured;
    }

    /**
     * @param clientPortfolioNumberInsured
     *            the clientPortfolioNumberInsured to set
     */
    public void setClientPortfolioNumberInsured(String clientPortfolioNumberInsured) {
        this.clientPortfolioNumberInsured = clientPortfolioNumberInsured;
    }

    /**
     * @return the clientSurnameInsured
     */
    public String clientSurnameInsured() {
        return clientSurnameInsured;
    }

    /**
     * @param clientSurnameInsured
     *            the clientSurnameInsured to set
     */
    public void setClientSurnameInsured(String clientSurnameInsured) {
        this.clientSurnameInsured = clientSurnameInsured;
    }

    /**
     * @return the clientInitialInsured
     */
    public String clientInitialInsured() {
        return clientInitialInsured;
    }

    /**
     * @param clientInitialInsured
     *            the clientInitialInsured to set
     */
    public void setClientInitialInsured(String clientInitialInsured) {
        this.clientInitialInsured = clientInitialInsured;
    }

    /**
     * @return the clientPortfolioNumberOwn
     */
    public String clientPortfolioNumberOwn() {
        return clientPortfolioNumberOwn;
    }

    /**
     * @param clientPortfolioNumberOwn
     *            the clientPortfolioNumberOwn to set
     */
    public void setClientPortfolioNumberOwn(String clientPortfolioNumberOwn) {
        this.clientPortfolioNumberOwn = clientPortfolioNumberOwn;
    }

    /**
     * @return the sourceSystem
     */
    public int sourceSystem() {
        return sourceSystem;
    }

    /**
     * @param sourceSystem
     *            the sourceSystem to set
     */
    public void setSourceSystem(int sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    /**
     * @return the premiumPaymentMethod
     */
    public int premiumPaymentMethod() {
        return premiumPaymentMethod;
    }

    /**
     * @param premiumPaymentMethod
     *            the premiumPaymentMethod to set
     */
    public void setPremiumPaymentMethod(int premiumPaymentMethod) {
        this.premiumPaymentMethod = premiumPaymentMethod;
    }

    /**
     * @return the negotiatedSalesPercentage
     */
    public String salesNegotiatedPercentage() {
        return formatDouble(salesNegotiatedPercentage);
    }

    /**
     * @param negotiatedSalesPercentage
     *            the negotiatedSalesPercentage to set
     */
    public void setSalesNegotiatedPercentage(double salesNegotiatedPercentage) {
        this.salesNegotiatedPercentage = String.valueOf(salesNegotiatedPercentage);
    }

    /**
     * @return the negotiatedServicePercentage
     */
    public String serviceNegotiatedPercentage() {
        return formatDouble(serviceNegotiatedPercentage);
    }

    /**
     * @param negotiatedServicePercentage
     *            the negotiatedServicePercentage to set
     */
    public void setServiceNegotiatedPercentage(double serviceNegotiatedPercentage) {
        this.serviceNegotiatedPercentage = String.valueOf(serviceNegotiatedPercentage);
    }

    /**
     * @return the numberOfPremiumsReceived
     */
    public int numberOfPremiumsReceived() {
        return numberOfPremiumsReceived;
    }

    /**
     * @param numberOfPremiumsReceived
     *            the numberOfPremiumsReceived to set
     */
    public void setNumberOfPremiumsReceived(int numberOfPremiumsReceived) {
        this.numberOfPremiumsReceived = numberOfPremiumsReceived;
    }

    /**
     * @return the replacementIndicator
     */
    public int replacementIndicator() {
        return replacementIndicator;
    }

    /**
     * @param replacementIndicator
     *            the replacementIndicator to set
     */
    public void setReplacementIndicator(int replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }

    /**
     * @return the serviceModelIndicator
     */
    public int serviceModelIndicator() {
        return serviceModelIndicator;
    }

    /**
     * @param serviceModelIndicator
     *            the serviceModelIndicator to set
     */
    public void setServiceModelIndicator(int serviceModelIndicator) {
        this.serviceModelIndicator = serviceModelIndicator;
    }

    /**
     * @return the conversionPolicyNumber
     */
    public String conversionPolicyNumber() {
        return conversionPolicyNumber;
    }

    /**
     * @param conversionPolicyNumber
     *            the conversionPolicyNumber to set
     */
    public void setConversionPolicyNumber(String conversionPolicyNumber) {
        this.conversionPolicyNumber = conversionPolicyNumber;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT KMIF_KMB_REF_ID,KMIF_INTM_NR,KMIF_POL_NR,"
                    + "KMIF_POL_INCP_DT,KMIF_MSTR_EVT_ID,KMIF_EVT_TYP,KMIF_EVT_EFF_DT,KMIF_SPLT_COMM_TYP,KMIF_TRCH_NR,"
                    + "KMIF_COMM_AMT,KMIF_VAT_AMT,KMIF_SCR_PRM,KMIF_POL_CNT,KMIF_TOT_SCR_PRM,KMIF_SCR_SPLT_PCT,KMIF_VAT_IND,"
                    + "KMIF_PMT_ACC,KMIF_EIP_ID,KMIF_EIP_TYP,KMIF_EIP_DT,KMIF_EVT_TRM,KMIF_ORI_ISE_IND,KMIF_CR_DT_IND,KMIF_IDX_GTH_TYP,KMIF_APP_NR,KMIF_MAN_CD,"
                    + "KMIF_CMPG_CD,KMIF_COMM_SPLT_PCT,KMIF_TAX_GRP_CD,KMIF_CLT_PF_NR_INS,KMIF_CLT_SUR_INS,KMIF_CLT_INI_INS,KMIF_CLT_PF_NR_OWN,KMIF_SRC_SYS,KMIF_PRD_TYP,"
                    + "KMIF_PRD_NAME_CD,KMIF_PRM_TYP,KMIF_PRM_PMT_METH,KMIF_PRM_FQ,KMIF_CURR,KMIF_EVT_ANN_PRM,KMIF_RTR_EVT_ID,KMIF_RTR_EVT_TYP,"
                    + "KMIF_RTR_EVT_TYP,KMIF_SLS_NEGO_PCT,KMIF_SRV_NEGO_PCT,KMIF_NO_PRM_RCVD,KMIF_CRTD_BY,KMIF_UPD_BY,KMIF_COMM_AMT_MON,"
                    + "KMIF_KMB_INF_VER,DM_LSTUPDDT,KMIF_REPL_IND,KMIF_RA_XER_IND,KMIF_OOFF_STYPE,KMIF_COM_PRO_TYPE,KMIF_ORIGIN,KMIF_SERVICE_MODEL_IND,KMIF_CONV_POL_NR "
                    + "FROM {0}KMIF_KMB_INF ORDER BY KMIF_KMB_REF_ID FOR FETCH ONLY WITH UR");

}

package za.co.sanlam.cms.service.batch;

import java.util.Arrays;

import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.util.db.DatabaseInitializer;

public class SetupBatchJob {

    private static final Logger LOGGER = LoggerFactory.getLogger(SetupBatchJob.class);

    private int batchKey;
    private String sqlSetupFileName;
    private int batchType = 0;
    private String tablesToClean;

    private DatabaseInitializer databaseInitializer;
    private BatchJobHandler batchHandler;

    public void beginTable() throws Exception {
        LOGGER.info("SetupReplacementBatch.beginTable()");
        if (databaseInitializer == null) {
            databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
        }
    }

    public void reset() {
    }

    public void execute() throws Exception {
        LOGGER.info("SetupReplacementBatch.execute()");
        LOGGER.info("batchKey : " + getBatchKey() + " :: " + batchKey);

        if (batchHandler == null) {
            batchHandler = (BatchJobHandler) BeanLocator.locateBean("batchJobHandler");
        }

        if (batchKey != 0) {

            // if set up data required, clear all tables
            if (sqlSetupFileName != null && !StringUtils.isEmpty(sqlSetupFileName)) {
                databaseInitializer.initialize();
                databaseInitializer.setUpData(sqlSetupFileName);
            } else if (tablesToClean != null) {
                // else just clear affected tables
                databaseInitializer.initialize(Arrays.asList(StringUtils.split(tablesToClean)));
            }

            batchHandler.processJob(batchKey, batchType);
        } else {
            throw new NotImplementedException("No batch key found!");
        }
    }

    public int getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(int batchKey) {
        this.batchKey = batchKey;
    }

    public String getSqlSetupFileName() {
        return sqlSetupFileName;
    }

    public void setSqlSetupFileName(String sqlSetupFileName) {
        this.sqlSetupFileName = sqlSetupFileName;
    }

    public void setBatchType(int batchType) {
        this.batchType = batchType;
    }

    /**
     * @return the tablesToClean
     */
    public String tablesToClean() {
        return tablesToClean;
    }

    /**
     * @param tablesToClean
     *            the tablesToClean to set
     */
    public void setTablesToClean(String tablesToClean) {
        this.tablesToClean = tablesToClean;
    }
}

/*
 * 
 */
package za.co.sanlam.cms.fixture.batch;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

/**
 */
public class FixtureTestAccountAdjustmentSummary extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestAccountAdjustmentSummary.class);

    private long accountAdjustmentId;
    private long masterEventId;
    private String policyNumber;
    private int cgeType;
    private long intermediaryNumber;
    private String splitCommissionType;
    private int creditDebitIndicator;
    private String productCode;
    private int taxGroupCode;
    private int currency;
    private String commissionAmount;
    private String vatAmount;
    private int paymentAccount;
    private int originalIndexEntitlementIndicator;
    private int replacementIndicator;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT ACAS_ACC_ADJ_ID,ACAS_MSTR_EVT_ID,ACAS_POL_NR,ACAS_CGE_TYP,ACAS_INTM_NR,"
                    + "ACAS_SPLT_COMM_TYP,ACAS_CR_DR_IND,ACAS_PRD_CD,ACAS_TAX_GRP_CD,ACAS_CURR,ACAS_COMM_AMT,ACAS_VAT_AMT,"
                    + "ACAS_PMT_ACC,ACAS_ORI_ISE_IND,ACAS_CRTD_BY,ACAS_UPD_BY,ACAS_CRTD_TMST,ACAS_UPD_TMST,ACAS_ADJ_SUM_VER,"
                    + "DM_LSTUPDDT,ACAS_REPL_IND FROM {0}ACAS_ADJ_SUM  ORDER BY ACAS_ACC_ADJ_ID FOR FETCH ONLY WITH UR");

    public FixtureTestAccountAdjustmentSummary() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setAccountAdjustmentId(getResultSet().getLong("ACAS_ACC_ADJ_ID"));
            setMasterEventId(getResultSet().getLong("ACAS_MSTR_EVT_ID"));
            setPolicyNumber(getResultSet().getString("ACAS_POL_NR"));
            setCgeType(getResultSet().getInt("ACAS_CGE_TYP"));
            setIntermediaryNumber(getResultSet().getLong("ACAS_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("ACAS_SPLT_COMM_TYP").trim());
            setCreditDebitIndicator(getResultSet().getInt("ACAS_CR_DR_IND"));
            setProductCode(getResultSet().getString("ACAS_PRD_CD").trim());
            setTaxGroupCode(getResultSet().getInt("ACAS_TAX_GRP_CD"));
            setCurrency(getResultSet().getInt("ACAS_CURR"));
            setCommissionAmount(formatDouble(getResultSet().getDouble("ACAS_COMM_AMT")));
            setVatAmount(formatDouble(getResultSet().getDouble("ACAS_VAT_AMT")));
            setPaymentAccount(getResultSet().getInt("ACAS_PMT_ACC"));
            setOriginalIndexEntitlementIndicator(getResultSet().getInt("ACAS_ORI_ISE_IND"));
            setReplacementIndicator(getResultSet().getInt("ACAS_REPL_IND"));
            setCreatedBy(getResultSet().getString("ACAS_CRTD_BY"));
            setUpdatedBy(getResultSet().getString("ACAS_UPD_BY"));
            setVersion(getResultSet().getInt("ACAS_ADJ_SUM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestAccountAdjustmentSummary", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestAccountAdjustmentSummary", se);
            }
        }
    }

    /**
     * @return the accountAdjustmentId
     */
    public long accountAdjustmentId() {
        return accountAdjustmentId;
    }

    /**
     * @param accountAdjustmentId
     *            the accountAdjustmentId to set
     */
    public void setAccountAdjustmentId(long accountAdjustmentId) {
        this.accountAdjustmentId = accountAdjustmentId;
    }

    /**
     * @return the masterEventId
     */
    public long masterEventId() {
        return masterEventId;
    }

    /**
     * @param masterEventId
     *            the masterEventId to set
     */
    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    /**
     * @return the policyNumber
     */
    public String policyNumber() {
        return policyNumber;
    }

    /**
     * @param policyNumber
     *            the policyNumber to set
     */
    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    /**
     * @return the cgeType
     */
    public int cgeType() {
        return cgeType;
    }

    /**
     * @param cgeType
     *            the cgeType to set
     */
    public void setCgeType(int cgeType) {
        this.cgeType = cgeType;
    }

    /**
     * @return the intermediaryNumber
     */
    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    /**
     * @param intermediaryNumber
     *            the intermediaryNumber to set
     */
    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    /**
     * @return the splitCommissionType
     */
    public String splitCommissionType() {
        return splitCommissionType;
    }

    /**
     * @param splitCommissionType
     *            the splitCommissionType to set
     */
    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    /**
     * @return the creditDebitIndicator
     */
    public int creditDebitIndicator() {
        return creditDebitIndicator;
    }

    /**
     * @param creditDebitIndicator
     *            the creditDebitIndicator to set
     */
    public void setCreditDebitIndicator(int creditDebitIndicator) {
        this.creditDebitIndicator = creditDebitIndicator;
    }

    /**
     * @return the productCode
     */
    public String productCode() {
        return productCode;
    }

    /**
     * @param productCode
     *            the productCode to set
     */
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    /**
     * @return the taxGroupCode
     */
    public int taxGroupCode() {
        return taxGroupCode;
    }

    /**
     * @param taxGroupCode
     *            the taxGroupCode to set
     */
    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    /**
     * @return the currency
     */
    public int currency() {
        return currency;
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(int currency) {
        this.currency = currency;
    }

    /**
     * @return the commissionAmount
     */
    public String commissionAmount() {
        return commissionAmount;
    }

    /**
     * @param commissionAmount
     *            the commissionAmount to set
     */
    public void setCommissionAmount(String commissionAmount) {
        this.commissionAmount = commissionAmount;
    }

    /**
     * @return the vatAmount
     */
    public String vatAmount() {
        return vatAmount;
    }

    /**
     * @param vatAmount
     *            the vatAmount to set
     */
    public void setVatAmount(String vatAmount) {
        this.vatAmount = vatAmount;
    }

    /**
     * @return the paymentAccount
     */
    public int paymentAccount() {
        return paymentAccount;
    }

    /**
     * @param paymentAccount
     *            the paymentAccount to set
     */
    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    /**
     * @return the originalIndexEntitlementIndicator
     */
    public int originalIndexEntitlementIndicator() {
        return originalIndexEntitlementIndicator;
    }

    /**
     * @param originalIndexEntitlementIndicator
     *            the originalIndexEntitlementIndicator to set
     */
    public void setOriginalIndexEntitlementIndicator(int originalIndexEntitlementIndicator) {
        this.originalIndexEntitlementIndicator = originalIndexEntitlementIndicator;
    }

    /**
     * @return the replacementIndicator
     */
    public int replacementIndicator() {
        return replacementIndicator;
    }

    /**
     * @param replacementIndicator
     *            the replacementIndicator to set
     */
    public void setReplacementIndicator(int replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }

}

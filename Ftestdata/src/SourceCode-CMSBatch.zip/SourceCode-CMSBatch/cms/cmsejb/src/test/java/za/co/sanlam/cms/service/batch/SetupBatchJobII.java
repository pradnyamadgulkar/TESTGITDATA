package za.co.sanlam.cms.service.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.util.db.DatabaseInitializer;
@Deprecated
public class SetupBatchJobII {

    private static final Logger LOGGER = LoggerFactory.getLogger(SetupBatchJobII.class);
    private String batchKey;
    private String sqlSetupFileName;
    private int dbInitializeLevel = 0;
    private int batchType = 0;

    private DatabaseInitializer databaseInitializer;
    private BatchJobHandler batchHandler;

    public void beginTable() throws Exception {
        LOGGER.info("SetupReplacementBatch.beginTable()");
        if (databaseInitializer == null) {
            databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
        }
    }

    public void reset() {
    }

    public void execute() throws Exception {
        LOGGER.info("batchKey : " + batchKey);
        LOGGER.info("dbInitializeLevel : " + dbInitializeLevel);
        if (batchHandler == null) {
            batchHandler = (BatchJobHandler) BeanLocator.locateBean("batchJobHandler");
        }
        if (batchKey != null && !batchKey.trim().equals("")) {
            if (dbInitializeLevel == 1) {
                // only initialize replacement tables
                databaseInitializer.initializeReplacement();
            }
            if (dbInitializeLevel == 2) {
                // initialize all business tables
                databaseInitializer.initialize();
            }
            
            if (dbInitializeLevel == 3) {
                // initialize all business tables
                databaseInitializer.initializeAssissa();
            }

            if (sqlSetupFileName != null && !sqlSetupFileName.trim().equals("")) {
                LOGGER.info("Executing SQL : " + sqlSetupFileName);
                databaseInitializer.setUpData(sqlSetupFileName);
            }
            batchHandler.processJob(Integer.parseInt(batchKey), batchType);
        } else {
            throw new Exception("No Batch Key Found!!!");
        }
    }

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public String getSqlSetupFileName() {
        return sqlSetupFileName;
    }

    public void setSqlSetupFileName(String sqlSetupFileName) {
        this.sqlSetupFileName = sqlSetupFileName;
    }

    public int getDbInitializeLevel() {
        return dbInitializeLevel;
    }

    public void setDbInitializeLevel(int dbInitializeLevel) {
        this.dbInitializeLevel = dbInitializeLevel;
    }

    public int getBatchType() {
        return batchType;
    }

    public void setBatchType(int batchType) {
        this.batchType = batchType;
    }
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PMIN_PMT_INF table.
 */
public class FixtureTestPaymentInfo extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPaymentInfo.class);

    private long paymentId;
    private String policyNumber;
    private long masterEventId;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private String splitCommissionId;
    private int scheduleType;
    private int trancheNumber;
    private String commissionAmount;
    private String vatAmount;
    private int vatIndicator;
    private int taxGroupCode;
    private int taxGrpCode;
    private String paymentDate;
    private int paymentAccount;
    private long eventInProcessId;
    private long kmbReferenceId;
    private long kommbRefId;
    private long skekReferenceId;
    private long skekRefId;
    private String vestingPercentage;
    private String vestingPerctage;
    private String eventInProcessDate;
    private int numberOfPremiumsReceived;
    private int NumberOfPremiumsRcvd;
    private int originalSalesEntitlementIndicator;
    private int origSalesEntitlementIndicator;
    private int creditDebitIndicator;
    private int creditDebtIndicator;
    private long retroEventId;
    private String eventAnnualPremium;
    private int oneOffPaymentId;
    private int kmbProcessStatus;
    private int kommbProcessStatus;
    private int infoVer;
    private int replacementIndicator;
    private int replacementInd;
    private int oneOffSubType;

    private String lastUpdated;

    public FixtureTestPaymentInfo() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestPayment.execute()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setPaymentId(getResultSet().getLong("PMIN_PMT_ID"));
            setPolicyNumber(getResultSet().getString("PMIN_POL_NR"));
            setMasterEventId(getResultSet().getLong("PMIN_MSTR_EVT_ID"));
            setElementNumber(getResultSet().getInt("PMIN_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getInt("PMIN_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("PMIN_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getString("PMIN_SPLT_COMM_ID").trim());
            setScheduleType(getResultSet().getInt("PMIN_SCHD_TYP"));
            setTrancheNumber(getResultSet().getInt("PMIN_TRCH_NR"));
            setCommissionAmount(getResultSet().getDouble("PMIN_COMM_AMT"));
            setVatAmount(getResultSet().getDouble("PMIN_VAT_AMT"));
            setVatIndicator(getResultSet().getInt("PMIN_VAT_IND"));
            setTaxGroupCode(getResultSet().getInt("PMIN_TAX_GRP_CD"));
            setPaymentDate(format(getResultSet().getDate("PMIN_PMT_DT")));
            setPaymentAccount(getResultSet().getInt("PMIN_PMT_ACC"));
            setEventInProcessId(getResultSet().getInt("PMIN_EIP_ID"));
            setKmbReferenceId(getResultSet().getLong("PMIN_KMB_REF_ID"));
            setSkekReferenceId(getResultSet().getLong("PMIN_SKEK_REF_ID"));
            setVestingPercentage(getResultSet().getDouble("PMIN_VST_PCT"));
            setEventInProcessDate(format(getResultSet().getDate("PMIN_EIP_DT")));
            setNumberOfPremiumsReceived(getResultSet().getInt("PMIN_NO_PRM_RCVD"));
            setOriginalSalesEntitlementIndicator(getResultSet().getInt("PMIN_ORI_ISE_IND"));
            setCreditDebitIndicator(getResultSet().getInt("PMIN_CR_DR_IND"));
            setRetroEventId(getResultSet().getInt("PMIN_RTR_VAT_ID"));
            setEventAnnualPremium(getResultSet().getDouble("PMIN_ANN_PRM"));
            setOneOffPaymentId(getResultSet().getInt("PMIN_1OFF_PMT_ID"));
            setKmbProcessStatus(getResultSet().getInt("PMIN_KMB_PRC_STS"));
            setCreatedBy(getResultSet().getString("PMIN_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PMIN_UPD_BY").trim());
            setVersion(getResultSet().getInt("PMIN_PMT_INF_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setReplacementIndicator(getResultSet().getInt("PMIN_REPL_IND"));
            setOneOffSubType(getResultSet().getInt("PMIN_OOFF_STYPE"));

            setTaxGrpCode(taxGroupCode());
            setKommbRefId(kmbReferenceId());
            setSkekRefId(skekReferenceId());
            setVestingPerctage(Double.parseDouble(vestingPercentage()));
            setNumberOfPremiumsRcvd(numberOfPremiumsReceived());
            setOrigSalesEntitlementIndicator(originalSalesEntitlementIndicator());
            setCreditDebtIndicator(creditDebitIndicator());
            setKommbProcessStatus(kmbProcessStatus());
            setInfoVer(version());
            setReplacementInd(replacementIndicator());
            setLastUpdated(lastUpdatedDate());

        } catch (SQLException ex1) {
            LOG.error(" Exception Encountered in operation execute of class FixtureTestPayment", ex1);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestPayment", se);
            }
        }
    }

    /**
     * @return the originalSalesEntitlementIndicator
     */
    public int originalSalesEntitlementIndicator() {
        return originalSalesEntitlementIndicator;
    }

    /**
     * @param originalSalesEntitlementIndicator
     *            the originalSalesEntitlementIndicator to set
     */
    public void setOriginalSalesEntitlementIndicator(int originalSalesEntitlementIndicator) {
        this.originalSalesEntitlementIndicator = originalSalesEntitlementIndicator;
    }

    /**
     * @return the taxGroupCode
     */
    public int taxGroupCode() {
        return taxGroupCode;
    }

    /**
     * @param taxGroupCode
     *            the taxGroupCode to set
     */
    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    /**
     * @return the kmbReferenceId
     */
    public long kmbReferenceId() {
        return kmbReferenceId;
    }

    /**
     * @param kmbReferenceId
     *            the kmbReferenceId to set
     */
    public void setKmbReferenceId(long kmbReferenceId) {
        this.kmbReferenceId = kmbReferenceId;
    }

    /**
     * @return the skekReferenceId
     */
    public long skekReferenceId() {
        return skekReferenceId;
    }

    /**
     * @param skekReferenceId
     *            the skekReferenceId to set
     */
    public void setSkekReferenceId(long skekReferenceId) {
        this.skekReferenceId = skekReferenceId;
    }

    /**
     * @return the vestingPercentage
     */
    public String vestingPercentage() {
        return formatDouble(vestingPercentage);
    }

    /**
     * @param vestingPercentage
     *            the vestingPercentage to set
     */
    public void setVestingPercentage(double vestingPercentage) {
        this.vestingPercentage = String.valueOf(vestingPercentage);
    }

    /**
     * @return the numberOfPremiumsReceived
     */
    public int numberOfPremiumsReceived() {
        return numberOfPremiumsReceived;
    }

    /**
     * @param numberOfPremiumsReceived
     *            the numberOfPremiumsReceived to set
     */
    public void setNumberOfPremiumsReceived(int numberOfPremiumsReceived) {
        this.numberOfPremiumsReceived = numberOfPremiumsReceived;
    }

    /**
     * @return the creditDebitIndicator
     */
    public int creditDebitIndicator() {
        return creditDebitIndicator;
    }

    /**
     * @param creditDebitIndicator
     *            the creditDebitIndicator to set
     */
    public void setCreditDebitIndicator(int creditDebitIndicator) {
        this.creditDebitIndicator = creditDebitIndicator;
    }

    /**
     * @return the kmbProcessStatus
     */
    public int kmbProcessStatus() {
        return kmbProcessStatus;
    }

    /**
     * @param kmbProcessStatus
     *            the kmbProcessStatus to set
     */
    public void setKmbProcessStatus(int kmbProcessStatus) {
        this.kmbProcessStatus = kmbProcessStatus;
    }

    /**
     * @return the replacementIndicator
     */
    public int replacementIndicator() {
        return replacementIndicator;
    }

    /**
     * @param replacementIndicator
     *            the replacementIndicator to set
     */
    public void setReplacementIndicator(int replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }

    public long paymentId() {
        return paymentId;
    }

    public void setPaymentId(long paymentId) {
        this.paymentId = paymentId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public String splitCommissionId() {
        return splitCommissionId;
    }

    public void setSplitCommissionId(String splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    public int scheduleType() {
        return scheduleType;
    }

    public void setScheduleType(int scheduleType) {
        this.scheduleType = scheduleType;
    }

    public int trancheNumber() {
        return trancheNumber;
    }

    public void setTrancheNumber(int trancheNumber) {
        this.trancheNumber = trancheNumber;
    }

    public String commissionAmount() {
        return formatDouble(commissionAmount);
    }

    public void setCommissionAmount(double commissionAmount) {
        this.commissionAmount = String.valueOf(commissionAmount);
    }

    public String vatAmount() {
        return formatDouble(vatAmount);
    }

    public void setVatAmount(double vatAmount) {
        this.vatAmount = String.valueOf(vatAmount);
    }

    public int vatIndicator() {
        return vatIndicator;
    }

    public void setVatIndicator(int vatIndicator) {
        this.vatIndicator = vatIndicator;
    }

    @Deprecated
    public int taxGrpCode() {
        return taxGrpCode;
    }

    @Deprecated
    public void setTaxGrpCode(int taxGrpCode) {
        this.taxGrpCode = taxGrpCode;
    }

    public String paymentDate() {
        return paymentDate;
    }

    @Deprecated
    public int infoVer() {
        return infoVer;
    }

    @Deprecated
    public void setInfoVer(int infoVer) {
        this.infoVer = infoVer;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public int paymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    @Deprecated
    public long kommbRefId() {
        return kommbRefId;
    }

    @Deprecated
    public void setKommbRefId(long kommbRefId) {
        this.kommbRefId = kommbRefId;
    }

    @Deprecated
    public long skekRefId() {
        return skekRefId;
    }

    @Deprecated
    public void setSkekRefId(long skekRefId) {
        this.skekRefId = skekRefId;
    }

    @Deprecated
    public String vestingPerctage() {
        if (vestingPerctage != null) {
            if (BigDecimal.valueOf(Double.parseDouble(vestingPerctage)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(vestingPerctage).intValue());
            }
        }
        return vestingPerctage;
    }

    @Deprecated
    public void setVestingPerctage(double vestingPerctage) {
        this.vestingPerctage = Double.toString(vestingPerctage);
    }

    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    @Deprecated
    public int numberOfPremiumsRcvd() {
        return NumberOfPremiumsRcvd;
    }

    @Deprecated
    public void setNumberOfPremiumsRcvd(int numberOfPremiumsRcvd) {
        NumberOfPremiumsRcvd = numberOfPremiumsRcvd;
    }

    @Deprecated
    public int origSalesEntitlementIndicator() {
        return origSalesEntitlementIndicator;
    }

    @Deprecated
    public void setOrigSalesEntitlementIndicator(int origSalesEntitlementIndicator) {
        this.origSalesEntitlementIndicator = origSalesEntitlementIndicator;
    }

    @Deprecated
    public int creditDebtIndicator() {
        return creditDebtIndicator;
    }

    @Deprecated
    public void setCreditDebtIndicator(int creditDebtIndicator) {
        this.creditDebtIndicator = creditDebtIndicator;
    }

    public long retroEventId() {
        return retroEventId;
    }

    public void setRetroEventId(long retroEventId) {
        this.retroEventId = retroEventId;
    }

    public String eventAnnualPremium() {
        return formatDouble(eventAnnualPremium);
    }

    public void setEventAnnualPremium(double eventAnnualPremium) {
        this.eventAnnualPremium = String.valueOf(eventAnnualPremium);
    }

    public int oneOffPaymentId() {
        return oneOffPaymentId;
    }

    public void setOneOffPaymentId(int oneOffPaymentId) {
        this.oneOffPaymentId = oneOffPaymentId;
    }

    @Deprecated
    public int kommbProcessStatus() {
        return kommbProcessStatus;
    }

    @Deprecated
    public void setKommbProcessStatus(int kommbProcessStatus) {
        this.kommbProcessStatus = kommbProcessStatus;
    }

    @Deprecated
    public int replacementInd() {
        return replacementInd;
    }

    @Deprecated
    public void setReplacementInd(int replacementInd) {
        this.replacementInd = replacementInd;
    }

    public int oneOffSubType() {
        return oneOffSubType;
    }

    public void setOneOffSubType(int oneOffSubType) {
        this.oneOffSubType = oneOffSubType;
    }

    @Deprecated
    public String lastUpdated() {
        return lastUpdated;
    }

    @Deprecated
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PMIN_PMT_ID, PMIN_POL_NR,PMIN_MSTR_EVT_ID,"
                    + "PMIN_ELMT_NR,PMIN_INTM_NR,PMIN_SPLT_COMM_TYP,PMIN_SPLT_COMM_ID,PMIN_SCHD_TYP,PMIN_TRCH_NR,"
                    + "PMIN_COMM_AMT,PMIN_VAT_AMT,PMIN_VAT_IND,PMIN_TAX_GRP_CD,PMIN_PMT_DT,PMIN_PMT_ACC,PMIN_EIP_ID,"
                    + "PMIN_KMB_REF_ID,PMIN_SKEK_REF_ID,PMIN_VST_PCT,PMIN_EIP_DT,PMIN_NO_PRM_RCVD,PMIN_ORI_ISE_IND,PMIN_CR_DR_IND,"
                    + "PMIN_RTR_VAT_ID,PMIN_ANN_PRM,PMIN_1OFF_PMT_ID,PMIN_KMB_PRC_STS,PMIN_CRTD_BY,PMIN_UPD_BY,"
                    + "PMIN_PMT_INF_VER,DM_LSTUPDDT,PMIN_REPL_IND,PMIN_OOFF_STYPE FROM "
                    + "{0}PMIN_PMT_INF "
                    + "ORDER BY PMIN_MSTR_EVT_ID, PMIN_ELMT_NR, PMIN_INTM_NR, PMIN_SPLT_COMM_TYP, PMIN_SPLT_COMM_ID, PMIN_SCHD_TYP, PMIN_TRCH_NR, PMIN_PMT_ID "
                    //+ "ORDER BY PMIN_MSTR_EVT_ID, PMIN_ELMT_NR, PMIN_EIP_ID, PMIN_SPLT_COMM_TYP, PMIN_TRCH_NR, PMIN_VAT_IND, "
                    //+ "PMIN_CR_DR_IND, PMIN_RTR_VAT_ID, PMIN_INTM_NR, PMIN_PMT_ACC 
                    + "FOR FETCH ONLY WITH UR");

}
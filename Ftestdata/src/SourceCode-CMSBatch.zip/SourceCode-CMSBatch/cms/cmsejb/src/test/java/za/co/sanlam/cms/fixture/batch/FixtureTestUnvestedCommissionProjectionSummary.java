package za.co.sanlam.cms.fixture.batch;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestUnvestedCommissionProjectionSummary extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestUnvestedCommissionProjectionSummary.class);

    private long batchId;
    private long intermediaryNumber;
    private String policyNumber;
    private String totalCommissionAmount;
    private String totalVatAmount;
    private String extractionDate;
    private int versionNumber;
    private int contractStatus;

    public FixtureTestUnvestedCommissionProjectionSummary() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet()) {
                return;
            }
            LOGGER.debug("execute" + rowNumber());
            setResultSetPosition();

            setBatchId(getResultSet().getLong("PUCS_UVST_BAT_ID"));
            setPolicyNumber(getResultSet().getString("PUCS_POL_NR"));
            setIntermediaryNumber(getResultSet().getLong("PUCS_INTM_NR"));
            setTotalCommissionAmount(getResultSet().getDouble("PUCS_TOT_COMM_AMT"));
            setTotalVatAmount(getResultSet().getDouble("PUCS_TOT_VAT_AMT"));
            setExtractionDate(format(getResultSet().getDate("PUCS_UVST_EXT_DT")));
            setCreatedBy(getResultSet().getString("PUCS_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PUCS_UPD_BY").trim());
            setVersion(getResultSet().getInt("PUCS_UVST_SUM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setContractStatus(getResultSet().getInt("PUCS_CNTR_STS"));

            setVersionNumber(getResultSet().getInt("PUCS_UVST_SUM_VER"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestUnvestedCommissionProjectionSummary", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestUnvestedCommissionProjectionSummary", se);
            }
        }
    }

    public long batchId() {
        return batchId;
    }

    public void setBatchId(long batchId) {
        this.batchId = batchId;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String totalCommissionAmount() {
        return formatDouble(totalCommissionAmount);
    }

    public void setTotalCommissionAmount(double totalCommissionAmount) {
        this.totalCommissionAmount = String.valueOf(totalCommissionAmount);
    }

    public String totalVatAmount() {
        return formatDouble(totalVatAmount);
    }

    public void setTotalVatAmount(double totalVatAmount) {
        this.totalVatAmount = String.valueOf(totalVatAmount);
    }

    public String extractionDate() {
        return extractionDate;
    }

    public void setExtractionDate(String extractionDate) {
        this.extractionDate = extractionDate;
    }

    @Deprecated
    public int versionNumber() {
        return versionNumber;
    }

    @Deprecated
    public void setVersionNumber(int versionNumber) {
        this.versionNumber = versionNumber;
    }

    public int contractStatus() {
        return contractStatus;
    }

    public void setContractStatus(int contractStatus) {
        this.contractStatus = contractStatus;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PUCS_UVST_BAT_ID, PUCS_INTM_NR, PUCS_TOT_COMM_AMT, PUCS_TOT_VAT_AMT, PUCS_UVST_EXT_DT, "
                    + "PUCS_CRTD_BY, PUCS_UPD_BY, PUCS_UVST_SUM_VER, DM_LSTUPDDT, PUCS_CNTR_STS, PUCS_POL_NR  "
                    + "FROM {0}PUCS_UVST_SUM " + "ORDER BY PUCS_UVST_BAT_ID " + "FOR FETCH ONLY WITH UR");

}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PTRI_PRE_TRAN table.
 */
public class FixtureTestPreTran extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPreTran.class);

    private long preTranRefId;
    private String policyNumber;
    private String policyInceptionDate;
    private String productType;
    private String productNameCode;
    private String clientOwnerPortfolioNumber;
    private String clientInsuredPortfolioNumber;
    private String clientInsuredSurname;
    private String clientInsuredInitial;
    private int currency;
    private int srcSystem;
    private String policyNumberConv;
    private String policyIssueDate;
    private int convIndicator;
    private int eventType;
    private String eventEffectiveDate;
    private String premiumHolidayEndDate;
    private String commissionType;
    private String premiumRdnPercntage;
    private int indexGrwthType;
    private String cmpgCode;
    private int indexOpIndicator;
    private int taxGrpCode;
    private int numberOfElemnts;
    private int rParIndicator;
    private int splRinstIndicator;
    private String transactionTimestamp;
    private int numberOfPremiumsRcvd;
    private int premiumFrequency;
    private int premiumPaymntMethod;
    private String rValPremiumInArr;
    private String policyTotalPremium;
    private int warningLevel;
    private String applicationDate;
    private String quotationDate;
    private int elementNumber;
    private String elementStrtDate;
    private int elementTerm;
    private String premiumPerFrquency;
    private String salesCommission;
    private String serviceCommission;
    private String renServiceCommission;
    private String negSalesPercentage;
    private String negServicePercentage;
    private int preTranInfoVer;
    private String seller;
    private String fundValue;
    private String fundCommission;
    private int raXerIndicator;
    private int scoreTerm; // --
    private int batchPrcSts;
    private String elementScorePremium;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PTRI_PTIN_REF_ID,PTRI_POL_NR,PTRI_POL_INCP_DT,PTRI_PRD_TYP,PTRI_PRD_NAME_CD,PTRI_CLT_PF_NR_OWN,PTRI_CLT_PF_NR_INS,"
                    + "PTRI_CLT_SUR_INS,PTRI_CLT_INI_INS,PTRI_CURR,PTRI_SRC_SYS,PTRI_POL_NR_CONV,PTRI_POL_ISSUE_DT,PTRI_CONV_IND,"
                    + "PTRI_EVT_TYP,PTRI_EVT_EFF_DT,PTRI_PRM_HOL_ED_DT,PTRI_COMM_TYP,PTRI_PRM_RDN_PCT,PTRI_IDX_GTH_TYP,PTRI_CMPG_CD,"
                    + "PTRI_IDX_OP_IND,PTRI_TAX_GRP_CD,PTRI_NR_OF_ELMTS,PTRI_RPAR_IND,PTRI_SPL_RINST_IND,PTRI_TRANSACT_TMST,PTRI_NR_PRM_RCVD,"
                    + "PTRI_PRM_FQ,PTRI_PRM_PMT_METH,PTRI_RVALPRM_INARR,PTRI_POL_TOT_PRM,PTRI_WRNG_LEVEL,PTRI_APP_DT,PTRI_QTE_DT,PTRI_ELMT_NR,"
                    + "PTRI_ELMT_START_DT,PTRI_ELMT_TRM,PTRI_PRM_PER_FQ,PTRI_SLS_COMM,PTRI_SRV_COMM,PTRI_REN_SERV_COMM,PTRI_SLS_NEGO_PCT,PTRI_SRV_NEGO_PCT,"
                    + "PTRI_CRTD_BY,PTRI_UPD_BY,PTRI_PRE_TRAN_VER,DM_LSTUPDDT,PTRI_SELLER,PTRI_FUND_VALUE,PTRI_FUND_COMM,"
                    + "PTRI_RA_XER_IND,PTRI_SCR_TRM, PTRI_BATCH_PRC_STS, PTRI_ELMT_SCR_PRM FROM {0}PTRI_PRE_TRAN ORDER BY PTRI_PTIN_REF_ID FOR FETCH ONLY WITH UR");

    public void beginTable() throws SQLException {
        LOG.debug("Entering FixtureTestPreTran.beginTable()");

        setSqlQuery(SQL_QUERY);

        super.beginTable();

        LOG.debug("Exit FixtureTestPreTran.beginTable()");
    }

    public void execute() {
        LOG.debug("Entering FixtureTestPreTran.execute()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setPreTranRefId(getResultSet().getLong("PTRI_PTIN_REF_ID"));
            setPolicyNumber(getResultSet().getString("PTRI_POL_NR"));
            setPolicyInceptionDate(format(getResultSet().getDate("PTRI_POL_INCP_DT")));
            setProductType(getResultSet().getString("PTRI_PRD_TYP").trim());
            setProductNameCode(getResultSet().getString("PTRI_PRD_NAME_CD").trim());
            setClientOwnerPortfolioNumber(getResultSet().getString("PTRI_CLT_PF_NR_OWN").trim());
            setClientInsuredPortfolioNumber(getResultSet().getString("PTRI_CLT_PF_NR_INS").trim());
            setClientInsuredSurname(getResultSet().getString("PTRI_CLT_SUR_INS").trim());
            setClientInsuredInitial(getResultSet().getString("PTRI_CLT_INI_INS").trim());
            setCurrency(getResultSet().getInt("PTRI_CURR"));
            setSrcSystem(getResultSet().getInt("PTRI_SRC_SYS"));
            setPolicyNumberConv(getResultSet().getString("PTRI_POL_NR_CONV"));
            setPolicyIssueDate(format(getResultSet().getDate("PTRI_POL_ISSUE_DT")));
            setConvIndicator(getResultSet().getInt("PTRI_CONV_IND"));
            setEventType(getResultSet().getInt("PTRI_EVT_TYP"));
            setEventEffectiveDate(format(getResultSet().getDate("PTRI_EVT_EFF_DT")));
            setPremiumHolidayEndDate(format(getResultSet().getDate("PTRI_PRM_HOL_ED_DT")));
            setCommissionType(getResultSet().getString("PTRI_COMM_TYP").trim());
            setPremiumRdnPercntage(getResultSet().getDouble("PTRI_PRM_RDN_PCT"));
            setIndexGrwthType(getResultSet().getInt("PTRI_IDX_GTH_TYP"));
            setCmpgCode(getResultSet().getString("PTRI_CMPG_CD").trim());
            setIndexOpIndicator(getResultSet().getInt("PTRI_IDX_OP_IND"));
            setTaxGrpCode(getResultSet().getInt("PTRI_TAX_GRP_CD"));
            setNumberOfElemnts(getResultSet().getInt("PTRI_NR_OF_ELMTS"));
            setrParIndicator(getResultSet().getInt("PTRI_RPAR_IND"));
            setSplRinstIndicator(getResultSet().getInt("PTRI_SPL_RINST_IND"));
            setTransactionTimestamp(format(getResultSet().getTimestamp("PTRI_TRANSACT_TMST")));
            setNumberOfPremiumsRcvd(getResultSet().getInt("PTRI_NR_PRM_RCVD"));
            setPremiumFrequency(getResultSet().getInt("PTRI_PRM_FQ"));
            setPremiumPaymntMethod(getResultSet().getInt("PTRI_PRM_PMT_METH"));
            setrValPremiumInArr(getResultSet().getDouble("PTRI_RVALPRM_INARR"));
            setPolicyTotalPremium(getResultSet().getDouble("PTRI_POL_TOT_PRM"));
            setWarningLevel(getResultSet().getInt("PTRI_WRNG_LEVEL"));
            setApplicationDate(format(getResultSet().getDate("PTRI_APP_DT")));
            setQuotationDate(format(getResultSet().getDate("PTRI_QTE_DT")));
            setElementNumber(getResultSet().getInt("PTRI_ELMT_NR"));
            setElementStrtDate(format(getResultSet().getDate("PTRI_ELMT_START_DT")));
            setElementTerm(getResultSet().getInt("PTRI_ELMT_TRM"));
            setPremiumPerFrquency(getResultSet().getDouble("PTRI_PRM_PER_FQ"));
            setSalesCommission(getResultSet().getDouble("PTRI_SLS_COMM"));
            setServiceCommission(getResultSet().getDouble("PTRI_SRV_COMM"));
            setRenServiceCommission(getResultSet().getDouble("PTRI_REN_SERV_COMM"));
            setNegSalesPercentage(getResultSet().getDouble("PTRI_SLS_NEGO_PCT"));
            setNegServicePercentage(getResultSet().getDouble("PTRI_SRV_NEGO_PCT"));
            setCreatedBy(getResultSet().getString("PTRI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PTRI_UPD_BY").trim());
            setPreTranInfoVer(getResultSet().getInt("PTRI_PRE_TRAN_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setSeller(getResultSet().getString("PTRI_SELLER"));
            setFundValue(getResultSet().getDouble("PTRI_FUND_VALUE"));
            setFundCommission(getResultSet().getDouble("PTRI_FUND_COMM"));
            setRaXerIndicator(getResultSet().getInt("PTRI_RA_XER_IND"));
            setScoreTerm(getResultSet().getInt("PTRI_SCR_TRM"));
            setBatchPrcSts(getResultSet().getInt("PTRI_BATCH_PRC_STS"));
            setElementScorePremium(getResultSet().getDouble("PTRI_ELMT_SCR_PRM"));

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestPreTran", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestPreTran", se);
            }
        }

        LOG.debug("Exit FixtureTestPreTran.execute()");
    }

    public long preTranRefId() {
        return preTranRefId;
    }

    public void setPreTranRefId(long preTranRefId) {
        this.preTranRefId = preTranRefId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String policyInceptionDate() {
        return policyInceptionDate;
    }

    public void setPolicyInceptionDate(String policyInceptionDate) {
        this.policyInceptionDate = policyInceptionDate;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String productNameCode() {
        return productNameCode;
    }

    public void setProductNameCode(String productNameCode) {
        this.productNameCode = productNameCode;
    }

    public String clientOwnerPortfolioNumber() {
        return clientOwnerPortfolioNumber;
    }

    public void setClientOwnerPortfolioNumber(String clientOwnerPortfolioNumber) {
        this.clientOwnerPortfolioNumber = clientOwnerPortfolioNumber;
    }

    public String clientInsuredPortfolioNumber() {
        return clientInsuredPortfolioNumber;
    }

    public void setClientInsuredPortfolioNumber(String clientInsuredPortfolioNumber) {
        this.clientInsuredPortfolioNumber = clientInsuredPortfolioNumber;
    }

    public String clientInsuredSurname() {
        return clientInsuredSurname;
    }

    public void setClientInsuredSurname(String clientInsuredSurname) {
        this.clientInsuredSurname = clientInsuredSurname;
    }

    public String clientInsuredInitial() {
        return clientInsuredInitial;
    }

    public void setClientInsuredInitial(String clientInsuredInitial) {
        this.clientInsuredInitial = clientInsuredInitial;
    }

    public int currency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int srcSystem() {
        return srcSystem;
    }

    public void setSrcSystem(int srcSystem) {
        this.srcSystem = srcSystem;
    }

    public String policyNumberConv() {
        return policyNumberConv;
    }

    public void setPolicyNumberConv(String policyNumberConv) {
        this.policyNumberConv = policyNumberConv;
    }

    public String policyIssueDate() {
        return policyIssueDate;
    }

    public void setPolicyIssueDate(String policyIssueDate) {
        this.policyIssueDate = policyIssueDate;
    }

    public int convIndicator() {
        return convIndicator;
    }

    public void setConvIndicator(int convIndicator) {
        this.convIndicator = convIndicator;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    public String premiumHolidayEndDate() {
        return premiumHolidayEndDate;
    }

    public void setPremiumHolidayEndDate(String premiumHolidayEndDate) {
        this.premiumHolidayEndDate = premiumHolidayEndDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String premiumRdnPercntage() {
        return formatDouble(premiumRdnPercntage);
    }

    public void setPremiumRdnPercntage(double premiumRdnPercntage) {
        this.premiumRdnPercntage = Double.toString(premiumRdnPercntage);
    }

    public int indexGrwthType() {
        return indexGrwthType;
    }

    public void setIndexGrwthType(int indexGrwthType) {
        this.indexGrwthType = indexGrwthType;
    }

    public String cmpgCode() {
        return cmpgCode;
    }

    public void setCmpgCode(String cmpgCode) {
        this.cmpgCode = cmpgCode;
    }

    public int indexOpIndicator() {
        return indexOpIndicator;
    }

    public void setIndexOpIndicator(int indexOpIndicator) {
        this.indexOpIndicator = indexOpIndicator;
    }

    public int taxGrpCode() {
        return taxGrpCode;
    }

    public void setTaxGrpCode(int taxGrpCode) {
        this.taxGrpCode = taxGrpCode;
    }

    public int numberOfElemnts() {
        return numberOfElemnts;
    }

    public void setNumberOfElemnts(int numberOfElemnts) {
        this.numberOfElemnts = numberOfElemnts;
    }

    public int rParIndicator() {
        return rParIndicator;
    }

    public void setrParIndicator(int rParIndicator) {
        this.rParIndicator = rParIndicator;
    }

    public int splRinstIndicator() {
        return splRinstIndicator;
    }

    public void setSplRinstIndicator(int splRinstIndicator) {
        this.splRinstIndicator = splRinstIndicator;
    }

    public String transactionTimestamp() {
        return format(transactionTimestamp);
    }

    public void setTransactionTimestamp(String transactionTimestamp) {
        this.transactionTimestamp = format(transactionTimestamp);
    }

    public int numberOfPremiumsRcvd() {
        return numberOfPremiumsRcvd;
    }

    public void setNumberOfPremiumsRcvd(int numberOfPremiumsRcvd) {
        this.numberOfPremiumsRcvd = numberOfPremiumsRcvd;
    }

    public int premiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    public int premiumPaymntMethod() {
        return premiumPaymntMethod;
    }

    public void setPremiumPaymntMethod(int premiumPaymntMethod) {
        this.premiumPaymntMethod = premiumPaymntMethod;
    }

    public String rValPremiumInArr() {
        return formatDouble(rValPremiumInArr);
    }

    public void setrValPremiumInArr(double rValPremiumInArr) {
        this.rValPremiumInArr = Double.toString(rValPremiumInArr);
    }

    public String policyTotalPremium() {
        return formatDouble(policyTotalPremium);
    }

    public void setPolicyTotalPremium(double policyTotalPremium) {
        this.policyTotalPremium = Double.toString(policyTotalPremium);
    }

    public int warningLevel() {
        return warningLevel;
    }

    public void setWarningLevel(int warningLevel) {
        this.warningLevel = warningLevel;
    }

    public String applicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String quotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(String quotationDate) {
        this.quotationDate = quotationDate;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public String elementStrtDate() {
        return elementStrtDate;
    }

    public void setElementStrtDate(String elementStrtDate) {
        this.elementStrtDate = elementStrtDate;
    }

    public int elementTerm() {
        return elementTerm;
    }

    public void setElementTerm(int elementTerm) {
        this.elementTerm = elementTerm;
    }

    public String premiumPerFrquency() {
        return formatDouble(premiumPerFrquency);
    }

    public void setPremiumPerFrquency(double premiumPerFrquency) {
        this.premiumPerFrquency = Double.toString(premiumPerFrquency);
    }

    public String salesCommission() {
        return formatDouble(salesCommission);
    }

    public void setSalesCommission(double salesCommission) {
        this.salesCommission = Double.toString(salesCommission);
    }

    public String serviceCommission() {
        return formatDouble(serviceCommission);
    }

    public void setServiceCommission(double serviceCommission) {
        this.serviceCommission = Double.toString(serviceCommission);
    }

    public String renServiceCommission() {
        return formatDouble(renServiceCommission);
    }

    public void setRenServiceCommission(double renServiceCommission) {
        this.renServiceCommission = Double.toString(renServiceCommission);
    }

    public String negSalesPercentage() {
        return formatDouble(negSalesPercentage);
    }

    public void setNegSalesPercentage(double negSalesPercentage) {
        this.negSalesPercentage = Double.toString(negSalesPercentage);
    }

    public String negServicePercentage() {
        return formatDouble(negServicePercentage);
    }

    public void setNegServicePercentage(double negServicePercentage) {
        this.negServicePercentage = Double.toString(negServicePercentage);
    }

    public int preTranInfoVer() {
        return preTranInfoVer;
    }

    public void setPreTranInfoVer(int preTranInfoVer) {
        this.preTranInfoVer = preTranInfoVer;
    }

    public String seller() {
        return format(seller);
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public String fundValue() {
        return formatDouble(fundValue);
    }

    public void setFundValue(double fundValue) {
        this.fundValue = Double.toString(fundValue);
    }

    public String fundCommission() {
        return formatDouble(fundCommission);
    }

    public void setFundCommission(double fundCommission) {
        this.fundCommission = Double.toString(fundCommission);
    }

    public int raXerIndicator() {
        return raXerIndicator;
    }

    public void setRaXerIndicator(int raXerIndicator) {
        this.raXerIndicator = raXerIndicator;
    }

    public int scoreTerm() {
        return scoreTerm;
    }

    public void setScoreTerm(int scoreTerm) {
        this.scoreTerm = scoreTerm;
    }

    public int batchPrcSts() {
        return batchPrcSts;
    }

    public void setBatchPrcSts(int batchPrcSts) {
        this.batchPrcSts = batchPrcSts;
    }

    public String elementScorePremium() {
        return formatDouble(elementScorePremium);
    }

    public void setElementScorePremium(double elementScorePremium) {
        this.elementScorePremium = Double.toString(elementScorePremium);
    }
}
package za.co.sanlam.cms.service;

import java.lang.reflect.InvocationTargetException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import za.co.sanlam.cms.IntegrationTest;
@Ignore
@Category(IntegrationTest.class)
public class SetupCommissionEventTest {
	
	private static SetupCommissionEvent setupCommissionEvent;

	@BeforeClass
	public static void setUp() throws Exception {
		setupCommissionEvent = new SetupCommissionEvent();
		setupCommissionEvent.beginTable();
		setupCommissionEvent.reset();
	}

	@Test
	public void testHandleEventsCommissionEvent()
			throws IllegalArgumentException, IllegalAccessException,
			InvocationTargetException {
		populateCommissionEvent();
		setupCommissionEvent.execute();
	}
	
	
	public void populateCommissionEvent() throws IllegalArgumentException, IllegalAccessException, InvocationTargetException{
		//Calendar defaultCalendar = Calendar.getInstance();		
		setupCommissionEvent.setPolicyNumber("0000000017");
		setupCommissionEvent.setProductType("D03"); 
		setupCommissionEvent.setNoOfPrmsRcvd(0); 
		setupCommissionEvent.setClientOwnerPFNumber("viki") ;		
		setupCommissionEvent.setClientInsuredPFNumber("viki") ;
		setupCommissionEvent.setClientInsuredSurname("kuttiappan") ;
		setupCommissionEvent.setClientInsuredInitials("VK") ;
		setupCommissionEvent.setOriginalPolicyNumber("0") ;
		setupCommissionEvent.setCurrency(1) ;
		setupCommissionEvent.setSourceSystem(1) ;
		setupCommissionEvent.setProductName("D03") ;
		setupCommissionEvent.setRandValuePremiumInArrears(0) ;
		setupCommissionEvent.setPolicyTotalPremium(0) ;
		setupCommissionEvent.setWarningLevel(0) ;
		setupCommissionEvent.setEventType(1) ;
		setupCommissionEvent.setEventEffectiveDate("20091001") ;
		setupCommissionEvent.setTaxFundGroupCode(5) ;
		setupCommissionEvent.setCommissionType("2") ;
		setupCommissionEvent.setPremumPaymentMethod(1);
		setupCommissionEvent.setPremiumFrequency(1) ;
		setupCommissionEvent.setCampaignCode("0") ;
		setupCommissionEvent.setIndexGrowthType(1) ;
		setupCommissionEvent.setQuotationDate("20120101") ;
		setupCommissionEvent.setApplicationDate("20090904") ;
		setupCommissionEvent.setIndexPlanOptionIndicator("FALSE") ;
		setupCommissionEvent.setNoOfElements(1) ;
		setupCommissionEvent.setPremiumHolidayStartDate("20091001") ;
		setupCommissionEvent.setPremiumHolidayEndDate("99991231");
		setupCommissionEvent.setRPARIndicator(0) ;
		setupCommissionEvent.setSpecialReinstatementIndicator("FALSE");
		setupCommissionEvent.setConversionIndicator("FALSE") ;
		setupCommissionEvent.setTransactionTimestamp("2009-04-07 11:30:00.000029");
		setupCommissionEvent.setElementNumber(1) ;
		setupCommissionEvent.setElementStartDate("20091001") ;
		setupCommissionEvent.setElementTerm(60) ;
		setupCommissionEvent.setElementPremium(3600);
		setupCommissionEvent.setFundValue(0);
		setupCommissionEvent.setPremiumReductionPercentage(0);
		setupCommissionEvent.setSalesCommissionMonthlyAmount(15);
		setupCommissionEvent.setServiceCommissionMonthlyAmount(0) ;
		setupCommissionEvent.setFundCommissionMonthlyAmount(0) ;
		setupCommissionEvent.setPolicyIssueDate("20090911") ;
		setupCommissionEvent.setSalesCommissionNegotiatedPercentage(100) ;
		setupCommissionEvent.setServiceCommissionNegotiatedPercentage(0) ;
		setupCommissionEvent.setScoreTerm(0) ;
		setupCommissionEvent.setCombinedAlterationsIndicator(0) ;
		setupCommissionEvent.setElementReplacedIndicator("FALSE");
		setupCommissionEvent.setRATransferIndicator(0);
		
		setupCommissionEvent.setIntermediaryNumber("170330");
		setupCommissionEvent.setApplicationNumber("0");
		setupCommissionEvent.setManCode("0");
		setupCommissionEvent.setSalesCommissionSplitPercentage("100");
		setupCommissionEvent.setServiceCommissionSplitPercentage("100");
		setupCommissionEvent.setFundCommissionSplitPercentage("0");
		//setupCommissionEvent.getIntermediarys().add(setupCommissionEvent);
	}
}

package za.co.sanlam.cms.fixture.batch;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestUnvestedCommissionProjectionDetail extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestUnvestedCommissionProjectionDetail.class);

    private long batchId;
    private long intermediaryNumber;
    private String policyNumber;
    private int cgeType;
    private String splitComissionType;
    private int orginalIndexSalesEntitlementIndicator;
    private String commissionAmount;
    private String vatAmount;
    private String effectiveDate;
    private String extractionDate;
    private int versionNumber;
    private long cgeEventId;
    private int paymentAccount;
    private int contractStatus;

    public FixtureTestUnvestedCommissionProjectionDetail() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet()) {
                return;
            }
            LOGGER.debug("execute" + rowNumber());

            setResultSetPosition();

            setBatchId(getResultSet().getLong("PUCD_UVST_BAT_ID"));
            setPolicyNumber(getResultSet().getString("PUCD_POL_NR"));
            setCgeEventId(getResultSet().getLong("PUCD_CGE_EVT_ID"));
            setIntermediaryNumber(getResultSet().getLong("PUCD_INTM_NR"));
            setCgeType(getResultSet().getInt("PUCD_CGE_TYP"));
            setSplitComissionType(getResultSet().getString("PUCD_SPL_COMM_TYP").trim());
            setPaymentAccount(getResultSet().getInt("PUCD_PMT_ACC"));
            setOrginalIndexSalesEntitlementIndicator(getResultSet().getInt("PUCD_ORI_ISE_IND"));
            setCommissionAmount(getResultSet().getDouble("PUCD_COMM_AMT"));
            setVatAmount(getResultSet().getDouble("PUCD_VAT_AMT"));
            setContractStatus(getResultSet().getInt("PUCD_CNTR_STS"));
            setEffectiveDate(format(getResultSet().getDate("PUCD_UVST_EFF_DT")));
            setExtractionDate(format(getResultSet().getDate("PUCD_UVST_EXT_DT")));
            setCreatedBy(getResultSet().getString("PUCD_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("PUCD_UPD_BY").trim());
            setVersion(getResultSet().getInt("PUCD_UVST_DET_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setContractStatus(getResultSet().getInt("PUCD_CNTR_STS"));

            setVersionNumber(getResultSet().getInt("PUCD_UVST_DET_VER"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestProjectionUnvestedCommDetail", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestProjectionUnvestedCommDetail", se);
            }
        }
    }

    public long batchId() {
        return batchId;
    }

    public void setBatchId(long batchId) {
        this.batchId = batchId;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public int cgeType() {
        return cgeType;
    }

    public void setCgeType(int cgeType) {
        this.cgeType = cgeType;
    }

    public String splitComissionType() {
        return splitComissionType;
    }

    public void setSplitComissionType(String splitComissionType) {
        this.splitComissionType = splitComissionType;
    }

    public int orginalIndexSalesEntitlementIndicator() {
        return orginalIndexSalesEntitlementIndicator;
    }

    public void setOrginalIndexSalesEntitlementIndicator(int orginalIndexSalesEntitlementIndicator) {
        this.orginalIndexSalesEntitlementIndicator = orginalIndexSalesEntitlementIndicator;
    }

    public String commissionAmount() {
        return formatDouble(commissionAmount);
    }

    public void setCommissionAmount(double commissionAmount) {
        this.commissionAmount = String.valueOf(commissionAmount);
    }

    public String vatAmount() {
        return formatDouble(vatAmount);
    }

    public void setVatAmount(double vatAmount) {
        this.vatAmount = String.valueOf(vatAmount);
    }

    public String effectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String extractionDate() {
        return extractionDate;
    }

    public void setExtractionDate(String extractionDate) {
        this.extractionDate = extractionDate;
    }

    public int versionNumber() {
        return versionNumber;
    }

    public void setVersionNumber(int versionNumber) {
        this.versionNumber = versionNumber;
    }

    public long cgeEventId() {
        return cgeEventId;
    }

    public void setCgeEventId(long cgeEventId) {
        this.cgeEventId = cgeEventId;
    }

    public int paymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public int contractStatus() {
        return contractStatus;
    }

    public void setContractStatus(int contractStatus) {
        this.contractStatus = contractStatus;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT PUCD_UVST_BAT_ID, PUCD_INTM_NR, PUCD_POL_NR, PUCD_CGE_EVT_ID, PUCD_CGE_TYP, PUCD_SPL_COMM_TYP, "
                    + "PUCD_PMT_ACC, PUCD_ORI_ISE_IND, PUCD_COMM_AMT, PUCD_VAT_AMT, PUCD_CNTR_STS, PUCD_UVST_EFF_DT, "
                    + "PUCD_UVST_EXT_DT, PUCD_CRTD_BY, PUCD_UPD_BY, PUCD_UVST_DET_VER, DM_LSTUPDDT  "
                    + "FROM {0}PUCD_UVST_DET ORDER BY PUCD_UVST_BAT_ID FOR FETCH ONLY WITH UR");
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for MSEI_MSTR_EVT table.
 */
public class FixtureTestMasterEvent extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestMasterEvent.class);

    private long masterEventId;
    private String policyNumber;
    private int eventCategory;
    private int eventType;
    private long eipId;
    private long eventInProcessId;
    private int eipType;
    private int eventInProcessType;
    private String transactionTimestamp;
    private int eventStatus;
    private int eventVer;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT MSEI_MSTR_EVT_ID, MSEI_POL_NR, MSEI_EVT_CAT, MSEI_EVT_TYP, MSEI_EIP_ID, MSEI_EIP_TYP, MSEI_TRANSACT_TMST, MSEI_EVT_STS, MSEI_CRTD_BY,"
                    + "MSEI_UPD_BY, MSEI_MSTR_EVT_VER, DM_LSTUPDDT FROM {0}MSEI_MSTR_EVT ORDER BY MSEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");

    public FixtureTestMasterEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestMasterEvent.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("MSEI_MSTR_EVT_ID"));
            setPolicyNumber(getResultSet().getString("MSEI_POL_NR"));
            setEventCategory(getResultSet().getInt("MSEI_EVT_CAT"));
            setEventType(getResultSet().getInt("MSEI_EVT_TYP"));
            setEventInProcessId(getResultSet().getLong("MSEI_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("MSEI_EIP_TYP"));
            setTransactionTimestamp(format(getResultSet().getTimestamp("MSEI_TRANSACT_TMST")));
            setEventStatus(getResultSet().getInt("MSEI_EVT_STS"));
            setCreatedBy(getResultSet().getString("MSEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("MSEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("MSEI_MSTR_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            // Backward compatibility
            setEipId(eventInProcessId());
            setEipType(eventInProcessType());
            setEventVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestMasterEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestMasterEvent", se);
            }
        }
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public int eventCategory() {
        return eventCategory;
    }

    public void setEventCategory(int eventCategory) {
        this.eventCategory = eventCategory;
    }

    public int eventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    @Deprecated
    public long eipId() {
        return eipId;
    }

    @Deprecated
    public void setEipId(long eipId) {
        this.eipId = eipId;
    }

    @Deprecated
    public int eipType() {
        return eipType;
    }

    @Deprecated
    public void setEipType(int eipType) {
        this.eipType = eipType;
    }

    /**
     * @return the eventInProcessId
     */
    public long eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    /**
     * @return the eventInProcessType
     */
    public int eventInProcessType() {
        return eventInProcessType;
    }

    /**
     * @param eventInProcessType
     *            the eventInProcessType to set
     */
    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    public String transactionTimestamp() {
        return transactionTimestamp;
    }

    public void setTransactionTimestamp(String transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
    }

    public int eventStatus() {
        return eventStatus;
    }

    public void setEventStatus(int eventStatus) {
        this.eventStatus = eventStatus;
    }

    @Deprecated
    public int eventVer() {
        return eventVer;
    }

    @Deprecated
    public void setEventVer(int eventVer) {
        this.eventVer = eventVer;
    }
}
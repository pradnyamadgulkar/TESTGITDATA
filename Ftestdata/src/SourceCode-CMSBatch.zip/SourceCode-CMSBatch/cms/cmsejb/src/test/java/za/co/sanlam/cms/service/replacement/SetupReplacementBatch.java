package za.co.sanlam.cms.service.replacement;

import org.apache.commons.lang.NotImplementedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.util.db.DatabaseInitializer;

public class SetupReplacementBatch {

    private static final Logger LOGGER = LoggerFactory.getLogger(SetupReplacementBatch.class);
    private String batchKey;
    private String sqlSetupFileName;

    private DatabaseInitializer databaseInitializer;
    private ReplacementJobHandler replacementTriggerHandler;

    public void beginTable() throws Exception {
        LOGGER.info("SetupReplacementBatch.beginTable()");
        if (databaseInitializer == null) {
            databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
        }
    }

    public void reset() {
    }

    public void execute() throws Exception {
        LOGGER.info("SetupReplacementBatch.execute()");
        LOGGER.info("batchKey : " + getBatchKey() + " :: " + batchKey);
        if (replacementTriggerHandler == null) {
            replacementTriggerHandler = (ReplacementJobHandler) BeanLocator.locateBean("replacementJobHandler");
        }
        if (batchKey.equals("410") || batchKey.equals("430") || batchKey.equals("450") || batchKey.equals("440")
                || batchKey.equals("420")) {
            if (getSqlSetupFileName() != null && !getSqlSetupFileName().trim().equals("")) {
                if (!batchKey.equals("450")) {
                    databaseInitializer.initialize();
                }
                databaseInitializer.setUpData(getSqlSetupFileName());
            }
            replacementTriggerHandler.processJob(Integer.parseInt(batchKey));
        } else {
            throw new NotImplementedException("This functionality not implemented yet.");
        }
    }

    public String getBatchKey() {
        return batchKey;
    }

    public void setBatchKey(String batchKey) {
        this.batchKey = batchKey;
    }

    public String getSqlSetupFileName() {
        return sqlSetupFileName;
    }

    public void setSqlSetupFileName(String sqlSetupFileName) {
        this.sqlSetupFileName = sqlSetupFileName;
    }

}

package za.co.sanlam.cms.service.replacement;

public interface ReplacementJobHandler {
   
    public void processJob(int batchKey);
    
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for MSEH_MSEVT_HST table.
 */
public class FixtureTestMasterEventHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestMasterEventHistory.class);

    private long masterEventId;
    private int eventStatus;
    private long eventInProcessId;
    private int eventInProcessType;
    private String eventInProcessDate;
    private int masterEventHistoryVerifier;

    public FixtureTestMasterEventHistory() throws SQLException {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("MSEH_MSTR_EVT_ID"));
            setEventStatus(getResultSet().getInt("MSEH_EVT_STS"));
            setEventInProcessId(getResultSet().getLong("MSEH_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("MSEH_EIP_TYP"));
            setEventInProcessDate(format(getResultSet().getDate("MSEH_EIP_DT")));
            setCreatedBy(getResultSet().getString("MSEH_CRTD_BY").trim());
            setVersion(getResultSet().getInt("MSEH_MSEVT_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setMasterEventHistoryVerifier(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestMasterEventHistory", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestMasterEventHistory", e);
            }
        }
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int eventStatus() {
        return eventStatus;
    }

    public void setEventStatus(int eventStatus) {
        this.eventStatus = eventStatus;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public int eventInProcessType() {
        return eventInProcessType;
    }

    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    @Deprecated
    public int masterEventHistoryVerifier() {
        return masterEventHistoryVerifier;
    }

    @Deprecated
    public void setMasterEventHistoryVerifier(int masterEventHistoryVerifier) {
        this.masterEventHistoryVerifier = masterEventHistoryVerifier;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "select MSEH_MSTR_EVT_ID,MSEH_EVT_STS,MSEH_EIP_ID, MSEH_EIP_TYP,MSEH_EIP_DT,MSEH_CRTD_BY,"
                    + "MSEH_MSEVT_HST_VER,DM_LSTUPDDT FROM {0}MSEH_MSEVT_HST "
                    + "ORDER BY MSEH_MSTR_EVT_ID, MSEH_EVT_STS, MSEH_EIP_TYP, MSEH_EIP_ID FOR FETCH ONLY WITH UR");
}

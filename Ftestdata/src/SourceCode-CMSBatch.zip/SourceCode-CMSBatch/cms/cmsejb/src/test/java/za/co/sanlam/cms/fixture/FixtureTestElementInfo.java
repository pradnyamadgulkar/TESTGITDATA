package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for EMIF_ELMT_INF table.
 */
public class FixtureTestElementInfo extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestElementInfo.class);

    private long elementId;
    private String policyNumber;
    private long masterEventId;
    private int elementNumber;
    private String elementStartDate;
    private String elementEndDate;
    private String annualElementPremium;
    private String salesCommissionMonthlyAmount;
    private String serviceCommissionMonthlyAmount;
    private int sender;
    private int elementStatus;
    private long eventInProcessId;
    private int serviceCommissionNegotiatedPercentage;
    private int salesCommissionNegotiatedPercentage;

    private String serviceComMonthlyAmt;
    private String salesComMonthlyAmt;
    private String serviceComNegoPct;
    private String salesComNegoPct;
    private int elementInfoVer;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT EMIF_ELMT_ID, EMIF_POL_NR, EMIF_MSTR_EVT_ID, EMIF_ELMT_NR, "
                    + "EMIF_ELMT_START_DT, EMIF_ELMT_END_DT, EMIF_ELMT_ANN_PRM, EMIF_SLS_COMM_MON, EMIF_SRV_COMM_MON, EMIF_SENDER, "
                    + "EMIF_ELMT_STS, EMIF_EIP_ID, EMIF_SLS_NEGO_PCT, EMIF_SRV_NEGO_PCT, EMIF_CRTD_BY, EMIF_UPD_BY, "
                    // +
                    // "EMIF_ELMT_INF_VER, DM_LSTUPDDT FROM {0}EMIF_ELMT_INF ORDER BY EMIF_ELMT_ID FOR FETCH ONLY WITH UR ");
                    + "EMIF_ELMT_INF_VER, DM_LSTUPDDT FROM {0}EMIF_ELMT_INF ORDER BY EMIF_MSTR_EVT_ID, EMIF_ELMT_NR FOR FETCH ONLY WITH UR ");

    public FixtureTestElementInfo() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestElementInfo.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setElementId(getResultSet().getLong("EMIF_ELMT_ID"));
            setPolicyNumber(getResultSet().getString("EMIF_POL_NR"));
            setMasterEventId(getResultSet().getLong("EMIF_MSTR_EVT_ID"));
            setElementNumber(getResultSet().getInt("EMIF_ELMT_NR"));
            setElementStartDate(format(getResultSet().getDate("EMIF_ELMT_START_DT")));
            setElementEndDate(format(getResultSet().getDate("EMIF_ELMT_END_DT")));
            setAnnualElementPremium(getResultSet().getDouble("EMIF_ELMT_ANN_PRM"));
            setSalesCommissionMonthlyAmount(getResultSet().getDouble("EMIF_SLS_COMM_MON"));
            setServiceCommissionMonthlyAmount(getResultSet().getDouble("EMIF_SRV_COMM_MON"));
            setSender(getResultSet().getInt("EMIF_SENDER"));
            setElementStatus(getResultSet().getInt("EMIF_ELMT_STS"));
            setEventInProcessId(getResultSet().getLong("EMIF_EIP_ID"));
            setSalesCommissionNegotiatedPercentage(getResultSet().getInt("EMIF_SLS_NEGO_PCT"));
            setServiceCommissionNegotiatedPercentage(getResultSet().getInt("EMIF_SRV_NEGO_PCT"));
            setCreatedBy(getResultSet().getString("EMIF_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("EMIF_UPD_BY").trim());
            setVersion(getResultSet().getInt("EMIF_ELMT_INF_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setSalesComMonthlyAmt(getResultSet().getDouble("EMIF_SLS_COMM_MON"));
            setServiceComMonthlyAmt(getResultSet().getDouble("EMIF_SRV_COMM_MON"));
            setSalesComNegoPct(getResultSet().getInt("EMIF_SLS_NEGO_PCT"));
            setServiceComNegoPct(getResultSet().getInt("EMIF_SRV_NEGO_PCT"));
            setElementInfoVer(version());

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestElementInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestElementInfo", se);
            }
        }
    }

    public long elementId() {
        return elementId;
    }

    public void setElementId(long elementId) {
        this.elementId = elementId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String string) {
        this.policyNumber = string;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public String elementStartDate() {
        return elementStartDate;
    }

    public void setElementStartDate(String elementStartDate) {
        this.elementStartDate = elementStartDate;
    }

    public String elementEndDate() {
        return elementEndDate;
    }

    public void setElementEndDate(String elementEndDate) {
        this.elementEndDate = elementEndDate;
    }

    public String annualElementPremium() {
        return formatDouble(annualElementPremium);
    }

    public void setAnnualElementPremium(double annualElementPremium) {
        this.annualElementPremium = String.valueOf(annualElementPremium);
    }

    @Deprecated
    public String salesComMonthlyAmt() {
        return formatDouble(salesComMonthlyAmt);
    }

    @Deprecated
    public void setSalesComMonthlyAmt(double salesComMonthlyAmt) {
        this.salesComMonthlyAmt = Double.toString(salesComMonthlyAmt);
    }

    @Deprecated
    public String serviceComMonthlyAmt() {
        return formatDouble(serviceComMonthlyAmt);
    }

    @Deprecated
    public void setServiceComMonthlyAmt(double serviceComMonthlyAmt) {
        this.serviceComMonthlyAmt = Double.toString(serviceComMonthlyAmt);
    }

    public int sender() {
        return sender;
    }

    public void setSender(int sender) {
        this.sender = sender;
    }

    public int elementStatus() {
        return elementStatus;
    }

    public void setElementStatus(int elementStatus) {
        this.elementStatus = elementStatus;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    /**
     * @return the salesCommissionMonthlyAmount
     */
    public String salesCommissionMonthlyAmount() {
        return formatDouble(salesCommissionMonthlyAmount);
    }

    /**
     * @param salesCommissionMonthlyAmount
     *            the salesCommissionMonthlyAmount to set
     */
    public void setSalesCommissionMonthlyAmount(double salesCommissionMonthlyAmount) {
        this.salesCommissionMonthlyAmount = Double.toString(salesCommissionMonthlyAmount);
    }

    /**
     * @return the serviceCommssionMonthlyAmount
     */
    public String serviceCommissionMonthlyAmount() {
        return formatDouble(serviceCommissionMonthlyAmount);
    }

    /**
     * @param serviceCommssionMonthlyAmount
     *            the serviceCommssionMonthlyAmount to set
     */
    public void setServiceCommissionMonthlyAmount(double serviceCommissionMonthlyAmount) {
        this.serviceCommissionMonthlyAmount = Double.toString(serviceCommissionMonthlyAmount);
    }

    /**
     * @return the serviceCommssionNegotiatedPercentage
     */
    public int serviceCommissionNegotiatedPercentage() {
        return serviceCommissionNegotiatedPercentage;
    }

    /**
     * @param serviceCommssionNegotiatedPercentage
     *            the serviceCommssionNegotiatedPercentage to set
     */
    public void setServiceCommissionNegotiatedPercentage(int serviceCommissionNegotiatedPercentage) {
        this.serviceCommissionNegotiatedPercentage = serviceCommissionNegotiatedPercentage;
    }

    /**
     * @return the salesCommssionNegotiatedPercentage
     */
    public int salesCommissionNegotiatedPercentage() {
        return salesCommissionNegotiatedPercentage;
    }

    /**
     * @param salesCommssionNegotiatedPercentage
     *            the salesCommssionNegotiatedPercentage to set
     */
    public void setSalesCommissionNegotiatedPercentage(int salesCommissionNegotiatedPercentage) {
        this.salesCommissionNegotiatedPercentage = salesCommissionNegotiatedPercentage;
    }

    @Deprecated
    public String serviceComNegoPct() {
        return String.valueOf(Integer.parseInt(serviceComNegoPct));
    }

    @Deprecated
    public void setServiceComNegoPct(int serviceComNegoPct) {
        this.serviceComNegoPct = Double.toString(serviceComNegoPct);
    }

    @Deprecated
    public String salesComNegoPct() {
        return String.valueOf(Integer.parseInt(salesComNegoPct));
    }

    @Deprecated
    public void setSalesComNegoPct(int salesComNegoPct) {
        this.salesComNegoPct = Double.toString(salesComNegoPct);
    }

    @Deprecated
    public int elementInfoVer() {
        return elementInfoVer;
    }

    @Deprecated
    public void setElementInfoVer(int elementInfoVer) {
        this.elementInfoVer = elementInfoVer;
    }
}

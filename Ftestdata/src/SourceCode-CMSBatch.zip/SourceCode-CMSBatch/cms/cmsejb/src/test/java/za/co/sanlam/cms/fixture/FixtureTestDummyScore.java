/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for INDS_DMY_SCR table.
 */
public class FixtureTestDummyScore extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestDummyScore.class);

    private long dummyScoreId;
    private String policyNumber;
    private long eventId;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private long commissionTypeId;
    private String scorePremium;
    private long policyCounter;
    private long policyCount;
    private String totalScorePremium;
    private String scoreSplitPercentage;
    private int eventInProgressId;
    private int eventInProcessId;
    private long dmkmbRefId;
    private long dummyKmbReferenceId;
    private int creditDebitIndicator;
    private int dummyScoreVerifier;
    private int replacementIndicator;
    private long replacementRetroId;

    public FixtureTestDummyScore() throws SQLException {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setDummyScoreId(getResultSet().getLong("INDS_INTM_DMSCR_ID"));
            setPolicyNumber(getResultSet().getString("INDS_POL_NR").trim());
            setEventId(getResultSet().getLong("INDS_EVT_ID"));
            setElementNumber(getResultSet().getInt("INDS_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("INDS_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("INDS_SPLT_COMM_TYP").trim());
            setCommissionTypeId(getResultSet().getLong("INDS_COMM_TYP_ID"));
            setScorePremium(getResultSet().getDouble("INDS_SCR_PRM"));
            setPolicyCounter(getResultSet().getLong("INDS_POL_CNT"));
            setTotalScorePremium(getResultSet().getDouble("INDS_TOT_SCR_PRM"));
            setScoreSplitPercentage(getResultSet().getDouble("INDS_SCR_SPLT_PCT"));
            setEventInProcessId(getResultSet().getInt("INDS_EIP_ID"));
            setDummyKmbReferenceId(getResultSet().getLong("INDS_DMKMB_REF_ID"));
            setCreditDebitIndicator(getResultSet().getInt("INDS_CR_DR_IND"));
            setCreatedBy(getResultSet().getString("INDS_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("INDS_UPD_BY").trim());
            setVersion(getResultSet().getInt("INDS_DMY_SCR_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setReplacementIndicator(getResultSet().getInt("INDS_REPL_IND"));
            setReplacementRetroId(getResultSet().getLong("INDS_REPL_RETRO_ID"));

            setEventInProgressId(eventInProcessId());
            setDmkmbRefId(dummyKmbReferenceId);
            setDummyScoreVerifier(version());

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestDummyScore", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestDummyScore", e);
            }
        }
    }

    public long dummyScoreId() {
        return dummyScoreId;
    }

    public void setDummyScoreId(long dummyScoreId) {
        this.dummyScoreId = dummyScoreId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long eventId() {
        return eventId;
    }

    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public long commissionTypeId() {
        return commissionTypeId;
    }

    public void setCommissionTypeId(long commissionTypeId) {
        this.commissionTypeId = commissionTypeId;
    }

    public String scorePremium() {
        return formatDouble(scorePremium);
    }

    public void setScorePremium(double scorePremium) {
        this.scorePremium = String.valueOf(scorePremium);
    }

    public long policyCounter() {
        return policyCounter;
    }

    public void setPolicyCounter(long policyCounter) {
        this.policyCounter = policyCounter;
    }

    public String totalScorePremium() {
        return formatDouble(totalScorePremium);
    }

    public void setTotalScorePremium(double totalScorePremium) {
        this.totalScorePremium = String.valueOf(totalScorePremium);
    }

    public String scoreSplitPercentage() {
        return formatDouble(scoreSplitPercentage);
    }

    public void setScoreSplitPercentage(double scoreSplitPercentage) {
        this.scoreSplitPercentage = String.valueOf(scoreSplitPercentage);
    }

    @Deprecated
    public int eventInProgressId() {
        return eventInProgressId;
    }

    @Deprecated
    public void setEventInProgressId(int eventInProgressId) {
        this.eventInProgressId = eventInProgressId;
    }

    @Deprecated
    public long dmkmbRefId() {
        return dmkmbRefId;
    }

    @Deprecated
    public void setDmkmbRefId(long dmkmbRefId) {
        this.dmkmbRefId = dmkmbRefId;
    }

    public int creditDebitIndicator() {
        return creditDebitIndicator;
    }

    public void setCreditDebitIndicator(int creditDebitIndicator) {
        this.creditDebitIndicator = creditDebitIndicator;
    }

    @Deprecated
    public int dummyScoreVerifier() {
        return dummyScoreVerifier;
    }

    @Deprecated
    public void setDummyScoreVerifier(int dummyScoreVerifier) {
        this.dummyScoreVerifier = dummyScoreVerifier;
    }

    public int replacementIndicator() {
        return replacementIndicator;
    }

    public void setReplacementIndicator(int replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }

    public long replacementRetroId() {
        return replacementRetroId;
    }

    public void setReplacementRetroId(long replacementRetroId) {
        this.replacementRetroId = replacementRetroId;
    }

    /**
     * @return the policyCount
     */
    public long policyCount() {
        return policyCount;
    }

    /**
     * @param policyCount
     *            the policyCount to set
     */
    public void setPolicyCount(long policyCount) {
        this.policyCount = policyCount;
    }

    /**
     * @return the eventInProcessId
     */
    public int eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(int eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    /**
     * @return the dummyKmbReferenceId
     */
    public long dummyKmbReferenceId() {
        return dummyKmbReferenceId;
    }

    /**
     * @param dummyKmbReferenceId
     *            the dummyKmbReferenceId to set
     */
    public void setDummyKmbReferenceId(long dummyKmbReferenceId) {
        this.dummyKmbReferenceId = dummyKmbReferenceId;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "select INDS_INTM_DMSCR_ID,INDS_POL_NR,INDS_EVT_ID,"
                    + "INDS_ELMT_NR,INDS_INTM_NR,INDS_SPLT_COMM_TYP,INDS_COMM_TYP_ID,INDS_EIP_ID,INDS_DMKMB_REF_ID,INDS_CR_DR_IND,INDS_CRTD_BY,"
                    + "INDS_UPD_BY,INDS_DMY_SCR_VER,DM_LSTUPDDT,INDS_REPL_IND,INDS_REPL_RETRO_ID FROM "
                    + "{0}INDS_DMY_SCR ORDER BY INDS_INTM_DMSCR_ID FOR FETCH ONLY WITH UR");

}

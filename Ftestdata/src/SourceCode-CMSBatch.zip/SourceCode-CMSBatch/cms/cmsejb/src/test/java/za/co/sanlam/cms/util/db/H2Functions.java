package za.co.sanlam.cms.util.db;

import org.apache.commons.lang.time.DateUtils;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;

/**
 * Custom functions required for the H2 database engine
 */
public class H2Functions {

    public static Date convertToDate(Timestamp timestamp) {
        return new Date(DateUtils.truncate(timestamp,Calendar.DATE).getTime());
    }
}

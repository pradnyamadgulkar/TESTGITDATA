/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for CREI_MSTR_EVT_ID table.
 */
public class FixtureTestCommissionReductionEvent extends FixtureTestMasterEvent {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestCommissionReductionEvent.class);

    private String effectiveDate;
    private String eventEffectiveDate;
    private String endDate;
    private String premiumReductionPercentage;
    private String premiumReductionPerctg;
    private int elementNumber;
    private int elementNo;

    private int commRedcnInfoVer;
    private String renegotiatedServiceCommission;
    private String renegServCom;

    public FixtureTestCommissionReductionEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestCommReductionEvent.execute()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("CREI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("CREI_CRE_TYP"));
            setEffectiveDate(format(getResultSet().getDate("CREI_CRE_EFF_DT")));
            setEndDate(format(getResultSet().getDate("CREI_CRE_END_DT")));
            setPremiumReductionPercentage(getResultSet().getDouble("CREI_PRM_RDN"));
            setElementNumber(getResultSet().getInt("CREI_ELMT_NR"));
            setPolicyNumber(getResultSet().getString("CREI_POL_NR"));
            setCreatedBy(getResultSet().getString("CREI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("CREI_UPD_BY").trim());
            setVersion(getResultSet().getInt("CREI_CRE_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setRenegotiatedServiceCommission(getResultSet().getDouble("CREI_REN_SERV_COMM"));

            setEventEffectiveDate(effectiveDate());
            setPremiumReductionPerctg(Double.parseDouble(premiumReductionPercentage()));
            setElementNo(elementNumber());
            setCommRedcnInfoVer(version());
            setRenegServCom(Double.parseDouble(renegotiatedServiceCommission()));
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestCommReductionEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestCommReductionEvent", se);
            }
        }
    }

    @Deprecated
    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    @Deprecated
    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    public String endDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Deprecated
    public String premiumReductionPerctg() {
        if (premiumReductionPerctg != null) {
            if (BigDecimal.valueOf(Double.parseDouble(premiumReductionPerctg)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(premiumReductionPerctg).intValue());
            }
        }
        return premiumReductionPerctg;
    }

    @Deprecated
    public void setPremiumReductionPerctg(double premiumReductionPerctg) {
        this.premiumReductionPerctg = Double.toString(premiumReductionPerctg);
    }

    @Deprecated
    public int elementNo() {
        return elementNo;
    }

    @Deprecated
    public void setElementNo(int elementNo) {
        this.elementNo = elementNo;
    }

    @Deprecated
    public int commRedcnInfoVer() {
        return commRedcnInfoVer;
    }

    @Deprecated
    public void setCommRedcnInfoVer(int commRedcnInfoVer) {
        this.commRedcnInfoVer = commRedcnInfoVer;
    }

    /**
     * @return the effectiveDate
     */
    public String effectiveDate() {
        return effectiveDate;
    }

    /**
     * @param effectiveDate
     *            the effectiveDate to set
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    @Deprecated
    public String renegServCom() {
        if (renegServCom != null) {
            if (BigDecimal.valueOf(Double.parseDouble(renegServCom)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(renegServCom).intValue());
            }
        }
        return renegServCom;
    }

    @Deprecated
    public void setRenegServCom(double renegServCom) {
        this.renegServCom = Double.toString(renegServCom);
    }

    /**
     * @return the premiumReductionPercentage
     */
    public String premiumReductionPercentage() {
        return formatDouble(premiumReductionPercentage);
    }

    /**
     * @param premiumReductionPercentage
     *            the premiumReductionPercentage to set
     */
    public void setPremiumReductionPercentage(double premiumReductionPercentage) {
        this.premiumReductionPercentage = String.valueOf(premiumReductionPercentage);
    }

    /**
     * @return the elementNumber
     */
    public int elementNumber() {
        return elementNumber;
    }

    /**
     * @param elementNumber
     *            the elementNumber to set
     */
    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    /**
     * @return the renegotiatedServiceCommission
     */
    public String renegotiatedServiceCommission() {
        return formatDouble(renegotiatedServiceCommission);
    }

    /**
     * @param renegotiatedServiceCommission
     *            the renegotiatedServiceCommission to set
     */
    public void setRenegotiatedServiceCommission(double renegotiatedServiceCommission) {
        this.renegotiatedServiceCommission = String.valueOf(renegotiatedServiceCommission);
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT CREI_MSTR_EVT_ID, CREI_CRE_TYP, CREI_CRE_EFF_DT, CREI_CRE_END_DT, "
                    + "CREI_PRM_RDN, CREI_ELMT_NR, CREI_POL_NR, CREI_CRTD_BY, CREI_UPD_BY, "
                    + "CREI_CRE_EVT_VER, DM_LSTUPDDT, CREI_REN_SERV_COMM FROM {0}CREI_CRE_EVT "
                    + "ORDER BY CREI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");
}

package za.co.sanlam.cms.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.util.db.DatabaseInitializer;

public class SetupCommissionEventFromPreTran {

    private String policyNumber;
    private long preTranRefId;
    private long dbInitializeLevel = 0;
    private String scenarioDescription;

    private EventFacade eventFacade;
    private DatabaseInitializer databaseInitializer;
    private Iterator<CommissionEvent> commissionEventIterator;

    public void beginTable() throws Exception {
        if (databaseInitializer == null) {
            databaseInitializer = (DatabaseInitializer) BeanLocator.locateBean("databaseInitializer");
        }
    }

    public void reset() {
        commissionEventIterator = null;
    }

    public void execute() throws Exception {
        if (dbInitializeLevel == 2) {
            // initialize all business tables
            databaseInitializer.initialize();
        }
        if (commissionEventIterator == null) {
            if (getPolicyNumber() != null && !getPolicyNumber().trim().equals("")) {
                commissionEventIterator = new CommissionEventGenerator().generateCommissionEventFromPreTran(getPolicyNumber())
                        .iterator();
            } else if (getPreTranRefId() > 0) {
                CommissionEvent commissionEvent = new CommissionEventGenerator()
                        .generateCommissionEventFromPreTran(getPreTranRefId());
                if (commissionEvent != null) {
                    List<CommissionEvent> commissionEvents = new ArrayList<CommissionEvent>();
                    commissionEvents.add(commissionEvent);
                    commissionEventIterator = commissionEvents.iterator();
                }
            }
        }
        if (eventFacade == null) {
            eventFacade = (EventFacade) BeanLocator.locateBean("eventFacade");
        }
        while (commissionEventIterator != null && commissionEventIterator.hasNext()) {
            eventFacade.handleEvents(commissionEventIterator.next());
        }
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long getPreTranRefId() {
        return preTranRefId;
    }

    public void setPreTranRefId(long preTranRefId) {
        this.preTranRefId = preTranRefId;
    }

    public long getDbInitializeLevel() {
        return dbInitializeLevel;
    }

    public void setDbInitializeLevel(long dbInitializeLevel) {
        this.dbInitializeLevel = dbInitializeLevel;
    }

    public String scenarioDescription() {
        return scenarioDescription;
    }

    public void setScenarioDescription(String scenarioDescription) {
        this.scenarioDescription = scenarioDescription;
    }

}

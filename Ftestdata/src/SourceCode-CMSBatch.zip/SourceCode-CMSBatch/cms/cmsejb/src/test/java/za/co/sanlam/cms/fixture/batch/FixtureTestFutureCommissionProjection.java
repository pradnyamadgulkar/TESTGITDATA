package za.co.sanlam.cms.fixture.batch;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestFutureCommissionProjection extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestFutureCommissionProjection.class);

    private long futureCommissionId;
    private String policyNumber;
    private long masterEventId;
    private long elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private String nextPaymentDate;
    private String commissionAdvanceAmount;
    private int versionNumber;
    private long splitCommissionId;
    private String monthIndicator;
    private long advanceScheduleId;

    public FixtureTestFutureCommissionProjection() throws SQLException {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet(getResultSet())) {
                return;
            }

            setResultSetPosition();

            setFutureCommissionId(getResultSet().getLong("FTCP_FUT_COMM_ID"));
            setPolicyNumber(getResultSet().getString("FTCP_POL_NR"));
            setMasterEventId(getResultSet().getLong("FTCP_MSTR_EVT_ID"));
            setElementNumber(getResultSet().getLong("FTCP_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("FTCP_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("FTCP_SPLT_COMM_TYP").trim());
            setNextPaymentDate(format(getResultSet().getDate("FTCP_NXT_PMT_DT")));
            setCommissionAdvanceAmount(getResultSet().getDouble("FTCP_COMM_ADV_AMT"));
            setSplitCommissionId(getResultSet().getLong("FTCP_SPLT_COMM_ID"));
            setCreatedBy(getResultSet().getString("FTCP_CRTD_BY"));
            setUpdatedBy(getResultSet().getString("FTCP_UPD_BY"));
            setVersion(getResultSet().getInt("FTCP_FUT_COMM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setMonthIndicator(getResultSet().getString("FTCP_MON_IND").trim());
            setAdvanceScheduleId(getResultSet().getLong("FTCP_ADSI_SCHD_ID"));

            setVersionNumber(getResultSet().getInt("FTCP_FUT_COMM_VER"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestFutureCommProjection", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestFutureCommProjection", se);
            }
        }
    }

    public long futureCommissionId() {
        return futureCommissionId;
    }

    public void setFutureCommissionId(long futureCommissionId) {
        this.futureCommissionId = futureCommissionId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public long elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(long elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public String nextPaymentDate() {
        return nextPaymentDate;
    }

    public void setNextPaymentDate(String nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    public String commissionAdvanceAmount() {
        return formatDouble(commissionAdvanceAmount);
    }

    public void setCommissionAdvanceAmount(double commissionAdvanceAmount) {
        this.commissionAdvanceAmount = String.valueOf(commissionAdvanceAmount);
    }

    @Deprecated
    public int versionNumber() {
        return versionNumber;
    }

    @Deprecated
    public void setVersionNumber(int versionNumber) {
        this.versionNumber = versionNumber;
    }

    public long splitCommissionId() {
        return splitCommissionId;
    }

    public void setSplitCommissionId(long splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    public String monthIndicator() {
        return monthIndicator;
    }

    public void setMonthIndicator(String monthIndicator) {
        this.monthIndicator = monthIndicator;
    }

    /**
     * @return the advanceScheduleId
     */
    public long advanceScheduleId() {
        return advanceScheduleId;
    }

    /**
     * @param advanceScheduleId
     *            the advanceScheduleId to set
     */
    public void setAdvanceScheduleId(long advanceScheduleId) {
        this.advanceScheduleId = advanceScheduleId;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT FTCP_FUT_COMM_ID, FTCP_POL_NR, FTCP_MSTR_EVT_ID, FTCP_ELMT_NR, FTCP_INTM_NR, FTCP_SPLT_COMM_TYP, "
                    + "FTCP_NXT_PMT_DT, FTCP_COMM_ADV_AMT, FTCP_SPLT_COMM_ID, FTCP_CRTD_BY, FTCP_UPD_BY, FTCP_FUT_COMM_VER, "
                    + "DM_LSTUPDDT, FTCP_MON_IND,FTCP_ADSI_SCHD_ID FROM {0}FTCP_FUT_COMM ORDER BY FTCP_FUT_COMM_ID FOR FETCH ONLY WITH UR");
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for PLHS_POL_HST table.
 */
public class FixtureTestPolicyHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestPolicyHistory.class);

    private String policyNumber;
    private int policyIdxOptionIndicator;
    private int policyIndexPlanOptionIndicator;
    private int policyStatus;
    private long eventInProcessId;
    private int eventInProcessType;
    private String eventInProcessDate;
    private int policyHistoryVersion;
    private int premiumFrequency;
    private int serviceModelIndicator;

    public FixtureTestPolicyHistory() throws SQLException {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }
            setResultSetPosition();

            setPolicyNumber(getResultSet().getString("PLHS_POL_NR"));
            setPolicyIndexPlanOptionIndicator(getResultSet().getInt("PLHS_IDX_PL_OP_IND"));
            setPolicyStatus(getResultSet().getInt("PLHS_POL_STS"));
            setEventInProcessId(getResultSet().getInt("PLHS_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("PLHS_EIP_TYP"));
            setEventInProcessDate(format(getResultSet().getDate("PLHS_EIP_DT")));
            setCreatedBy(getResultSet().getString("PLHS_CRTD_BY").trim());
            setVersion(getResultSet().getInt("PLHS_POL_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setPremiumFrequency(getResultSet().getInt("PLHS_PRM_FQ"));
            setServiceModelIndicator(getResultSet().getInt("PLHS_SERVICE_MODEL_IND"));

            setPolicyIdxOptionIndicator(getResultSet().getInt("PLHS_IDX_PL_OP_IND"));
            setPolicyHistoryVersion(getResultSet().getInt("PLHS_POL_HST_VER"));
        } catch (SQLException ignore) {
            LOG.error(" Exception encountered in operation execute of class FixtureTestPolicyInfoHistory", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestPolicyInfoHistory", e);
            }
        }
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    @Deprecated
    public int policyIdxOptionIndicator() {
        return policyIdxOptionIndicator;
    }

    @Deprecated
    public void setPolicyIdxOptionIndicator(int policyIdxOptionIndicator) {
        this.policyIdxOptionIndicator = policyIdxOptionIndicator;
    }

    public int policyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(int policyStatus) {
        this.policyStatus = policyStatus;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public int eventInProcessType() {
        return eventInProcessType;
    }

    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    @Deprecated
    public int policyHistoryVersion() {
        return policyHistoryVersion;
    }

    @Deprecated
    public void setPolicyHistoryVersion(int policyHistoryVersion) {
        this.policyHistoryVersion = policyHistoryVersion;
    }

    public int premiumFrequency() {
        return premiumFrequency;
    }

    public void setPremiumFrequency(int premiumFrequency) {
        this.premiumFrequency = premiumFrequency;
    }

    /**
     * @return the policyIndexPlanOptionIndicator
     */
    public int policyIndexPlanOptionIndicator() {
        return policyIndexPlanOptionIndicator;
    }

    /**
     * @param policyIndexPlanOptionIndicator
     *            the policyIndexPlanOptionIndicator to set
     */
    public void setPolicyIndexPlanOptionIndicator(int policyIndexPlanOptionIndicator) {
        this.policyIndexPlanOptionIndicator = policyIndexPlanOptionIndicator;
    }

    /**
     * @return the serviceModelIndicator
     */
    public int serviceModelIndicator() {
        return serviceModelIndicator;
    }

    /**
     * @param serviceModelIndicator
     *            the serviceModelIndicator to set
     */
    public void setServiceModelIndicator(int serviceModelIndicator) {
        this.serviceModelIndicator = serviceModelIndicator;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "select PLHS_POL_NR, PLHS_IDX_PL_OP_IND, PLHS_POL_STS, PLHS_EIP_ID, "
                    + "PLHS_EIP_TYP, PLHS_EIP_DT, PLHS_CRTD_BY, PLHS_POL_HST_VER, DM_LSTUPDDT, PLHS_PRM_FQ, PLHS_SERVICE_MODEL_IND FROM "
                    + "{0}PLHS_POL_HST ORDER BY  PLHS_POL_NR, PLHS_EIP_ID FOR FETCH ONLY WITH UR");

}

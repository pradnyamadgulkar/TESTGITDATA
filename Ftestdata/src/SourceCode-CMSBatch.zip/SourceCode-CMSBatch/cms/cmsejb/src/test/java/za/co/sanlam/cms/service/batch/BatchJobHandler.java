package za.co.sanlam.cms.service.batch;

public interface BatchJobHandler {
   
    public void processJob(int batchKey);
    
    public void processJob(int batchKey, int batchType);
    
}

package za.co.sanlam.cms.fixture.replacement;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

import com.tcs.mastercraft.mctype.ServerContext;

public class FixtureTestMarketerInfo extends FixtureTestKomEvents {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestMarketerInfo.class);

    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    private long marketerId;
    private String policyNumber;
    private String cgeDate;
    private String commissionType;
    private long intermediaryNumber;
    private String intermediaryPercentage;
    private int rowNumber;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestInActiveInfo.beginTable()");
        initialize();
    }

    public void execute() {
        try {
            if (inValidResultSet(resultSet)) {
                return;
            }
            resultSet.absolute(rowNumber);
            setMarketerId(resultSet.getLong("RPMI_MKTR_ID"));
            setPolicyNumber(resultSet.getString("RPMI_POL_NR").trim());
            setCgeDate(dateFormatter.format(resultSet.getDate("RPMI_CGE_DATE")));
            setCommissionType(resultSet.getString("RPMI_COMM_TYPE").trim());
            setIntermediaryNumber(resultSet.getLong("RPMI_INTM_NR"));
            setIntermediaryPercentage(resultSet.getString("RPMI_INTM_PCT"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestMarketerInfo", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestMarketerInfo", se);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public long marketerId() {
        return marketerId;
    }

    public void setMarketerId(long marketerId) {
        this.marketerId = marketerId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String cgeDate() {
        return cgeDate;
    }

    public void setCgeDate(String cgeDate) {
        this.cgeDate = cgeDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String intermediaryPercentage() {
        if (intermediaryPercentage != null) {
            if (BigDecimal.valueOf(Double.parseDouble(intermediaryPercentage)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(intermediaryPercentage).intValue());
            }
        }
        return intermediaryPercentage;
    }

    public void setIntermediaryPercentage(String intermediaryPercentage) {
        this.intermediaryPercentage = intermediaryPercentage;
    }

    private void initialize() throws SQLException {
        LOGGER.debug("Retrieving info for Marketers");
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("RPMI_MKTR_ID , RPMI_POL_NR, RPMI_CGE_DATE,  RPMI_COMM_TYPE, RPMI_INTM_NR, RPMI_INTM_PCT ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("RPMI_MKTR_INFO ");
        sqlStatement.append("ORDER BY RPMI_MKTR_ID ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");

        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestMarketerInfo", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }
}

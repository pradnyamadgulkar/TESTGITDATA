/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for ADSH_SCHD_HST table.
 */
public class FixtureTestAdvanceScheduleHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestAdvanceScheduleHistory.class);

    private long scheduleId;
    private String commissionAmountMon;
    private String commissionAmountMonthly;
    private int scheduleStatus;
    private String statusEndDate;
    private long eipId;
    private long eventInProcessId;
    private int eipType;
    private int eventInProcessType;
    private String eipDate;
    private String eventInProcessDate;
    private int scheduleHistoryVer;

    public FixtureTestAdvanceScheduleHistory() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestAdvanceScheduleHistory.execute()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setScheduleId(getResultSet().getLong("ADSH_SCHD_ID"));
            setCommissionAmountMonthly(getResultSet().getDouble("ADSH_COMM_AMT_MON"));
            setScheduleStatus(getResultSet().getInt("ADSH_SCHD_STS"));
            setStatusEndDate(format(getResultSet().getDate("ADSH_STS_END_DT")));
            setEventInProcessId(getResultSet().getLong("ADSH_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("ADSH_EIP_TYP"));
            setEventInProcessDate(format(getResultSet().getDate("ADSH_EIP_DT")));
            setCreatedBy(getResultSet().getString("ADSH_CRTD_BY").trim());
            setVersion(getResultSet().getInt("ADSH_SCHD_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            // --
            setCommissionAmountMon(Double.parseDouble(commissionAmountMonthly()));
            setEipId(eventInProcessId());
            setEipType(eventInProcessType());
            setEipDate(eventInProcessDate());
            setScheduleHistoryVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestAdvanceScheduleHistory: " + ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestAdvanceScheduleHistory", se);
            }
        }

        LOG.debug("Exit FixtureTestAdvanceScheduleHistory.execute()");
    }

    // ---
    /**
     * @return the commissionAmountMonthly
     */
    public String commissionAmountMonthly() {
        return formatDouble(commissionAmountMonthly);
    }

    /**
     * @param commissionAmountMonthly
     *            the commissionAmountMonthly to set
     */
    public void setCommissionAmountMonthly(double commissionAmountMonthly) {
        this.commissionAmountMonthly = String.valueOf(commissionAmountMonthly);
    }

    /**
     * @return the eventInProcessId
     */
    public long eventInProcessId() {
        return eventInProcessId;
    }

    /**
     * @param eventInProcessId
     *            the eventInProcessId to set
     */
    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    /**
     * @return the eventInProcessType
     */
    public int eventInProcessType() {
        return eventInProcessType;
    }

    /**
     * @param eventInProcessType
     *            the eventInProcessType to set
     */
    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    /**
     * @return the eventInProcessDate
     */
    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    /**
     * @param eventInProcessDate
     *            the eventInProcessDate to set
     */
    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    public long scheduleId() {
        return scheduleId;
    }

    public void setScheduleId(long scheduleId) {
        this.scheduleId = scheduleId;
    }

    @Deprecated
    public String commissionAmountMon() {
        if (commissionAmountMon != null) {
            if (BigDecimal.valueOf(Double.parseDouble(commissionAmountMon)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(commissionAmountMon).intValue());
            }
        }
        return commissionAmountMon;
    }

    @Deprecated
    public void setCommissionAmountMon(double commissionAmountMon) {
        this.commissionAmountMon = Double.toString(commissionAmountMon);
    }

    public int scheduleStatus() {
        return scheduleStatus;
    }

    public void setScheduleStatus(int scheduleStatus) {
        this.scheduleStatus = scheduleStatus;
    }

    public String statusEndDate() {
        return statusEndDate;
    }

    public void setStatusEndDate(String string) {
        this.statusEndDate = string;
    }

    @Deprecated
    public long eipId() {
        return eipId;
    }

    @Deprecated
    public void setEipId(long eipId) {
        this.eipId = eipId;
    }

    @Deprecated
    public int eipType() {
        return eipType;
    }

    @Deprecated
    public void setEipType(int eipType) {
        this.eipType = eipType;
    }

    @Deprecated
    public String eipDate() {
        return eipDate;
    }

    @Deprecated
    public void setEipDate(String string) {
        this.eipDate = string;
    }

    @Deprecated
    public int scheduleHistoryVer() {
        return scheduleHistoryVer;
    }

    @Deprecated
    public void setScheduleHistoryVer(int scheduleHistoryVer) {
        this.scheduleHistoryVer = scheduleHistoryVer;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT ADSH_SCHD_ID, ADSH_COMM_AMT_MON, ADSH_SCHD_STS, ADSH_STS_END_DT, "
                    + "ADSH_EIP_ID, ADSH_EIP_TYP, ADSH_EIP_DT, ADSH_CRTD_BY, ADSH_SCHD_HST_VER, DM_LSTUPDDT from {0}"
                    + "ADSH_SCHD_HST  ORDER BY ADSH_SCHD_ID, ADSH_EIP_ID FOR FETCH ONLY WITH UR");
}

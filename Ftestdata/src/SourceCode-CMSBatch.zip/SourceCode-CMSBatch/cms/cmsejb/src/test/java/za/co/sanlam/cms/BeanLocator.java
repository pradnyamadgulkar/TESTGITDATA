package za.co.sanlam.cms;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.access.BeanFactoryLocator;
import org.springframework.beans.factory.access.BeanFactoryReference;
import org.springframework.context.access.ContextSingletonBeanFactoryLocator;

/**
 *
 */
public class BeanLocator {

    private static BeanFactory factory;

    public static Object locateBean(String name) {
        if (factory == null) {
            BeanFactoryLocator locator = ContextSingletonBeanFactoryLocator.getInstance();
            BeanFactoryReference ref = locator.useBeanFactory("beans");
            factory = ref.getFactory();
        }

        return factory.getBean(name);
    }
}

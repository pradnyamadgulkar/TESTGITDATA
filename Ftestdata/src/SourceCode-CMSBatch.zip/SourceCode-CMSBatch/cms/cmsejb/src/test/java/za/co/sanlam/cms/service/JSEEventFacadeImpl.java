package za.co.sanlam.cms.service;

import KomEvents.*;
import KomEventsMDB.AgtRetroVatMDBBean;
import KomEventsMDB.KomEventsMDBBean;
import KomEventsRef.KomEventsRefBEAN;
import KomEventsRef.KomEventsRefDataFactory;
import KomEventsRules.KomEventsRulesBEAN;
import KomSecurity.KomSecurityBEAN;
import com.atomikos.icatch.jta.UserTransactionImp;
import com.atomikos.icatch.jta.UserTransactionManager;
import com.tcs.mastercraft.mctype.ServerContext;
import org.apache.xmlbeans.XmlCursor;
import org.apache.xmlbeans.XmlOptions;
import org.mockejb.*;
import org.mockejb.interceptor.*;
import org.mockejb.jms.MockQueue;
import org.mockejb.jms.QueueConnectionFactoryImpl;
import org.mockejb.jndi.MockContextFactory;
import za.co.sanlam.sib.commission.commevent.CommissionableEventDocument;
import za.co.sanlam.sib.commission.commevent.CommissionableEventType;
import za.co.sanlam.sib.commission.commevent.IntdCommInfoType;

import javax.jms.*;
import javax.jms.Queue;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.transaction.UserTransaction;
import javax.xml.namespace.QName;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

//import org.mockejb.TransactionManager;

public class JSEEventFacadeImpl implements EventFacade {

    private MockContainer mockContainer;
    private Context context;
    private Queue queue;
    private XmlOptions xmlOptions = null;
    private XmlCursor xmlCursor = null;
    private QName QNXmlns = null;
    private QName QNXmi = null;
    // Aspect system used by this test
    private AspectSystem aspectSystem;

    //Dependencies
    private DataSource dataSource;
    private String webServiceProperties;
    private String schemaName;
    private String enablePrint;


    public void handleEvents(CommissionEvent commissionEvent) {
        sendMessage(commissionEvent);
    }

    public void handleEvents(RetroVATEvent retroVATEvent) {
        sendMessage(retroVATEvent);
    }

    public void initialize() {

        try {

            aspectSystem =  AspectSystemFactory.getAspectSystem();

            //MockContextFactory becomes the primary JNDI provider
            MockContextFactory.setAsInitial();
            context = new InitialContext();
            mockContainer = new MockContainer(context);

            String lamdaQ = "jms/queue/LAMDAQ";
            String retroQ = "jms/queue/RETROQ";
            String factoryName = "jms/QueueConnectionFactory";
            QueueConnectionFactory qcf = new QueueConnectionFactoryImpl();
            context.rebind(factoryName, qcf);
            queue = new MockQueue(lamdaQ);
            context.rebind(lamdaQ, this.queue);

            URL configFile = JSEEventFacadeImpl.class.getResource("/config.properties");


            context.rebind("java:comp/env/url/mcappkom/ConfigPropertiesURL",configFile);


            context.rebind("java:comp/env/WebServiceProperties",webServiceProperties);

            ServerContext.setDataSource(dataSource);
            context.rebind("java:comp/env/jdbc/MCDataSource", dataSource);

            ServerContext.getServerContextObject().setSchemaName(schemaName);
            KomEventsRefDataFactory.loadReferenceData();


            ServerContext.getClientContext().setUserDefinedProperties("WebServiceProperties",webServiceProperties);

            context.rebind("java:comp/env/mastercraft.ejb.enablePrint",enablePrint);

            KomEventsMDBBean komEventsMDBBean = new KomEventsMDBBean();
            ((MockQueue) queue).addMessageListener(komEventsMDBBean);

            // Create a deployment descriptor for the MDB
            // and set the flag indicating that the JMS
            // objects are already created and bound to the
            // specified names
            MDBDescriptor mdbDD = new MDBDescriptor(factoryName,
                    lamdaQ, komEventsMDBBean);
            mdbDD.setIsAlreadyBound(true);
            this.mockContainer.deploy(mdbDD);

            //Retro Queue Binding
            queue = new MockQueue(retroQ);
            context.rebind(retroQ, this.queue);

            //Setup transaction manager
            UserTransaction userTransactionImp = new UserTransactionImp();
            context.rebind("javax.transaction.UserTransaction", userTransactionImp);

            //Bind transaction to EJBs

            bindTransaction(new ClassPointcut(KomEventsBEAN.class), TransactionPolicy.REQUIRED);
            bindTransaction(PointcutPair.and(new ClassPointcut(KomEventsBEAN.class),new MethodPatternPointcut("sh_delegateEvent")),
                    TransactionPolicy.REQUIRED_NEW);
            bindTransaction(PointcutPair.and(new ClassPointcut(KomEventsBEAN.class),new MethodPatternPointcut("sh_handleRejectedEvents")),
                    TransactionPolicy.REQUIRED_NEW);
            bindTransaction(PointcutPair.and(new ClassPointcut(KomEventsBEAN.class),new MethodPatternPointcut("sh_delegateRetroEvent")),
                    TransactionPolicy.REQUIRED_NEW);
            bindTransaction(new ClassPointcut(KomEventsRefBEAN.class), TransactionPolicy.REQUIRED);
            bindTransaction(new ClassPointcut(KomEventsRulesBEAN.class), TransactionPolicy.REQUIRED);
            bindTransaction(new ClassPointcut(KomSecurityBEAN.class), TransactionPolicy.REQUIRED);


            AgtRetroVatMDBBean vatMDBBean = new AgtRetroVatMDBBean();
            ((MockQueue) queue).addMessageListener(vatMDBBean);
            //MockEjbObject.setTransactionPolicy(TransactionPolicy.REQUIRED_NEW);
            // Create a deployment descriptor for the MDB
            // and set the flag indicating that the JMS
            // objects are already created and bound to the
            // specified names
            MDBDescriptor retroVATMDBDD = new MDBDescriptor(factoryName,
                    retroQ, vatMDBBean);
            retroVATMDBDD.setIsAlreadyBound(true);
            this.mockContainer.deploy(retroVATMDBDD);


            // Remote Session bean deploy
            SessionBeanDescriptor sampleBeanDescriptor = new SessionBeanDescriptor(
                    "ejb/KomEvents", KomEventsBEAN_HOME_INTF.class,
                    KomEventsBEAN_INTF.class, new KomEventsBEAN());
            this.mockContainer.deploy(sampleBeanDescriptor);

            // Local Session bean deploy
            SessionBeanDescriptor komEventsLocalBeanDescriptor = new SessionBeanDescriptor(
                    "java:comp/env/ejb/LocalKomEvents",
                    KomEventsBEAN_LOCAL_HOME_INTF.class,
                    KomEventsBEAN_LOCAL_INTF.class, new KomEventsBEAN());
            this.mockContainer.deploy(komEventsLocalBeanDescriptor);

        } catch (NamingException e) {
            e.printStackTrace();
        } catch (JMSException e) {
            e.printStackTrace();
        }
    }

    private void bindTransaction(Pointcut defaultKomEventsBeanPointcut, TransactionPolicy policy) {
        TransactionManagerAdapter manager = new TransactionManagerAdapter();

        manager.setPolicy(policy);

        manager.setTransactionManager(new UserTransactionManager());

        aspectSystem.add(defaultKomEventsBeanPointcut, manager);
    }

    public void sendMessage(CommissionEvent commissionEvent){
        initialize();
        try {

            // Provide us with access to the queues
            Queue queue = (Queue) context.lookup("jms/queue/LAMDAQ");

            // lookup the queue connection factory
            QueueConnectionFactory connFactory = (QueueConnectionFactory) context
                    .lookup("jms/QueueConnectionFactory");
            QueueConnection queueConnection = connFactory
                    .createQueueConnection();
            QueueSession queueSession = queueConnection.createQueueSession(
                    false, Session.AUTO_ACKNOWLEDGE);

            // create a queue sender
            QueueSender queueSender = queueSession.createSender(queue);
            queueSender.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            // create the message
            TextMessage textMessage = queueSession.createTextMessage();
            //textMessage
            //	.setText("<q1:commissionableEvent xmi:schemaLocation=\"http://sib.sanlam.co.za/commission/commevent.xsd CommEvent.xsd\" xmlns:q1=\"http://sib.sanlam.co.za/commission/commevent.xsd\" xmlns:xmi=\"http://www.w3.org/2001/XMLSchema-instance\"><policyNo>0000000015</policyNo><productType>D03</productType><noOfPrmRecvd>0</noOfPrmRecvd><clientOwnerPortfolioNo>VDWCH006</clientOwnerPortfolioNo><clientInsuredPortfolioNo>VDWCH006</clientInsuredPortfolioNo><clientInsuredSurname>VAN DER WESTHUIZEN</clientInsuredSurname><clientInsuredInitials>CH   </clientInsuredInitials><orgPolicyNo>0</orgPolicyNo><currency>1</currency><sourceSys>1</sourceSys><productNameCode>D03</productNameCode><randValuePrmInArrears>0</randValuePrmInArrears><policyTotalPremium>0</policyTotalPremium><warningLevel>0</warningLevel><eventType>1</eventType><eventEffDate>20091001</eventEffDate><taxFundGroupCode>5</taxFundGroupCode><commissionType>2     </commissionType><premiumPymtMethod>1</premiumPymtMethod><premiumFreq>1</premiumFreq><campaignCode>0       </campaignCode><indexGrowthType>1</indexGrowthType><quotationDate>20120101</quotationDate><appInDate>20090904</appInDate><indexPlanOptionInd>false</indexPlanOptionInd><noOfElements>1</noOfElements><premiumHolidayStartDate>20091001</premiumHolidayStartDate><premiumHolidayEndDate>99991231</premiumHolidayEndDate><rparInd>false</rparInd><spclReInsInd>false</spclReInsInd><coversionInd>false</coversionInd><transactionTs>2006-09-09 09:36:01.000000</transactionTs><elementNo>1</elementNo><elementStDate>20091001</elementStDate><elementTerm>60</elementTerm><elementPremium>3600</elementPremium><fundValue>0</fundValue><premiumReductionPct>0</premiumReductionPct><salesCommMonthlyAmt>15</salesCommMonthlyAmt><serviceCommMonthlyAmt>0</serviceCommMonthlyAmt><fundCommMonthlyAmt>0</fundCommMonthlyAmt><intdCommInfo><intermediaryNo>173525</intermediaryNo><appInNo>0</appInNo><manCode>0</manCode><salesCommSplitPct>100</salesCommSplitPct><serviceCommSplitPct>100</serviceCommSplitPct><fundCommSplitPct>0</fundCommSplitPct></intdCommInfo><policyIssueDate>20090911</policyIssueDate><salesCommNegotiatedPct>100</salesCommNegotiatedPct><serviceCommNegotiatedPct>0</serviceCommNegotiatedPct><scoreTerm>0</scoreTerm><combAltInd>0</combAltInd><elemReplacedInd>0</elemReplacedInd><transferSourceRA>0</transferSourceRA></q1:commissionableEvent>");
            textMessage.setText(createMessage(commissionEvent));
            queueSender.send(textMessage);
            // print what we did
            System.out.println("sent: " + textMessage.getText());
            // close the queue connection
            queueConnection.close();

        } catch (JMSException e) {
            e.printStackTrace();
            e.getMessage();
        } catch (NamingException e) {
            e.printStackTrace();
            e.getMessage();
        }catch (Exception e) {
            e.printStackTrace();
            e.getMessage();
        }
    }


    public void sendMessage(RetroVATEvent retroVATEvent){
        initialize();

        try {

            // Provide us with access to the queues
            Queue queue = (Queue) context.lookup("jms/queue/RETROQ");

            // lookup the queue connection factory
            QueueConnectionFactory connFactory = (QueueConnectionFactory) context
                    .lookup("jms/QueueConnectionFactory");
            QueueConnection queueConnection = connFactory
                    .createQueueConnection();
            QueueSession queueSession = queueConnection.createQueueSession(
                    false, Session.AUTO_ACKNOWLEDGE);

            // create a queue sender
            QueueSender queueSender = queueSession.createSender(queue);
            queueSender.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

            // create the message
            TextMessage textMessage = queueSession.createTextMessage();

            textMessage.setText(createMessage(retroVATEvent));
            queueSender.send(textMessage);
            //ServerContext.getJDBCHandle().commit();
            // print what we did
            System.out.println("sent: " + textMessage.getText());

            // close the queue connection
            queueConnection.close();

        } catch (JMSException e) {
            e.printStackTrace();
            e.getMessage();
        } catch (NamingException e) {
            e.printStackTrace();
            e.getMessage();
        }catch (Exception e) {
            e.printStackTrace();
            e.getMessage();
        }
    }

    public String createMessage(RetroVATEvent retroVATEvent) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        StringBuffer retroVATEventMessage = new StringBuffer(50);
        //String timeStamp=Long.toString(retroVATEvent.getTransactionTimestamp().getTime());
        retroVATEventMessage.append("0000000000000000000000000000");
        String intermediaryNumber=Integer.toString(retroVATEvent.getIntermediaryNumber());
        retroVATEventMessage.append("0000000000".substring(0,10 - intermediaryNumber.length())+ intermediaryNumber);
        retroVATEventMessage.append(retroVATEvent.getVatStatus());
        retroVATEventMessage.append(simpleDateFormat.format(retroVATEvent.getEventEffectiveDate()));
        String eventType=Integer.toString(retroVATEvent.getEventType());
        retroVATEventMessage.append("000".substring(0,3 - eventType.length())+ eventType);
        System.out.println("Input Message RetroVAT :"+retroVATEventMessage);
        System.out.println("Intermediary Number :"+retroVATEventMessage.toString().substring(28,38));
        System.out.println("VAT Status :"+retroVATEventMessage.toString().charAt(38));
        System.out.println("Date :"+retroVATEventMessage.toString().substring(39, 47));
        System.out.println("EventType :"+retroVATEventMessage.toString().substring(47,50));
        return retroVATEventMessage.toString();
    }

    public String createMessage(CommissionEvent commissionEvent){

        CommissionableEventDocument commissionableEventDoc = null;
        CommissionableEventType commissionableEventType = null;
        String DATE_FORMAT = "yyyyMMdd";
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);

        commissionableEventDoc = CommissionableEventDocument.Factory.newInstance();
        commissionableEventType = commissionableEventDoc.addNewCommissionableEvent();
        int eventType = commissionEvent.getEventType();
        int elementNo = commissionEvent.getElementNumber();
        Date premiumHolidayStartDate = commissionEvent.getPremiumHolidayStartDate();
        Date premiumHolidayEndDate = commissionEvent.getPremiumHolidayEndDate();
        int elementTerm = commissionEvent.getElementTerm();

        commissionableEventType.setEventType(eventType);
        commissionableEventType.setEventEffDate(sdf.format(commissionEvent.getEventEffectiveDate()));
        commissionableEventType.setPremiumHolidayStartDate(sdf.format(premiumHolidayStartDate));
        commissionableEventType.setPremiumHolidayEndDate(sdf.format(premiumHolidayEndDate));
        commissionableEventType.setCommissionType(commissionEvent.getCommissionType().trim());
        commissionableEventType.setPremiumReductionPct(new BigDecimal(Double.toString(commissionEvent.getPremiumReductionPercentage())));
        commissionableEventType.setIndexGrowthType(commissionEvent.getIndexGrowthType());
        commissionableEventType.setCampaignCode(commissionEvent.getCampaignCode().trim());
        commissionableEventType.setIndexPlanOptionInd(commissionEvent.getIndexPlanOptionIndicator()== 1?true:false);
        commissionableEventType.setTaxFundGroupCode(commissionEvent.getTaxFundGroupCode());
        commissionableEventType.setNoOfElements(commissionEvent.getNoOfElements());
        commissionableEventType.setElementTerm(elementTerm);
        commissionableEventType.setRparInd(commissionEvent.getRparIndicator()== 1?true:false);
        commissionableEventType.setSpclReInsInd(commissionEvent.getSpecialReInstatementIndicator()== 1?true:false);
        commissionableEventType.setTransferSourceRA(commissionEvent.getTransferSourceRA());
        commissionableEventType.setTransactionTs(commissionEvent.getTransactionTimestamp().toString());
        commissionableEventType.setNoOfPrmRecvd(commissionEvent.getNoOfPremiumReceived());
        commissionableEventType.setElementNo(elementNo);
        commissionableEventType.setRandValuePrmInArrears(new BigDecimal(Double.toString(commissionEvent.getRandValuePremiumInArrears())));
        commissionableEventType.setPolicyTotalPremium(new BigDecimal(Double.toString(commissionEvent.getPolicyTotalPremium())));
        commissionableEventType.setWarningLevel(commissionEvent.getWarningLevel());
        commissionableEventType.setAppInDate(sdf.format(commissionEvent.getApplicationInceptionDate()));
        commissionableEventType.setQuotationDate(sdf.format(commissionEvent.getQuotationDate()));
        commissionableEventType.setPolicyNo(commissionEvent.getPolicyNumber().trim());
        commissionableEventType.setProductType(commissionEvent.getProductType() != null ? commissionEvent.getProductType().trim() : "");
        commissionableEventType.setProductNameCode(commissionEvent.getProductNameCode() != null ? commissionEvent.getProductNameCode().trim() : commissionableEventType.getProductType());
        commissionableEventType.setPremiumFreq(commissionEvent.getPremiumFrequency());
        commissionableEventType.setPremiumPymtMethod(commissionEvent.getPremiumPaymentMethod());
        commissionableEventType.setClientOwnerPortfolioNo(commissionEvent.getClientOwnerPortfolioNo().trim());
        commissionableEventType
                .setClientInsuredPortfolioNo(commissionEvent.getClientInsuredPortfolioNo());
        commissionableEventType.setClientInsuredSurname(commissionEvent.getClientInsuredSurname());
        commissionableEventType.setClientInsuredInitials(commissionEvent.getClientInsuredInitials());
        commissionableEventType.setCurrency(commissionEvent.getCurrency());
        commissionableEventType.setSourceSys(commissionEvent.getSourceSystem());

        commissionableEventType.setPolicyIssueDate(sdf.format(commissionEvent.getPolicyIssueDate()));
        commissionableEventType.setCoversionInd(commissionEvent.getCoversionIndicator()== 1 ? true:false);
        commissionableEventType.setElementStDate(sdf.format(commissionEvent.getElementStartDate()));
        commissionableEventType.setScoreTerm(commissionEvent.getScoreTerm());
        commissionableEventType.setElementPremium(new BigDecimal(Double.toString(commissionEvent
                .getElementPremium())));
        commissionableEventType.setSalesCommMonthlyAmt(new BigDecimal(Double.toString(commissionEvent.getSalesCommissionMonthlyAmount())));
        commissionableEventType.setServiceCommMonthlyAmt(new BigDecimal(Double.toString(commissionEvent.getServiceCommissionMonthlyAmount())));
        commissionableEventType.setServiceCommNegotiatedPct(new BigDecimal(Double.toString(commissionEvent.getServiceCommissionNegotiatedPercentage())));
        commissionableEventType.setSalesCommNegotiatedPct(new BigDecimal(Double.toString(commissionEvent.getSalesCommissionNegotiatedPercentage())));
        commissionableEventType.setFundCommMonthlyAmt(new BigDecimal(Double.toString(commissionEvent.getFundCommissionMonthlyAmount())));
        commissionableEventType.setFundValue(new BigDecimal(Double.toString(commissionEvent.getFundValue())));
        commissionableEventType.setOrgPolicyNo(commissionEvent.getOrginalPolicyNumber());
        commissionableEventType.setCombAltInd(commissionEvent.getCombinedAlterationIndicator());
        commissionableEventType.setElemReplacedInd(commissionEvent.getReplacementIndicator());
        commissionableEventType.setCommissionPremiumAmount(new BigDecimal(commissionEvent.getElementScorePremium()));
        commissionableEventType.setPremiumAtConversionAmount(new BigDecimal(commissionEvent.getConversionPremium()));

        List<IntdCommInfoType> intermediaries = new ArrayList<IntdCommInfoType>();
        for (IntermediaryInfo intermediaryInfo : commissionEvent.getIntermediarys()) {
            IntdCommInfoType intermediary = IntdCommInfoType.Factory.newInstance();
            intermediary.setIntermediaryNo((int) intermediaryInfo.getIntermediaryNumber());
            intermediary.setAppInNo(intermediaryInfo.getApplicationNumber());
            intermediary.setManCode(intermediaryInfo.getManCode());
            intermediary.setSalesCommSplitPct(new BigDecimal(Double.toString(intermediaryInfo.getSalesCommissionSplitPercentage())));
            intermediary.setServiceCommSplitPct(new BigDecimal(Double.toString(intermediaryInfo.getServiceCommissionSplitPercentage())));
            intermediary.setFundCommSplitPct(new BigDecimal(Double.toString(intermediaryInfo.getFundCommissionSplitPercentage())));
            intermediaries.add(intermediary);
        }
        commissionableEventType.setIntdCommInfoArray(intermediaries.toArray(new IntdCommInfoType[intermediaries
                .size()]));
        
        xmlOptions = new XmlOptions();
        // Create new XML string according the the input event
        // details.
        xmlCursor = commissionableEventDoc.newCursor();
        QNXmlns = new QName("http://sib.sanlam.co.za/commission/commevent.xsd", "q1", "xmlns");
        QNXmi = new QName("http://www.w3.org/2001/XMLSchema-instance", "schemaLocation", "xmi");
        xmlCursor.toNextToken();
        xmlCursor.toNextToken();
        xmlCursor.insertAttributeWithValue(QNXmlns, "http://sib.sanlam.co.za/commission/commevent.xsd");
        xmlCursor.insertAttributeWithValue(QNXmi, "http://sib.sanlam.co.za/commission/commevent.xsd CommEvent.xsd");
        return commissionableEventDoc.xmlText(xmlOptions);
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void setWebServiceProperties(String webServiceProperties) {
        this.webServiceProperties = webServiceProperties;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public void setEnablePrint(String enablePrint) {
        this.enablePrint = enablePrint;
    }
}

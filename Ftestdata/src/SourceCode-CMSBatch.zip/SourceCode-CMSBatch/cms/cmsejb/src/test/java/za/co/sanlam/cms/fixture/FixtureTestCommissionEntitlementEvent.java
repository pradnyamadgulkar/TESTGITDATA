/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for CEEI_CEE_EVT table.
 */
public class FixtureTestCommissionEntitlementEvent extends FixtureTestMasterEvent {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestCommissionEntitlementEvent.class);

    private String startDate;
    private int comEntitlmentInfoVer;

    public FixtureTestCommissionEntitlementEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestCommGenEvent.execute()");
        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("CEEI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("CEEI_CEE_EVT_TYP"));
            setStartDate(format(getResultSet().getDate("CEEI_CEE_START_DT")));
            setPolicyNumber(getResultSet().getString("CEEI_POL_NR").trim());
            setCreatedBy(getResultSet().getString("CEEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("CEEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("CEEI_CEE_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setComEntitlmentInfoVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception Encountered in operation execute of class FixtureTestComEntitlementEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestComEntitlementEvent", se);
            }
        }
        LOG.debug("Exit FixtureTestCommGenEvent.execute()");
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String startDate() {
        return startDate;
    }

    @Deprecated
    public void setComEntitlmentInfoVer(int comEntitlmentInfoVer) {
        this.comEntitlmentInfoVer = comEntitlmentInfoVer;
    }

    @Deprecated
    public int comEntitlmentInfoVer() {
        return comEntitlmentInfoVer;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT CEEI_MSTR_EVT_ID, CEEI_CEE_EVT_TYP, CEEI_CEE_START_DT, CEEI_POL_NR, " + "CEEI_CRTD_BY, CEEI_UPD_BY, "
                    + "CEEI_CEE_EVT_VER, DM_LSTUPDDT from {0}CEEI_CEE_EVT ORDER BY CEEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");
}

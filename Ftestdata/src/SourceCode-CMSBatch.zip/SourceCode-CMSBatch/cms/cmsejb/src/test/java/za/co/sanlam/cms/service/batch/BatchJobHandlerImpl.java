package za.co.sanlam.cms.service.batch;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.annotation.BeforeJob;

import KomEvents.KomEventsBatchPrgInvoker;

public class BatchJobHandlerImpl implements BatchJobHandler, JobExecutionListener {

    private String webServiceProperties;
    private long batchType;

    public void processJob(int batchKey) {
        try {
            System.setProperty("WebServiceProperties", webServiceProperties);

            switch (batchKey) {
                case 100:
                    KomEventsBatchPrgInvoker.processCGEKommb();
                    break;
                case 110:
                    KomEventsBatchPrgInvoker.processOneOffKommb();
                case 120:
                    KomEventsBatchPrgInvoker.processOneOffEvents();
                    break;
                case 210:
                    KomEventsBatchPrgInvoker.processScheduledPayments();
                    break;
                case 410:
                    KomEventsBatchPrgInvoker.processReplacements();
                    break;
                case 420:
                    KomEventsBatchPrgInvoker.processPremiumHistory();
                    break;
                case 430:
                    KomEventsBatchPrgInvoker.processReplacementTriggers();
                    break;
                case 440:
                    KomEventsBatchPrgInvoker.processReplacementPolicy();
                    break;
                case 450:
                    KomEventsBatchPrgInvoker.processReplacementReinstates();
                    break;
                case 460:
                    KomEventsBatchPrgInvoker.processReplacementIdentityEvent(batchType);
                    break;
                case 910:
                    KomEventsBatchPrgInvoker.invokeKMIFToACASAuditBatch();
                    break;
                case 920:
                    KomEventsBatchPrgInvoker.invokeUnvestedCommissionAuditBatch();
                    break;
                case 700:
                    KomEventsBatchPrgInvoker.processFutureCommissionProjectionBatch();
                    break;
                case 702:
                    System.setProperty("FULLRUN", "TRUE");
                    KomEventsBatchPrgInvoker.processFutureCommissionProjectionPreProcessingBatch();
                    break;
                case 703:
                    KomEventsBatchPrgInvoker.processFutureCommissionProjectionPreProcessingBatch();
                    break;
                case 500:
                    KomEventsBatchPrgInvoker.processUnvestedCommissionProjectionBatch();
                    break;
                case 502:
                    System.setProperty("FULLRUN", "TRUE");
                    KomEventsBatchPrgInvoker.processUnvestedCommissionProjectionPreProcessingBatch();
                    break;
                case 503:
                    KomEventsBatchPrgInvoker.processUnvestedCommissionProjectionPreProcessingBatch();
                    break;
                case 790:
                    KomEventsBatchPrgInvoker.invokeAsisaReplacementInfoLoadingBatch();
                    break;
                case 791:
                    KomEventsBatchPrgInvoker.invokeAsisaReplacementInfoProcessingBatch();
                    break;
                case 960:
                    KomEventsBatchPrgInvoker.processRetroEvent();
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void processJob(int batchKey, int batchType) {
        setBatchType(batchType);
        processJob(batchKey);
    }

    public void setWebServiceProperties(String webServiceProperties) {
        this.webServiceProperties = webServiceProperties;
    }

    public void setBatchType(long batchType) {
        this.batchType = batchType;
    }

    public void afterJob(JobExecution arg0) {

    }

    @BeforeJob
    public void beforeJob(JobExecution jobExecution) {
        batchType = jobExecution.getJobInstance().getJobParameters().getLong("batchType");
    }
}

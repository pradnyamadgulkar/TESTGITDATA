/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for TRIF_TRCH_INF table.
 */
public class FixtureTestTrancheInfo extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestTrancheInfo.class);

    private long trancheId;
    private String policyNumber;
    private long masterEventId;
    private int elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private String splitCommissionId;
    private int scheduleType;
    private int trancheNumber;
    private String startDate;
    private String endDate;
    private String advanceCommissionAmount;
    private String advanceCommAmnt;
    private String clawbackCommissionAmount;
    private String clwBackCommAmnt;
    private String vatAmount;
    private String clawbackVatAmount;
    private String clwBackVatAmount;
    private String multiplicationFactor;
    private String multFactor;
    private String vatRate;
    private int trancheStatus;
    private String statusChangedDate;
    private String statusChangdDate;
    private long eventInProcessId;
    private String paymentDate;
    private int paymentAccount;
    private int trancheInfoVer;

    public FixtureTestTrancheInfo() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestTrancheInfo.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setTrancheId(getResultSet().getLong("TRIF_TRCH_ID"));
            setPolicyNumber(getResultSet().getString("TRIF_POL_NR"));
            setMasterEventId(getResultSet().getLong("TRIF_MSTR_EVT_ID"));
            setElementNumber(getResultSet().getInt("TRIF_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("TRIF_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("TRIF_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getString("TRIF_SPLT_COMM_ID"));
            setScheduleType(getResultSet().getInt("TRIF_SCHD_TYP"));
            setTrancheNumber(getResultSet().getInt("TRIF_TRCH_NR"));
            setStartDate(format(getResultSet().getDate("TRIF_START_DT")));
            setEndDate(format(getResultSet().getDate("TRIF_END_DT")));
            setAdvanceCommissionAmount(getResultSet().getDouble("TRIF_ADV_COMM_AMT"));
            setClawbackCommissionAmount(getResultSet().getDouble("TRIF_CLBK_COMM_AMT"));
            setVatAmount(getResultSet().getDouble("TRIF_VAT_AMT"));
            setClawbackVatAmount(getResultSet().getDouble("TRIF_CLBK_VAT_AMT"));
            setMultiplicationFactor(getResultSet().getDouble("TRIF_MUL_FACT"));
            setVatRate(getResultSet().getDouble("TRIF_VAT_RT"));
            setTrancheStatus(getResultSet().getInt("TRIF_TRCH_STS"));
            setStatusChangedDate(format(getResultSet().getDate("TRIF_STS_CHGD_DT")));
            setEventInProcessId(getResultSet().getLong("TRIF_EIP_ID"));
            setPaymentDate(format(getResultSet().getDate("TRIF_PMT_DT")));
            setPaymentAccount(getResultSet().getInt("TRIF_PMT_ACC"));
            setCreatedBy(getResultSet().getString("TRIF_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("TRIF_UPD_BY").trim());
            setVersion(getResultSet().getInt("TRIF_TRCH_INF_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setAdvanceCommAmnt(Double.parseDouble(advanceCommissionAmount()));
            setClwBackCommAmnt(Double.parseDouble(clawbackCommissionAmount()));
            setClwBackVatAmount(Double.parseDouble(clawbackVatAmount()));
            setMultFactor(Double.parseDouble(multiplicationFactor()));
            setStatusChangdDate(statusChangedDate());
            setTrancheInfoVer(version());

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestTrancheInfo", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestTrancheInfo", se);
            }
        }
    }

    /**
     * @return the advanceCommissiomAmount
     */
    public String advanceCommissionAmount() {
        return formatDouble(advanceCommissionAmount);
    }

    /**
     * @param advanceCommissiomAmount
     *            the advanceCommissiomAmount to set
     */
    public void setAdvanceCommissionAmount(double advanceCommissionAmount) {
        this.advanceCommissionAmount = String.valueOf(advanceCommissionAmount);
    }

    /**
     * @return the clawbackCommissionAmount
     */
    public String clawbackCommissionAmount() {
        return formatDouble(clawbackCommissionAmount);
    }

    /**
     * @param clawbackCommissionAmount
     *            the clawbackCommissionAmount to set
     */
    public void setClawbackCommissionAmount(double clawbackCommissionAmount) {
        this.clawbackCommissionAmount = String.valueOf(clawbackCommissionAmount);
    }

    /**
     * @return the clawbackVatAmount
     */
    public String clawbackVatAmount() {
        return formatDouble(clawbackVatAmount);
    }

    /**
     * @param clawbackVatAmount
     *            the clawbackVatAmount to set
     */
    public void setClawbackVatAmount(double clawbackVatAmount) {
        this.clawbackVatAmount = String.valueOf(clawbackVatAmount);
    }

    /**
     * @return the multiplicationFactor
     */
    public String multiplicationFactor() {
        return formatDouble(multiplicationFactor);
    }

    /**
     * @param multiplicationFactor
     *            the multiplicationFactor to set
     */
    public void setMultiplicationFactor(double multiplicationFactor) {
        this.multiplicationFactor = String.valueOf(multiplicationFactor);
    }

    /**
     * @return the statusChangedDate
     */
    public String statusChangedDate() {
        return statusChangedDate;
    }

    /**
     * @param statusChangedDate
     *            the statusChangedDate to set
     */
    public void setStatusChangedDate(String statusChangedDate) {
        this.statusChangedDate = statusChangedDate;
    }

    public long trancheId() {
        return trancheId;
    }

    public void setTrancheId(long trancheId) {
        this.trancheId = trancheId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(int elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    public String splitCommissionId() {
        return splitCommissionId;
    }

    public void setSplitCommissionId(String splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    public int scheduleType() {
        return scheduleType;
    }

    public void setScheduleType(int scheduleType) {
        this.scheduleType = scheduleType;
    }

    public int trancheNumber() {
        return trancheNumber;
    }

    public void setTrancheNumber(int trancheNumber) {
        this.trancheNumber = trancheNumber;
    }

    public String startDate() {
        return startDate;
    }

    public void setStartDate(String string) {
        this.startDate = string;
    }

    public String endDate() {
        return endDate;
    }

    public void setEndDate(String string) {
        this.endDate = string;
    }

    @Deprecated
    public String advanceCommAmnt() {
        if (advanceCommAmnt != null) {
            if (BigDecimal.valueOf(Double.parseDouble(advanceCommAmnt)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(advanceCommAmnt).intValue());
            }
        }
        return advanceCommAmnt;
    }

    @Deprecated
    public void setAdvanceCommAmnt(double advanceCommAmnt) {
        this.advanceCommAmnt = Double.toString(advanceCommAmnt);
    }

    @Deprecated
    public String clwBackCommAmnt() {
        if (clwBackCommAmnt != null) {
            if (BigDecimal.valueOf(Double.parseDouble(clwBackCommAmnt)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(clwBackCommAmnt).intValue());
            }
        }
        return clwBackCommAmnt;
    }

    @Deprecated
    public void setClwBackCommAmnt(double clwBackCommAmnt) {
        this.clwBackCommAmnt = Double.toString(clwBackCommAmnt);
    }

    public String vatAmount() {
        return formatDouble(vatAmount);
    }

    public void setVatAmount(double vatAmount) {
        this.vatAmount = String.valueOf(vatAmount);
    }

    @Deprecated
    public String clwBackVatAmount() {
        if (clwBackVatAmount != null) {
            if (BigDecimal.valueOf(Double.parseDouble(clwBackVatAmount)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(clwBackVatAmount).intValue());
            }
        }
        return clwBackVatAmount;

    }

    @Deprecated
    public void setClwBackVatAmount(double clwBackVatAmount) {
        this.clwBackVatAmount = Double.toString(clwBackVatAmount);
    }

    @Deprecated
    public String multFactor() {
        if (multFactor != null) {
            if (BigDecimal.valueOf(Double.parseDouble(multFactor)).divideAndRemainder(BigDecimal.ONE)[1].signum() == 0) {
                return String.valueOf(Double.valueOf(multFactor).intValue());
            }
        }
        return multFactor;
    }

    @Deprecated
    public void setMultFactor(double multFactor) {
        this.multFactor = Double.toString(multFactor);
    }

    public String vatRate() {
        return formatDouble(vatRate);
    }

    public void setVatRate(double vatRate) {
        this.vatRate = String.valueOf(vatRate);
    }

    public int trancheStatus() {
        return trancheStatus;
    }

    public void setTrancheStatus(int trancheStatus) {
        this.trancheStatus = trancheStatus;
    }

    @Deprecated
    public String statusChangdDate() {
        return statusChangdDate;
    }

    @Deprecated
    public void setStatusChangdDate(String string) {
        this.statusChangdDate = string;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public String paymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String string) {
        this.paymentDate = string;
    }

    public int paymentAccount() {
        return paymentAccount;
    }

    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    @Deprecated
    public int trancheInfoVer() {
        return trancheInfoVer;
    }

    @Deprecated
    public void setTrancheInfoVer(int trancheInfoVer) {
        this.trancheInfoVer = trancheInfoVer;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "select TRIF_TRCH_ID,TRIF_POL_NR,TRIF_MSTR_EVT_ID,"
                    + "TRIF_ELMT_NR,TRIF_INTM_NR,TRIF_SPLT_COMM_TYP,TRIF_SPLT_COMM_ID,TRIF_SCHD_TYP,TRIF_TRCH_NR,"
                    + "TRIF_START_DT,TRIF_END_DT,TRIF_ADV_COMM_AMT,TRIF_CLBK_COMM_AMT,TRIF_VAT_AMT,TRIF_CLBK_VAT_AMT,TRIF_MUL_FACT,"
                    + "TRIF_VAT_RT,TRIF_TRCH_STS,TRIF_STS_CHGD_DT,TRIF_EIP_ID,TRIF_PMT_DT,TRIF_PMT_ACC,TRIF_CRTD_BY,"
                    + "TRIF_UPD_BY,TRIF_TRCH_INF_VER,DM_LSTUPDDT from {0}TRIF_TRCH_INF "
                    + "ORDER BY  TRIF_MSTR_EVT_ID, TRIF_ELMT_NR, TRIF_INTM_NR,TRIF_SPLT_COMM_TYP,TRIF_SPLT_COMM_ID,TRIF_SCHD_TYP,TRIF_TRCH_NR FOR FETCH ONLY WITH UR");
}

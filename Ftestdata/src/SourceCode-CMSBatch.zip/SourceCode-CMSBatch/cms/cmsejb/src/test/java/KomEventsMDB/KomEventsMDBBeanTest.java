package KomEventsMDB;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import za.co.sanlam.cms.BeanLocator;
import za.co.sanlam.cms.IntegrationTest;
import za.co.sanlam.cms.service.CommissionEvent;
import za.co.sanlam.cms.service.CommissionEventBuilder;
import za.co.sanlam.cms.service.EventFacade;

import com.tcs.mastercraft.mctype.ServerContext;
@Ignore
@Category(IntegrationTest.class)
public class KomEventsMDBBeanTest extends TestCase {

	private EventFacade facade;

	@Before
	public void setUp() throws Exception {
		facade = (EventFacade) BeanLocator.locateBean("eventFacade");
		ServerContext.getClientContext().setUserId(new StringBuffer("IntTest"));
	}

	@Test
	public void testOnMessage() throws Exception {
		CommissionEvent commissionEvent = new CommissionEventBuilder()
				.withProductNameCode(" ").withProductType(" ").withEventType(5).withPremiumReductionPercentage(10).build();
		facade.handleEvents(commissionEvent);

		commissionEvent.setPremiumReductionPercentage(0);
		facade.handleEvents(commissionEvent);
				
		commissionEvent.setProductType("D03");
		facade.handleEvents(commissionEvent);
	}
}

package za.co.sanlam.cms.fixture;

import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FixtureTestRetroVatEvent extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestRetroVatEvent.class);

    private long masterEventId;
    private int retroVatEventType;
    private String retroEventEffectiveDate;
    private long intermediaryNumber;
    private int retroVatStatus;
    private int retroProcessStatus;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT VAEI_MSTR_EVT_ID,VAEI_EVT_TYP, VAEI_VAT_STS,VAEI_VAT_EFF_DT,VAEI_PROC_STS,VAEI_INTM_NR, VAEI_CRTD_BY, VAEI_UPD_BY,"
                    + "VAEI_VAT_EVT_VER, DM_LSTUPDDT FROM {0}VAEI_VAT_EVT ORDER BY VAEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");

    public FixtureTestRetroVatEvent() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        LOG.debug("Entering FixtureTestRetroVatEvent.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("VAEI_MSTR_EVT_ID"));
            setRetroVatEventType(getResultSet().getInt("VAEI_EVT_TYP"));
            setRetroVatStatus(getResultSet().getInt("VAEI_VAT_STS"));
            setIntermediaryNumber(getResultSet().getLong("VAEI_INTM_NR"));
            setRetroEventEffectiveDate(format(getResultSet().getDate("VAEI_VAT_EFF_DT")));
            setRetroProcessStatus(getResultSet().getInt("VAEI_PROC_STS"));
            setCreatedBy(getResultSet().getString("VAEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("VAEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("VAEI_VAT_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestRetroVatEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestRetroEvent", se);
            }
        }
    }

    public long masterEventId() {
        return masterEventId;
    }

    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public int retroVatEventType() {
        return retroVatEventType;
    }

    public void setRetroVatEventType(int retroVatEventType) {
        this.retroVatEventType = retroVatEventType;
    }

    public String retroEventEffectiveDate() {
        return retroEventEffectiveDate;
    }

    public void setRetroEventEffectiveDate(String retroEventEffectiveDate) {
        this.retroEventEffectiveDate = retroEventEffectiveDate;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public int retroProcessStatus() {
        return retroProcessStatus;
    }

    public void setRetroProcessStatus(int retroProcessStatus) {
        this.retroProcessStatus = retroProcessStatus;
    }

    public int retroVatStatus() {
        return retroVatStatus;
    }

    public void setRetroVatStatus(int retroVatStatus) {
        this.retroVatStatus = retroVatStatus;
    }

}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for CGEI_CGE_EVT table.
 */
public class FixtureTestCommissionGeneratingEvent extends FixtureTestMasterEvent {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestCommissionGeneratingEvent.class);

    private String eventEffectiveDate;
    private String effectiveDate;
    private String commissionType;
    private int indexGrwthType;
    private int indexGrowthType;
    private String cmpgCode;
    private String campaignCode;
    private int indexOpIndicator;
    private int indexOptionIndicator;
    private int taxGrpCode;
    private int taxGroupCode;
    private int numberOfElemnts;
    private int numberOfElements;
    private int rParIndicator;
    private int rparIndicator;
    private String applicationDate;
    private String quotationDate;
    private int cgeInfoVer;
    private int replIndicator;
    private int replacementIndicator;
    private int raXerIndicator;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT CGEI_MSTR_EVT_ID, CGEI_CGE_TYP, CGEI_CGE_EFF_DT, CGEI_COMM_TYP, "
                    + "CGEI_IDX_GTH_TYP, CGEI_CMPG_CD, CGEI_IDX_OP_IND, CGEI_TAX_GRP_CD, CGEI_NR_ELMTS, CGEI_RPAR_IND, "
                    + "CGEI_APP_DT, CGEI_QTE_DT, CGEI_POL_NR, CGEI_CRTD_BY, CGEI_UPD_BY, CGEI_CGE_EVT_VER, "
                    + "DM_LSTUPDDT, CGEI_REPL_IND, CGEI_RA_XER_IND FROM {0}CGEI_CGE_EVT ORDER BY CGEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");

    public FixtureTestCommissionGeneratingEvent() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        LOG.debug("Entering FixtureTestCommissionGeneratingEvent.execute()");

        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("CGEI_MSTR_EVT_ID"));
            setEventType(getResultSet().getInt("CGEI_CGE_TYP"));
            setEffectiveDate(format(getResultSet().getDate("CGEI_CGE_EFF_DT")));
            setCommissionType(getResultSet().getString("CGEI_COMM_TYP").trim());
            setIndexGrowthType(getResultSet().getInt("CGEI_IDX_GTH_TYP"));
            setCampaignCode(getResultSet().getString("CGEI_CMPG_CD").trim());
            setIndexOptionIndicator(getResultSet().getInt("CGEI_IDX_OP_IND"));
            setTaxGroupCode(getResultSet().getInt("CGEI_TAX_GRP_CD"));
            setNumberOfElements(getResultSet().getInt("CGEI_NR_ELMTS"));
            setRparIndicator(getResultSet().getInt("CGEI_RPAR_IND"));
            setApplicationDate(format(getResultSet().getDate("CGEI_APP_DT")));
            setQuotationDate(format(getResultSet().getDate("CGEI_QTE_DT")));
            setPolicyNumber(getResultSet().getString("CGEI_POL_NR"));
            setCreatedBy(getResultSet().getString("CGEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("CGEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("CGEI_CGE_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
            setReplacementIndicator(getResultSet().getInt("CGEI_REPL_IND"));
            setRaXerIndicator(getResultSet().getInt("CGEI_RA_XER_IND"));

            // Backward compatibility
            setEventEffectiveDate(effectiveDate());
            setIndexGrwthType(indexOptionIndicator());
            setCmpgCode(campaignCode());
            setIndexOpIndicator(indexOptionIndicator());
            setTaxGrpCode(taxGroupCode());
            setNumberOfElemnts(numberOfElements());
            setrParIndicator(rparIndicator());
            setCgeInfoVer(version());
            setReplIndicator(replacementIndicator());

        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestCommGenEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestCommGenEvent", se);
            }
        }
    }

    @Deprecated
    public String eventEffectiveDate() {
        return eventEffectiveDate;
    }

    @Deprecated
    public void setEventEffectiveDate(String eventEffectiveDate) {
        this.eventEffectiveDate = eventEffectiveDate;
    }

    /**
     * @return the effectiveDate
     */
    public String effectiveDate() {
        return effectiveDate;
    }

    /**
     * @param effectiveDate
     *            the effectiveDate to set
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    @Deprecated
    public int indexGrwthType() {
        return indexGrwthType;
    }

    @Deprecated
    public void setIndexGrwthType(int indexGrwthType) {
        this.indexGrwthType = indexGrwthType;
    }

    @Deprecated
    public String cmpgCode() {
        return cmpgCode;
    }

    @Deprecated
    public void setCmpgCode(String cmpgCode) {
        this.cmpgCode = cmpgCode;
    }

    @Deprecated
    public int indexOpIndicator() {
        return indexOpIndicator;
    }

    @Deprecated
    public void setIndexOpIndicator(int indexOpIndicator) {
        this.indexOpIndicator = indexOpIndicator;
    }

    @Deprecated
    public int taxGrpCode() {
        return taxGrpCode;
    }

    @Deprecated
    public void setTaxGrpCode(int taxGrpCode) {
        this.taxGrpCode = taxGrpCode;
    }

    @Deprecated
    public int numberOfElemnts() {
        return numberOfElemnts;
    }

    @Deprecated
    public void setNumberOfElemnts(int numberOfElemnts) {
        this.numberOfElemnts = numberOfElemnts;
    }

    @Deprecated
    public int rParIndicator() {
        return rParIndicator;
    }

    @Deprecated
    public void setrParIndicator(int rParIndicator) {
        this.rParIndicator = rParIndicator;
    }

    public String applicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String quotationDate() {
        return quotationDate;
    }

    public void setQuotationDate(String quotationDate) {
        this.quotationDate = quotationDate;
    }

    @Deprecated
    public int cgeInfoVer() {
        return cgeInfoVer;
    }

    @Deprecated
    public void setCgeInfoVer(int cgeInfoVer) {
        this.cgeInfoVer = cgeInfoVer;
    }

    @Deprecated
    public int replIndicator() {
        return replIndicator;
    }

    @Deprecated
    public void setReplIndicator(int replIndicator) {
        this.replIndicator = replIndicator;
    }

    public int raXerIndicator() {
        return raXerIndicator;
    }

    public void setRaXerIndicator(int raXerIndicator) {
        this.raXerIndicator = raXerIndicator;
    }

    /**
     * @return the indexGrowthType
     */
    public int indexGrowthType() {
        return indexGrowthType;
    }

    /**
     * @param indexGrowthType
     *            the indexGrowthType to set
     */
    public void setIndexGrowthType(int indexGrowthType) {
        this.indexGrowthType = indexGrowthType;
    }

    /**
     * @return the campaignCode
     */
    public String campaignCode() {
        return campaignCode;
    }

    /**
     * @param campaignCode
     *            the campaignCode to set
     */
    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    /**
     * @return the indexOptionIndicator
     */
    public int indexOptionIndicator() {
        return indexOptionIndicator;
    }

    /**
     * @param indexOptionIndicator
     *            the indexOptionIndicator to set
     */
    public void setIndexOptionIndicator(int indexOptionIndicator) {
        this.indexOptionIndicator = indexOptionIndicator;
    }

    /**
     * @return the taxGroupCode
     */
    public int taxGroupCode() {
        return taxGroupCode;
    }

    /**
     * @param taxGroupCode
     *            the taxGroupCode to set
     */
    public void setTaxGroupCode(int taxGroupCode) {
        this.taxGroupCode = taxGroupCode;
    }

    /**
     * @return the numberOfElements
     */
    public int numberOfElements() {
        return numberOfElements;
    }

    /**
     * @param numberOfElements
     *            the numberOfElements to set
     */
    public void setNumberOfElements(int numberOfElements) {
        this.numberOfElements = numberOfElements;
    }

    /**
     * @return the rparIndicator
     */
    public int rparIndicator() {
        return rparIndicator;
    }

    /**
     * @param rparIndicator
     *            the rparIndicator to set
     */
    public void setRparIndicator(int rparIndicator) {
        this.rparIndicator = rparIndicator;
    }

    /**
     * @return the replacementIndicator
     */
    public int replacementIndicator() {
        return replacementIndicator;
    }

    /**
     * @param replacementIndicator
     *            the replacementIndicator to set
     */
    public void setReplacementIndicator(int replacementIndicator) {
        this.replacementIndicator = replacementIndicator;
    }
}

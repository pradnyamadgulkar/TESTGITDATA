/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for INCH_ITCOM_HST table.
 */
public class FixtureTestIntermediaryCommissionHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestIntermediaryCommissionHistory.class);

    private long intermediaryCommissionId;
    private String commissionAmountMonthly;
    private int intermediaryCommissionStatus;
    private long eventInProcessId;
    private int eventInProcessType;
    private String eventInProcessDate;
    private String statusEndDate;
    private int intermediaryCommissionHistoryVer;

    public FixtureTestIntermediaryCommissionHistory() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setIntermediaryCommissionId(getResultSet().getLong("INCH_INTM_COMM_ID"));
            setCommissionAmountMonthly(getResultSet().getDouble("INCH_COMM_AMT_MON"));
            setIntermediaryCommissionStatus(getResultSet().getInt("INCH_INTM_COMM_STS"));
            setEventInProcessId(getResultSet().getLong("INCH_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("INCH_EIP_TYP"));
            setEventInProcessDate(format(getResultSet().getDate("INCH_EIP_DT")));
            setStatusEndDate(format(getResultSet().getDate("INCH_STS_END_DT")));
            setCreatedBy(getResultSet().getString("INCH_CRTD_BY").trim());
            setVersion(getResultSet().getInt("INCH_ITCOM_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setIntermediaryCommissionHistoryVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestIntermediaryCommissionHistory", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException e) {
                LOG.error("Error cleaning up connections in FixtureTestIntermediaryCommissionHistory", e);
            }
        }
    }

    public long intermediaryCommissionId() {
        return intermediaryCommissionId;
    }

    public void setIntermediaryCommissionId(long intermediaryCommissionId) {
        this.intermediaryCommissionId = intermediaryCommissionId;
    }

    public String commissionAmountMonthly() {
        return formatDouble(commissionAmountMonthly);
    }

    public void setCommissionAmountMonthly(double commissionAmountMonthly) {
        this.commissionAmountMonthly = String.valueOf(commissionAmountMonthly);
    }

    public int intermediaryCommissionStatus() {
        return intermediaryCommissionStatus;
    }

    public void setIntermediaryCommissionStatus(int intermediaryCommissionStatus) {
        this.intermediaryCommissionStatus = intermediaryCommissionStatus;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public int eventInProcessType() {
        return eventInProcessType;
    }

    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    public String statusEndDate() {
        return statusEndDate;
    }

    public void setStatusEndDate(String statusEndDate) {
        this.statusEndDate = statusEndDate;
    }

    @Deprecated
    public int intermediaryCommissionHistoryVer() {
        return intermediaryCommissionHistoryVer;
    }

    @Deprecated
    public void setIntermediaryCommissionHistoryVer(int intermediaryCommissionHistoryVer) {
        this.intermediaryCommissionHistoryVer = intermediaryCommissionHistoryVer;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT INCH_INTM_COMM_ID,INCH_COMM_AMT_MON,INCH_INTM_COMM_STS,"
                    + "INCH_EIP_ID,INCH_EIP_TYP,INCH_EIP_DT,INCH_STS_END_DT, INCH_CRTD_BY,INCH_ITCOM_HST_VER,DM_LSTUPDDT from "
                    + "{0}.INCH_ITCOM_HST ORDER BY INCH_INTM_COMM_ID, INCH_EIP_ID  FOR FETCH ONLY WITH UR");

}
/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for CXEI_CXE_EVT table.
 */
public class FixtureTestCommissionTransferEvent extends FixtureTestMasterEvent {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestCommissionTransferEvent.class);

    private long cgeEventId;

    private int cxeEventType;

    private String startDate;
    private String endDate;
    private long intermediaryNumber;
    private int indexGwthInd;
    private int indexGrowthIndicator;

    private int cxeEventInfoVer;

    public FixtureTestCommissionTransferEvent() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestCommTransferEvent.beginTable()");

        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setMasterEventId(getResultSet().getLong("CXEI_MSTR_EVT_ID"));
            setCgeEventId(getResultSet().getLong("CXEI_CGE_EVT_ID"));
            setEventType(getResultSet().getInt("CXEI_CXE_TYP"));
            setStartDate(format(getResultSet().getDate("CXEI_START_DT")));
            setEndDate(format(getResultSet().getDate("CXEI_END_DT")));
            setIntermediaryNumber(getResultSet().getLong("CXEI_INTM_NR"));
            setIndexGrowthIndicator(getResultSet().getInt("CXEI_IDX_GTH_IND"));
            setPolicyNumber(getResultSet().getString("CXEI_POL_NR"));
            setCreatedBy(getResultSet().getString("CXEI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("CXEI_UPD_BY").trim());
            setVersion(getResultSet().getInt("CXEI_CXE_EVT_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setCxeEventType(eventType());
            setIndexGwthInd(indexGrowthIndicator());
            setCxeEventInfoVer(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestCommTransferEvent", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestCommTransferEvent", se);
            }
        }
    }

    public long cgeEventId() {
        return cgeEventId;
    }

    public void setCgeEventId(long cgeEventId) {
        this.cgeEventId = cgeEventId;
    }

    @Deprecated
    public int cxeEventType() {
        return cxeEventType;
    }

    @Deprecated
    public void setCxeEventType(int cxeEventType) {
        this.cxeEventType = cxeEventType;
    }

    public String startDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String endDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    @Deprecated
    public int indexGwthInd() {
        return indexGwthInd;
    }

    @Deprecated
    public void setIndexGwthInd(int indexGwthInd) {
        this.indexGwthInd = indexGwthInd;
    }

    @Deprecated
    public int cxeEventInfoVer() {
        return cxeEventInfoVer;
    }

    @Deprecated
    public void setCxeEventInfoVer(int cxeEventInfoVer) {
        this.cxeEventInfoVer = cxeEventInfoVer;
    }

    /**
     * @return the indexGrowthIndicator
     */
    public int indexGrowthIndicator() {
        return indexGrowthIndicator;
    }

    /**
     * @param indexGrowthIndicator
     *            the indexGrowthIndicator to set
     */
    public void setIndexGrowthIndicator(int indexGrowthIndicator) {
        this.indexGrowthIndicator = indexGrowthIndicator;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT CXEI_MSTR_EVT_ID, CXEI_CGE_EVT_ID, CXEI_CXE_TYP, CXEI_START_DT, "
                    + "CXEI_END_DT, CXEI_INTM_NR, CXEI_IDX_GTH_IND, CXEI_POL_NR, CXEI_CRTD_BY, CXEI_UPD_BY, "
                    + "CXEI_CXE_EVT_VER, DM_LSTUPDDT FROM {0}CXEI_CXE_EVT ORDER BY CXEI_MSTR_EVT_ID FOR FETCH ONLY WITH UR");
}

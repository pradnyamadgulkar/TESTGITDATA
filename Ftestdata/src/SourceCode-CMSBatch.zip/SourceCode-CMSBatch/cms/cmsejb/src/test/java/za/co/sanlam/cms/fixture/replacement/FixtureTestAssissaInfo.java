package za.co.sanlam.cms.fixture.replacement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

import com.tcs.mastercraft.mctype.ServerContext;

public class FixtureTestAssissaInfo extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestAssissaInfo.class);

    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    private int rowNumber;

    private long assissaId;
    private String batchId;
    private String batchDate;
    private String transactionId;
    private int sequenceNr;
    private String returnCode;
    private String responseGuid;
    private String transactionTimestamp;
    private String transactionResultInd;
    private String policyNumber;
    private String productType;
    private String carrierCode;
    private String carrierReplacer;
    private String effectiveDate;
    private String terminationDate;
    private String policyStatus;
    private String policyStatusDate;
    private String eventType;
    private String matchType;
    private String holderOrginisationName;
    private String holderKey;
    private String holderIdNumber;
    private String holderIdType;
    private String holderFirstName;
    private String holderMiddleName;
    private String holderLastName;
    private String holderInitials;
    private String holderTitle;
    private String holderGender;
    private String holderDob;
    private String holderPostalCode;
    private String insuredKey;
    private String insuredIdNumber;
    private String insuredIdType;
    private String insuredFirstName;
    private String insuredMiddleName;
    private String insuredLastName;
    private String insuredInitials;
    private String insuredTitle;
    private String insuredGender;
    private String insuredDob;
    private String insuredPostalCode;
    private String intermediaryFspNumber;
    private String intermediaryOrginisationName;
    private String intermediaryType;
    private String intermediaryKey;
    private String intermediaryIdNumber;
    private String intermediaryIdType;
    private String intermediaryFirstName;
    private String intermediaryMiddleName;
    private String intermediaryLastName;
    private String intermediaryInitials;
    private String intermediaryTitle;
    private String intermediaryGender;
    private String intermediaryDob;
    private String intermediaryPostalCode;
    private String processedInd;
    private String drpaMatchType;
    private String processedDate;
    private String completionDate;
    private String productTypeDwh;
    private String productTypeAsAndWhen;
    private String upfrontCommission;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestAssissaInfo.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute() {
        try {
            LOGGER.debug("execute");

            if (inValidResultSet(resultSet)) {
                return;
            }
            resultSet.absolute(rowNumber);
            setAssissaId(resultSet.getLong("RPAS_ASISA_ID"));
            setBatchId(resultSet.getString("RPAS_BATCH_ID"));
            setBatchDate(dateFormatter.format(resultSet.getDate("RPAS_BATCH_DATE")));
            setTransactionId(resultSet.getString("RPAS_TRANSACT_ID"));
            setSequenceNr(resultSet.getInt("RPAS_SEQ_NR"));
            setReturnCode(resultSet.getString("RPAS_RETURN_CODE"));
            setResponseGuid(resultSet.getString("RPAS_RESPONSE_GUID"));
            setTransactionTimestamp(format(resultSet.getTimestamp("RPAS_TRANSACT_TMST")));
            setTransactionResultInd(resultSet.getString("RPAS_TRANSACT_RESULT_IND"));
            setPolicyNumber(resultSet.getString("RPAS_POL_NR"));
            setProductType(resultSet.getString("RPAS_PRD_TYP"));
            setCarrierCode(resultSet.getString("RPAS_CARRIER_CODE"));
            setCarrierReplacer(resultSet.getString("RPAS_CARRIER_REPLACER"));
            setEffectiveDate(resultSet.getString("RPAS_EFF_DATE"));
            setTerminationDate(resultSet.getString("RPAS_TERM_DATE"));
            setPolicyStatus(resultSet.getString("RPAS_POL_STS"));
            setPolicyStatusDate(dateFormatter.format(resultSet.getDate("RPAS_POL_STS_DATE")));
            setEventType(resultSet.getString("RPAS_EVT_TYP"));
            setMatchType(resultSet.getString("RPAS_MATCH_TYP"));
            setHolderOrginisationName(resultSet.getString("RPAS_HOLDER_ORG_NAME"));
            setHolderKey(resultSet.getString("RPAS_HOLDER_KEY"));
            setHolderIdNumber(resultSet.getString("RPAS_HOLDER_ID_NR"));
            setHolderIdType(resultSet.getString("RPAS_HOLDER_ID_TYPE"));
            setHolderFirstName(resultSet.getString("RPAS_HOLDER_FIRST_NAME"));
            setHolderMiddleName(resultSet.getString("RPAS_HOLDER_MIDDLE_NAME"));
            setHolderLastName(resultSet.getString("RPAS_HOLDER_LAST_NAME"));
            setHolderInitials(resultSet.getString("RPAS_HOLDER_INITIALS"));
            setHolderTitle(resultSet.getString("RPAS_HOLDER_TITLE"));
            setHolderGender(resultSet.getString("RPAS_HOLDER_GENDER"));
            setHolderDob(dateFormatter.format(resultSet.getDate("RPAS_HOLDER_DOB")));
            setHolderPostalCode(resultSet.getString("RPAS_HOLDER_POST_CODE"));
            setInsuredKey(resultSet.getString("RPAS_INS_KEY"));
            setInsuredIdNumber(resultSet.getString("RPAS_INS_ID_NR"));
            setInsuredIdType(resultSet.getString("RPAS_INS_ID_TYP"));
            setInsuredFirstName(resultSet.getString("RPAS_INS_FIRST_NAME"));
            setInsuredMiddleName(resultSet.getString("RPAS_INS_MIDDLE_NAME"));
            setInsuredLastName(resultSet.getString("RPAS_INS_LAST_NAME"));
            setInsuredInitials(resultSet.getString("RPAS_INS_INITIALS"));
            setInsuredTitle(resultSet.getString("RPAS_INS_TITLE"));
            setInsuredGender(resultSet.getString("RPAS_INS_GENDER"));
            setInsuredDob(dateFormatter.format(resultSet.getDate("RPAS_INS_DOB")));
            setInsuredPostalCode(resultSet.getString("RPAS_INS_POST_CODE"));
            setIntermediaryFspNumber(resultSet.getString("RPAS_INTM_FSP_NR"));
            setIntermediaryOrginisationName(resultSet.getString("RPAS_INTM_ORG_NAME"));
            setIntermediaryType(resultSet.getString("RPAS_INTM_TYPE"));
            setIntermediaryKey(resultSet.getString("RPAS_INTM_KEY"));
            setIntermediaryIdNumber(resultSet.getString("RPAS_INTM_ID_NR"));
            setIntermediaryIdType(resultSet.getString("RPAS_INTM_ID_TYP"));
            setIntermediaryFirstName(resultSet.getString("RPAS_INTM_FIRST_NAME"));
            setIntermediaryMiddleName(resultSet.getString("RPAS_INTM_MIDDLE_NAME"));
            setIntermediaryLastName(resultSet.getString("RPAS_INTM_LAST_NAME"));
            setIntermediaryInitials(resultSet.getString("RPAS_INTM_INITIALS"));
            setIntermediaryTitle(resultSet.getString("RPAS_INTM_TITLE"));
            setIntermediaryGender(resultSet.getString("RPAS_INTM_GENDER"));
            setIntermediaryDob(dateFormatter.format(resultSet.getDate("RPAS_INTM_DOB")));
            setIntermediaryPostalCode(resultSet.getString("RPAS_INTM_POST_CODE"));
            setProcessedInd(resultSet.getString("RPAS_PROCESS_IND"));
            setDrpaMatchType(resultSet.getString("RPAS_DRPA_MATCH_TYP"));
            setProcessedDate(dateFormatter.format(resultSet.getDate("RPAS_PROCESS_DATE")));
            setCompletionDate(dateFormatter.format(resultSet.getDate("RPAS_COMPLETE_DATE")));
            setProductTypeDwh(resultSet.getString("RPAS_PRD_TYP_DWH"));
            setProductTypeAsAndWhen(resultSet.getString("RPAS_PRD_TYP_AS_AND_WHEN"));
            setUpfrontCommission(resultSet.getString("RPAS_UPFRONT_COMM"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestAssissaInfo", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestAssissaInfo", se);
            }
        }
    }

    private void initialize() throws SQLException {
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement
                .append("RPAS_ASISA_ID, RPAS_BATCH_ID, RPAS_BATCH_DATE, RPAS_TRANSACT_ID, RPAS_SEQ_NR, RPAS_RETURN_CODE, RPAS_RESPONSE_GUID, ");
        sqlStatement
                .append("RPAS_TRANSACT_TMST, RPAS_TRANSACT_RESULT_IND, RPAS_POL_NR, RPAS_PRD_TYP, RPAS_CARRIER_CODE, RPAS_CARRIER_REPLACER, ");
        sqlStatement
                .append("RPAS_EFF_DATE, RPAS_TERM_DATE, RPAS_POL_STS, RPAS_POL_STS_DATE, RPAS_EVT_TYP, RPAS_MATCH_TYP, RPAS_HOLDER_ORG_NAME, ");
        sqlStatement
                .append("RPAS_HOLDER_KEY, RPAS_HOLDER_ID_NR, RPAS_HOLDER_ID_TYPE, RPAS_HOLDER_FIRST_NAME, RPAS_HOLDER_MIDDLE_NAME, ");
        sqlStatement
                .append("RPAS_HOLDER_LAST_NAME, RPAS_HOLDER_INITIALS, RPAS_HOLDER_TITLE, RPAS_HOLDER_GENDER, RPAS_HOLDER_DOB, RPAS_HOLDER_POST_CODE, ");
        sqlStatement
                .append("RPAS_INS_KEY, RPAS_INS_ID_NR, RPAS_INS_ID_TYP, RPAS_INS_FIRST_NAME, RPAS_INS_MIDDLE_NAME, RPAS_INS_LAST_NAME, ");
        sqlStatement
                .append("RPAS_INS_INITIALS, RPAS_INS_TITLE, RPAS_INS_GENDER, RPAS_INS_DOB, RPAS_INS_POST_CODE, RPAS_INTM_FSP_NR, RPAS_INTM_ORG_NAME, ");
        sqlStatement
                .append("RPAS_INTM_TYPE, RPAS_INTM_KEY, RPAS_INTM_ID_NR, RPAS_INTM_ID_TYP, RPAS_INTM_FIRST_NAME, RPAS_INTM_MIDDLE_NAME, RPAS_INTM_LAST_NAME, ");
        sqlStatement
                .append("RPAS_INTM_INITIALS, RPAS_INTM_TITLE, RPAS_INTM_GENDER, RPAS_INTM_DOB, RPAS_INTM_POST_CODE, RPAS_PROCESS_IND, RPAS_DRPA_MATCH_TYP, ");
        sqlStatement
                .append("RPAS_PROCESS_DATE, RPAS_COMPLETE_DATE, RPAS_PRD_TYP_DWH, RPAS_PRD_TYP_AS_AND_WHEN, RPAS_UPFRONT_COMM  ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("RPAS_REPL_ASISA_INF ");
        sqlStatement.append("ORDER BY RPAS_ASISA_ID ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");
        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestAssissaInfo", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public long assissaId() {
        return assissaId;
    }

    public void setAssissaId(long assissaId) {
        this.assissaId = assissaId;
    }

    public String batchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String batchDate() {
        return batchDate;
    }

    public void setBatchDate(String batchDate) {
        this.batchDate = batchDate;
    }

    public String transactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public int sequenceNr() {
        return sequenceNr;
    }

    public void setSequenceNr(int sequenceNr) {
        this.sequenceNr = sequenceNr;
    }

    public String returnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String responseGuid() {
        return responseGuid;
    }

    public void setResponseGuid(String responseGuid) {
        this.responseGuid = responseGuid;
    }

    public String transactionTimestamp() {
        return transactionTimestamp;
    }

    public void setTransactionTimestamp(String transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
    }

    public String transactionResultInd() {
        return transactionResultInd;
    }

    public void setTransactionResultInd(String transactionResultInd) {
        this.transactionResultInd = transactionResultInd;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String carrierCode() {
        return carrierCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode;
    }

    public String carrierReplacer() {
        return carrierReplacer;
    }

    public void setCarrierReplacer(String carrierReplacer) {
        this.carrierReplacer = carrierReplacer;
    }

    public String effectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String terminationDate() {
        return terminationDate;
    }

    public void setTerminationDate(String terminationDate) {
        this.terminationDate = terminationDate;
    }

    public String policyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public String policyStatusDate() {
        return policyStatusDate;
    }

    public void setPolicyStatusDate(String policyStatusDate) {
        this.policyStatusDate = policyStatusDate;
    }

    public String eventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String matchType() {
        return matchType;
    }

    public void setMatchType(String matchType) {
        this.matchType = matchType;
    }

    public String holderOrginisationName() {
        return holderOrginisationName;
    }

    public void setHolderOrginisationName(String holderOrginisationName) {
        this.holderOrginisationName = holderOrginisationName;
    }

    public String holderKey() {
        return holderKey;
    }

    public void setHolderKey(String holderKey) {
        this.holderKey = holderKey;
    }

    public String holderIdNumber() {
        return holderIdNumber;
    }

    public void setHolderIdNumber(String holderIdNumber) {
        this.holderIdNumber = holderIdNumber;
    }

    public String holderIdType() {
        return holderIdType;
    }

    public void setHolderIdType(String holderIdType) {
        this.holderIdType = holderIdType;
    }

    public String holderFirstName() {
        return holderFirstName;
    }

    public void setHolderFirstName(String holderFirstName) {
        this.holderFirstName = holderFirstName;
    }

    public String holderMiddleName() {
        return holderMiddleName;
    }

    public void setHolderMiddleName(String holderMiddleName) {
        this.holderMiddleName = holderMiddleName;
    }

    public String holderLastName() {
        return holderLastName;
    }

    public void setHolderLastName(String holderLastName) {
        this.holderLastName = holderLastName;
    }

    public String holderInitials() {
        return holderInitials;
    }

    public void setHolderInitials(String holderInitials) {
        this.holderInitials = holderInitials;
    }

    public String holderTitle() {
        return holderTitle;
    }

    public void setHolderTitle(String holderTitle) {
        this.holderTitle = holderTitle;
    }

    public String holderGender() {
        return holderGender;
    }

    public void setHolderGender(String holderGender) {
        this.holderGender = holderGender;
    }

    public String holderDob() {
        return holderDob;
    }

    public void setHolderDob(String holderDob) {
        this.holderDob = holderDob;
    }

    public String holderPostalCode() {
        return holderPostalCode;
    }

    public void setHolderPostalCode(String holderPostalCode) {
        this.holderPostalCode = holderPostalCode;
    }

    public String insuredKey() {
        return insuredKey;
    }

    public void setInsuredKey(String insuredKey) {
        this.insuredKey = insuredKey;
    }

    public String insuredIdNumber() {
        return insuredIdNumber;
    }

    public void setInsuredIdNumber(String insuredIdNumber) {
        this.insuredIdNumber = insuredIdNumber;
    }

    public String insuredIdType() {
        return insuredIdType;
    }

    public void setInsuredIdType(String insuredIdType) {
        this.insuredIdType = insuredIdType;
    }

    public String insuredFirstName() {
        return insuredFirstName;
    }

    public void setInsuredFirstName(String insuredFirstName) {
        this.insuredFirstName = insuredFirstName;
    }

    public String insuredMiddleName() {
        return insuredMiddleName;
    }

    public void setInsuredMiddleName(String insuredMiddleName) {
        this.insuredMiddleName = insuredMiddleName;
    }

    public String insuredLastName() {
        return insuredLastName;
    }

    public void setInsuredLastName(String insuredLastName) {
        this.insuredLastName = insuredLastName;
    }

    public String insuredInitials() {
        return insuredInitials;
    }

    public void setInsuredInitials(String insuredInitials) {
        this.insuredInitials = insuredInitials;
    }

    public String insuredTitle() {
        return insuredTitle;
    }

    public void setInsuredTitle(String insuredTitle) {
        this.insuredTitle = insuredTitle;
    }

    public String insuredGender() {
        return insuredGender;
    }

    public void setInsuredGender(String insuredGender) {
        this.insuredGender = insuredGender;
    }

    public String insuredDob() {
        return insuredDob;
    }

    public void setInsuredDob(String insuredDob) {
        this.insuredDob = insuredDob;
    }

    public String insuredPostalCode() {
        return insuredPostalCode;
    }

    public void setInsuredPostalCode(String insuredPostalCode) {
        this.insuredPostalCode = insuredPostalCode;
    }

    public String intermediaryFspNumber() {
        return intermediaryFspNumber;
    }

    public void setIntermediaryFspNumber(String intermediaryFspNumber) {
        this.intermediaryFspNumber = intermediaryFspNumber;
    }

    public String intermediaryOrginisationName() {
        return intermediaryOrginisationName;
    }

    public void setIntermediaryOrginisationName(String intermediaryOrginisationName) {
        this.intermediaryOrginisationName = intermediaryOrginisationName;
    }

    public String intermediaryType() {
        return intermediaryType;
    }

    public void setIntermediaryType(String intermediaryType) {
        this.intermediaryType = intermediaryType;
    }

    public String intermediaryKey() {
        return intermediaryKey;
    }

    public void setIntermediaryKey(String intermediaryKey) {
        this.intermediaryKey = intermediaryKey;
    }

    public String intermediaryIdNumber() {
        return intermediaryIdNumber;
    }

    public void setIntermediaryIdNumber(String intermediaryIdNumber) {
        this.intermediaryIdNumber = intermediaryIdNumber;
    }

    public String intermediaryIdType() {
        return intermediaryIdType;
    }

    public void setIntermediaryIdType(String intermediaryIdType) {
        this.intermediaryIdType = intermediaryIdType;
    }

    public String intermediaryFirstName() {
        return intermediaryFirstName;
    }

    public void setIntermediaryFirstName(String intermediaryFirstName) {
        this.intermediaryFirstName = intermediaryFirstName;
    }

    public String intermediaryMiddleName() {
        return intermediaryMiddleName;
    }

    public void setIntermediaryMiddleName(String intermediaryMiddleName) {
        this.intermediaryMiddleName = intermediaryMiddleName;
    }

    public String intermediaryLastName() {
        return intermediaryLastName;
    }

    public void setIntermediaryLastName(String intermediaryLastName) {
        this.intermediaryLastName = intermediaryLastName;
    }

    public String intermediaryInitials() {
        return intermediaryInitials;
    }

    public void setIntermediaryInitials(String intermediaryInitials) {
        this.intermediaryInitials = intermediaryInitials;
    }

    public String intermediaryTitle() {
        return intermediaryTitle;
    }

    public void setIntermediaryTitle(String intermediaryTitle) {
        this.intermediaryTitle = intermediaryTitle;
    }

    public String intermediaryGender() {
        return intermediaryGender;
    }

    public void setIntermediaryGender(String intermediaryGender) {
        this.intermediaryGender = intermediaryGender;
    }

    public String intermediaryDob() {
        return intermediaryDob;
    }

    public void setIntermediaryDob(String intermediaryDob) {
        this.intermediaryDob = intermediaryDob;
    }

    public String intermediaryPostalCode() {
        return intermediaryPostalCode;
    }

    public void setIntermediaryPostalCode(String intermediaryPostalCode) {
        this.intermediaryPostalCode = intermediaryPostalCode;
    }

    public String processedInd() {
        return processedInd;
    }

    public void setProcessedInd(String processedInd) {
        this.processedInd = processedInd;
    }

    public String drpaMatchType() {
        return drpaMatchType;
    }

    public void setDrpaMatchType(String drpaMatchType) {
        this.drpaMatchType = drpaMatchType;
    }

    public String processedDate() {
        return processedDate;
    }

    public void setProcessedDate(String processedDate) {
        this.processedDate = processedDate;
    }

    public String completionDate() {
        return completionDate;
    }

    public void setCompletionDate(String completionDate) {
        this.completionDate = completionDate;
    }

    public String productTypeDwh() {
        return productTypeDwh;
    }

    public void setProductTypeDwh(String productTypeDwh) {
        this.productTypeDwh = productTypeDwh;
    }

    public String productTypeAsAndWhen() {
        return productTypeAsAndWhen;
    }

    public void setProductTypeAsAndWhen(String productTypeAsAndWhen) {
        this.productTypeAsAndWhen = productTypeAsAndWhen;
    }

    public String upfrontCommission() {
        return upfrontCommission;
    }

    public void setUpfrontCommission(String upfrontCommission) {
        this.upfrontCommission = upfrontCommission;
    }
}

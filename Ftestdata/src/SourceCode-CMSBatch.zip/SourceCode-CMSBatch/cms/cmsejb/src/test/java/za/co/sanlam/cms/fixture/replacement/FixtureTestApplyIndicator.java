package za.co.sanlam.cms.fixture.replacement;

import java.sql.SQLException;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.domain.IntermediaryCommission;
import za.co.sanlam.cms.domain.replacement.ReplacementPolicy;
import za.co.sanlam.cms.domain.repository.ReferenceDataRepository;
import za.co.sanlam.cms.domain.repository.replacement.ReplacementRuleRepository;
import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

public class FixtureTestApplyIndicator extends FixtureTestKomEvents {

    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestApplyIndicator.class);
    
    private ReplacementRuleRepository replacementRuleRepository;

    private int activeRaIndicator;
    private int inActiveRaIndicator;
    private String activeProductType;
    private String inActiveProductType;
    private int activeRparIndicator;
    private String contractCode;

    private int result;
    
    public void beginTable() throws SQLException {
        LOGGER.debug("Entering beginTable()");
        super.beginTable();

        replacementRuleRepository = new ReplacementRuleRepository();
        replacementRuleRepository.setReferenceDataRepository(new ReferenceDataRepository());
    }

    public void execute() {
        ReplacementPolicy activeReplacementPolicy = new ReplacementPolicy();
        activeReplacementPolicy.setRaIndicator(activeRaIndicator());
        activeReplacementPolicy.setRparIndicator(activeRparIndicator());
        activeReplacementPolicy.setProductType(activeProductType());
        
        StringTokenizer st = new StringTokenizer(contractCode(), ",");
        while (st.hasMoreTokens()) {
            IntermediaryCommission intermediaryCommission = new IntermediaryCommission();
            intermediaryCommission.setContractCode(Integer.parseInt(st.nextToken()));
            activeReplacementPolicy.getIntermediaryCommissions().add(intermediaryCommission);
        }

        ReplacementPolicy inActiveReplacementPolicy = new ReplacementPolicy();
        inActiveReplacementPolicy.setRaIndicator(inActiveRaIndicator());
        inActiveReplacementPolicy.setProductType(inActiveProductType());
        setResult(replacementRuleRepository.determineApplyIndicator(activeReplacementPolicy, inActiveReplacementPolicy));
    }

    public int result() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public int activeRaIndicator() {
        return activeRaIndicator;
    }

    public void setActiveRaIndicator(int activeRaIndicator) {
        this.activeRaIndicator = activeRaIndicator;
    }

    public int inActiveRaIndicator() {
        return inActiveRaIndicator;
    }

    public void setInActiveRaIndicator(int inActiveRaIndicator) {
        this.inActiveRaIndicator = inActiveRaIndicator;
    }

    public int activeRparIndicator() {
        return activeRparIndicator;
    }

    public void setActiveRparIndicator(int activeRparIndicator) {
        this.activeRparIndicator = activeRparIndicator;
    }

    public String activeProductType() {
        return activeProductType;
    }

    public void setActiveProductType(String activeProductType) {
        this.activeProductType = activeProductType;
    }

    public String inActiveProductType() {
        return inActiveProductType;
    }

    public void setInActiveProductType(String inActiveProductType) {
        this.inActiveProductType = inActiveProductType;
    }

    public String contractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode;
    }
}

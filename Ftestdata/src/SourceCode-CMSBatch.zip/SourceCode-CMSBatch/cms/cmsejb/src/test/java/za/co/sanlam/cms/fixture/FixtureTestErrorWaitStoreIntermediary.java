/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for EWSI_ERWT_INTM table.
 */
public class FixtureTestErrorWaitStoreIntermediary extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestErrorWaitStoreIntermediary.class);

    private long errorWaitStoreReferenceId;
    private long intermediaryNumber;
    private String salesSplitPercentage;
    private String serviceSplitPercenatge;
    private String applicationNumber;
    private int manCode;
    private String fundSplitPercentage;

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT EWSI_ERWS_REF_ID, EWSI_INTM_NR, EWSI_SLS_SPLT_PCT, "
                    + "EWSI_SRV_SPLT_PCT, EWSI_APP_NR, EWSI_MAN_CD, EWSI_CRTD_BY, EWSI_UPD_BY, EWSI_CRTD_TMST, EWSI_UPD_TMST, "
                    + "EWSI_ERWT_INTM_VER, DM_LSTUPDDT, EWSI_FUND_SPLT_PCT FROM {0}.EWSI_ERWT_INTM ORDER BY EWSI_ERWS_REF_ID, EWSI_INTM_NR FOR FETCH ONLY WITH UR");

    public FixtureTestErrorWaitStoreIntermediary() {
        setSqlQuery(SQL_QUERY);
    }

    @Override
    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setErrorWaitStoreReferenceId(getResultSet().getLong("EWSI_ERWS_REF_ID"));
            setIntermediaryNumber(getResultSet().getLong("EWSI_INTM_NR"));
            setSalesSplitPercentage(getResultSet().getDouble("EWSI_SLS_SPLT_PCT"));
            setServiceSplitPercenatge(getResultSet().getDouble("EWSI_SRV_SPLT_PCT"));
            setApplicationNumber(getResultSet().getDouble("EWSI_APP_NR"));
            setManCode(getResultSet().getInt("EWSI_MAN_CD"));
            setFundSplitPercentage(getResultSet().getDouble("EWSI_FUND_SPLT_PCT"));
            setCreatedBy(getResultSet().getString("EWSI_CRTD_BY"));
            setUpdatedBy(getResultSet().getString("EWSI_UPD_BY"));
            setVersion(getResultSet().getInt("EWSI_ERWT_INTM_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestErrorWaitStoreIntermediary: " + ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestErrorWaitStoreIntermediary", se);
            }
        }

    }

    /**
     * @return the errorWaitStoreReferenceId
     */
    public long errorWaitStoreReferenceId() {
        return errorWaitStoreReferenceId;
    }

    /**
     * @param errorWaitStoreReferenceId
     *            the errorWaitStoreReferenceId to set
     */
    public void setErrorWaitStoreReferenceId(long errorWaitStoreReferenceId) {
        this.errorWaitStoreReferenceId = errorWaitStoreReferenceId;
    }

    /**
     * @return the intermediaryNumber
     */
    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    /**
     * @param intermediaryNumber
     *            the intermediaryNumber to set
     */
    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    /**
     * @return the salesSplitPercentage
     */
    public String salesSplitPercentage() {
        return format(salesSplitPercentage);
    }

    /**
     * @param salesSplitPercentage
     *            the salesSplitPercentage to set
     */
    public void setSalesSplitPercentage(double salesSplitPercentage) {
        this.salesSplitPercentage = String.valueOf(salesSplitPercentage);
    }

    /**
     * @return the serviceSplitPercenatge
     */
    public String serviceSplitPercenatge() {
        return formatDouble(serviceSplitPercenatge);
    }

    /**
     * @param serviceSplitPercenatge
     *            the serviceSplitPercenatge to set
     */
    public void setServiceSplitPercenatge(double serviceSplitPercenatge) {
        this.serviceSplitPercenatge = String.valueOf(serviceSplitPercenatge);
    }

    /**
     * @return the applicationNumber
     */
    public String applicationNumber() {
        return formatDouble(applicationNumber);
    }

    /**
     * @param applicationNumber
     *            the applicationNumber to set
     */
    public void setApplicationNumber(double applicationNumber) {
        this.applicationNumber = String.valueOf(applicationNumber);
    }

    /**
     * @return the manCode
     */
    public int manCode() {
        return manCode;
    }

    /**
     * @param manCode
     *            the manCode to set
     */
    public void setManCode(int manCode) {
        this.manCode = manCode;
    }

    /**
     * @return the fundSplitPercentage
     */
    public String fundSplitPercentage() {
        return formatDouble(fundSplitPercentage);
    }

    /**
     * @param fundSplitPercentage
     *            the fundSplitPercentage to set
     */
    public void setFundSplitPercentage(double fundSplitPercentage) {
        this.fundSplitPercentage = String.valueOf(fundSplitPercentage);
    }

}

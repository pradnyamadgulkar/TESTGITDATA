package za.co.sanlam.cms.service;


public class IntermediaryInfoBuilder {

	private long intermediaryNumber = 170330;
	private long applicationNumber = 0;
	private int manCode = 0;
	private double salesCommissionSplitPercentage = 100;
	private double serviceCommissionSplitPercentage = 100;
	private double fundCommissionSplitPercentage = 100;

	public IntermediaryInfoBuilder withIntermediaryNumber(long intermediaryNumber) {
		this.intermediaryNumber = intermediaryNumber;
		return this;
	}

	public IntermediaryInfoBuilder withApplicationNumber(long applicationNumber) {
		this.applicationNumber = applicationNumber;
		return this;
	}

	public IntermediaryInfoBuilder withManCode(int manCode) {
		this.manCode = manCode;
		return this;
	}

	public IntermediaryInfoBuilder withSalesCommissionSplitPercentage(double salesCommissionSplitPercentage) {
		this.salesCommissionSplitPercentage =salesCommissionSplitPercentage;
		return this;
	}

	public IntermediaryInfoBuilder withServiceCommissionSplitPercentage(double serviceCommissionSplitPercentage) {
		this.serviceCommissionSplitPercentage = serviceCommissionSplitPercentage;
		return this;
	}

	public IntermediaryInfoBuilder withFundCommissionSplitPercentage(double fundCommissionSplitPercentage) {
		this.fundCommissionSplitPercentage = fundCommissionSplitPercentage;
		return this;
	}

	public IntermediaryInfo build() {
		IntermediaryInfo intermediaryInfo = new IntermediaryInfo();
		intermediaryInfo.setIntermediaryNumber(intermediaryNumber);
		intermediaryInfo.setApplicationNumber(applicationNumber);
		intermediaryInfo.setManCode(manCode);
		intermediaryInfo.setSalesCommissionSplitPercentage(salesCommissionSplitPercentage);
		intermediaryInfo.setServiceCommissionSplitPercentage(serviceCommissionSplitPercentage);
		intermediaryInfo.setFundCommissionSplitPercentage(fundCommissionSplitPercentage);
		return intermediaryInfo;
	}
}

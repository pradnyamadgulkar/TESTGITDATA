package za.co.sanlam.cms.service;


public interface EventFacade {
	public void handleEvents(CommissionEvent commissionEvent);
	
	public void handleEvents(RetroVATEvent retroVATEvent);
	
	public void initialize();
}

/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for OOPI_1OFF_PMT table.
 */
public class FixtureTestOneOffPayment extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestOneOffPayment.class);

    private long oneOffPaymentId;
    private String policyNumber;
    private long eventId;
    private long elementNumber;
    private long intermediaryNumber;
    private String splitCommissionType;
    private long splitCommissionId;
    private String paymentDueDate;
    private String commissionAmount;
    private String vatAmount;
    private int paymentStatus;
    private long eventInProcessId;
    private int paymentAccount;
    private int paymentVersion;
    private int oneOffSubType;

    private long masterEventId;
    private long intermediarySplitCommTypeId;
    private int paymentAccountType;

    public FixtureTestOneOffPayment() throws SQLException {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        LOG.debug("Entering FixtureTestOneOffPayment.beginTable()");
        try {

            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setOneOffPaymentId(getResultSet().getLong("OOPI_1OFF_PMT_ID"));
            setPolicyNumber(getResultSet().getString("OOPI_POL_NR"));
            setEventId(getResultSet().getLong("OOPI_EVT_ID"));
            setElementNumber(getResultSet().getInt("OOPI_ELMT_NR"));
            setIntermediaryNumber(getResultSet().getLong("OOPI_INTM_NR"));
            setSplitCommissionType(getResultSet().getString("OOPI_SPLT_COMM_TYP").trim());
            setSplitCommissionId(getResultSet().getLong("OOPI_SPLT_COMM_ID"));
            setPaymentDueDate(format(getResultSet().getDate("OOPI_PMT_DUE_DT")));
            setCommissionAmount(getResultSet().getDouble("OOPI_COMM_AMT"));
            setVatAmount(getResultSet().getDouble("OOPI_VAT_AMT"));
            setPaymentStatus(getResultSet().getInt("OOPI_PMT_STS"));
            setEventInProcessId(getResultSet().getLong("OOPI_EIP_ID"));
            setPaymentAccount(getResultSet().getInt("OOPI_PMT_ACC"));
            setCreatedBy(getResultSet().getString("OOPI_CRTD_BY").trim());
            setUpdatedBy(getResultSet().getString("OOPI_UPD_BY").trim());
            setVersion(getResultSet().getInt("OOPI_1OFF_PMT_VER"));
            setOneOffSubType(getResultSet().getInt("OOPI_OOFF_STYPE"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setMasterEventId(eventId());
            setIntermediarySplitCommTypeId(splitCommissionId());
            setPaymentAccountType(paymentAccount());
            setPaymentVersion(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestOneOffPayment: " + ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestOneOffPayment", se);
            }
        }
    }

    /**
     * @return the eventId
     */
    public long eventId() {
        return eventId;
    }

    /**
     * @param eventId
     *            the eventId to set
     */
    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the splitCommissionId
     */
    public long splitCommissionId() {
        return splitCommissionId;
    }

    /**
     * @param splitCommissionId
     *            the splitCommissionId to set
     */
    public void setSplitCommissionId(long splitCommissionId) {
        this.splitCommissionId = splitCommissionId;
    }

    /**
     * @return the paymentAccount
     */
    public int paymentAccount() {
        return paymentAccount;
    }

    /**
     * @param paymentAccount
     *            the paymentAccount to set
     */
    public void setPaymentAccount(int paymentAccount) {
        this.paymentAccount = paymentAccount;
    }

    public long oneOffPaymentId() {
        return oneOffPaymentId;
    }

    public void setOneOffPaymentId(long oneOffPaymentId) {
        this.oneOffPaymentId = oneOffPaymentId;
    }

    public String policyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    @Deprecated
    public long masterEventId() {
        return masterEventId;
    }

    @Deprecated
    public void setMasterEventId(long masterEventId) {
        this.masterEventId = masterEventId;
    }

    public long elementNumber() {
        return elementNumber;
    }

    public void setElementNumber(long elementNumber) {
        this.elementNumber = elementNumber;
    }

    public long intermediaryNumber() {
        return intermediaryNumber;
    }

    public void setIntermediaryNumber(long intermediaryNumber) {
        this.intermediaryNumber = intermediaryNumber;
    }

    public String splitCommissionType() {
        return splitCommissionType;
    }

    public void setSplitCommissionType(String splitCommissionType) {
        this.splitCommissionType = splitCommissionType;
    }

    @Deprecated
    public long intermediarySplitCommTypeId() {
        return intermediarySplitCommTypeId;
    }

    @Deprecated
    public void setIntermediarySplitCommTypeId(long intermediarySplitCommTypeId) {
        this.intermediarySplitCommTypeId = intermediarySplitCommTypeId;
    }

    public String paymentDueDate() {
        return paymentDueDate;
    }

    public void setPaymentDueDate(String paymentDueDate) {
        this.paymentDueDate = paymentDueDate;
    }

    public String commissionAmount() {
        return formatDouble(commissionAmount);
    }

    public void setCommissionAmount(double commissionAmount) {
        this.commissionAmount = Double.toString(commissionAmount);
    }

    public String vatAmount() {
        return formatDouble(vatAmount);
    }

    public void setVatAmount(double vatAmount) {
        this.vatAmount = Double.toString(vatAmount);
    }

    public int paymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(int paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    @Deprecated
    public int paymentAccountType() {
        return paymentAccountType;
    }

    @Deprecated
    public void setPaymentAccountType(int paymentAccountType) {
        this.paymentAccountType = paymentAccountType;
    }

    @Deprecated
    public int paymentVersion() {
        return paymentVersion;
    }

    @Deprecated
    public void setPaymentVersion(int paymentVersion) {
        this.paymentVersion = paymentVersion;
    }

    public int oneOffSubType() {
        return oneOffSubType;
    }

    public void setOneOffSubType(int oneOffSubType) {
        this.oneOffSubType = oneOffSubType;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "SELECT OOPI_1OFF_PMT_ID, OOPI_POL_NR, OOPI_EVT_ID, OOPI_ELMT_NR, OOPI_INTM_NR, OOPI_SPLT_COMM_TYP, "
                    + "OOPI_SPLT_COMM_ID, OOPI_PMT_DUE_DT, OOPI_COMM_AMT, OOPI_VAT_AMT, OOPI_PMT_STS, OOPI_EIP_ID, OOPI_PMT_ACC, OOPI_CRTD_BY, "
                    + "OOPI_UPD_BY, OOPI_1OFF_PMT_VER, DM_LSTUPDDT, OOPI_OOFF_STYPE  "
                    + " FROM {0}OOPI_1OFF_PMT ORDER BY OOPI_EVT_ID, OOPI_ELMT_NR, OOPI_INTM_NR,  OOPI_SPLT_COMM_TYP,  OOPI_SPLT_COMM_ID, OOPI_EIP_ID FOR FETCH ONLY WITH UR");

}

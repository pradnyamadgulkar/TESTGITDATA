/*
 * 
 */
package za.co.sanlam.cms.fixture;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Fixture for EMHS_ELMT_HST table.
 */
public class FixtureTestElementHistory extends FixtureTestKomEvents {

    private static final Logger LOG = LoggerFactory.getLogger(FixtureTestElementHistory.class);

    private long elementId;
    private String elementAnnualPremium;
    private String salesCommissionMonthlyAmount;
    private String serviceCommissionMonthlyAmount;
    private int elementStatus;
    private long eventInProcessId;
    private int eventInProcessType;
    private String eventInProcessDate;

    private int elementHistoryVersion;
    private String salesCommissionMonthlyAmt;
    private String serviceCommissionMonthlyAmt;

    public FixtureTestElementHistory() {
        setSqlQuery(SQL_QUERY);
    }

    public void execute() {
        try {
            if (inValidResultSet()) {
                return;
            }

            setResultSetPosition();

            setElementId(getResultSet().getLong("EMHS_ELMT_ID"));
            setElementAnnualPremium(getResultSet().getDouble("EMHS_ELMT_ANN_PRM"));
            setSalesCommissionMonthlyAmount(getResultSet().getDouble("EMHS_SLS_COMM_MON"));
            setServiceCommissionMonthlyAmount(getResultSet().getDouble("EMHS_SRV_COMM_MON"));
            setElementStatus(getResultSet().getInt("EMHS_ELMT_STS"));
            setEventInProcessId(getResultSet().getLong("EMHS_EIP_ID"));
            setEventInProcessType(getResultSet().getInt("EMHS_EIP_TYP"));
            setEventInProcessDate(format(getResultSet().getDate("EMHS_EIP_DT")));
            setCreatedBy(getResultSet().getString("EMHS_CRTD_BY").trim());
            setVersion(getResultSet().getInt("EMHS_ELMT_HST_VER"));
            setLastUpdatedDate(format(getResultSet().getDate("DM_LSTUPDDT")));

            setSalesCommissionMonthlyAmt(serviceCommissionMonthlyAmount());
            setServiceCommissionMonthlyAmt(salesCommissionMonthlyAmount());
            setElementHistoryVersion(version());
        } catch (SQLException ignore) {
            LOG.error("Exception encountered in operation execute of class FixtureTestElementInfoHistory", ignore);
        } finally {
            try {
                cleanUp();
            } catch (SQLException se) {
                LOG.error("Error cleaning up connections in FixtureTestElementInfoHistory", se);
            }
        }
    }

    /**
     * @return the salesCommissionMonthlyAmount
     */
    public String salesCommissionMonthlyAmount() {
        return formatDouble(salesCommissionMonthlyAmount);
    }

    /**
     * @param salesCommissionMonthlyAmount
     *            the salesCommissionMonthlyAmount to set
     */
    public void setSalesCommissionMonthlyAmount(double salesCommissionMonthlyAmount) {
        this.salesCommissionMonthlyAmount = String.valueOf(salesCommissionMonthlyAmount);
    }

    /**
     * @return the serviceCommissionMonthlyAmount
     */
    public String serviceCommissionMonthlyAmount() {
        return formatDouble(serviceCommissionMonthlyAmount);
    }

    /**
     * @param serviceCommissionMonthlyAmount
     *            the serviceCommissionMonthlyAmount to set
     */
    public void setServiceCommissionMonthlyAmount(double serviceCommissionMonthlyAmount) {
        this.serviceCommissionMonthlyAmount = String.valueOf(serviceCommissionMonthlyAmount);
    }

    public long elementId() {
        return elementId;
    }

    public void setElementId(long elementId) {
        this.elementId = elementId;
    }

    public String elementAnnualPremium() {
        return formatDouble(elementAnnualPremium);
    }

    public void setElementAnnualPremium(double elementAnnualPremium) {
        this.elementAnnualPremium = String.valueOf(elementAnnualPremium);
    }

    @Deprecated
    public String salesCommissionMonthlyAmt() {
        return salesCommissionMonthlyAmt != null ? formatDouble(salesCommissionMonthlyAmt) : "0";
    }

    @Deprecated
    public void setSalesCommissionMonthlyAmt(String salesCommissionMonthlyAmt) {
        this.salesCommissionMonthlyAmt = salesCommissionMonthlyAmt;
    }

    @Deprecated
    public String serviceCommissionMonthlyAmt() {
        return serviceCommissionMonthlyAmt != null ? formatDouble(serviceCommissionMonthlyAmt) : "0";
    }

    @Deprecated
    public void setServiceCommissionMonthlyAmt(String serviceCommissionMonthlyAmt) {
        this.serviceCommissionMonthlyAmt = serviceCommissionMonthlyAmt;
    }

    public int elementStatus() {
        return elementStatus;
    }

    public void setElementStatus(int elementStatus) {
        this.elementStatus = elementStatus;
    }

    public long eventInProcessId() {
        return eventInProcessId;
    }

    public void setEventInProcessId(long eventInProcessId) {
        this.eventInProcessId = eventInProcessId;
    }

    public int eventInProcessType() {
        return eventInProcessType;
    }

    public void setEventInProcessType(int eventInProcessType) {
        this.eventInProcessType = eventInProcessType;
    }

    public String eventInProcessDate() {
        return eventInProcessDate;
    }

    public void setEventInProcessDate(String eventInProcessDate) {
        this.eventInProcessDate = eventInProcessDate;
    }

    @Deprecated
    public int elementHistoryVersion() {
        return elementHistoryVersion;
    }

    @Deprecated
    public void setElementHistoryVersion(int elementHistoryVersion) {
        this.elementHistoryVersion = elementHistoryVersion;
    }

    private static final StringBuffer SQL_QUERY = new StringBuffer(
            "select EMHS_ELMT_ID, EMHS_ELMT_ANN_PRM, EMHS_SLS_COMM_MON, EMHS_SRV_COMM_MON, "
                    + "EMHS_ELMT_STS, EMHS_EIP_ID, EMHS_EIP_TYP, EMHS_EIP_DT, EMHS_CRTD_BY, EMHS_CRTD_TMST, EMHS_ELMT_HST_VER, "
                    + "DM_LSTUPDDT FROM {0}EMHS_ELMT_HST ORDER BY EMHS_ELMT_ID, EMHS_EIP_ID FOR FETCH ONLY WITH UR");
}

package za.co.sanlam.cms.fixture.replacement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import za.co.sanlam.cms.fixture.FixtureTestKomEvents;

import com.tcs.mastercraft.mctype.ServerContext;

public class FixtureTestInActiveInfo extends FixtureTestKomEvents {
    private static final Logger LOGGER = LoggerFactory.getLogger(FixtureTestInActiveInfo.class);

    private PreparedStatement preparedStatement;
    private ResultSet resultSet;

    private long inActiveId;
    private String activePolicyNumber;
    private String cgeDate;
    private String commissionType;
    private String inActivePolicyNumber;
    private int policyAddIndicator;
    private int policyLapseIndicator;
    private String productType;
    private int terminationEventType;

    private int rowNumber;

    public void beginTable() throws SQLException {
        LOGGER.debug("FixtureTestInActiveInfo.beginTable()");
        super.beginTable();
        initialize();
    }

    public void execute() {
        try {
            if (inValidResultSet(resultSet)) {
                return;
            }
            resultSet.absolute(rowNumber);
            setInActiveId(resultSet.getLong("RPII_INACTV_ID"));
            setActivePolicyNumber(resultSet.getString("RPII_ACTV_POL_NR").trim());
            setCgeDate(dateFormatter.format(resultSet.getDate("RPII_CGE_DATE")));
            setCommissionType(resultSet.getString("RPII_COMM_TYPE").trim());
            setInActivePolicyNumber(resultSet.getString("RPII_POL_NR").trim());
            setPolicyAddIndicator(resultSet.getInt("RPII_POL_ADD_IND"));
            setPolicyLapseIndicator(resultSet.getInt("RPII_POL_LAPSE_IND"));
            setProductType(resultSet.getString("RPII_PRD_TYPE"));
            setTerminationEventType(resultSet.getInt("RPII_TRM_EVT_TYPE"));
        } catch (SQLException ignore) {
            LOGGER.error("Exception encountered in operation execute of class FixtureTestInActiveInfo", ignore);
        } finally {
            try {
                cleanUp(resultSet, preparedStatement);
            } catch (SQLException se) {
                LOGGER.error("Error cleaning up connections in FixtureTestInActiveInfo", se);
            }
        }
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public long inActiveId() {
        return inActiveId;
    }

    public void setInActiveId(long inActiveId) {
        this.inActiveId = inActiveId;
    }

    public String activePolicyNumber() {
        return activePolicyNumber;
    }

    public void setActivePolicyNumber(String activePolicyNumber) {
        this.activePolicyNumber = activePolicyNumber;
    }

    public String cgeDate() {
        return cgeDate;
    }

    public void setCgeDate(String cgeDate) {
        this.cgeDate = cgeDate;
    }

    public String commissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String inActivePolicyNumber() {
        return inActivePolicyNumber;
    }

    public void setInActivePolicyNumber(String inActivePolicyNumber) {
        this.inActivePolicyNumber = inActivePolicyNumber;
    }

    public int policyAddIndicator() {
        return policyAddIndicator;
    }

    public void setPolicyAddIndicator(int policyAddIndicator) {
        this.policyAddIndicator = policyAddIndicator;
    }

    public int policyLapseIndicator() {
        return policyLapseIndicator;
    }

    public void setPolicyLapseIndicator(int policyLapseIndicator) {
        this.policyLapseIndicator = policyLapseIndicator;
    }

    public String productType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int terminationEventType() {
        return terminationEventType;
    }

    public void setTerminationEventType(int terminationEventType) {
        this.terminationEventType = terminationEventType;
    }

    private void initialize() throws SQLException {
        LOGGER.debug("Setting info for InActive Policies");
        boolean foundData = false;
        StringBuffer sqlStatement = new StringBuffer("SELECT ");
        sqlStatement.append("RPII_INACTV_ID, RPII_ACTV_POL_NR, RPII_CGE_DATE,  RPII_COMM_TYPE, RPII_POL_NR, RPII_POL_ADD_IND, ");
        sqlStatement.append("RPII_POL_LAPSE_IND, RPII_PRD_TYPE, RPII_TRM_EVT_TYPE ");
        sqlStatement.append("FROM ");
        sqlStatement.append(ServerContext.getSchemaName());
        sqlStatement.append("RPII_INACTV_INFO ");
        sqlStatement.append("ORDER BY RPII_INACTV_ID, RPII_ACTV_POL_NR, RPII_CGE_DATE, RPII_POL_NR, RPII_COMM_TYPE ");
        sqlStatement.append("FOR FETCH ONLY WITH UR");

        try {
            preparedStatement = ServerContext.getJDBCHandle().prepareStatement(sqlStatement.toString(),
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = preparedStatement.executeQuery();
            foundData = resultSet.next();
        } catch (SQLException e) {
            LOGGER.error("Exception encountered in operation initialize of class FixtureTestInActiveInfo", e);
            throw e;
        } finally {
            if (!foundData) {
                close(resultSet, preparedStatement);
            }
        }
    }
}

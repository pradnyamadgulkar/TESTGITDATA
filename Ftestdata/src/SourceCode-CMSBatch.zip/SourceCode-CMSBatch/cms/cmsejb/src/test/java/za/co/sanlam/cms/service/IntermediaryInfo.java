package za.co.sanlam.cms.service;


public class IntermediaryInfo {

    private long intermediaryNumber;
    private long applicationNumber;
    private int manCode;
    private double salesCommissionSplitPercentage;
    private double serviceCommissionSplitPercentage;
    private double fundCommissionSplitPercentage;
    private String createdby;
    private String updateby;
    private String createTimeStamp;
    private String updateTimeStamp;
    
	public long getIntermediaryNumber() {
		return intermediaryNumber;
	}
	public void setIntermediaryNumber(long intermediaryNumber) {
		this.intermediaryNumber = intermediaryNumber;
	}
	public long getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(long applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
	public int getManCode() {
		return manCode;
	}
	public void setManCode(int manCode) {
		this.manCode = manCode;
	}
	public double getSalesCommissionSplitPercentage() {
		return salesCommissionSplitPercentage;
	}
	public void setSalesCommissionSplitPercentage(
			double salesCommissionSplitPercentage) {
		this.salesCommissionSplitPercentage = salesCommissionSplitPercentage;
	}
	public double getServiceCommissionSplitPercentage() {
		return serviceCommissionSplitPercentage;
	}
	public void setServiceCommissionSplitPercentage(
			double serviceCommissionSplitPercentage) {
		this.serviceCommissionSplitPercentage = serviceCommissionSplitPercentage;
	}
	public double getFundCommissionSplitPercentage() {
		return fundCommissionSplitPercentage;
	}
	public void setFundCommissionSplitPercentage(
			double fundCommissionSplitPercentage) {
		this.fundCommissionSplitPercentage = fundCommissionSplitPercentage;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public String getUpdateby() {
		return updateby;
	}
	public void setUpdateby(String updateby) {
		this.updateby = updateby;
	}
	public String getCreateTimeStamp() {
		return createTimeStamp;
	}
	public void setCreateTimeStamp(String createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}
	public String getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	public void setUpdateTimeStamp(String updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}     
    
}

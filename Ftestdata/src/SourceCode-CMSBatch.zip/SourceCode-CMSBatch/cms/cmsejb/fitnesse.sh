mvn test-compile dependency:copy-dependencies -DincludeScope=test
cd src/test/resources/fitnesse
java -jar fitnesse-standalone.jar -p 8089 -e 0 &
